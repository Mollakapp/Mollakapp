// ===== Mollak Auth Context =====
import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react";
import { createClient, type Session } from "@supabase/supabase-js";
import { projectId, publicAnonKey } from "/utils/supabase/info";
import { setActiveBuildingId } from "./api";

// ── Replace navigator.locks with a spec-compliant no-op mock ──
// React Strict Mode double-mounts cause gotrue-js's navigatorLock to
// acquire + steal locks, producing "Lock broken" AbortErrors.
// gotrue checks `'locks' in navigator` (property existence), so setting
// to undefined doesn't help. We provide a mock whose request() passes
// a truthy lock object to the callback (gotrue warns if lock is null).
if (typeof globalThis !== "undefined" && globalThis.navigator) {
  try {
    const fakeLock = { name: "mollak-noop", mode: "exclusive" };
    const noOpLocks = {
      request: async (_name: string, ...args: any[]) => {
        // Signature: request(name, callback) or request(name, options, callback)
        const cb = args[args.length - 1];
        if (typeof cb === "function") {
          return await cb(fakeLock); // pass truthy lock to satisfy gotrue's null-check
        }
      },
      query: async () => ({ held: [], pending: [] }),
    };
    Object.defineProperty(globalThis.navigator, "locks", {
      value: noOpLocks,
      writable: true,
      configurable: true,
    });
  } catch {
    // Safari / secure contexts may throw — ignore
  }
}

// Singleton Supabase client — cached on globalThis to survive HMR re-evaluation
const supabaseUrl = `https://${projectId}.supabase.co`;
const SUPABASE_SINGLETON_KEY = "__mollak_supabase__";
export const supabase: ReturnType<typeof createClient> =
  (globalThis as any)[SUPABASE_SINGLETON_KEY] ??
  ((globalThis as any)[SUPABASE_SINGLETON_KEY] = createClient(supabaseUrl, publicAnonKey, {
    auth: {
      storageKey: "mollak-auth-token",
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  }));

export interface ResidentProfile {
  id: string; // auth user id
  email: string;
  name: string;
  phone: string;
  unitCode: string;
  floor: string;
  type: string; // مالك | مستأجر
  buildingId: string;
  buildingName: string;
  role?: string; // "resident" | "رئيس اتحاد" | "أمين صندوق" | "عضو" etc.
  adminRole?: string; // specific admin position
  // Optional extended fields
  gender?: string;
  birthDate?: string;
  bio?: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  nationalId?: string;
  avatarBase64?: string | null;
}

interface AuthContextType {
  session: Session | null;
  profile: ResidentProfile | null;
  loading: boolean;
  banned: boolean;
  loginWithPhone: (phone: string, password: string) => Promise<{ error?: string; profile?: ResidentProfile | null }>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  session: null,
  profile: null,
  loading: true,
  banned: false,
  loginWithPhone: async () => ({}),
  logout: async () => {},
  refreshProfile: async () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}

const BASE = `https://${projectId}.supabase.co/functions/v1/make-server-86a3da15`;

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<ResidentProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [banned, setBanned] = useState(false);

  // Single attempt to call /auth/me
  const _callAuthMe = useCallback(async (token: string) => {
    const res = await fetch(`${BASE}/auth/me`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${publicAnonKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ token }),
    });
    return res;
  }, []);

  // Fetch resident profile — on 401, refresh session once then retry
  const fetchProfile = useCallback(async (accessToken: string): Promise<ResidentProfile | null> => {
    try {
      let res = await _callAuthMe(accessToken);

      // If 401, token might be expired — try refreshing the session
      if (res.status === 401) {
        console.warn("Profile fetch returned 401 — refreshing session...");
        try {
          const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
          if (refreshError || !refreshData.session) {
            console.warn("Session refresh failed — clearing stale session:", refreshError?.message);
            await supabase.auth.signOut();
            setSession(null);
            setProfile(null);
            setActiveBuildingId(null);
            return null;
          }
          // Retry with refreshed token
          setSession(refreshData.session);
          res = await _callAuthMe(refreshData.session.access_token);
        } catch (refreshErr) {
          console.error("Exception during session refresh:", refreshErr);
          await supabase.auth.signOut();
          setSession(null);
          setProfile(null);
          setActiveBuildingId(null);
          return null;
        }
      }

      if (!res.ok) {
        const errorText = await res.text();
        console.error("Failed to fetch profile:", res.status, errorText);
        // Check if banned (403 with banned flag)
        if (res.status === 403) {
          try {
            const errData = JSON.parse(errorText);
            if (errData.banned) {
              console.warn("User is banned — signing out");
              setBanned(true);
              await supabase.auth.signOut();
              setSession(null);
              setProfile(null);
              setActiveBuildingId(null);
              return null;
            }
          } catch { /* not JSON */ }
        }
        // If still 401 after refresh, sign out
        if (res.status === 401) {
          await supabase.auth.signOut();
          setSession(null);
          setActiveBuildingId(null);
        }
        setProfile(null);
        return null;
      }
      const data = await res.json();
      if (data.profile) {
        setProfile(data.profile);
        // ── Set the active building for all subsequent API calls ──
        if (data.profile.buildingId) {
          setActiveBuildingId(data.profile.buildingId);
        }
        return data.profile;
      } else {
        setProfile(null);
        return null;
      }
    } catch (err) {
      console.error("Error fetching profile:", err);
      setProfile(null);
      return null;
    }
  }, [_callAuthMe]);

  // Initialize: check for existing session
  useEffect(() => {
    let mounted = true;
    const initDone = { current: false };

    async function init() {
      if (initDone.current) return;
      initDone.current = true;
      try {
        const { data: { session: existingSession }, error } = await supabase.auth.getSession();
        if (error) {
          // Gracefully handle lock/abort errors from React Strict Mode double-mount
          const msg = error.message || error.name || "";
          if (msg.includes("AbortError") || msg.includes("Lock broken") || msg.includes("steal")) {
            console.warn("Auth getSession aborted (Strict Mode), retrying...");
            await new Promise((r) => setTimeout(r, 200));
            try {
              const retry = await supabase.auth.getSession();
              if (mounted && retry.data.session) {
                setSession(retry.data.session);
                await fetchProfile(retry.data.session.access_token);
              }
            } catch {
              // give up silently — user can refresh
            }
            return;
          }
          console.error("Auth getSession error:", error);
          return;
        }
        if (mounted && existingSession) {
          setSession(existingSession);
          await fetchProfile(existingSession.access_token);
        }
      } catch (err: any) {
        // Handle AbortError / Lock broken thrown as exception
        const msg = err?.message || err?.name || "";
        if (msg.includes("AbortError") || msg.includes("Lock broken") || msg.includes("steal")) {
          console.warn("Auth init lock conflict (Strict Mode) — retrying...");
          await new Promise((r) => setTimeout(r, 200));
          try {
            const retry = await supabase.auth.getSession();
            if (mounted && retry.data.session) {
              setSession(retry.data.session);
              await fetchProfile(retry.data.session.access_token);
            }
          } catch {
            // give up silently
          }
        } else {
          console.error("Auth init error:", err);
        }
      } finally {
        if (mounted) setLoading(false);
      }
    }

    init();

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, newSession) => {
        if (!mounted) return;
        // Skip INITIAL_SESSION — init() already handles it to avoid double-processing
        // which causes visible re-renders / "refresh" on landing & registration pages
        if (event === 'INITIAL_SESSION') return;
        setSession(newSession);
        if (newSession) {
          await fetchProfile(newSession.access_token);
        } else {
          setProfile(null);
          setActiveBuildingId(null);
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [fetchProfile]);

  // Convert phone to fake email for Supabase Auth
  function phoneToEmail(phone: string): string {
    // Normalize: remove spaces and convert Arabic/Eastern Arabic digits to English
    const normalized = phone
      .replace(/[\u0660-\u0669]/g, (c) => String(c.charCodeAt(0) - 0x0660))
      .replace(/[\u06F0-\u06F9]/g, (c) => String(c.charCodeAt(0) - 0x06F0))
      .replace(/\s/g, "");
    return `${normalized}@mollak.app`;
  }

  const loginWithPhone = useCallback(async (phone: string, password: string) => {
    try {
      const fakeEmail = phoneToEmail(phone);
      // Normalized phone (no spaces, English digits)
      const normalizedPhone = fakeEmail.replace("@mollak.app", "");

      // Step 1: Call pre-login to ensure auth user exists (handles failed creation during approval)
      try {
        const preLoginRes = await fetch(`${BASE}/auth/pre-login`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ phone: normalizedPhone }),
        });
        const preLoginData = await preLoginRes.json();
        console.log("Pre-login result:", preLoginData);

        if (!preLoginRes.ok) {
          // Return specific error messages from pre-login
          if (preLoginData.status === "pending") {
            return { error: preLoginData.error || "طلب انضمامك لم تتم الموافقة عليه بعد" };
          }
          if (preLoginData.status === "not_found") {
            return { error: preLoginData.error || "لا يوجد حساب مرتبط بهذا الرقم" };
          }
          if (preLoginData.status === "no_password") {
            return { error: preLoginData.error || "تواصل مع إدارة المبنى لإعادة تعيين حسابك" };
          }
          if (preLoginData.status === "admin_no_auth") {
            return { error: preLoginData.error || "حساب الإدارة غير مكتمل — أعد تسجيل المبنى" };
          }
          if (preLoginData.status === "banned") {
            setBanned(true);
            return { error: preLoginData.error || "تم حظر حسابك — تواصل مع إدارة المبنى" };
          }
          // For other errors, continue to try login anyway
          console.warn("Pre-login warning:", preLoginData.error);
        }
      } catch (preErr) {
        // Pre-login failed — still try to login directly
        console.warn("Pre-login request failed, trying direct login:", preErr);
      }

      // Step 2: Attempt Supabase login
      const { data, error } = await supabase.auth.signInWithPassword({
        email: fakeEmail,
        password,
      });
      if (error) {
        // ── Handle "Invalid login credentials" — do NOT auto-repair/reset password ──
        if (error.message.includes("Invalid login credentials")) {
          return { error: "رقم الجوال أو كلمة المرور غير صحيحة" };
        }

        console.log("Login error:", error.message);
        if (error.message.includes("Email not confirmed")) {
          return { error: "الحساب لم يتم تأكيده بعد — تواصل مع إدارة المبنى" };
        }
        return { error: `خطأ في تسجيل الدخول: ${error.message}` };
      }
      if (data.session) {
        setSession(data.session);
        const fetchedProfile = await fetchProfile(data.session.access_token);
        return { profile: fetchedProfile };
      }
      return {};
    } catch (err: any) {
      console.error("Login exception:", err);
      return { error: "حدث خطأ غير متوقع — حاول مرة أخرى" };
    }
  }, [fetchProfile]);

  const logout = useCallback(async () => {
    await supabase.auth.signOut();
    setSession(null);
    setProfile(null);
    setBanned(false);
    setActiveBuildingId(null);
  }, []);

  const refreshProfile = useCallback(async () => {
    if (session?.access_token) {
      await fetchProfile(session.access_token);
    }
  }, [session, fetchProfile]);

  return (
    <AuthContext.Provider value={{ session, profile, loading, banned, loginWithPhone, logout, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}