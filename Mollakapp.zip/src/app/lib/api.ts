// ===== Mollak API Service Layer =====
import { projectId, publicAnonKey } from '/utils/supabase/info';

const BASE = `https://${projectId}.supabase.co/functions/v1/make-server-86a3da15`;

// ── Active Building ID (set after login from user profile) ──
let _activeBuildingId: string | null = null;

export function setActiveBuildingId(id: string | null): void {
  _activeBuildingId = id;
}

export function getStoredBuildingId(): string | null {
  return _activeBuildingId;
}

const MAX_RETRIES = 2;
const RETRY_DELAY = 1500; // ms

async function request(path: string, options: RequestInit = {}, retriesLeft = MAX_RETRIES): Promise<any> {
  try {
    const res = await fetch(`${BASE}${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${publicAnonKey}`,
        ...(_activeBuildingId ? { 'X-Building-Id': _activeBuildingId } : {}),
        ...(options.headers || {}),
      },
    });
    if (!res.ok) {
      const text = await res.text();
      console.error(`API Error [${res.status}] ${path}: ${text}`);
      // Try to extract a user-friendly error message from JSON response
      let errorMessage = `API Error: ${res.status}`;
      try {
        const parsed = JSON.parse(text);
        if (parsed.error) {
          errorMessage = parsed.error;
        }
      } catch {
        if (text) errorMessage = text;
      }
      throw new Error(errorMessage);
    }
    return res.json();
  } catch (err: any) {
    // Retry on network errors (Failed to fetch = cold start / transient)
    if (retriesLeft > 0 && err instanceof TypeError && err.message.includes('fetch')) {
      console.log(`Retrying ${path} (${MAX_RETRIES - retriesLeft + 1}/${MAX_RETRIES})...`);
      await new Promise((r) => setTimeout(r, RETRY_DELAY));
      return request(path, options, retriesLeft - 1);
    }
    throw err;
  }
}

// Warm up the edge function (fire-and-forget health check)
export async function warmUp(): Promise<void> {
  try {
    await fetch(`${BASE}/health`, {
      headers: { Authorization: `Bearer ${publicAnonKey}` },
    });
  } catch {
    // ignore — just waking up the function
  }
}

// ===== Phone Check =====
export async function checkPhoneExists(phone: string): Promise<boolean> {
  try {
    const data = await request('/auth/check-phone', {
      method: 'POST',
      body: JSON.stringify({ phone }),
    });
    return !!data?.exists;
  } catch {
    return false; // fail open — don't block registration on network error
  }
}

// ===== Building Units =====
export interface Unit {
  id: string;
  label: string;
  unitCode: string;
  floor: string;
  floorLabel: string;
  unitType?: "سكني" | "تجاري";
  occupied: boolean;
  resident?: string;
  ownerName: string;
}

export async function getUnits(): Promise<Unit[]> {
  return request('/building/units');
}

export async function updateFloorUnits(floorNum: string, data: {
  label?: string;
  unitType?: "سكني" | "تجاري";
  unitCount?: number;
}): Promise<{ message: string; units: Unit[]; floorUnits: Unit[]; occupiedProtected: number }> {
  return request(`/building/units/floor/${encodeURIComponent(floorNum)}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function seedBuilding(): Promise<{ message: string }> {
  return request('/building/seed', { method: 'POST' });
}

// ===== Building Registration =====
export interface FloorConfig {
  label: string;
  unitCount: number;
  unitType: "سكني" | "تجاري";
}

export interface BuildingInfo {
  id: string;
  name: string;
  address: string;
  city: string;
  floors: number;
  unitsPerFloor: number[];
  floorConfigs?: FloorConfig[];
  totalUnits: number;
  slug: string;
  admin: {
    name: string;
    phone: string;
    email: string;
    role: string;
    password?: string;
    unitCode?: string;
  };
  initialBalance: number;
  previousDebts: number;
  previousRevenues: number;
  createdAt: string;
  updatedAt: string;
}

export interface BuildingResponse {
  exists: boolean;
  building?: BuildingInfo;
}

export async function getBuilding(): Promise<BuildingResponse> {
  return request('/building');
}

export async function getBuildingsList(): Promise<{ buildings: { id: string; name: string; slug: string; createdAt: string }[]; activeId: string | null }> {
  return request('/buildings');
}

export async function registerBuilding(data: {
  name: string;
  address?: string;
  city?: string;
  floors: number;
  defaultUnitsPerFloor?: number;
  unitsPerFloor?: number[];
  floorConfigs?: FloorConfig[];
  initialBalance?: number;
  previousDebts?: number;
  previousRevenues?: number;
  admin: {
    name: string;
    phone: string;
    email: string;
    role: string;
    password?: string;
    unitCode?: string;
  };
}): Promise<{ message: string; building: BuildingInfo; unitsCount: number }> {
  return request('/building', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateBuilding(data: {
  name?: string;
  address?: string;
  city?: string;
  floors?: number;
  defaultUnitsPerFloor?: number;
  unitsPerFloor?: number[];
  floorConfigs?: FloorConfig[];
  initialBalance?: number;
  previousDebts?: number;
  previousRevenues?: number;
  admin?: {
    name: string;
    phone: string;
    email: string;
    role: string;
    unitCode?: string;
  };
}): Promise<{ message: string; building: BuildingInfo }> {
  return request('/building', { method: 'PUT', body: JSON.stringify(data) });
}

// ===== Invoice Batches =====
export interface Invoice {
  id: string;
  resident: string;
  unit: string;
  floor: string;
  amount: number;
  status: 'paid' | 'pending' | 'overdue' | 'awaiting_collection';
  method: string;
  occupied: boolean;
  paidDate?: string;
}

export interface InvoiceBatch {
  id: string;
  description: string;
  scope: 'عام' | 'مخصص';
  type?: 'دائم' | 'مؤقت';
  date: string;
  dueDate: string;
  stoppedAt?: string;
  createdAt?: string;
  invoices: Invoice[];
}

export async function getInvoiceBatches(): Promise<InvoiceBatch[]> {
  return request('/invoices');
}

export async function processRecurringInvoices(): Promise<{ message: string; monthKey: string; created: number; invoices: number; autoPaid: number }> {
  return request('/invoices/process-recurring', { method: 'POST' });
}

export async function createInvoiceBatch(batch: InvoiceBatch): Promise<{ message: string }> {
  return request('/invoices', {
    method: 'POST',
    body: JSON.stringify(batch),
  });
}

export async function updateInvoiceBatch(batchId: string, batch: InvoiceBatch): Promise<{ message: string }> {
  return request(`/invoices/${encodeURIComponent(batchId)}`, {
    method: 'PUT',
    body: JSON.stringify(batch),
  });
}

export async function deleteInvoiceBatch(batchId: string): Promise<{ message: string }> {
  return request(`/invoices/${encodeURIComponent(batchId)}`, {
    method: 'DELETE',
  });
}

export async function stopInvoiceBatch(batchId: string): Promise<{ message: string; batch: InvoiceBatch }> {
  return request(`/invoices/${encodeURIComponent(batchId)}/stop`, { method: 'PUT' });
}

export async function reactivateInvoiceBatch(batchId: string): Promise<{ message: string; batch: InvoiceBatch }> {
  return request(`/invoices/${encodeURIComponent(batchId)}/reactivate`, { method: 'PUT' });
}

export async function markInvoicePaid(
  batchId: string,
  invoiceId: string,
  method: string = 'كاش'
): Promise<{ message: string }> {
  return request(`/invoices/${encodeURIComponent(batchId)}/pay/${encodeURIComponent(invoiceId)}`, {
    method: 'PUT',
    body: JSON.stringify({ method }),
  });
}

// ===== Cash Payment Flow =====
export interface CashCollection {
  id: string;
  batchId: string;
  invoiceId: string;
  batchDescription: string;
  residentName: string;
  unitCode: string;
  amount: number;
  date: string;
  status: 'pending' | 'collected';
}

export async function requestCashPayment(
  batchId: string,
  invoiceId: string,
  residentName: string,
  unitCode: string,
  amount: number
): Promise<{ message: string }> {
  return request('/resident/pay-cash', {
    method: 'POST',
    body: JSON.stringify({ batchId, invoiceId, residentName, unitCode, amount }),
  });
}

export async function getCashCollections(): Promise<CashCollection[]> {
  return request('/invoices/cash-collections');
}

// Treasurer confirms collection = marks invoice as paid
export async function confirmCashCollection(
  batchId: string,
  invoiceId: string
): Promise<{ message: string }> {
  return markInvoicePaid(batchId, invoiceId, 'كاش عبر الأمن');
}

// ===== Resident Invoices =====
export interface ResidentInvoice {
  id: string;
  batchId: string;
  description: string;
  amount: number;
  status: 'paid' | 'pending' | 'overdue' | 'awaiting_collection';
  dueDate: string;
  paidDate?: string;
  category: string;
  method?: string;
  type?: 'دائم' | 'مؤقت';
}

export async function getResidentInvoices(unitCode: string): Promise<ResidentInvoice[]> {
  return request(`/resident/invoices?unit=${encodeURIComponent(unitCode)}`);
}

// ===== Activity Log =====
export interface ActivityEntry {
  id: string;
  type: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

export async function getActivityLog(limit: number = 20): Promise<ActivityEntry[]> {
  return request(`/activity-log?limit=${limit}`);
}

// ===== Overview Stats =====
export interface OverviewStats {
  revenue: number;
  internalRevenue: number;
  externalRevenue: number;
  expenses: number;
  balance: number;
  initialBalance: number;
  previousDebts: number;
  previousRevenues: number;
  pendingCount: number;
  pendingAmount: number;
  totalInvoices: number;
  paidCount: number;
  overdueCount: number;
  awaitingCount: number;
  residentsCount: number;
  occupiedUnits: number;
  totalUnits: number;
}

export async function getOverviewStats(period: {
  type: string;
  year: number;
  month: number;
  quarter: number;
}): Promise<OverviewStats> {
  const params = new URLSearchParams({
    period: period.type,
    year: `${period.year}`,
    month: `${period.month + 1}`,
    quarter: `${period.quarter}`,
  });
  return request(`/overview-stats?${params}`);
}

// ===== Buildings Management =====
export interface BuildingSummary {
  id: string;
  name: string;
  slug: string;
  createdAt: string;
}

export async function listBuildings(): Promise<{ buildings: BuildingSummary[]; activeId: string | null }> {
  return request('/buildings');
}

export async function switchBuilding(buildingId: string): Promise<{ message: string; building: BuildingInfo }> {
  return request('/buildings/switch', { method: 'PUT', body: JSON.stringify({ buildingId }) });
}

export async function deleteBuilding(buildingId: string): Promise<{ message: string }> {
  return request(`/buildings/${encodeURIComponent(buildingId)}`, { method: 'DELETE' });
}

// ===== Join Requests =====
export interface JoinBuildingData {
  found: boolean;
  building?: {
    id: string;
    name: string;
    address: string;
    city: string;
    floors: number;
    totalUnits: number;
    admin: { name: string; role: string };
    approvedCount: number;
  };
  units?: { id: string; unitCode: string; floor: string; floorLabel?: string; label: string; unitType?: string; occupied: boolean }[];
}

export async function getBuildingBySlug(slug: string): Promise<JoinBuildingData> {
  return request(`/building/by-slug/${encodeURIComponent(slug)}`);
}

export interface JoinRequest {
  id: string;
  buildingId: string;
  title?: string;
  name: string;
  phone: string;
  unitCode: string;
  floor: string;
  type: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt: string;
}

export async function submitJoinRequest(data: {
  buildingId: string;
  title?: string;
  name: string;
  phone: string;
  password: string;
  unitCode: string;
  floor: string;
  type: string;
}): Promise<{ message: string; request: JoinRequest }> {
  return request('/join-requests', { method: 'POST', body: JSON.stringify(data) });
}

export async function getJoinRequests(): Promise<JoinRequest[]> {
  return request('/join-requests');
}

export async function respondToJoinRequest(
  requestId: string,
  action: 'approve' | 'reject'
): Promise<{ message: string; request: JoinRequest }> {
  return request(`/join-requests/${encodeURIComponent(requestId)}`, {
    method: 'PUT',
    body: JSON.stringify({ action }),
  });
}

// ===== Residents =====
export interface Resident {
  id: string;
  title?: string;
  name: string;
  phone: string;
  unitCode: string;
  floor: string;
  type: string;
  joinedAt: string;
  banned: boolean;
  debt: number;
  role: 'resident' | 'treasurer' | 'board_member';
  creditBalance: number;
  previousDebt: number;
  lastLogin: string | null;
}

export async function getResidents(): Promise<Resident[]> {
  return request('/residents');
}

// Public resident info (for resident portal — no financial data)
export interface PublicResident {
  id: string;
  title?: string;
  name: string;
  phone: string;
  unitCode: string;
  floor: string;
  type: string;
  bio?: string;
  avatarBase64?: string;
}

export async function getResidentsPublic(): Promise<PublicResident[]> {
  return request('/resident/residents-public');
}

export async function toggleResidentBan(requestId: string): Promise<{ message: string }> {
  return request(`/residents/${encodeURIComponent(requestId)}/ban`, { method: 'PUT' });
}

export async function updateResidentRole(requestId: string, role: string): Promise<{ message: string }> {
  return request(`/residents/${encodeURIComponent(requestId)}/role`, {
    method: 'PUT',
    body: JSON.stringify({ role }),
  });
}

export async function deleteResident(requestId: string): Promise<{ message: string }> {
  return request(`/residents/${encodeURIComponent(requestId)}`, { method: 'DELETE' });
}

export async function editResident(
  requestId: string,
  data: { name?: string; unitCode?: string; floor?: string; type?: string }
): Promise<{ message: string; resident: any }> {
  return request(`/residents/${encodeURIComponent(requestId)}/edit`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

// ===== Resident Credit Balance =====
export async function updateResidentCredit(
  requestId: string,
  amount: number,
  note: string = ''
): Promise<{ message: string; creditBalance: number }> {
  return request(`/residents/${encodeURIComponent(requestId)}/credit`, {
    method: 'PUT',
    body: JSON.stringify({ amount, note }),
  });
}

// ===== Resident Previous Debt =====
export async function updateResidentPreviousDebt(
  requestId: string,
  amount: number,
  note: string = ''
): Promise<{ message: string; previousDebt: number }> {
  return request(`/residents/${encodeURIComponent(requestId)}/previous-debt`, {
    method: 'PUT',
    body: JSON.stringify({ amount, note }),
  });
}

// ===== Resident Credit History =====
export interface CreditTransaction {
  id: string;
  residentId: string;
  residentName: string;
  unitCode: string;
  amount: number;
  balanceAfter: number;
  note: string;
  createdAt: string;
}

export async function getResidentCreditHistory(requestId: string): Promise<CreditTransaction[]> {
  return request(`/residents/${encodeURIComponent(requestId)}/credit-history`);
}

// ===== Advances =====
export interface Advance {
  id: string;
  person: string;
  amount: number;
  reason: string;
  date: string;
  dueDate: string;
  status: 'active' | 'returned' | 'overdue';
  approvedBy: string;
  createdAt?: string;
}

export async function getAdvances(): Promise<Advance[]> {
  return request('/advances');
}

export async function createAdvance(data: Omit<Advance, 'id' | 'status' | 'createdAt'>): Promise<{ message: string; advance: Advance }> {
  return request('/advances', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateAdvance(advanceId: string, data: Partial<Advance>): Promise<{ message: string; advance: Advance }> {
  return request(`/advances/${encodeURIComponent(advanceId)}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteAdvance(advanceId: string): Promise<{ message: string }> {
  return request(`/advances/${encodeURIComponent(advanceId)}`, { method: 'DELETE' });
}

export async function getResidentAdvances(): Promise<Advance[]> {
  return request('/resident/advances');
}

// ===== Expenses =====
export interface Expense {
  id: string;
  title: string;
  unitPrice: number;
  quantity: number;
  amount: number;
  category: string;
  type: 'دائم' | 'مؤقت';
  date: string;
  endDate?: string;
  stoppedAt?: string;
  image?: string;
  createdAt?: string;
}

export async function getExpenses(): Promise<Expense[]> {
  return request('/expenses');
}

export async function createExpense(data: Omit<Expense, 'id' | 'amount' | 'createdAt'>): Promise<{ message: string; expense: Expense }> {
  return request('/expenses', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateExpense(expenseId: string, data: Partial<Expense>): Promise<{ message: string; expense: Expense }> {
  return request(`/expenses/${encodeURIComponent(expenseId)}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteExpense(expenseId: string): Promise<{ message: string }> {
  return request(`/expenses/${encodeURIComponent(expenseId)}`, { method: 'DELETE' });
}

export async function stopExpense(expenseId: string): Promise<{ message: string; expense: Expense }> {
  return request(`/expenses/${encodeURIComponent(expenseId)}/stop`, { method: 'PUT' });
}

export async function reactivateExpense(expenseId: string): Promise<{ message: string; expense: Expense }> {
  return request(`/expenses/${encodeURIComponent(expenseId)}/reactivate`, { method: 'PUT' });
}

// ===== Revenues =====
export interface Revenue {
  id: string;
  title: string;
  amount: number;
  category: string;
  type: 'دائم' | 'مؤقت';
  date: string;
  stoppedAt?: string;
  createdAt?: string;
}

export async function getRevenues(): Promise<Revenue[]> {
  return request('/revenues');
}

export async function createRevenue(data: Omit<Revenue, 'id' | 'createdAt'>): Promise<{ message: string; revenue: Revenue }> {
  return request('/revenues', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateRevenue(revenueId: string, data: Partial<Revenue>): Promise<{ message: string; revenue: Revenue }> {
  return request(`/revenues/${encodeURIComponent(revenueId)}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteRevenue(revenueId: string): Promise<{ message: string }> {
  return request(`/revenues/${encodeURIComponent(revenueId)}`, { method: 'DELETE' });
}

export async function stopRevenue(revenueId: string): Promise<{ message: string; revenue: Revenue }> {
  return request(`/revenues/${encodeURIComponent(revenueId)}/stop`, { method: 'PUT' });
}

export async function reactivateRevenue(revenueId: string): Promise<{ message: string; revenue: Revenue }> {
  return request(`/revenues/${encodeURIComponent(revenueId)}/reactivate`, { method: 'PUT' });
}

// ===== Announcements =====
export interface Announcement {
  id: string;
  title: string;
  description: string;
  category: string;
  date: string;
  timeFrom: string;
  timeTo: string;
  urgent: boolean;
  author: string;
  createdAt?: string;
}

export async function getAnnouncements(): Promise<Announcement[]> {
  return request('/announcements');
}

export async function createAnnouncement(data: Omit<Announcement, 'id' | 'createdAt'>): Promise<{ message: string; announcement: Announcement }> {
  return request('/announcements', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateAnnouncement(annId: string, data: Partial<Announcement>): Promise<{ message: string; announcement: Announcement }> {
  return request(`/announcements/${encodeURIComponent(annId)}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteAnnouncement(annId: string): Promise<{ message: string }> {
  return request(`/announcements/${encodeURIComponent(annId)}`, { method: 'DELETE' });
}

// ===== Directory (Contacts) =====
export interface DirectoryContact {
  id: string;
  name: string;
  specialty: string;
  phone: string;
  area: string;
  createdAt?: string;
}

export async function getDirectory(): Promise<DirectoryContact[]> {
  return request('/directory');
}

export async function createDirectoryContact(data: Omit<DirectoryContact, 'id' | 'createdAt'>): Promise<{ message: string; contact: DirectoryContact }> {
  return request('/directory', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateDirectoryContact(contactId: string, data: Partial<DirectoryContact>): Promise<{ message: string; contact: DirectoryContact }> {
  return request(`/directory/${encodeURIComponent(contactId)}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteDirectoryContact(contactId: string): Promise<{ message: string }> {
  return request(`/directory/${encodeURIComponent(contactId)}`, { method: 'DELETE' });
}

// ===== Events (المناسبات) =====
export interface EventComment {
  id: string;
  name: string;
  unit: string;
  text: string;
  createdAt: string;
}

export interface MollakEvent {
  id: string;
  type: 'congratulation' | 'condolence';
  title: string;
  resident: string;
  unit: string;
  message: string;
  date: string;
  reactions: number;
  comments: EventComment[];
  createdAt?: string;
}

export async function getEvents(): Promise<MollakEvent[]> {
  return request('/events');
}

export async function createEvent(data: Omit<MollakEvent, 'id' | 'reactions' | 'comments' | 'createdAt'>): Promise<{ message: string; event: MollakEvent }> {
  return request('/events', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateEvent(eventId: string, data: Partial<MollakEvent>): Promise<{ message: string; event: MollakEvent }> {
  return request(`/events/${encodeURIComponent(eventId)}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteEvent(eventId: string): Promise<{ message: string }> {
  return request(`/events/${encodeURIComponent(eventId)}`, { method: 'DELETE' });
}

export async function reactToEvent(eventId: string): Promise<{ message: string; reactions: number }> {
  return request(`/events/${encodeURIComponent(eventId)}/react`, { method: 'PUT' });
}

export async function addEventComment(eventId: string, data: { name: string; unit: string; text: string }): Promise<{ message: string; comment: EventComment; comments: EventComment[] }> {
  return request(`/events/${encodeURIComponent(eventId)}/comments`, { method: 'POST', body: JSON.stringify(data) });
}

export async function deleteEventComment(eventId: string, commentId: string): Promise<{ message: string; comments: EventComment[] }> {
  return request(`/events/${encodeURIComponent(eventId)}/comments/${encodeURIComponent(commentId)}`, { method: 'DELETE' });
}

// ===== Donations (التبرعات) =====
export interface Donor {
  name: string;
  amount: number;
  date: string;
  anonymous?: boolean;
}

export interface DonationCampaign {
  id: string;
  title: string;
  description: string;
  target: number;
  collected: number;
  donors: Donor[];
  status: 'active' | 'completed';
  deadline: string;
  createdBy: string;
  createdAt?: string;
}

export async function getDonations(): Promise<DonationCampaign[]> {
  return request('/donations');
}

export async function createDonation(data: { title: string; description: string; target: number; deadline: string; createdBy?: string }): Promise<{ message: string; campaign: DonationCampaign }> {
  return request('/donations', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateDonation(id: string, data: Partial<DonationCampaign>): Promise<{ message: string; campaign: DonationCampaign }> {
  return request(`/donations/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteDonation(id: string): Promise<{ message: string }> {
  return request(`/donations/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

export async function addDonation(campaignId: string, data: { name: string; amount: number; anonymous?: boolean }): Promise<{ message: string; campaign: DonationCampaign }> {
  return request(`/donations/${encodeURIComponent(campaignId)}/donate`, { method: 'POST', body: JSON.stringify(data) });
}

export async function toggleDonationStatus(id: string): Promise<{ message: string; campaign: DonationCampaign }> {
  return request(`/donations/${encodeURIComponent(id)}/toggle-status`, { method: 'PUT' });
}

// ===== Donation Cash Requests =====
export interface DonationCashRequest {
  id: string;
  campaignId: string;
  campaignTitle: string;
  residentName: string;
  unitCode: string;
  phone: string;
  amount: number;
  date: string;
  status: 'pending' | 'collected' | 'cancelled';
  anonymous?: boolean;
}

export async function requestDonationCash(campaignId: string, data: {
  residentName: string;
  unitCode: string;
  phone: string;
  amount: number;
  anonymous?: boolean;
}): Promise<{ message: string; request: DonationCashRequest }> {
  return request(`/donations/${encodeURIComponent(campaignId)}/request-cash`, { method: 'POST', body: JSON.stringify(data) });
}

export async function getDonationCashRequests(): Promise<DonationCashRequest[]> {
  return request('/donations/cash-requests');
}

export async function confirmDonationCash(campaignId: string, requestId: string): Promise<{ message: string; campaign: DonationCampaign }> {
  return request(`/donations/${encodeURIComponent(campaignId)}/confirm-cash/${encodeURIComponent(requestId)}`, { method: 'PUT' });
}

export async function cancelDonationCash(requestId: string): Promise<{ message: string }> {
  return request(`/donations/cancel-cash/${encodeURIComponent(requestId)}`, { method: 'PUT' });
}

// ===== Notifications (الإشعارات) =====
export interface AppNotification {
  id: string;
  type: string;
  title: string;
  body: string;
  icon: string;
  color: string;
  read: boolean;
  timestamp: string;
  metadata?: Record<string, any>;
}

export async function getNotifications(phone: string): Promise<AppNotification[]> {
  return request(`/notifications?phone=${encodeURIComponent(phone)}`);
}

export async function markNotificationRead(id: string, phone: string): Promise<{ message: string }> {
  return request(`/notifications/${encodeURIComponent(id)}/read`, { method: 'PUT', body: JSON.stringify({ phone }) });
}

export async function markAllNotificationsRead(phone: string): Promise<{ message: string }> {
  return request('/notifications/read-all', { method: 'PUT', body: JSON.stringify({ phone }) });
}

// ===== Profile Update =====
export interface ProfileUpdateData {
  token: string;
  name?: string;
  phone?: string;
  gender?: string;
  birthDate?: string;
  bio?: string;
  emergencyContact?: string;
  emergencyPhone?: string;
  nationalId?: string;
  avatarBase64?: string | null;
  unitCode?: string;
  floor?: string;
  type?: string;
}

export async function updateProfile(data: ProfileUpdateData): Promise<{ profile: any; message: string }> {
  return request('/auth/profile', { method: 'PUT', body: JSON.stringify(data) });
}

// ===== Polls / Voting (التصويت) =====
export interface PollOption {
  label: string;
  votes: number;
  voters: string[];
}

export interface Poll {
  id: string;
  title: string;
  description: string;
  options: PollOption[];
  status: 'active' | 'ended';
  deadline: string;
  createdBy: string;
  createdAt?: string;
}

export async function getPolls(): Promise<Poll[]> {
  return request('/polls');
}

export async function createPoll(data: { title: string; description: string; options: string[]; deadline: string; createdBy?: string }): Promise<{ message: string; poll: Poll }> {
  return request('/polls', { method: 'POST', body: JSON.stringify(data) });
}

export async function votePoll(pollId: string, data: { optionIndex: number; voterName: string }): Promise<{ message: string; poll: Poll }> {
  return request(`/polls/${encodeURIComponent(pollId)}/vote`, { method: 'POST', body: JSON.stringify(data) });
}

export async function endPoll(pollId: string): Promise<{ message: string; poll: Poll }> {
  return request(`/polls/${encodeURIComponent(pollId)}/end`, { method: 'PUT' });
}

export async function reactivatePoll(pollId: string): Promise<{ message: string; poll: Poll }> {
  return request(`/polls/${encodeURIComponent(pollId)}/reactivate`, { method: 'PUT' });
}

export async function deletePoll(pollId: string): Promise<{ message: string }> {
  return request(`/polls/${encodeURIComponent(pollId)}`, { method: 'DELETE' });
}

// ===== Chat Messages =====
export interface ChatMsg {
  id: string;
  sender: string;
  senderRole: string;
  senderPhone: string;
  text: string;
  timestamp: string;
}

export async function getChatMessages(): Promise<ChatMsg[]> {
  return request('/chat');
}

export async function sendChatMessage(data: {
  sender: string;
  senderRole: string;
  senderPhone: string;
  text: string;
}): Promise<{ message: string; msg: ChatMsg }> {
  return request('/chat', { method: 'POST', body: JSON.stringify(data) });
}

// ===== Direct Messages (DM) =====
export interface DMConversation {
  phone: string;
  name: string;
  unitCode: string;
  lastMessage: string;
  lastTimestamp: string;
  unread: number;
}

export async function getDMMessages(targetPhone: string, myPhone: string): Promise<ChatMsg[]> {
  return request(`/dm/${encodeURIComponent(targetPhone)}?myPhone=${encodeURIComponent(myPhone)}`);
}

export async function sendDMMessage(targetPhone: string, data: {
  sender: string;
  senderRole: string;
  senderPhone: string;
  text: string;
}): Promise<{ message: string; msg: ChatMsg }> {
  return request(`/dm/${encodeURIComponent(targetPhone)}`, { method: 'POST', body: JSON.stringify(data) });
}

export async function getDMList(myPhone: string): Promise<DMConversation[]> {
  return request(`/dm-list?myPhone=${encodeURIComponent(myPhone)}`);
}

// ===== Password Reset (Admin) =====
export async function resetUserPassword(phone: string, newPassword: string): Promise<{ message: string }> {
  return request('/auth/reset-password', {
    method: 'POST',
    body: JSON.stringify({ phone, newPassword }),
  });
}

// ===== Service Requests (طلبات الخدمة) =====
export interface ServiceRequest {
  id: string;
  requesterPhone: string;
  requesterName: string;
  unitCode: string;
  title: string;
  description: string;
  category: string;
  status: "pending" | "approved" | "rejected" | "closed";
  adminNote?: string;
  closingNote?: string;
  createdAt: string;
  updatedAt: string;
  respondedBy?: string;
  closedBy?: string;
}

export async function getServiceRequests(phone?: string): Promise<ServiceRequest[]> {
  const q = phone ? `?phone=${encodeURIComponent(phone)}` : "";
  return request(`/service-requests${q}`);
}

export async function createServiceRequest(data: {
  requesterPhone: string;
  requesterName: string;
  unitCode: string;
  title: string;
  description?: string;
  category: string;
}): Promise<{ message: string; request: ServiceRequest }> {
  return request('/service-requests', { method: 'POST', body: JSON.stringify(data) });
}

export async function updateServiceRequest(id: string, data: {
  status: string;
  adminNote?: string;
  closingNote?: string;
  respondedBy?: string;
  closedBy?: string;
}): Promise<{ message: string; request: ServiceRequest }> {
  return request(`/service-requests/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(data) });
}

export async function deleteServiceRequest(id: string, phone: string): Promise<{ message: string }> {
  return request(`/service-requests/${encodeURIComponent(id)}?phone=${encodeURIComponent(phone)}`, { method: 'DELETE' });
}

// ===== Subscription (الاشتراك) =====
export interface Subscription {
  plan: "trial" | "monthly" | "semi_annual" | "annual";
  status: "active" | "expired" | "cancelled";
  startDate: string;
  endDate: string;
  trialStartDate: string;
  trialEndDate: string;
  amount: number;
  remainingDays: number;
  history: { plan: string; startDate: string; endDate: string; amount: number }[];
  plans: {
    monthly: { label: string; months: number; price: number; discount: number };
    semi_annual: { label: string; months: number; price: number; discount: number };
    annual: { label: string; months: number; price: number; discount: number };
  };
}

export async function getSubscription(): Promise<Subscription> {
  return request('/subscription');
}

export async function activateSubscription(plan: string): Promise<{ message: string; subscription: Subscription }> {
  return request('/subscription', { method: 'POST', body: JSON.stringify({ plan }) });
}

// ===== Reports (التقارير) =====
export interface ReportIndex {
  id: string;
  year: number;
  month: number;
  monthName: string;
  generatedAt: string;
  sentToResidents: boolean;
  sentAt?: string;
}

export interface UnitReport {
  unitCode: string;
  floor: string;
  residentName: string;
  invoices: { description: string; amount: number; status: string; dueDate: string; paidDate?: string; method?: string }[];
  totalDue: number;
  totalPaid: number;
  totalPending: number;
  totalOverdue: number;
  paidCount: number;
  pendingCount: number;
  overdueCount: number;
  donations: number;
}

export interface BuildingReport {
  name: string;
  address: string;
  city: string;
  totalUnits: number;
  occupiedUnits: number;
  totalRevenue: number;
  invoiceRevenue: number;
  otherRevenue: number;
  totalExpenses: number;
  netBalance: number;
  initialBalance: number;
  previousDebts: number;
  previousRevenues: number;
  totalDonations: number;
  collectionRate: number;
  totalInvoices: number;
  paidCount: number;
  pendingCount: number;
  overdueCount: number;
  totalPending: number;
  activeAdvances: number;
  activeAdvancesCount: number;
  returnedAdvances: number;
  expensesByCategory: Record<string, number>;
  revenuesByCategory: Record<string, number>;
  expensesList: { title: string; amount: number; category: string; date: string; type: string }[];
  revenuesList: { title: string; amount: number; category: string; date: string; type: string }[];
  advancesList: { person: string; amount: number; reason: string; status: string; dueDate: string }[];
  delinquentUnits: { unitCode: string; residentName: string; amount: number; overdueCount: number }[];
  comparison: { revenueDiff: number; expensesDiff: number; collectionRateDiff: number; hasPrev: boolean };
}

export interface FullReport {
  id: string;
  year: number;
  month: number;
  monthName: string;
  generatedAt: string;
  sentToResidents: boolean;
  sentAt?: string;
  building: BuildingReport;
  unitReports: UnitReport[];
}

export async function getReportsIndex(): Promise<ReportIndex[]> {
  const data = await request('/reports');
  return data.reports || [];
}

export async function generateReport(year: number, month: number): Promise<{ report: FullReport; cached: boolean }> {
  return request('/reports/generate', { method: 'POST', body: JSON.stringify({ year, month }) });
}

export async function regenerateReport(year: number, month: number): Promise<{ report: FullReport }> {
  return request('/reports/regenerate', { method: 'PUT', body: JSON.stringify({ year, month }) });
}

export async function getReport(id: string): Promise<{ report: FullReport }> {
  return request(`/reports/${encodeURIComponent(id)}`);
}

export async function sendReportToResidents(id: string): Promise<{ message: string; report: FullReport }> {
  return request(`/reports/${encodeURIComponent(id)}/send`, { method: 'PUT' });
}