/**
 * Converts Arabic-Indic (٠١٢٣٤٥٦٧٨٩) and Eastern Arabic (۰۱۲۳۴۵۶۷۸۹)
 * numerals to Western/English digits, then strips any non-digit character.
 */
export function normalizeToEnglishDigits(value: string): string {
  return value
    // Arabic-Indic numerals ٠-٩
    .replace(/[\u0660-\u0669]/g, (c) => String(c.charCodeAt(0) - 0x0660))
    // Eastern Arabic-Indic numerals ۰-۹
    .replace(/[\u06F0-\u06F9]/g, (c) => String(c.charCodeAt(0) - 0x06F0))
    // Remove anything that isn't a digit
    .replace(/[^0-9]/g, "");
}
