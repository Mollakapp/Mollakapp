/** الألقاب المتاحة في مُلاك */
export const TITLES = [
  { value: "", label: "بدون لقب" },
  { value: "الأستاذ", label: "الأستاذ" },
  { value: "الأستاذة", label: "الأستاذة" },
  { value: "المهندس", label: "المهندس" },
  { value: "المهندسة", label: "المهندسة" },
  { value: "الدكتور", label: "الدكتور" },
  { value: "الدكتورة", label: "الدكتورة" },
  { value: "الحاج", label: "الحاج" },
  { value: "الحاجة", label: "الحاجة" },
  { value: "الشيخ", label: "الشيخ" },
  { value: "مدام", label: "مدام" },
  { value: "آنسة", label: "آنسة" },
] as const;

/** قائمة قيم الألقاب للبحث السريع */
const TITLE_VALUES = new Set(TITLES.map((t) => t.value).filter(Boolean));

/** دمج اللقب مع الاسم */
export function displayName(title: string | undefined | null, name: string): string {
  if (title && title.trim()) {
    return `${title} ${name}`;
  }
  return name;
}

/**
 * استخراج الاسم الأول الحقيقي — يتخطى اللقب إذا كان في بداية الاسم.
 * مثال: "المهندس محمد أحمد" → "محمد"
 *        "أحمد علي"         → "أحمد"
 */
export function getFirstName(fullName: string | undefined | null, fallback = "ساكن"): string {
  if (!fullName?.trim()) return fallback;
  const parts = fullName.trim().split(/\s+/);
  // تخطى اللقب إذا كان الكلمة الأولى لقباً معروفاً
  const start = TITLE_VALUES.has(parts[0]) ? 1 : 0;
  return parts[start] || fallback;
}