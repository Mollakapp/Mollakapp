import { Suspense, useEffect } from "react";
import { Outlet } from "react-router";
import { Loader2 } from "lucide-react";
import { AuthProvider } from "../lib/auth";
import { PwaInstallBanner } from "./PwaInstallBanner";

function PageLoader() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-[#f8fffe]">
      <div className="text-center">
        <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin mx-auto mb-3" />
        <p className="text-sm text-[#5f6b7a]">جاري التحميل...</p>
      </div>
    </div>
  );
}

export function RootLayout() {
  // Inject PWA meta tags dynamically (standalone mode = no URL bar)
  useEffect(() => {
    const head = document.head;

    const ensureMeta = (name: string, content: string, attr = "name") => {
      let el = head.querySelector(`meta[${attr}="${name}"]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, name);
        head.appendChild(el);
      }
      el.content = content;
    };

    // Web App Manifest
    if (!head.querySelector('link[rel="manifest"]')) {
      const link = document.createElement("link");
      link.rel = "manifest";
      link.href = "/manifest.json";
      head.appendChild(link);
    }

    // Theme color
    ensureMeta("theme-color", "#0D9488");

    // iOS standalone mode
    ensureMeta("apple-mobile-web-app-capable", "yes");
    ensureMeta("apple-mobile-web-app-status-bar-style", "black-translucent");
    ensureMeta("apple-mobile-web-app-title", "مُلاك");

    // Android Chrome
    ensureMeta("mobile-web-app-capable", "yes");

    // Viewport (ensure it exists with proper settings)
    let viewport = head.querySelector('meta[name="viewport"]') as HTMLMetaElement | null;
    if (viewport) {
      viewport.content = "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover";
    } else {
      ensureMeta("viewport", "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover");
    }

    // Apple touch icon
    if (!head.querySelector('link[rel="apple-touch-icon"]')) {
      const link = document.createElement("link");
      link.rel = "apple-touch-icon";
      link.href = "/apple-touch-icon.svg";
      head.appendChild(link);
    }

    // Favicon
    if (!head.querySelector('link[rel="icon"][type="image/svg+xml"]')) {
      const link = document.createElement("link");
      link.rel = "icon";
      link.type = "image/svg+xml";
      link.href = "/icon.svg";
      head.appendChild(link);
    }

    // Generate PNG icons via canvas for broader compatibility
    generatePngIcons();
  }, []);

  return (
    <AuthProvider>
      <Suspense fallback={<PageLoader />}>
        <Outlet />
      </Suspense>
      <PwaInstallBanner />
    </AuthProvider>
  );
}

function generatePngIcons() {
  const sizes = [16, 32, 192, 512];
  const svg = document.querySelector('link[rel="icon"][type="image/svg+xml"]') as HTMLLinkElement;
  if (!svg) return;

  const img = new Image();
  img.src = svg.href;
  img.onload = () => {
    sizes.forEach(size => {
      const canvas = document.createElement("canvas");
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(img, 0, 0, size, size);
        const link = document.createElement("link");
        link.rel = "icon";
        link.type = "image/png";
        link.href = canvas.toDataURL("image/png");
        link.sizes = `${size}x${size}`;
        document.head.appendChild(link);
      }
    });
  };
}