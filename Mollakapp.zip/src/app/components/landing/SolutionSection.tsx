import { Wallet, Eye, Megaphone, Receipt, Calculator, TrendingUp, FileText, CreditCard, Bell, CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";

const solutions = [
  {
    title: "تنظيم المصروفات والتحصيل",
    icon: Wallet,
    iconBg: "rgba(13,148,136,0.1)",
    iconColor: "#0D9488",
    gradientColor: "rgba(13,148,136,0.03)",
    points: [
      { icon: Receipt, text: "تسجيل المصروفات المشتركة بسهولة" },
      { icon: Calculator, text: "احتساب المستحقات لكل شقة بدقة" },
      { icon: TrendingUp, text: "متابعة نسبة التحصيل بشكل واضح" },
    ],
  },
  {
    title: "شفافية للجميع",
    icon: Eye,
    iconBg: "rgba(245,158,11,0.1)",
    iconColor: "#F59E0B",
    gradientColor: "rgba(245,158,11,0.03)",
    points: [
      { icon: FileText, text: "عرض المستحقات لكل ساكن بوضوح" },
      { icon: CreditCard, text: "سجل كامل للمدفوعات" },
      { icon: TrendingUp, text: "معرفة الحالة المالية العامة للبرج" },
    ],
  },
  {
    title: "تواصل رسمي ومنظم",
    icon: Megaphone,
    iconBg: "rgba(99,102,241,0.1)",
    iconColor: "#6366f1",
    gradientColor: "rgba(99,102,241,0.03)",
    points: [
      { icon: Bell, text: "إرسال إعلانات وتنبيهات رسمية" },
      { icon: FileText, text: "توثيق القرارات المهمة" },
      { icon: Megaphone, text: "تقليل الاعتماد على المجموعات غير المنظمة" },
    ],
  },
];

export function SolutionSection() {
  return (
    <section id="solution" className="py-14 sm:py-20 md:py-28 relative overflow-hidden" style={{ backgroundColor: '#fafbfc' }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: 'linear-gradient(to left, transparent, #e5e7eb, transparent)' }} />

      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ y: 20 }}
          whileInView={{ y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-8 sm:mb-14"
        >
          <div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 sm:mb-6"
            style={{ backgroundColor: 'rgba(13,148,136,0.08)', border: '1px solid rgba(13,148,136,0.1)', color: '#0D9488' }}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span className="text-sm font-medium">الحل</span>
          </div>
          <h2 className="text-2xl sm:text-3xl mb-3 sm:mb-4 font-bold" style={{ color: '#1a1a2e' }}>
            مُلاك… حل عملي وبسيط
          </h2>
          <p className="text-base sm:text-lg max-w-xl mx-auto leading-relaxed" style={{ color: '#5f6b7a' }}>
            منصة رقمية متكاملة تنظّم كل جوانب إدارة البرج السكني في مكان واحد
          </p>
        </motion.div>

        <div className="flex flex-col md:grid md:grid-cols-3 gap-4 md:gap-5 lg:gap-6">
          {solutions.map((solution, index) => (
            <motion.div
              key={solution.title}
              initial={{ y: 25 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative rounded-2xl sm:rounded-3xl p-5 sm:p-6 md:p-7 hover:shadow-xl transition-all duration-300"
              style={{ backgroundColor: '#ffffff', border: '1px solid #f3f4f6' }}
            >
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4 sm:mb-5 group-hover:scale-110 transition-transform"
                style={{ backgroundColor: solution.iconBg }}
              >
                <solution.icon className="w-7 h-7" style={{ color: solution.iconColor }} />
              </div>

              <h3 className="text-lg font-bold mb-4 sm:mb-5" style={{ color: '#1a1a2e' }}>{solution.title}</h3>

              <div className="space-y-3.5">
                {solution.points.map((point) => (
                  <div key={point.text} className="flex items-start gap-3">
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                      style={{ backgroundColor: solution.iconBg }}
                    >
                      <point.icon className="w-3.5 h-3.5" style={{ color: solution.iconColor }} />
                    </div>
                    <span className="text-base leading-relaxed" style={{ color: '#5f6b7a' }}>{point.text}</span>
                  </div>
                ))}
              </div>

              <div
                className="absolute top-0 left-0 w-20 h-20 rounded-tl-2xl sm:rounded-tl-3xl rounded-br-[60px]"
                style={{ backgroundColor: solution.gradientColor }}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
