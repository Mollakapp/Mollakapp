import { useNavigate } from "react-router";
import { Navbar } from "./Navbar";
import { HeroSection } from "./HeroSection";
import { ProblemSection } from "./ProblemSection";
import { SolutionSection } from "./SolutionSection";
import { BenefitsSection } from "./BenefitsSection";
import { AudienceSection } from "./AudienceSection";
import { CTASection } from "./CTASection";
import { Footer } from "./Footer";

export function LandingPage() {
  const navigate = useNavigate();
  const handleGetStarted = () => navigate("/register");
  const handleLogin = () => navigate("/login");

  return (
    <div className="min-h-screen">
      <Navbar onGetStarted={handleGetStarted} onLogin={handleLogin} />
      <HeroSection onGetStarted={handleGetStarted} />
      <ProblemSection />
      <SolutionSection />
      <BenefitsSection />
      <AudienceSection />
      <CTASection onGetStarted={handleGetStarted} />
      <Footer />
    </div>
  );
}