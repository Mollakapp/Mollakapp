import { ArrowLeft, Building2, Shield, Zap, Globe, Sparkles } from "lucide-react";
import { motion } from "motion/react";

export function CTASection({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <section className="py-10 sm:py-16 md:py-20" style={{ backgroundColor: '#ffffff' }}>
      <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <motion.div
          initial={{ y: 20 }}
          whileInView={{ y: 0 }}
          viewport={{ once: true }}
          className="relative rounded-2xl sm:rounded-[2rem] p-6 sm:p-10 md:p-12 lg:p-16 text-center overflow-hidden"
          style={{ background: 'linear-gradient(to bottom left, #0D9488, #0D9488, #047857)' }}
        >
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-48 sm:w-72 md:w-96 h-48 sm:h-72 md:h-96 rounded-full -translate-y-1/2 translate-x-1/3" style={{ backgroundColor: 'rgba(255,255,255,0.04)' }} />
          <div className="absolute bottom-0 left-0 w-40 sm:w-56 md:w-72 h-40 sm:h-56 md:h-72 rounded-full translate-y-1/2 -translate-x-1/4" style={{ backgroundColor: 'rgba(255,255,255,0.03)' }} />

          <div className="relative z-10">
            <motion.div
              initial={{ scale: 0.8 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="w-14 h-14 sm:w-16 sm:h-16 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-5 sm:mb-8"
              style={{ backgroundColor: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.1)' }}
            >
              <Building2 className="w-7 h-7 sm:w-8 sm:h-8" style={{ color: '#ffffff' }} />
            </motion.div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl mb-3 sm:mb-4 font-bold leading-tight" style={{ color: '#ffffff' }}>
              ابدأ بتنظيم برجك اليوم
            </h2>
            <p className="text-base sm:text-lg max-w-lg mx-auto mb-6 sm:mb-8 md:mb-10 leading-relaxed" style={{ color: 'rgba(255,255,255,0.8)' }}>
              انتقل بإدارة اتحاد الملاك من الاجتهاد الشخصي إلى نظام واضح ومنظم.
              <br className="hidden sm:block" />
              أنشئ حسابك وابدأ في تنظيم أعمال البرج بطريقة أكثر احترافية.
            </p>

            {/* Trust badges */}
            <div className="flex flex-wrap justify-center gap-3 mb-6 sm:mb-8 md:mb-10">
              {[
                { icon: Shield, label: "آمن ومشفر" },
                { icon: Zap, label: "سهل وسريع" },
                { icon: Globe, label: "من أي مكان" },
              ].map((badge) => (
                <div
                  key={badge.label}
                  className="flex items-center gap-2 backdrop-blur-sm rounded-xl px-4 py-2.5"
                  style={{ backgroundColor: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.1)' }}
                >
                  <badge.icon className="w-4 h-4" style={{ color: '#F59E0B' }} />
                  <span className="text-sm font-medium" style={{ color: 'rgba(255,255,255,0.9)' }}>{badge.label}</span>
                </div>
              ))}
            </div>

            <button
              onClick={onGetStarted}
              className="group inline-flex items-center justify-center gap-2.5 px-7 sm:px-8 py-3.5 sm:py-4 rounded-2xl text-base sm:text-lg transition-all font-bold w-full sm:w-auto active:scale-[0.98]"
              style={{ backgroundColor: '#ffffff', color: '#0D9488', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)' }}
            >
              <Sparkles className="w-5 h-5" style={{ color: '#F59E0B' }} />
              أنشئ حسابك مجانًا
              <ArrowLeft className="w-5 h-5 transition-transform group-hover:-translate-x-1" />
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
