import { AlertTriangle, FileQuestion, MessageSquareWarning, Users, ScrollText } from "lucide-react";
import { motion } from "motion/react";

const problems = [
  {
    icon: FileQuestion,
    text: "يصعب تتبع المصروفات المشتركة بدقة",
    color: "#f43f5e",
    bg: "#fff1f2",
  },
  {
    icon: ScrollText,
    text: "لا تتوفر صورة واضحة للمستحقات والمدفوعات",
    color: "#f97316",
    bg: "#fff7ed",
  },
  {
    icon: MessageSquareWarning,
    text: "تكثر الخلافات بسبب غياب المعلومات",
    color: "#f59e0b",
    bg: "#fffbeb",
  },
  {
    icon: Users,
    text: "يعتمد التواصل على مجموعات واتساب غير منظمة",
    color: "#f87171",
    bg: "#fef2f2",
  },
  {
    icon: AlertTriangle,
    text: "تضيع القرارات وسط الرسائل اليومية",
    color: "#fb7185",
    bg: "#fff1f2",
  },
];

export function ProblemSection() {
  return (
    <section id="problem" className="py-14 sm:py-20 md:py-28 relative overflow-hidden" style={{ backgroundColor: '#ffffff' }}>
      <div className="absolute inset-0 opacity-[0.02]" style={{ backgroundImage: "radial-gradient(circle, #1a1a2e 1px, transparent 1px)", backgroundSize: "24px 24px" }} />

      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ y: 20 }}
          whileInView={{ y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-8 sm:mb-14"
        >
          <div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 sm:mb-6"
            style={{ backgroundColor: '#fff1f2', border: '1px solid #ffe4e6', color: '#e11d48' }}
          >
            <AlertTriangle className="w-4 h-4" />
            <span className="text-sm font-medium">المشكلة</span>
          </div>
          <h2 className="text-2xl sm:text-3xl mb-3 sm:mb-4 font-bold" style={{ color: '#1a1a2e' }}>
            لماذا نحتاج إلى منصة مُلاك؟
          </h2>
          <p className="text-base sm:text-lg max-w-xl mx-auto leading-relaxed" style={{ color: '#5f6b7a' }}>
            في كثير من الأبراج السكنية، تتكرر نفس المشاكل بسبب غياب التنظيم والوضوح
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          <div className="flex flex-col sm:grid sm:grid-cols-2 gap-3 sm:gap-4 mb-6 sm:mb-8">
            {problems.map((problem, index) => (
              <motion.div
                key={problem.text}
                initial={{ x: index % 2 === 0 ? 20 : -20 }}
                whileInView={{ x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.06 }}
                className="flex items-center gap-3 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 hover:shadow-md transition-all group"
                style={{ backgroundColor: '#ffffff', border: '1px solid #f3f4f6' }}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform"
                  style={{ backgroundColor: problem.bg }}
                >
                  <problem.icon className="w-5 h-5" style={{ color: problem.color }} />
                </div>
                <span className="text-base font-medium leading-relaxed" style={{ color: '#3a3f4a' }}>{problem.text}</span>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ y: 15 }}
            whileInView={{ y: 0 }}
            viewport={{ once: true }}
            className="rounded-xl sm:rounded-2xl p-4 sm:p-6 text-center"
            style={{ background: 'linear-gradient(to left, #fff1f2, #fff7ed)', border: '1px solid rgba(255,228,230,0.6)' }}
          >
            <p className="text-lg font-semibold mb-1" style={{ color: '#1a1a2e' }}>
              النتيجة؟
            </p>
            <p className="text-base leading-relaxed" style={{ color: '#5f6b7a' }}>
              ضغط مستمر على رئيس الاتحاد، وتوتر بين السكان، وغياب الثقة بين الجميع
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}