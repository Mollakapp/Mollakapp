import { Crown, Building2, Home, Briefcase } from "lucide-react";
import { motion } from "motion/react";

const audiences = [
  {
    icon: Crown,
    title: "رؤساء اتحادات الملاك",
    description: "نظّم أعمال الاتحاد واحفظ حقوق الجميع بأدوات رقمية متكاملة",
    bg: "rgba(13,148,136,0.06)",
    iconColor: "#0D9488",
    gradientFrom: "#0D9488",
    gradientTo: "#059669",
    borderHoverColor: "rgba(13,148,136,0.2)",
  },
  {
    icon: Building2,
    title: "الأبراج السكنية المتوسطة والراقية",
    description: "إدارة احترافية تليق بمستوى المبنى وسكانه",
    bg: "rgba(245,158,11,0.06)",
    iconColor: "#F59E0B",
    gradientFrom: "#F59E0B",
    gradientTo: "#d97706",
    borderHoverColor: "rgba(245,158,11,0.2)",
  },
  {
    icon: Home,
    title: "المجتمعات السكنية الصغيرة",
    description: "حتى لو كان برجك صغيرًا، التنظيم يفرق كثيرًا",
    bg: "rgba(99,102,241,0.06)",
    iconColor: "#6366f1",
    gradientFrom: "#6366f1",
    gradientTo: "#7c3aed",
    borderHoverColor: "rgba(99,102,241,0.2)",
  },
  {
    icon: Briefcase,
    title: "كل من يسعى لإدارة أكثر احترافية",
    description: "انتقل من الاجتهاد الشخصي إلى نظام واضح ومنظم",
    bg: "rgba(139,92,246,0.06)",
    iconColor: "#8b5cf6",
    gradientFrom: "#8b5cf6",
    gradientTo: "#9333ea",
    borderHoverColor: "rgba(139,92,246,0.2)",
  },
];

export function AudienceSection() {
  return (
    <section id="audience" className="py-14 sm:py-20 md:py-28 relative overflow-hidden" style={{ backgroundColor: '#fafbfc' }}>
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: 'linear-gradient(to left, transparent, #e5e7eb, transparent)' }} />

      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ y: 20 }}
          whileInView={{ y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-8 sm:mb-14"
        >
          <div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 sm:mb-6"
            style={{ backgroundColor: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.1)', color: '#F59E0B' }}
          >
            <Crown className="w-4 h-4" />
            <span className="text-sm font-medium">لمن مُلاك؟</span>
          </div>
          <h2 className="text-2xl sm:text-3xl mb-3 sm:mb-4 font-bold" style={{ color: '#1a1a2e' }}>
            صُمم خصيصًا لتلبية احتياجاتك
          </h2>
          <p className="text-base sm:text-lg max-w-xl mx-auto leading-relaxed" style={{ color: '#5f6b7a' }}>
            سواء كنت تدير برجًا كبيرًا أو مجتمعًا سكنيًا صغيرًا، مُلاك هو الحل الأمثل
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-5">
          {audiences.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ y: 25 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.08 }}
              className="group relative rounded-2xl sm:rounded-3xl p-5 sm:p-6 text-center hover:shadow-xl transition-all duration-300"
              style={{ backgroundColor: '#ffffff', border: '1px solid #f3f4f6' }}
            >
              <div
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-5 group-hover:scale-110 transition-transform"
                style={{ backgroundColor: item.bg }}
              >
                <item.icon className="w-7 h-7 sm:w-8 sm:h-8" style={{ color: item.iconColor }} />
              </div>
              <h3 className="text-lg font-bold mb-2" style={{ color: '#1a1a2e' }}>{item.title}</h3>
              <p className="text-base leading-relaxed" style={{ color: '#5f6b7a' }}>{item.description}</p>

              <div
                className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-1 rounded-t-full opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ background: `linear-gradient(to left, ${item.gradientFrom}, ${item.gradientTo})` }}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
