import { Building2, Menu, X } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";

export function Navbar({ onGetStarted, onLogin }: { onGetStarted: () => void; onLogin: () => void }) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  const scrollTo = (id: string) => {
    setIsOpen(false);
    setTimeout(() => {
      document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const links = [
    { label: "المشكلة", id: "problem" },
    { label: "الحل", id: "solution" },
    { label: "المميزات", id: "benefits" },
    { label: "لمن مُلاك؟", id: "audience" },
  ];

  return (
    <nav className="fixed top-0 right-0 left-0 z-50">
      <div className="mx-auto px-3 sm:px-4 md:px-6 lg:px-8 pt-2 sm:pt-3 max-w-7xl">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="rounded-2xl px-3 sm:px-5 transition-all duration-300"
          style={
            scrolled
              ? { backgroundColor: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)', border: '1px solid rgba(229,231,235,0.6)', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.03)' }
              : { backgroundColor: 'rgba(255,255,255,0.5)', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)', border: '1px solid rgba(255,255,255,0.4)' }
          }
        >
          <div className="flex items-center justify-between h-14">
            {/* Logo */}
            <div className="flex items-center gap-2.5">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shadow-sm"
                style={{ background: 'linear-gradient(to bottom right, #0D9488, rgba(13,148,136,0.8))' }}
              >
                <Building2 className="w-4 h-4" style={{ color: '#ffffff' }} />
              </div>
              <span style={{ color: '#1a1a2e' }} className="text-base font-semibold">مُلاك</span>
            </div>

            {/* Nav Links - Desktop */}
            <div className="hidden md:flex items-center gap-1">
              {links.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollTo(item.id)}
                  className="text-sm px-3.5 py-2 rounded-xl font-medium transition-colors"
                  style={{ color: '#5f6b7a' }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = '#0D9488')}
                  onMouseLeave={(e) => (e.currentTarget.style.color = '#5f6b7a')}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* CTA - Desktop */}
            <div className="hidden md:flex items-center gap-3">
              <button
                onClick={onLogin}
                className="text-sm px-3.5 py-2 font-medium transition-colors"
                style={{ color: '#5f6b7a' }}
              >
                تسجيل الدخول
              </button>
              <button
                onClick={onGetStarted}
                className="text-sm px-5 py-2.5 rounded-xl transition-all shadow-sm font-medium"
                style={{ backgroundColor: '#0D9488', color: '#ffffff', boxShadow: '0 4px 6px -1px rgba(13,148,136,0.2)' }}
              >
                ابدأ الآن
              </button>
            </div>

            {/* Mobile menu button */}
            <button
              className="md:hidden w-10 h-10 flex items-center justify-center rounded-xl"
              style={{ color: '#5f6b7a' }}
              onClick={() => setIsOpen(!isOpen)}
              aria-label="القائمة"
            >
              {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

          {/* Mobile menu */}
          <AnimatePresence>
            {isOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="md:hidden overflow-hidden"
              >
                <div className="py-3" style={{ borderTop: '1px solid rgba(243,244,246,0.6)' }}>
                  <div className="flex flex-col gap-1">
                    {links.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => scrollTo(item.id)}
                        className="text-base px-3 py-3 rounded-xl text-right font-medium transition-colors"
                        style={{ color: '#5f6b7a' }}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-3 pt-4 mt-2 px-1" style={{ borderTop: '1px solid rgba(243,244,246,0.6)' }}>
                    <button
                      onClick={() => { setIsOpen(false); onLogin(); }}
                      className="flex-1 text-base font-medium py-3 rounded-xl transition-colors"
                      style={{ color: '#0D9488', border: '1px solid rgba(13,148,136,0.2)' }}
                    >
                      تسجيل الدخول
                    </button>
                    <button
                      onClick={() => { setIsOpen(false); onGetStarted(); }}
                      className="flex-1 text-base py-3 rounded-xl font-medium transition-colors"
                      style={{ backgroundColor: '#0D9488', color: '#ffffff' }}
                    >
                      ابدأ الآن
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </nav>
  );
}
