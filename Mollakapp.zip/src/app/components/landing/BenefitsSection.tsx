import { Home, CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";

const cultureGoals = [
  "حفظ حقوق الملاك والشاغلين",
  "تعزيز العدالة في توزيع المصروفات",
  "توثيق الالتزامات بوضوح",
  "دعم حسن الانتفاع من الأجزاء المشتركة",
];

export function BenefitsSection() {
  return (
    <section id="benefits" className="py-14 sm:py-20 md:py-28 relative overflow-hidden" style={{ backgroundColor: '#ffffff' }}>
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Culture Section */}
        <motion.div
          initial={{ y: 20 }}
          whileInView={{ y: 0 }}
          viewport={{ once: true }}
          className="relative rounded-2xl sm:rounded-3xl p-6 sm:p-8 md:p-10 lg:p-14 overflow-hidden"
          style={{ background: 'linear-gradient(to left, #f0fdf9, #ffffff, rgba(255,251,235,0.3))', border: '1px solid rgba(13,148,136,0.1)' }}
        >
          {/* Decorative */}
          <div className="absolute top-0 right-0 w-40 h-40 rounded-full blur-[60px]" style={{ backgroundColor: 'rgba(13,148,136,0.03)' }} />
          <div className="absolute bottom-0 left-0 w-40 h-40 rounded-full blur-[60px]" style={{ backgroundColor: 'rgba(245,158,11,0.03)' }} />

          <div className="relative z-10 grid lg:grid-cols-2 gap-6 sm:gap-8 items-center">
            <div>
              <div
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 sm:mb-6"
                style={{ backgroundColor: '#ffffff', border: '1px solid rgba(13,148,136,0.1)', color: '#0D9488' }}
              >
                <Home className="w-4 h-4" />
                <span className="text-sm font-medium">التعايش المشترك</span>
              </div>

              <h2 className="text-2xl sm:text-3xl mb-3 sm:mb-4 font-bold" style={{ color: '#1a1a2e' }}>
                دعم ثقافة التعايش المشترك
              </h2>
              <p className="text-base sm:text-lg leading-relaxed mb-5 lg:mb-0" style={{ color: '#5f6b7a' }}>
                إدارة العقار المشترك مسؤولية جماعية.{" "}
                <span className="font-medium" style={{ color: '#1a1a2e' }}>مُلاك</span> يساعد على بناء مجتمع سكني متماسك ومنظم.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {cultureGoals.map((goal, i) => (
                <motion.div
                  key={goal}
                  initial={{ scale: 0.95 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06 }}
                  className="flex items-start gap-3 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 hover:shadow-md transition-all"
                  style={{ backgroundColor: 'rgba(255,255,255,0.8)', border: '1px solid #f3f4f6' }}
                >
                  <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" style={{ color: '#0D9488' }} />
                  <span className="text-base font-medium leading-relaxed" style={{ color: '#3a3f4a' }}>{goal}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
