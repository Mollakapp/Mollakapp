import { ArrowLeft, Sparkles, Shield, Users, BarChart3 } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { motion } from "motion/react";

export function HeroSection({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <section className="relative flex items-center pt-20 sm:pt-24 pb-10 sm:pb-16 min-h-[calc(100svh-2rem)] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, #f0fdf9, #ffffff, #ffffff)' }} />
      <div className="absolute top-0 left-0 right-0 h-full overflow-hidden">
        <div className="absolute top-20 right-[5%] w-[300px] sm:w-[500px] h-[300px] sm:h-[500px] rounded-full blur-[80px] sm:blur-[100px]" style={{ backgroundColor: 'rgba(13,148,136,0.04)' }} />
        <div className="absolute bottom-20 left-[10%] w-[250px] sm:w-[400px] h-[250px] sm:h-[400px] rounded-full blur-[80px] sm:blur-[100px]" style={{ backgroundColor: 'rgba(245,158,11,0.04)' }} />
      </div>

      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Right side - Text */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="text-right"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.4 }}
              className="inline-flex items-center gap-2 backdrop-blur-sm px-4 py-2 rounded-full mb-5 sm:mb-8 shadow-sm"
              style={{ backgroundColor: 'rgba(255,255,255,0.8)', border: '1px solid rgba(13,148,136,0.1)', color: '#0D9488' }}
            >
              <Sparkles className="w-4 h-4" style={{ color: '#F59E0B' }} />
              <span className="text-sm font-medium">منصة مُلاك لجميع المُلاك</span>
            </motion.div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl mb-4 sm:mb-6 leading-[1.3] font-bold" style={{ color: '#1a1a2e' }}>
              إدارة احترافية ...{" "}
              <span style={{ color: '#0D9488' }}>
                بثقة وشفافية
              </span>
            </h1>

            <p className="text-base sm:text-lg mb-6 sm:mb-8 max-w-lg leading-relaxed" style={{ color: '#5f6b7a' }}>
              منصة <span className="font-medium" style={{ color: '#1a1a2e' }}>مُلاك</span> هي المنصة الأولى التي تهتم بمساعدة اتحاد المُلاك على إدارة مصروفات وخدمات البرج السكني
            </p>

            {/* Buttons */}
            <div className="flex flex-col xs:flex-row gap-3 mb-8 sm:mb-10">
              <button
                onClick={onGetStarted}
                className="group inline-flex items-center justify-center gap-2.5 px-6 sm:px-7 py-3 sm:py-3.5 rounded-2xl text-base font-medium transition-all w-full sm:w-auto active:scale-[0.98]"
                style={{ backgroundColor: '#0D9488', color: '#ffffff', boxShadow: '0 10px 15px -3px rgba(13,148,136,0.2)' }}
              >
                أنشئ حسابك الآن
                <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
              </button>
              <button
                onClick={() => document.getElementById("solution")?.scrollIntoView({ behavior: "smooth" })}
                className="inline-flex items-center justify-center gap-2 px-6 sm:px-7 py-3 sm:py-3.5 rounded-2xl text-base font-medium transition-all shadow-sm w-full sm:w-auto active:scale-[0.98]"
                style={{ backgroundColor: '#ffffff', border: '1px solid #e5e7eb', color: '#5f6b7a' }}
              >
                اكتشف المزيد
              </button>
            </div>

            {/* Trust indicators */}
            <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:gap-5 items-start sm:items-center">
              {[
                { icon: Shield, text: "بيانات مشفرة وآمنة", color: "#0D9488" },
                { icon: Users, text: "مجتمعات سكنية نشطة", color: "#F59E0B" },
                { icon: BarChart3, text: "تقارير مالية شفافة", color: "#6366f1" },
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-2" style={{ color: '#5f6b7a' }}>
                  <item.icon className="w-4 h-4" style={{ color: item.color }} />
                  <span className="text-sm font-medium">{item.text}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Left side - Image */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3, ease: "easeOut" }}
            className="relative mt-4 lg:mt-0"
          >
            <div className="relative">
              <div className="rounded-2xl sm:rounded-3xl overflow-hidden shadow-xl sm:shadow-2xl" style={{ border: '1px solid rgba(255,255,255,0.5)', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.08)' }}>
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1758448617761-09367c1748d4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsdXh1cnklMjByZXNpZGVudGlhbCUyMHRvd2VyJTIwZXZlbmluZ3xlbnwxfHx8fDE3NzIyMDQ5MzF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="برج سكني حديث"
                  className="w-full h-[220px] sm:h-[320px] lg:h-[500px] object-cover"
                />
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.25), transparent, transparent)' }} />
              </div>

              {/* Floating card bottom-right */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.8 }}
                className="absolute -bottom-3 sm:-bottom-5 right-2 sm:-right-5 backdrop-blur-xl rounded-xl sm:rounded-2xl px-3 sm:px-4 py-2.5 sm:py-3 flex items-center gap-2.5 sm:gap-3"
                style={{ backgroundColor: 'rgba(255,255,255,0.9)', border: '1px solid #f3f4f6', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.05)' }}
              >
                <div
                  className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl flex items-center justify-center"
                  style={{ background: 'linear-gradient(to bottom right, rgba(13,148,136,0.1), rgba(13,148,136,0.05))' }}
                >
                  <Shield className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#0D9488' }} />
                </div>
                <div>
                  <div className="text-sm font-semibold" style={{ color: '#1a1a2e' }}>شفافية كاملة</div>
                  <div className="text-sm" style={{ color: '#5f6b7a' }}>كل ساكن يشوف مستحقاته</div>
                </div>
              </motion.div>

              {/* Floating card top-left */}
              <motion.div
                initial={{ opacity: 0, y: -15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 1 }}
                className="absolute -top-3 sm:-top-4 left-2 sm:-left-4 backdrop-blur-xl rounded-xl sm:rounded-2xl px-3 sm:px-4 py-2.5 sm:py-3 items-center gap-2.5 sm:gap-3 hidden sm:flex"
                style={{ backgroundColor: 'rgba(255,255,255,0.9)', border: '1px solid #f3f4f6', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.05)' }}
              >
                <div
                  className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl flex items-center justify-center"
                  style={{ background: 'linear-gradient(to bottom right, rgba(245,158,11,0.1), rgba(245,158,11,0.05))' }}
                >
                  <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#F59E0B' }} />
                </div>
                <div>
                  <div className="text-sm font-semibold" style={{ color: '#1a1a2e' }}>تتبع مالي دقيق</div>
                  <div className="text-sm" style={{ color: '#5f6b7a' }}>مصروفات وإيرادات واضحة</div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}