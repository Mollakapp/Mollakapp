import { Building2 } from "lucide-react";

export function Footer() {
  return (
    <footer style={{ backgroundColor: '#1a1a2e', color: '#ffffff' }} className="py-10 sm:py-14">
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 mb-8 sm:mb-10">
          {/* Logo */}
          <div className="col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: '#0D9488' }}>
                <Building2 className="w-5 h-5" style={{ color: '#ffffff' }} />
              </div>
              <span className="text-lg font-bold" style={{ color: '#ffffff' }}>مُلاك</span>
            </div>
            <p className="text-sm leading-relaxed max-w-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>
              إدارة احترافية لاتحاد الملاك… بثقة وشفافية. منصة رقمية لتنظيم أعمال البرج السكني.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-sm font-semibold mb-4" style={{ color: 'rgba(255,255,255,0.9)' }}>المنصة</h4>
            <ul className="space-y-2.5">
              {["المميزات", "الأسعار", "الأسئلة الشائعة", "تواصل معنا"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm transition-colors" style={{ color: 'rgba(255,255,255,0.4)' }}>
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-4" style={{ color: 'rgba(255,255,255,0.9)' }}>الدعم</h4>
            <ul className="space-y-2.5">
              {["مركز المساعدة", "سياسة الخصوصية", "الشروط والأحكام"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm transition-colors" style={{ color: 'rgba(255,255,255,0.4)' }}>
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="col-span-2 sm:col-span-1">
            <h4 className="text-sm font-semibold mb-4" style={{ color: 'rgba(255,255,255,0.9)' }}>تواصل معنا</h4>
            <ul className="space-y-2.5">
              <li className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }}>info@mollak.app</li>
              <li className="text-sm" style={{ color: 'rgba(255,255,255,0.4)' }} dir="ltr">+20 123 456 7890</li>
            </ul>
          </div>
        </div>

        <div className="pt-5 sm:pt-6 flex flex-col sm:flex-row items-center justify-between gap-2 sm:gap-3" style={{ borderTop: '1px solid rgba(255,255,255,0.1)' }}>
          <p className="text-sm" style={{ color: 'rgba(255,255,255,0.3)' }}>
            © 2026 مُلاك — جميع الحقوق محفوظة
          </p>
          <div className="flex items-center gap-1.5">
            <span className="text-sm" style={{ color: 'rgba(255,255,255,0.3)' }}>صُنع بـ</span>
            <span style={{ color: '#F59E0B' }}>♥</span>
            <span className="text-sm" style={{ color: 'rgba(255,255,255,0.3)' }}>لمجتمعات سكنية أفضل</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
