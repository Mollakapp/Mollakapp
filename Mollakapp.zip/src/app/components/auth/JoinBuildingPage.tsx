import { useState, useEffect, useMemo } from "react";
import { useParams, useNavigate } from "react-router";
import {
  Building2,
  User,
  Phone,
  Hash,
  Home,
  CheckCircle2,
  Loader2,
  ArrowLeft,
  ArrowRight,
  MapPin,
  Users,
  Layers,
  DoorOpen,
  ShieldCheck,
  Key,
  AlertCircle,
  UserCheck,
  UserX,
  Mail,
  Lock,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import * as api from "../../lib/api";
import { normalizeToEnglishDigits } from "../../lib/phoneUtils";
import { TITLES } from "../../lib/titles";

type ResidentType = "مالك" | "مستأجر" | "";
type OccupancyStatus = "شاغر" | "غير شاغر" | "";

interface ResidentData {
  title: string;
  name: string;
  phone: string;
  password: string;
  confirmPassword: string;
  otp: string;
  otpSent: boolean;
  otpVerified: boolean;
  floor: string;
  unit: string;
  type: ResidentType;
  occupancy: OccupancyStatus;
}

const steps = [
  { id: 1, title: "بيانات البرج", icon: Building2 },
  { id: 2, title: "بياناتك", icon: User },
  { id: 3, title: "تم الإرسال", icon: CheckCircle2 },
];

const residentTypes: { value: ResidentType; label: string; icon: typeof Key; desc: string }[] = [
  { value: "مالك", label: "مالك", icon: ShieldCheck, desc: "أملك الوحدة السكنية في هذا البرج" },
  { value: "مستأجر", label: "مستأجر", icon: Key, desc: "أستأجر الوحدة السكنية في هذا البرج" },
];

export function JoinBuildingPage() {
  const { buildingSlug } = useParams();
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [pageLoading, setPageLoading] = useState(true);
  const [error, setError] = useState("");
  const [submitError, setSubmitError] = useState("");

  // Building data from API
  const [buildingData, setBuildingData] = useState<api.JoinBuildingData | null>(null);
  const [allUnits, setAllUnits] = useState<{ id: string; unitCode: string; floor: string; floorLabel?: string; label: string; occupied: boolean; unitType?: string }[]>([]);

  const [resident, setResident] = useState<ResidentData>({
    title: "",
    name: "",
    phone: "",
    password: "",
    confirmPassword: "",
    otp: "",
    otpSent: false,
    otpVerified: false,
    floor: "",
    unit: "",
    type: "",
    occupancy: "شاغر",
  });

  // Load building data by slug
  useEffect(() => {
    if (!buildingSlug) {
      setError("رابط الدعوة غير صالح");
      setPageLoading(false);
      return;
    }
    (async () => {
      try {
        const data = await api.getBuildingBySlug(buildingSlug);
        if (data.found && data.building) {
          setBuildingData(data);
          setAllUnits(data.units || []);
        } else {
          setError("لم يتم العثور على المبنى — تأكد من رابط الدعوة");
        }
      } catch (err: any) {
        console.error("Error loading building:", err);
        setError("حدث خطأ أثناء تحميل بيانات المبنى");
      } finally {
        setPageLoading(false);
      }
    })();
  }, [buildingSlug]);

  const building = buildingData?.building;

  // Derive floor options from actual units
  const floorOptions = useMemo(() => {
    const floors = [...new Set(allUnits.map((u) => u.floor))];
    return floors.sort((a, b) => parseInt(a) - parseInt(b));
  }, [allUnits]);

  // Units for selected floor (only unoccupied)
  const unitOptions = useMemo(() => {
    if (!resident.floor) return [];
    return allUnits
      .filter((u) => u.floor === resident.floor && !u.occupied)
      .sort((a, b) => parseInt(a.unitCode) - parseInt(b.unitCode));
  }, [allUnits, resident.floor]);

  // OTP simulation
  const handleSendOtp = () => {
    if (!resident.phone || resident.phone.length < 10) return;
    setIsLoading(true);
    setTimeout(() => {
      setResident((prev) => ({ ...prev, otpSent: true }));
      setIsLoading(false);
    }, 1500);
  };

  const handleVerifyOtp = () => {
    if (resident.otp.length < 4) return;
    setIsLoading(true);
    setTimeout(() => {
      setResident((prev) => ({ ...prev, otpVerified: true }));
      setIsLoading(false);
    }, 1200);
  };

  const canProceedStep2 =
    resident.name.trim() !== "" &&
    resident.phone.trim() !== "" &&
    resident.password.length >= 6 &&
    resident.password === resident.confirmPassword &&
    resident.otpVerified &&
    resident.floor !== "" &&
    resident.unit !== "" &&
    resident.type !== "";

  const handleJoin = async () => {
    if (!canProceedStep2 || !building) return;
    setIsLoading(true);
    setSubmitError("");
    try {
      await api.submitJoinRequest({
        buildingId: building.id,
        title: resident.title,
        name: resident.name.trim(),
        phone: resident.phone.trim(),
        password: resident.password,
        unitCode: resident.unit,
        floor: resident.floor,
        type: resident.type,
      });
      setCurrentStep(3);
    } catch (err: any) {
      console.error("Error submitting join request:", err);
      // Parse error message
      const msg = err.message || "";
      if (msg.includes("409")) {
        if (msg.includes("الرقم مسجل")) {
          setSubmitError("هذا الرقم مسجل بالفعل في المبنى");
        } else if (msg.includes("رقم الجوال مسجل") || msg.includes("برج آخر") || msg.includes("أكثر من برج")) {
          // Extract building name from server message if available
          const buildingMatch = msg.match(/برج "([^"]+)"/);
          const otherBuilding = buildingMatch ? buildingMatch[1] : "آخر";
          setSubmitError(`رقم الجوال مسجل بالفعل في برج "${otherBuilding}". لا يمكن التسجيل في أكثر من برج بنفس الرقم.`);
        } else if (msg.includes("طلب انضمام معلق")) {
          setSubmitError("يوجد طلب انضمام معلق لهذا الرقم بالفعل — انتظر الموافقة");
        } else if (msg.includes("الوحدة مسجلة")) {
          setSubmitError("هذه الوحدة مسجلة بالفعل لساكن آخر");
        } else {
          setSubmitError("هذا الطلب مكرر — تأكد من البيانات");
        }
      } else {
        setSubmitError("حدث خطأ أثناء إرسال الطلب — حاول مرة أخرى");
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Loading state
  if (pageLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-bl from-[#0D9488]/5 via-[#f8fffe] to-[#F59E0B]/5 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-10 h-10 text-[#0D9488] animate-spin mx-auto mb-4" />
          <p className="text-sm text-[#5f6b7a]">جاري تحميل بيانات المبنى...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error || !building) {
    return (
      <div className="min-h-screen bg-gradient-to-bl from-[#0D9488]/5 via-[#f8fffe] to-[#F59E0B]/5 flex items-center justify-center p-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8 text-red-400" />
          </div>
          <h2 className="text-xl text-[#1a1a2e] mb-2">رابط غير صالح</h2>
          <p className="text-sm text-[#5f6b7a] mb-6">{error || "لم يتم العثور على المبنى"}</p>
          <button
            onClick={() => navigate("/")}
            className="inline-flex items-center gap-2 bg-[#0D9488] text-white px-6 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all text-sm"
          >
            الصفحة الرئيسية
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-bl from-[#0D9488]/5 via-[#f8fffe] to-[#F59E0B]/5 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div
            className="inline-flex items-center gap-2 cursor-pointer mb-6"
            onClick={() => navigate("/")}
          >
            <div className="w-10 h-10 bg-[#0D9488] rounded-xl flex items-center justify-center">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl text-[#1a1a2e]">مُلاك</span>
          </div>
          <p className="text-sm text-[#5f6b7a]">
            تمت دعوتك للانضمام لمنصة مُلاك من أحد اعضاء اتحاد الملاك
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-3xl shadow-xl shadow-[#0D9488]/5 border border-[#0D9488]/10 overflow-hidden">
          <AnimatePresence mode="wait">
            {/* Step 1: Building Info */}
            {currentStep === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.3 }}
                className="p-6 sm:p-8"
              >
                {/* Building Hero */}
                <div className="relative rounded-xl overflow-hidden mb-5 py-4 px-5" style={{ background: 'linear-gradient(to left, #0D9488, rgba(13,148,136,0.8))' }}>
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-white text-base sm:text-lg mb-0.5">{building.name}</h2>
                      {(building.address || building.city) && (
                        <div className="flex items-center gap-1.5 text-white/80 text-xs">
                          <MapPin className="w-3 h-3" />
                          {building.address}{building.address && building.city ? "، " : ""}{building.city}
                        </div>
                      )}
                    </div>
                    <Building2 className="w-12 h-12 text-white/10" />
                  </div>
                </div>

                {/* Building Stats */}
                <div className="grid grid-cols-3 gap-2 mb-5">
                  <div className="bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-lg px-2 py-2.5 text-center">
                    <Layers className="w-4 h-4 text-[#0D9488] mx-auto mb-1" />
                    <div className="text-sm text-[#1a1a2e]">{building.floors}</div>
                    <div className="text-[10px] text-[#5f6b7a]">دور</div>
                  </div>
                  <div className="bg-[#F59E0B]/5 border border-[#F59E0B]/10 rounded-lg px-2 py-2.5 text-center">
                    <DoorOpen className="w-4 h-4 text-[#F59E0B] mx-auto mb-1" />
                    <div className="text-sm text-[#1a1a2e]">{building.totalUnits}</div>
                    <div className="text-[10px] text-[#5f6b7a]">وحدة</div>
                  </div>
                  <div className="bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-lg px-2 py-2.5 text-center">
                    <Users className="w-4 h-4 text-[#0D9488] mx-auto mb-1" />
                    <div className="text-sm text-[#1a1a2e]">{building.approvedCount}</div>
                    <div className="text-[10px] text-[#5f6b7a]">ساكن مسجّل</div>
                  </div>
                </div>

                {/* Admin Info */}
                {building.admin?.name && (
                  <div className="bg-[#f0f5f4] rounded-xl p-4 flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-[#0D9488] rounded-full flex items-center justify-center shrink-0">
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-[#1a1a2e]">{building.admin.name}</div>
                      <div className="text-xs text-[#0D9488]">{building.admin.role}</div>
                    </div>
                    <div className="text-xs text-[#5f6b7a] bg-white px-3 py-1.5 rounded-lg">مسؤول البرج</div>
                  </div>
                )}

                {/* Features Preview */}
                <div className="border border-[#0D9488]/10 rounded-xl p-4">
                  <div className="text-sm text-[#1a1a2e] mb-3">بانضمامك هتقدر تستخدم:</div>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      "متابعة الفواتير والمصروفات",
                      "دفع إلكتروني آمن",
                      "التصويت على القرارات",
                      "إعلانات وتنبيهات فورية",
                      "شات مع الإدارة والسكان",
                      "دليل أرقام مهمة",
                    ].map((feature) => (
                      <div key={feature} className="flex items-center gap-2 text-xs text-[#5f6b7a]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#0D9488] shrink-0" />
                        {feature}
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 2: Resident Data */}
            {currentStep === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.3 }}
                className="p-6 sm:p-8"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-[#F59E0B]/10 rounded-xl flex items-center justify-center">
                    <User className="w-5 h-5 text-[#F59E0B]" />
                  </div>
                  <div>
                    <h2 className="text-lg text-[#1a1a2e]">بياناتك الشخصية</h2>
                    <p className="text-xs text-[#5f6b7a]">
                      أدخل بياناتك للانضمام إلى{" "}
                      <strong className="text-[#0D9488]">{building.name}</strong>
                    </p>
                  </div>
                </div>

                {submitError && (
                  <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded-xl px-4 py-3 mb-5 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    {submitError}
                  </div>
                )}

                <div className="space-y-5">
                  {/* Title */}
                  <div>
                    <label className="block text-sm text-[#1a1a2e] mb-2">
                      اللقب
                    </label>
                    <select
                      value={resident.title}
                      onChange={(e) => setResident((prev) => ({ ...prev, title: e.target.value }))}
                      className="w-full pr-3 pl-2 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm appearance-none cursor-pointer"
                    >
                      {TITLES.map((t) => (
                        <option key={t.value} value={t.value}>{t.label}</option>
                      ))}
                    </select>
                  </div>

                  {/* Full Name */}
                  <div>
                    <label className="block text-sm text-[#1a1a2e] mb-2">
                      الاسم الكامل <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                      <input
                        type="text"
                        placeholder="مثال: محمد أحمد"
                        value={resident.name}
                        onChange={(e) => setResident((prev) => ({ ...prev, name: e.target.value }))}
                        className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm"
                      />
                    </div>
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-sm text-[#1a1a2e] mb-2">
                      رقم الموبيل <span className="text-red-500">*</span>
                    </label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                        <input
                          type="tel"
                          placeholder="01XX XXX XXXX"
                          value={resident.phone}
                          onChange={(e) =>
                            setResident((prev) => ({
                              ...prev,
                              phone: normalizeToEnglishDigits(e.target.value),
                              otpSent: false,
                              otpVerified: false,
                              otp: "",
                            }))
                          }
                          disabled={resident.otpVerified}
                          className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm disabled:opacity-60"
                          dir="ltr"
                        />
                      </div>
                      {!resident.otpVerified && (
                        <button
                          onClick={handleSendOtp}
                          disabled={isLoading || resident.phone.length < 10 || resident.otpSent}
                          className="shrink-0 bg-[#0D9488] text-white px-5 py-3.5 rounded-xl hover:bg-[#0D9488]/90 transition-all text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                          {isLoading && resident.phone.length >= 10 && !resident.otpSent ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : null}
                          {resident.otpSent ? "تم الإرسال" : "إرسال كود"}
                        </button>
                      )}
                      {resident.otpVerified && (
                        <div className="shrink-0 flex items-center gap-2 bg-green-50 text-green-600 px-4 py-3.5 rounded-xl text-sm">
                          <CheckCircle2 className="w-4 h-4" />تم التأكيد
                        </div>
                      )}
                    </div>
                  </div>

                  {/* OTP */}
                  {resident.otpSent && !resident.otpVerified && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="overflow-hidden"
                    >
                      <label className="block text-sm text-[#1a1a2e] mb-2">
                        كود التأكيد <span className="text-red-500">*</span>
                      </label>
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <Hash className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                          <input
                            type="text"
                            placeholder="أدخل الكود المكون من 4 أرقام"
                            value={resident.otp}
                            onChange={(e) =>
                              setResident((prev) => ({
                                ...prev,
                                otp: e.target.value.replace(/\D/g, "").slice(0, 4),
                              }))
                            }
                            maxLength={4}
                            className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm"
                            dir="ltr"
                          />
                        </div>
                        <button
                          onClick={handleVerifyOtp}
                          disabled={isLoading || resident.otp.length < 4}
                          className="shrink-0 bg-[#F59E0B] text-white px-5 py-3.5 rounded-xl hover:bg-[#F59E0B]/90 transition-all text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                          {isLoading && resident.otp.length >= 4 ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : null}
                          تأكيد
                        </button>
                      </div>
                      <p className="text-xs text-[#5f6b7a] mt-2">
                        تم إرسال كود التأكيد إلى {resident.phone} —{" "}
                        <button
                          className="text-[#0D9488] underline"
                          onClick={() => setResident((prev) => ({ ...prev, otpSent: false, otp: "" }))}
                        >
                          إعادة الإرسال
                        </button>
                      </p>
                    </motion.div>
                  )}

                  {/* Floor & Unit */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm text-[#1a1a2e] mb-2">
                        رقم الدور <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Layers className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                        <select
                          value={resident.floor}
                          onChange={(e) =>
                            setResident((prev) => ({
                              ...prev,
                              floor: e.target.value,
                              unit: "",
                            }))
                          }
                          className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm appearance-none cursor-pointer"
                        >
                          <option value="">اختر الدور</option>
                          {floorOptions.map((f) => {
                            const floorUnit = allUnits.find(u => u.floor === f);
                            const label = floorUnit?.floorLabel && floorUnit.floorLabel !== f ? floorUnit.floorLabel : `الدور ${f}`;
                            return <option key={f} value={f}>{label}</option>;
                          })}
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm text-[#1a1a2e] mb-2">
                        رقم الوحدة <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Home className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                        <select
                          value={resident.unit}
                          onChange={(e) => setResident((prev) => ({ ...prev, unit: e.target.value }))}
                          disabled={!resident.floor}
                          className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm appearance-none cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <option value="">اختر الوحدة</option>
                          {unitOptions.map((u) => (
                            <option key={u.id} value={u.unitCode}>
                              {u.label}
                            </option>
                          ))}
                        </select>
                        {resident.floor && unitOptions.length === 0 && (
                          <p className="text-xs text-[#F59E0B] mt-1">جميع وحدات هذا الدور مسجلة</p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Resident Type & Occupancy */}
                  <div className="grid grid-cols-2 gap-3 sm:gap-4">
                    {/* Resident Type - compact */}
                    <div>
                      <label className="block text-xs sm:text-sm text-[#1a1a2e] mb-1.5 sm:mb-2">
                        صفتك <span className="text-red-500">*</span>
                      </label>
                      <div className="flex gap-1.5 sm:gap-2">
                        {residentTypes.map((t) => (
                          <button
                            key={t.value}
                            onClick={() => setResident((prev) => ({ ...prev, type: t.value }))}
                            className={`flex-1 flex items-center justify-center gap-1 sm:gap-2 py-2 sm:py-3 rounded-lg sm:rounded-xl border-2 transition-all text-xs sm:text-sm ${
                              resident.type === t.value
                                ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]"
                                : "border-[#f0f5f4] bg-[#f0f5f4] text-[#5f6b7a] hover:border-[#0D9488]/30"
                            }`}
                          >
                            <t.icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                            {t.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Occupancy Status */}
                    <div>
                      <label className="block text-xs sm:text-sm text-[#1a1a2e] mb-1.5 sm:mb-2">
                        حالة الوحدة <span className="text-red-500">*</span>
                      </label>
                      <div className="flex gap-1.5 sm:gap-2">
                        {([
                          { value: "غير شاغر" as OccupancyStatus, label: "غير شاغر", icon: UserCheck, color: "#22c55e" },
                          { value: "شاغر" as OccupancyStatus, label: "شاغر", icon: UserX, color: "#F59E0B" },
                        ]).map((o) => (
                          <button
                            key={o.value}
                            onClick={() => setResident((prev) => ({ ...prev, occupancy: o.value }))}
                            className={`flex-1 flex items-center justify-center gap-1 sm:gap-2 py-2 sm:py-3 rounded-lg sm:rounded-xl border-2 transition-all text-xs sm:text-sm ${
                              resident.occupancy === o.value
                                ? `border-[${o.color}] bg-[${o.color}]/5 text-[${o.color}]`
                                : "border-[#f0f5f4] bg-[#f0f5f4] text-[#5f6b7a] hover:border-[#0D9488]/30"
                            }`}
                            style={resident.occupancy === o.value ? { borderColor: o.color, backgroundColor: `${o.color}10`, color: o.color } : {}}
                          >
                            <o.icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                            {o.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Password — Account credentials */}
                  <div className="bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-xl p-3 sm:p-4">
                    <div className="flex items-center gap-1.5 sm:gap-2 mb-2.5 sm:mb-3 flex-wrap">
                      <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#0D9488]" />
                      <span className="text-xs sm:text-sm text-[#1a1a2e]">كلمة مرور حسابك</span>
                      <span className="text-[9px] sm:text-[10px] text-[#5f6b7a] bg-white px-1.5 sm:px-2 py-0.5 rounded-md">لتسجيل الدخول برقمك بعد الموافقة</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-3">
                      <div>
                        <label className="block text-xs text-[#5f6b7a] mb-1.5">
                          كلمة المرور <span className="text-red-500">*</span>
                        </label>
                        <div className="relative">
                          <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" />
                          <input
                            type="password"
                            placeholder="6 أحرف على الأقل"
                            value={resident.password}
                            onChange={(e) => setResident((prev) => ({ ...prev, password: e.target.value }))}
                            className="w-full pr-10 pl-4 py-2.5 sm:py-3 bg-white border border-[#0D9488]/15 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 focus:border-[#0D9488] transition-all text-xs sm:text-sm"
                          />
                        </div>
                        {resident.password && resident.password.length < 6 && (
                          <p className="text-xs text-red-500 mt-1">6 أحرف على الأقل</p>
                        )}
                      </div>
                      <div>
                        <label className="block text-xs text-[#5f6b7a] mb-1.5">
                          تأكيد كلمة المرور <span className="text-red-500">*</span>
                        </label>
                        <div className="relative">
                          <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" />
                          <input
                            type="password"
                            placeholder="أعد كتابة كلمة المرور"
                            value={resident.confirmPassword}
                            onChange={(e) => setResident((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                            className="w-full pr-10 pl-4 py-2.5 sm:py-3 bg-white border border-[#0D9488]/15 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 focus:border-[#0D9488] transition-all text-xs sm:text-sm"
                          />
                        </div>
                        {resident.confirmPassword && resident.password !== resident.confirmPassword && (
                          <p className="text-xs text-red-500 mt-1">كلمة المرور غير متطابقة</p>
                        )}
                      </div>
                    </div>
                    <p className="text-[10px] text-[#5f6b7a] mt-2 flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      هتسجل دخولك بعد كده برقم جوالك <span dir="ltr" className="text-[#0D9488]">{resident.phone || "01XX..."}</span> + كلمة المرور دي
                    </p>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Step 3: Success */}
            {currentStep === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
                className="p-6 sm:p-10 text-center"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  className="w-20 h-20 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto mb-6"
                >
                  <CheckCircle2 className="w-10 h-10 text-[#0D9488]" />
                </motion.div>

                <h2 className="text-2xl text-[#1a1a2e] mb-2">تم إرسال طلبك!</h2>
                <p className="text-sm text-[#5f6b7a] mb-8 max-w-md mx-auto">
                  تم إرسال طلب الانضمام لإدارة {building.name}. سيتم مراجعة بياناتك والرد عليك في أقرب وقت.
                </p>

                {/* Summary */}
                <div className="bg-[#f0f5f4] rounded-2xl p-5 text-right max-w-md mx-auto mb-8">
                  <div className="text-xs text-[#5f6b7a] mb-3">ملخص بياناتك</div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">الاسم</span>
                      <span className="text-[#1a1a2e]">{resident.title ? `${resident.title} ${resident.name}` : resident.name}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">الجوال</span>
                      <span className="text-[#1a1a2e]" dir="ltr">{resident.phone}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">البرج</span>
                      <span className="text-[#0D9488]">{building.name}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">الدور / الوحدة</span>
                      <span className="text-[#1a1a2e]">الدور {resident.floor} — شقة {resident.unit}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">الصفة</span>
                      <span className="text-[#F59E0B]">{resident.type}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">حالة الوحدة</span>
                      <span className={resident.occupancy === "غير شاغر" ? "text-[#22c55e]" : "text-[#F59E0B]"}>{resident.occupancy}</span>
                    </div>
                  </div>
                </div>

                {/* Waiting Notice */}
                <div className="bg-[#0D9488]/5 border border-[#0D9488]/15 rounded-xl p-4 max-w-md mx-auto mb-8 text-right">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-[#0D9488]/10 rounded-lg flex items-center justify-center shrink-0 mt-0.5">
                      <ShieldCheck className="w-4 h-4 text-[#0D9488]" />
                    </div>
                    <div>
                      <div className="text-sm text-[#1a1a2e] mb-1">في انتظار الموافقة</div>
                      <p className="text-xs text-[#5f6b7a]">
                        سيتم مراجعة طلبك من قِبل إدارة البرج. بعد الموافقة، سجّل دخولك برقم جوالك وكلمة المرور اللي اخترتها.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 justify-center">
                  <button
                    onClick={() => navigate("/login")}
                    className="inline-flex items-center gap-2 bg-[#F59E0B] text-white px-8 py-4 rounded-xl hover:bg-[#F59E0B]/90 transition-all shadow-lg shadow-[#F59E0B]/25"
                  >
                    تسجيل الدخول
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => navigate("/")}
                    className="inline-flex items-center gap-2 bg-[#0D9488]/10 text-[#0D9488] px-6 py-4 rounded-xl hover:bg-[#0D9488]/15 transition-all"
                  >
                    الرئيسية
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Navigation Buttons */}
          {currentStep < 3 && (
            <div className="flex items-center justify-between p-6 sm:px-8 border-t border-[#0D9488]/10 bg-[#f8fffe]">
              {currentStep > 1 ? (
                <button
                  onClick={() => { setCurrentStep(1); setSubmitError(""); }}
                  className="flex items-center gap-2 text-sm text-[#5f6b7a] hover:text-[#0D9488] transition-colors"
                >
                  <ArrowRight className="w-4 h-4" />رجوع
                </button>
              ) : (
                <div />
              )}

              {currentStep === 1 ? (
                <button
                  onClick={() => setCurrentStep(2)}
                  className="flex items-center gap-2 bg-[#0D9488] text-white px-6 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20 text-sm"
                >
                  انضم الآن
                  <ArrowLeft className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={handleJoin}
                  disabled={!canProceedStep2 || isLoading}
                  className="flex items-center gap-2 bg-[#0D9488] text-white px-6 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <><Loader2 className="w-4 h-4 animate-spin" />جاري الإرسال...</>
                  ) : (
                    <><CheckCircle2 className="w-4 h-4" />إرسال الطلب</>
                  )}
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}