import { useState } from "react";
import { useNavigate } from "react-router";
import { Building2, Phone, Home, ArrowLeft, AlertCircle, Info } from "lucide-react";
import { motion } from "motion/react";

export function ForgotPasswordPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-bl from-[#f8fffe] via-white to-[#0D9488]/5 flex items-center justify-center p-4" dir="rtl">
      {/* Back to home */}
      <button
        onClick={() => navigate("/")}
        className="absolute top-4 right-4 sm:top-6 sm:right-6 flex items-center gap-2 text-sm text-[#5f6b7a] hover:text-[#0D9488] transition-colors"
      >
        <Home className="w-4 h-4" />
        الرئيسية
      </button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#F59E0B] rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-[#F59E0B]/20">
            <Building2 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl text-[#1a1a2e] mb-1">نسيت كلمة المرور</h1>
          <p className="text-sm text-[#5f6b7a]">إعادة تعيين كلمة المرور</p>
        </div>

        {/* Info Card */}
        <div className="bg-white rounded-2xl border border-[#0D9488]/10 p-6 shadow-xl shadow-black/5">
          <div className="bg-[#F59E0B]/5 border border-[#F59E0B]/20 rounded-xl p-4 mb-5">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-[#F59E0B] shrink-0 mt-0.5" />
              <div>
                <h3 className="text-sm text-[#1a1a2e] mb-2">كيف أستعيد كلمة المرور؟</h3>
                <p className="text-xs text-[#5f6b7a] leading-relaxed">
                  نظام مُلاك لا يستخدم البريد الإلكتروني، لذلك إعادة تعيين كلمة المرور تتم عبر إدارة المبنى مباشرة.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-4 mb-6">
            <div className="flex items-start gap-3 p-3 bg-[#f8fffe] rounded-xl">
              <div className="w-7 h-7 bg-[#0D9488]/10 rounded-full flex items-center justify-center shrink-0 text-xs text-[#0D9488]">1</div>
              <div>
                <p className="text-sm text-[#1a1a2e]">تواصل مع إدارة المبنى</p>
                <p className="text-xs text-[#5f6b7a] mt-0.5">تواصل مع رئيس اتحاد الملاك أو أمين الصندوق</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-[#f8fffe] rounded-xl">
              <div className="w-7 h-7 bg-[#0D9488]/10 rounded-full flex items-center justify-center shrink-0 text-xs text-[#0D9488]">2</div>
              <div>
                <p className="text-sm text-[#1a1a2e]">اطلب إعادة تعيين كلمة المرور</p>
                <p className="text-xs text-[#5f6b7a] mt-0.5">الإدارة تقدر تعيد تعيين كلمة مرورك من لوحة التحكم</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-[#f8fffe] rounded-xl">
              <div className="w-7 h-7 bg-[#0D9488]/10 rounded-full flex items-center justify-center shrink-0 text-xs text-[#0D9488]">3</div>
              <div>
                <p className="text-sm text-[#1a1a2e]">سجّل دخولك بكلمة المرور الجديدة</p>
                <p className="text-xs text-[#5f6b7a] mt-0.5">بعد ما الإدارة تعيّن كلمة مرور جديدة، سجّل دخولك بيها</p>
              </div>
            </div>
          </div>

          <button
            onClick={() => navigate("/login")}
            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20"
          >
            <ArrowLeft className="w-4 h-4" />
            العودة لتسجيل الدخول
          </button>
        </div>
      </motion.div>
    </div>
  );
}
