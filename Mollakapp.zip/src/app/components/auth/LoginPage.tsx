import { useState } from "react";
import { useNavigate } from "react-router";
import { Building2, Users, Shield, ArrowLeft, Home, Phone, Lock, Loader2, AlertCircle, ShieldBan } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useAuth } from "../../lib/auth";
import { normalizeToEnglishDigits } from "../../lib/phoneUtils";

function LoginFields({
  role,
  phone,
  password,
  onPhoneChange,
  onPasswordChange,
  onSubmit,
  isLoading,
  error,
  onForgotPassword,
}: {
  role: "union" | "resident";
  phone: string;
  password: string;
  onPhoneChange: (v: string) => void;
  onPasswordChange: (v: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
  error: string;
  onForgotPassword: () => void;
}) {
  const accentColor = role === "union" ? "#0D9488" : "#F59E0B";

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.25 }}
      className="overflow-hidden"
    >
      <div className="pt-3 pb-1 px-1 space-y-3">
        {/* Phone */}
        <div>
          <label className="text-sm text-[#5f6b7a] mb-1.5 block">رقم الموبيل</label>
          <div className="relative">
            <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" />
            <input
              type="tel"
              dir="ltr"
              placeholder="01XX XXX XXXX"
              value={phone}
              onChange={(e) => onPhoneChange(normalizeToEnglishDigits(e.target.value))}
              className="w-full pr-10 pl-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-right"
            />
          </div>
        </div>

        {/* Password */}
        <div>
          <label className="text-sm text-[#5f6b7a] mb-1.5 block">كلمة المرور</label>
          <div className="relative">
            <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" />
            <input
              type="password"
              placeholder="كلمة المرور"
              value={password}
              onChange={(e) => onPasswordChange(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && onSubmit()}
              className="w-full pr-10 pl-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
            />
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded-xl px-4 py-3 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        {/* Login Button */}
        <button
          onClick={onSubmit}
          disabled={isLoading}
          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl text-white transition-all text-sm font-medium disabled:opacity-60"
          style={{
            backgroundColor: accentColor,
            boxShadow: `0 4px 12px ${accentColor}33`,
          }}
        >
          {isLoading ? (
            <><Loader2 className="w-4 h-4 animate-spin" />جاري تسجيل الدخول...</>
          ) : (
            <>تسجيل الدخول <ArrowLeft className="w-4 h-4" /></>
          )}
        </button>

        {/* Forgot password */}
        <div className="text-center">
          <button onClick={onForgotPassword} className="text-sm text-[#5f6b7a] hover:text-[#0D9488] transition-colors">
            نسيت كلمة المرور؟
          </button>
        </div>
      </div>
    </motion.div>
  );
}

export function LoginPage() {
  const navigate = useNavigate();
  const { loginWithPhone, logout, banned } = useAuth();
  const [selectedRole, setSelectedRole] = useState<"union" | "resident" | null>(null);
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSelectRole = (role: "union" | "resident") => {
    if (selectedRole === role) return; // already selected
    setSelectedRole(role);
    setError("");
  };

  const handleLogin = async () => {
    if (!selectedRole) return;
    if (!phone || !password) {
      setError("أدخل رقم الموبيل وكلمة المرور");
      return;
    }
    setIsLoading(true);
    setError("");
    const result = await loginWithPhone(phone.trim(), password);
    setIsLoading(false);
    if (result.error) {
      setError(result.error);
    } else {
      const userRole = result.profile?.role;
      const isAdmin = userRole === "admin" || userRole === "treasurer" || userRole === "board_member";

      if (isAdmin) {
        // Admin/treasurer/board_member can access both portals — go to selected one
        if (selectedRole === "resident") {
          navigate("/resident");
        } else {
          navigate("/dashboard");
        }
      } else if (selectedRole === "union") {
        // Selected "union" but role is resident → sign out and block access
        await logout();
        setError("هذا الحساب مسجّل كـ «ساكن» وليس كعضو اتحاد — اختر «ساكن» لتسجيل الدخول أو تواصل مع رئيس الاتحاد لترقية صلاحياتك");
      } else {
        // Regular resident → resident portal
        navigate("/resident");
      }
    }
  };

  // Banned screen
  if (banned) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" dir="rtl" style={{ background: "linear-gradient(to bottom left, #f8fffe, white, rgba(13,148,136,0.05))" }}>
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-sm text-center"
        >
          <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ backgroundColor: "rgba(239,68,68,0.1)" }}>
            <ShieldBan className="w-10 h-10 text-[#ef4444]" />
          </div>
          <h1 className="text-2xl text-[#1a1a2e] font-bold mb-3">تم حظر حسابك</h1>
          <p className="text-sm text-[#5f6b7a] leading-relaxed mb-6">
            تم تعليق حسابك من قِبل إدارة المبنى. إذا كنت تعتقد أن هذا خطأ، يرجى التواصل مع رئيس الاتحاد أو إدارة المبنى لإعادة تفعيل حسابك.
          </p>
          <div className="rounded-xl px-4 py-3 mb-6" style={{ backgroundColor: "rgba(239,68,68,0.05)", border: "1px solid rgba(239,68,68,0.15)" }}>
            <p className="text-xs text-[#ef4444]">لا يمكنك تسجيل الدخول أثناء فترة الحظر</p>
          </div>
          <button
            onClick={() => { logout(); navigate("/"); }}
            className="w-full py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-all shadow-md" style={{ boxShadow: "0 4px 12px rgba(13,148,136,0.2)" }}
          >
            <Home className="w-4 h-4 inline ml-2" />العودة للرئيسية
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" dir="rtl" style={{ background: "linear-gradient(to bottom left, #f8fffe, white, rgba(13,148,136,0.05))" }}>
      {/* Back to home */}
      <button
        onClick={() => navigate("/")}
        className="absolute top-4 right-4 sm:top-6 sm:right-6 flex items-center gap-2 text-sm text-[#5f6b7a] hover:text-[#0D9488] transition-colors"
      >
        <Home className="w-4 h-4" />
        الرئيسية
      </button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#0D9488] rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-[#0D9488]/20">
            <Building2 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl text-[#1a1a2e] mb-1 font-bold">تسجيل الدخول</h1>
          <p className="text-base text-[#5f6b7a]">اختر نوع حسابك للدخول إلى مُلاك</p>
        </div>

        {/* Role Selection with inline fields */}
        <div className="bg-white rounded-2xl border border-[#0D9488]/10 p-5 sm:p-6 shadow-xl shadow-black/5">
          <p className="text-base text-[#5f6b7a] mb-4">أنا أدخل بصفتي:</p>

          <div className="space-y-3">
            {/* ===== Union Member ===== */}
            <div>
              <button
                onClick={() => handleSelectRole("union")}
                className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-right ${
                  selectedRole === "union"
                    ? "border-[#0D9488] bg-[#0D9488]/5"
                    : "border-[#0D9488]/10 hover:border-[#0D9488]/30 hover:bg-[#f8fffe]"
                }`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                  selectedRole === "union" ? "bg-[#0D9488] text-white" : "bg-[#0D9488]/10 text-[#0D9488]"
                }`}>
                  <Shield className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className={`text-base font-medium ${selectedRole === "union" ? "text-[#0D9488]" : "text-[#1a1a2e]"}`}>
                    عضو اتحاد ملاك
                  </div>
                  <div className="text-sm text-[#5f6b7a] mt-0.5">
                    رئيس،أمين،عضو
                  </div>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                  selectedRole === "union" ? "border-[#0D9488]" : "border-[#5f6b7a]/30"
                }`}>
                  {selectedRole === "union" && (
                    <div className="w-3 h-3 rounded-full bg-[#0D9488]" />
                  )}
                </div>
              </button>

              {/* Fields appear directly below union button */}
              <AnimatePresence>
                {selectedRole === "union" && (
                  <LoginFields
                    role="union"
                    phone={phone}
                    password={password}
                    onPhoneChange={setPhone}
                    onPasswordChange={setPassword}
                    onSubmit={handleLogin}
                    isLoading={isLoading}
                    error={error}
                    onForgotPassword={() => navigate("/forgot-password")}
                  />
                )}
              </AnimatePresence>
            </div>

            {/* ===== Resident ===== */}
            <div>
              <button
                onClick={() => handleSelectRole("resident")}
                className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-right ${
                  selectedRole === "resident"
                    ? "border-[#F59E0B] bg-[#F59E0B]/5"
                    : "border-[#0D9488]/10 hover:border-[#F59E0B]/30 hover:bg-[#fffcf5]"
                }`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                  selectedRole === "resident" ? "bg-[#F59E0B] text-white" : "bg-[#F59E0B]/10 text-[#F59E0B]"
                }`}>
                  <Users className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className={`text-base font-medium ${selectedRole === "resident" ? "text-[#F59E0B]" : "text-[#1a1a2e]"}`}>
                    ساكن
                  </div>
                  <div className="text-sm text-[#5f6b7a] mt-0.5">
                    مالك أو مستأجر
                  </div>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                  selectedRole === "resident" ? "border-[#F59E0B]" : "border-[#5f6b7a]/30"
                }`}>
                  {selectedRole === "resident" && (
                    <div className="w-3 h-3 rounded-full bg-[#F59E0B]" />
                  )}
                </div>
              </button>

              {/* Fields appear directly below resident button */}
              <AnimatePresence>
                {selectedRole === "resident" && (
                  <LoginFields
                    role="resident"
                    phone={phone}
                    password={password}
                    onPhoneChange={setPhone}
                    onPasswordChange={setPassword}
                    onSubmit={handleLogin}
                    isLoading={isLoading}
                    error={error}
                    onForgotPassword={() => navigate("/forgot-password")}
                  />
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Register link */}
        <div className="text-center mt-6">
          <p className="text-base text-[#5f6b7a]">
            ليس لديك حساب؟{" "}
            <button onClick={() => navigate("/register")} className="text-[#0D9488] hover:underline font-medium">
              سجّل مبناك الآن
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
}