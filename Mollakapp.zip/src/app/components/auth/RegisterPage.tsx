import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router";
import {
  Building2,
  User,
  Phone,
  Shield,
  MapPin,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Loader2,
  KeyRound,
  Hash,
  Home,
  Map,
  ChevronDown,
  Search,
  Lock,
  Wallet,
  AlertTriangle,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import * as api from "../../lib/api";
import { normalizeToEnglishDigits } from "../../lib/phoneUtils";
import { TITLES } from "../../lib/titles";

type Position = "رئيس اتحاد" | "أمين صندوق" | "عضو" | "";

interface AdminData {
  title: string;
  name: string;
  phone: string;
  otp: string;
  password: string;
  position: Position;
  otpSent: boolean;
  otpVerified: boolean;
}

interface BuildingData {
  name: string;
  floors: string;
  units: string;
  city: string;
  neighborhood: string;
  initialBalance: string;
  previousDebts: string;
  previousRevenues: string;
}

const positions: { value: Position; label: string; icon: typeof Shield; desc: string }[] = [
  { value: "رئيس اتحاد", label: "رئيس اتحاد", icon: Shield, desc: "المسؤول الأول عن إدارة البرج وتوزيع الصلاحيات" },
  { value: "أمين صندوق", label: "أمين صندوق", icon: KeyRound, desc: "المسؤول عن إدارة الأموال والفواتير والدفوعات" },
  { value: "عضو", label: "عضو", icon: User, desc: "عضو في اتحاد الملاك بصلاحيات محددة" },
];

const steps = [
  { id: 1, title: "بيانات المسؤول", icon: User },
  { id: 2, title: "بيانات البرج", icon: Building2 },
  { id: 3, title: "تم التسجيل", icon: CheckCircle2 },
];

const citiesWithNeighborhoods: Record<string, string[]> = {
  "القاهرة": ["المعادي", "مدينة نصر", "مصر الجديدة", "الزمالك", "المقطم", "التجمع الخامس", "الشروق", "العبور", "بدر", "الرحاب", "مدينتي", "حلوان", "شبرا", "عين شمس", "المرج", "دار السلام", "البساتين", "السيدة زينب", "الدقي", "العجوزة", "المهندسين", "الهرم", "فيصل", "حدائق الأهرام"],
  "الجيزة": ["الشيخ زايد", "أكتوبر", "الحوامدية", "البدرشين", "العياط", "الصف", "أطفيح", "الواحات", "منشأة القناطر", "أوسيم", "كرداسة", "أبو النمرس"],
  "الإسكندرية": ["المنتزه", "شرق", "وسط", "غرب", "العجمي", "العامرية", "برج العرب", "سموحة", "كليوباترا", "سيدي جابر", "محرم بك", "بحري", "الإبراهيمية", "لوران", "جليم", "ستانلي", "سان ستيفانو", "المندرة", "المعمورة", "أبو قير"],
  "الشرقية": ["الزقازيق", "العاشر من رمضان", "منيا القمح", "بلبيس", "أبو حماد", "فاقوس", "ههيا", "أبو كبير", "ديرب نجم", "الحسينية", "كفر صقر", "أولاد صقر"],
  "الدقهلية": ["المنصورة", "طلخا", "ميت غمر", "دكرنس", "أجا", "السنبلاوين", "بني عبيد", "المنزلة", "شربين", "تمي الأمديد", "الجمالية", "نبروه"],
  "البحيرة": ["دمنهور", "كفر الدوار", "رشيد", "إدكو", "أبو حمص", "الدلنجات", "إيتاي البارود", "حوش عيسى", "شبراخيت", "كوم حمادة", "بدر", "الرحمانية", "وادي النطرون"],
  "الغربية": ["طنطا", "المحلة الكبرى", "كفر الزيات", "زفتى", "السنطة", "بسيون", "قطور", "سمنود"],
  "المنوفية": ["شبين الكوم", "منوف", "مدينة السادات", "أشمون", "الباجور", "قويسنا", "بركة السبع", "تلا", "الشهداء"],
  "القليوبية": ["بنها", "شبرا الخيمة", "قليوب", "القناطر الخيرية", "الخانكة", "كفر شكر", "طوخ", "شبين القناطر", "العبور"],
  "كفر الشيخ": ["كفر الشيخ", "دسوق", "فوه", "بيلا", "الرياض", "الحامول", "بلطيم", "مطوبس", "سيدي سالم"],
  "الفيوم": ["الفيوم", "سنورس", "إطسا", "طامية", "أبشواي", "يوسف الصديق"],
  "بني سويف": ["بني سويف", "الواسطى", "ناصر", "إهناسيا", "ببا", "الفشن", "سمسطا"],
  "المنيا": ["المنيا", "ملوي", "أبو قرقاص", "سمالوط", "مغاغة", "بني مزار", "مطاي", "العدوة", "دير مواس"],
  "أسيوط": ["أسيوط", "ديروط", "القوصية", "منفلوط", "أبنوب", "الفتح", "ساحل سليم", "أبو تيج", "صدفا", "الغنايم", "البداري"],
  "سوهاج": ["سوهاج", "أخميم", "طهطا", "جرجا", "المراغة", "المنشأة", "البلينا", "دار السلام", "ساقلتة", "طما", "جهينة"],
  "قنا": ["قنا", "نجع حمادي", "أبو تشت", "فرشوط", "دشنا", "الوقف", "قوص", "نقادة", "قفط"],
  "الأقصر": ["الأقصر", "إسنا", "أرمنت", "الطود", "القرنة", "البياضية"],
  "أسوان": ["أسوان", "كوم أمبو", "نصر النوبة", "دراو", "إدفو", "أبو سمبل"],
  "البحر الأحمر": ["الغردقة", "سفاجا", "القصير", "مرسى علم", "رأس غارب", "الشلاتين", "حلايب"],
  "الوادي الجديد": ["الخارجة", "الداخلة", "الفرافرة", "باريس", "بلاط"],
  "مطروح": ["مرسى مطروح", "الحمام", "العلمين", "الضبعة", "النجيلة", "سيوة", "سيدي براني", "السلوم"],
  "شمال سيناء": ["العريش", "الشيخ زويد", "رفح", "بئر العبد", "الحسنة", "نخل"],
  "جنوب سيناء": ["شرم الشيخ", "دهب", "نويبع", "طابا", "سانت كاترين", "الطور", "رأس سدر", "أبو رديس", "أبو زنيمة"],
  "بورسعيد": ["بورسعيد", "بورفؤاد", "الزهور", "المناخ", "الشرق", "الضواحي", "العرب"],
  "الإسماعيلية": ["الإسماعيلية", "القنطرة شرق", "القنطرة غرب", "فايد", "التل الكبير", "أبو صوير"],
  "السويس": ["السويس", "الأربعين", "عتاقة", "الجناين", "فيصل"],
  "دمياط": ["دمياط", "رأس البر", "فارسكور", "كفر سعد", "الزرقا", "كفر البطيخ"],
  "العاصمة الإدارية": ["الحي الحكومي", "الحي السكني R1", "الحي السكني R2", "الحي السكني R3", "الحي السكني R5", "الحي السكني R7", "الحي السكني R8", "حي المال والأعمال", "الداون تاون"],
};

const cities = Object.keys(citiesWithNeighborhoods);

function SearchableSelect({
  label,
  required,
  icon: Icon,
  placeholder,
  options,
  value,
  onChange,
  disabled,
}: {
  label: string;
  required?: boolean;
  icon: typeof Map;
  placeholder: string;
  options: string[];
  value: string;
  onChange: (val: string) => void;
  disabled?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setIsOpen(false);
        setSearch("");
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filtered = options.filter((o) => o.includes(search));

  return (
    <div>
      <label className="block text-sm text-[#1a1a2e] mb-2">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <div className="relative" ref={ref}>
        <Icon className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a] z-10 pointer-events-none" />
        <button
          type="button"
          onClick={() => {
            if (!disabled) {
              setIsOpen(!isOpen);
              setSearch("");
            }
          }}
          disabled={disabled}
          className={`w-full pr-11 pl-9 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl text-right text-sm transition-all flex items-center justify-between ${
            disabled ? "opacity-50 cursor-not-allowed" : "hover:border-[#0D9488]/30 cursor-pointer"
          } ${isOpen ? "ring-2 ring-[#0D9488]/30 border-[#0D9488] bg-white" : ""}`}
        >
          <span className={value ? "text-[#1a1a2e]" : "text-[#9ca3af]"}>
            {value || placeholder}
          </span>
        </button>
        <ChevronDown
          className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a] transition-transform pointer-events-none ${
            isOpen ? "rotate-180" : ""
          }`}
        />

        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.15 }}
              className="absolute z-50 top-full mt-2 w-full bg-white rounded-xl border border-[#0D9488]/15 shadow-xl shadow-black/10 overflow-hidden"
            >
              {/* Search inside dropdown */}
              <div className="p-2 border-b border-[#f0f5f4]">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" />
                  <input
                    type="text"
                    placeholder="ابحث..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full pr-9 pl-3 py-2.5 bg-[#f0f5f4] rounded-lg text-sm focus:outline-none"
                    autoFocus
                  />
                </div>
              </div>
              <div className="max-h-48 overflow-y-auto">
                {filtered.length === 0 ? (
                  <div className="p-4 text-center text-sm text-[#5f6b7a]">لا توجد نتائج</div>
                ) : (
                  filtered.map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => {
                        onChange(option);
                        setIsOpen(false);
                        setSearch("");
                      }}
                      className={`w-full text-right px-4 py-3 text-sm transition-colors hover:bg-[#0D9488]/5 ${
                        value === option
                          ? "bg-[#0D9488]/10 text-[#0D9488]"
                          : "text-[#1a1a2e]"
                      }`}
                    >
                      {option}
                      {value === option && (
                        <CheckCircle2 className="inline-block w-4 h-4 mr-2 text-[#0D9488]" />
                      )}
                    </button>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export function RegisterPage() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [registerError, setRegisterError] = useState("");
  const [registeredSlug, setRegisteredSlug] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [phoneChecking, setPhoneChecking] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const linkInputRef = useRef<HTMLInputElement>(null);

  const [admin, setAdmin] = useState<AdminData>({
    title: "",
    name: "",
    phone: "",
    otp: "",
    password: "",
    position: "",
    otpSent: false,
    otpVerified: false,
  });

  const [building, setBuilding] = useState<BuildingData>({
    name: "",
    floors: "",
    units: "",
    city: "",
    neighborhood: "",
    initialBalance: "",
    previousDebts: "",
    previousRevenues: "",
  });

  const neighborhoods = building.city ? citiesWithNeighborhoods[building.city] || [] : [];

  const handlePhoneBlur = async () => {
    const phone = admin.phone.replace(/\s/g, "");
    if (phone.length < 10) {
      setPhoneError("");
      return;
    }
    setPhoneChecking(true);
    setPhoneError("");
    try {
      const exists = await api.checkPhoneExists(phone);
      if (exists) {
        setPhoneError(`رقم الجوال ${phone} مسجّل بالفعل في مبنى آخر — استخدم رقم مختلف أو سجّل دخول بحسابك الحالي`);
      }
    } catch {
      // fail silently
    } finally {
      setPhoneChecking(false);
    }
  };

  const handleSendOtp = () => {
    if (!admin.phone || admin.phone.length < 10 || phoneError) return;
    setIsLoading(true);
    setTimeout(() => {
      setAdmin((prev) => ({ ...prev, otpSent: true }));
      setIsLoading(false);
    }, 1500);
  };

  const handleVerifyOtp = () => {
    if (admin.otp.length < 4) return;
    setIsLoading(true);
    setTimeout(() => {
      setAdmin((prev) => ({ ...prev, otpVerified: true }));
      setIsLoading(false);
    }, 1200);
  };

  const canProceedStep1 =
    admin.name.trim() !== "" &&
    admin.phone.trim() !== "" &&
    !phoneError &&
    admin.otpVerified &&
    admin.password.length >= 6 &&
    admin.position !== "";

  const canProceedStep2 =
    building.name.trim() !== "" &&
    building.floors.trim() !== "" &&
    building.units.trim() !== "" &&
    building.city.trim() !== "" &&
    building.neighborhood.trim() !== "";

  const handleNext = async () => {
    if (currentStep === 1 && canProceedStep1) {
      setCurrentStep(2);
    } else if (currentStep === 2 && canProceedStep2) {
      setIsLoading(true);
      setRegisterError("");
      try {
        const floors = parseInt(normalizeToEnglishDigits(building.floors), 10);
        const totalUnits = parseInt(normalizeToEnglishDigits(building.units), 10);

        // Safety check: ensure parsed values are valid numbers
        if (isNaN(floors) || floors < 1) {
          setRegisterError("يرجى إدخال عدد أدوار صحيح (1 أو أكثر)");
          setIsLoading(false);
          return;
        }
        if (isNaN(totalUnits) || totalUnits < 1) {
          setRegisterError("يرجى إدخال عدد وحدات صحيح (1 أو أكثر)");
          setIsLoading(false);
          return;
        }
        if (!building.name.trim()) {
          setRegisterError("يرجى إدخال اسم البرج");
          setIsLoading(false);
          return;
        }

        const unitsPerFloor = Math.ceil(totalUnits / floors);

        const result = await api.registerBuilding({
          name: building.name.trim(),
          address: building.neighborhood,
          city: building.city,
          floors,
          defaultUnitsPerFloor: unitsPerFloor,
          initialBalance: building.initialBalance ? parseFloat(building.initialBalance) : 0,
          previousDebts: building.previousDebts ? parseFloat(building.previousDebts) : 0,
          previousRevenues: building.previousRevenues ? parseFloat(building.previousRevenues) : 0,
          admin: {
            name: admin.title ? `${admin.title} ${admin.name.trim()}` : admin.name.trim(),
            phone: admin.phone.trim(),
            email: "",
            role: admin.position,
            password: admin.password,
          },
        });

        // Save the real slug from the API response
        if (result.building?.slug) {
          setRegisteredSlug(result.building.slug);
        }

        setCurrentStep(3);
      } catch (err: any) {
        console.error("Registration error:", err);
        setRegisterError(err.message || "حدث خطأ أثناء التسجيل. حاول مرة أخرى.");
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleBack = () => {
    if (currentStep > 1 && currentStep < 3) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(to bottom left, rgba(13,148,136,0.05), #f8fffe, rgba(245,158,11,0.05))' }}
    >
      <div className="w-full max-w-2xl">
        {/* Stepper */}
        <div className="flex items-center justify-center gap-0 mb-8 px-4">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center">
              <div className="flex flex-col items-center">
                <div
                  className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${
                    currentStep >= step.id
                      ? currentStep > step.id
                        ? "bg-[#0D9488] text-white"
                        : "bg-[#0D9488] text-white shadow-lg shadow-[#0D9488]/30"
                      : "bg-[#f0f5f4] text-[#5f6b7a]"
                  }`}
                >
                  {currentStep > step.id ? (
                    <CheckCircle2 className="w-5 h-5" />
                  ) : (
                    <step.icon className="w-5 h-5" />
                  )}
                </div>
              </div>
              {index < steps.length - 1 && (
                <div
                  className={`w-16 sm:w-24 h-0.5 mx-2 transition-all ${
                    currentStep > step.id ? "bg-[#0D9488]" : "bg-[#e0e0e0]"
                  }`}
                />
              )}
            </div>
          ))}
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-3xl shadow-xl shadow-[#0D9488]/5 border border-[#0D9488]/10 overflow-hidden">
          <AnimatePresence mode="wait">
            {/* Step 1: Admin Data */}
            {currentStep === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.3 }}
                className="p-6 sm:p-8"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-[#0D9488]/10 rounded-xl flex items-center justify-center">
                    <User className="w-5 h-5 text-[#0D9488]" />
                  </div>
                  <div>
                    <h2 className="text-lg text-[#1a1a2e]">بيانات المسؤول</h2>
                  </div>
                </div>

                <div className="space-y-5">
                  {/* Title */}
                  <div>
                    <label className="block text-sm text-[#1a1a2e] mb-2">
                      اللقب <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={admin.title}
                      onChange={(e) => setAdmin((prev) => ({ ...prev, title: e.target.value }))}
                      className="w-full pr-3 pl-2 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm appearance-none cursor-pointer"
                    >
                      {TITLES.map((t) => (
                        <option key={t.value} value={t.value}>{t.label}</option>
                      ))}
                    </select>
                  </div>

                  {/* Name */}
                  <div>
                    <label className="block text-sm text-[#1a1a2e] mb-2">
                      الاسم الكامل <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                      <input
                        type="text"
                        placeholder="مثال: أحمد محمد"
                        value={admin.name}
                        onChange={(e) => setAdmin((prev) => ({ ...prev, name: e.target.value }))}
                        className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm"
                      />
                    </div>
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-sm text-[#1a1a2e] mb-2">
                      رقم الموبيل <span className="text-red-500">*</span>
                    </label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                        <input
                          type="tel"
                          placeholder="01XX XXX XXXX"
                          value={admin.phone}
                          onChange={(e) => {
                            const normalized = normalizeToEnglishDigits(e.target.value);
                            setPhoneError("");
                            setAdmin((prev) => ({
                              ...prev,
                              phone: normalized,
                              otpSent: false,
                              otpVerified: false,
                              otp: "",
                            }));
                          }}
                          disabled={admin.otpVerified}
                          className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm disabled:opacity-60"
                          dir="ltr"
                          onBlur={handlePhoneBlur}
                        />
                      </div>
                      {!admin.otpVerified && (
                        <button
                          onClick={handleSendOtp}
                          disabled={
                            isLoading || admin.phone.length < 10 || admin.otpSent || !!phoneError
                          }
                          className="shrink-0 bg-[#0D9488] text-white px-5 py-3.5 rounded-xl hover:bg-[#0D9488]/90 transition-all text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                          {isLoading && admin.phone.length >= 10 && !admin.otpSent ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : null}
                          {admin.otpSent ? "تم الإرسال" : "إرسال كود"}
                        </button>
                      )}
                      {admin.otpVerified && (
                        <div className="shrink-0 flex items-center gap-2 bg-green-50 text-green-600 px-4 py-3.5 rounded-xl text-sm">
                          <CheckCircle2 className="w-4 h-4" />
                          تم التأكيد
                        </div>
                      )}
                    </div>
                    {phoneError && (
                      <p className="text-xs text-red-500 mt-1">{phoneError}</p>
                    )}
                    {phoneChecking && (
                      <p className="text-xs text-[#5f6b7a] mt-1">جارٍ التحقق من رقم الموبيل...</p>
                    )}
                  </div>

                  {/* OTP */}
                  {admin.otpSent && !admin.otpVerified && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="overflow-hidden"
                    >
                      <label className="block text-sm text-[#1a1a2e] mb-2">
                        كود التأكيد <span className="text-red-500">*</span>
                      </label>
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <Hash className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                          <input
                            type="text"
                            placeholder="أدخل الكود المكون من 4 أرقام"
                            value={admin.otp}
                            onChange={(e) =>
                              setAdmin((prev) => ({
                                ...prev,
                                otp: e.target.value.replace(/\D/g, "").slice(0, 4),
                              }))
                            }
                            maxLength={4}
                            className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm"
                            dir="ltr"
                          />
                        </div>
                        <button
                          onClick={handleVerifyOtp}
                          disabled={isLoading || admin.otp.length < 4}
                          className="shrink-0 bg-[#F59E0B] text-white px-5 py-3.5 rounded-xl hover:bg-[#F59E0B]/90 transition-all text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                        >
                          {isLoading && admin.otp.length >= 4 ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : null}
                          تأكيد
                        </button>
                      </div>
                      <p className="text-xs text-[#5f6b7a] mt-2">
                        تم إرسال كود التأكيد إلى {admin.phone} —{" "}
                        <button
                          className="text-[#0D9488] underline"
                          onClick={() => setAdmin((prev) => ({ ...prev, otpSent: false, otp: "" }))}
                        >
                          إعادة الإرسال
                        </button>
                      </p>
                    </motion.div>
                  )}

                  {/* Password — appears after OTP verified */}
                  {admin.otpVerified && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="overflow-hidden"
                    >
                      <label className="block text-sm text-[#1a1a2e] mb-2">
                        كلمة المرور <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                        <input
                          type="password"
                          placeholder="اختر كلمة مرور قوية (6 أحرف على الأقل)"
                          value={admin.password}
                          onChange={(e) =>
                            setAdmin((prev) => ({ ...prev, password: e.target.value }))
                          }
                          className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm"
                        />
                      </div>
                      {admin.password.length > 0 && admin.password.length < 6 && (
                        <p className="text-xs text-red-500 mt-1">كلمة المرور يجب أن تكون 6 أحرف على الأقل</p>
                      )}
                    </motion.div>
                  )}

                  {/* Position — appears after password is valid */}
                   {admin.password.length >= 6 && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="overflow-hidden"
                    >
                    <label className="block text-sm text-[#1a1a2e] mb-3">
                      المنصب <span className="text-red-500">*</span>
                    </label>
                    <div className="grid gap-3">
                      {positions.map((pos) => (
                        <button
                          key={pos.value}
                          onClick={() =>
                            setAdmin((prev) => ({ ...prev, position: pos.value }))
                          }
                          className={`flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-right ${
                            admin.position === pos.value
                              ? "border-[#0D9488] bg-[#0D9488]/5 shadow-sm"
                              : "border-[#f0f5f4] bg-[#f0f5f4] hover:border-[#0D9488]/30"
                          }`}
                        >
                          <div
                            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                              admin.position === pos.value
                                ? "bg-[#0D9488] text-white"
                                : "bg-white text-[#5f6b7a]"
                            }`}
                          >
                            <pos.icon className="w-5 h-5" />
                          </div>
                          <div className="flex-1">
                            <div
                              className={`text-sm ${
                                admin.position === pos.value
                                  ? "text-[#0D9488]"
                                  : "text-[#1a1a2e]"
                              }`}
                            >
                              {pos.label}
                            </div>
                            <div className="text-xs text-[#5f6b7a] mt-0.5">{pos.desc}</div>
                          </div>
                          <div
                            className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                              admin.position === pos.value
                                ? "border-[#0D9488] bg-[#0D9488]"
                                : "border-[#cbced4]"
                            }`}
                          >
                            {admin.position === pos.value && (
                              <CheckCircle2 className="w-4 h-4 text-white" />
                            )}
                          </div>
                        </button>
                      ))}
                    </div>
                    </motion.div>
                   )}
                </div>
              </motion.div>
            )}

            {/* Step 2: Building Data */}
            {currentStep === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.3 }}
                className="p-6 sm:p-8"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-[#F59E0B]/10 rounded-xl flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-[#F59E0B]" />
                  </div>
                  <div>
                    <h2 className="text-lg text-[#1a1a2e]">بيانات البرج</h2>
                  </div>
                </div>

                <div className="space-y-5">
                  {/* Building Name */}
                  <div>
                    <label className="block text-sm text-[#1a1a2e] mb-2">
                      اسم البرج <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Building2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                      <input
                        type="text"
                        placeholder="مثال: برج الصفا"
                        value={building.name}
                        onChange={(e) =>
                          setBuilding((prev) => ({ ...prev, name: e.target.value }))
                        }
                        className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm"
                      />
                    </div>
                  </div>

                  {/* Floors & Units */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm text-[#1a1a2e] mb-2">
                        عدد الأدوار <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Hash className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                        <input
                          type="number"
                          placeholder="12"
                          min={1}
                          value={building.floors}
                          onChange={(e) =>
                            setBuilding((prev) => ({ ...prev, floors: normalizeToEnglishDigits(e.target.value) }))
                          }
                          className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm"
                          dir="ltr"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm text-[#1a1a2e] mb-2">
                        عدد الوحدات <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Home className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
                        <input
                          type="number"
                          placeholder="48"
                          min={1}
                          value={building.units}
                          onChange={(e) =>
                            setBuilding((prev) => ({ ...prev, units: normalizeToEnglishDigits(e.target.value) }))
                          }
                          className="w-full pr-11 pl-4 py-3.5 bg-[#f0f5f4] border border-transparent rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/30 focus:border-[#0D9488] focus:bg-white transition-all text-sm"
                          dir="ltr"
                        />
                      </div>
                    </div>
                  </div>

                  {/* City & Neighborhood Dropdowns */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <SearchableSelect
                      label="المحافظة"
                      required
                      icon={Map}
                      placeholder="اختر المحافظة"
                      options={cities}
                      value={building.city}
                      onChange={(val) =>
                        setBuilding((prev) => ({ ...prev, city: val, neighborhood: "" }))
                      }
                    />
                    <SearchableSelect
                      label="المدينة / الحي"
                      required
                      icon={MapPin}
                      placeholder="اختر المدينة"
                      options={neighborhoods}
                      value={building.neighborhood}
                      onChange={(val) =>
                        setBuilding((prev) => ({ ...prev, neighborhood: val }))
                      }
                      disabled={!building.city}
                    />
                  </div>

                  {/* Financial Starting Point */}
                  <div className="bg-[#F59E0B]/5 border border-[#F59E0B]/10 rounded-xl p-4 space-y-4">
                    <div className="flex items-center gap-2 text-sm text-[#1a1a2e]">
                      <Wallet className="w-4 h-4 text-[#F59E0B]" />
                      الوضع المالي قبل مُلاك
                      <span className="text-[10px] text-[#5f6b7a] bg-[#F59E0B]/10 px-2 py-0.5 rounded-full">اختياري</span>
                    </div>
                    <p className="text-[11px] text-[#5f6b7a] -mt-2">
                      لو الاتحاد عنده رصيد محفوظ أو مديونيات من قبل، سجّلها هنا عشان الحسابات تكون دقيقة
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs text-[#5f6b7a] mb-1.5">
                          <span className="flex items-center gap-1">
                            <Wallet className="w-3 h-3 text-[#0D9488]" />
                            رصيد حالي (ج.م)
                          </span>
                        </label>
                        <input
                          type="number"
                          inputMode="decimal"
                          value={building.initialBalance}
                          onChange={(e) => setBuilding((prev) => ({ ...prev, initialBalance: e.target.value }))}
                          placeholder="0"
                          min="0"
                          className="w-full px-3 py-2.5 bg-white rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm transition-all text-left"
                          dir="ltr"
                        />
                        <p className="text-[10px] text-[#5f6b7a]/70 mt-1">المبلغ المحفوظ مع أمين الصندوق</p>
                      </div>
                      <div>
                        <label className="block text-xs text-[#5f6b7a] mb-1.5">
                          <span className="flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 text-[#F59E0B]" />
                            مديونيات سابقة (ج.م)
                          </span>
                        </label>
                        <input
                          type="number"
                          inputMode="decimal"
                          value={building.previousDebts}
                          onChange={(e) => setBuilding((prev) => ({ ...prev, previousDebts: e.target.value }))}
                          placeholder="0"
                          min="0"
                          className="w-full px-3 py-2.5 bg-white rounded-xl border border-gray-200 focus:border-[#F59E0B] focus:ring-2 focus:ring-[#F59E0B]/10 outline-none text-sm transition-all text-left"
                          dir="ltr"
                        />
                        <p className="text-[10px] text-[#5f6b7a]/70 mt-1">مبالغ مستحقة على السكان من قبل</p>
                      </div>
                      <div>
                        <label className="block text-xs text-[#5f6b7a] mb-1.5">
                          <span className="flex items-center gap-1">
                            <Wallet className="w-3 h-3 text-[#22c55e]" />
                            إيرادات سابقة (ج.م)
                          </span>
                        </label>
                        <input
                          type="number"
                          inputMode="decimal"
                          value={building.previousRevenues}
                          onChange={(e) => setBuilding((prev) => ({ ...prev, previousRevenues: e.target.value }))}
                          placeholder="0"
                          min="0"
                          className="w-full px-3 py-2.5 bg-white rounded-xl border border-gray-200 focus:border-[#22c55e] focus:ring-2 focus:ring-[#22c55e]/10 outline-none text-sm transition-all text-left"
                          dir="ltr"
                        />
                        <p className="text-[10px] text-[#5f6b7a]/70 mt-1">إيرادات تم تحصيلها قبل استخدام مُلاك</p>
                      </div>
                    </div>
                  </div>

                  {/* Registration Error */}
                  {registerError && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-red-50 border border-red-200 rounded-xl p-4 text-right"
                    >
                      <p className="text-sm text-red-600">{registerError}</p>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Step 3: Success */}
            {currentStep === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
                className="p-6 sm:p-10 text-center"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  className="w-20 h-20 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto mb-6"
                >
                  <CheckCircle2 className="w-10 h-10 text-[#0D9488]" />
                </motion.div>

                <h2 className="text-2xl text-[#1a1a2e] mb-2">تم التسجيل بنجاح!</h2>
                <p className="text-sm text-[#5f6b7a] mb-4 max-w-md mx-auto">
                  تم تسجيل <strong className="text-[#0D9488]">{building.name}</strong> بنجاح.
                  يمكنك الآن إدارة برجك ودعوة السكان من خلال لوحة التحكم.
                </p>
                <div className="bg-[#0D9488]/5 border border-[#0D9488]/15 rounded-xl p-3 max-w-md mx-auto mb-8">
                  <p className="text-xs text-[#5f6b7a] text-center">
                    سجّل دخولك من صفحة تسجيل الدخول بـ<strong className="text-[#0D9488]"> رقم جوالك </strong>وكلمة المرور اللي اخترتها
                  </p>
                </div>

                {/* Summary */}
                <div className="bg-[#f0f5f4] rounded-2xl p-5 text-right max-w-md mx-auto mb-8">
                  <div className="text-xs text-[#5f6b7a] mb-3">ملخص التسجيل</div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">المسؤول</span>
                      <span className="text-[#1a1a2e]">{admin.name}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">المنصب</span>
                      <span className="text-[#0D9488]">{admin.position}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">البرج</span>
                      <span className="text-[#1a1a2e]">{building.name}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">الأدوار / الوحدات</span>
                      <span className="text-[#1a1a2e]">
                        {building.floors} دور — {building.units} وحدة
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#5f6b7a]">الموقع</span>
                      <span className="text-[#1a1a2e]">
                        {building.neighborhood}، {building.city}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Invite Link - removed */}

                <button
                  onClick={() => navigate("/login")}
                  className="inline-flex items-center gap-2 bg-[#0D9488] text-white px-8 py-4 rounded-xl hover:bg-[#0D9488]/90 transition-all shadow-lg shadow-[#0D9488]/25"
                >
                  تسجيل الدخول
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Navigation Buttons */}
          {currentStep < 3 && (
            <div className="flex items-center justify-between p-6 sm:px-8 border-t border-[#0D9488]/10 bg-[#f8fffe]">
              {currentStep > 1 ? (
                <button
                  onClick={handleBack}
                  className="flex items-center gap-2 text-sm text-[#5f6b7a] hover:text-[#0D9488] transition-colors"
                >
                  <ArrowRight className="w-4 h-4" />
                  رجوع
                </button>
              ) : (
                <button
                  onClick={() => navigate("/")}
                  className="flex items-center gap-2 text-sm text-[#5f6b7a] hover:text-[#0D9488] transition-colors"
                >
                  <ArrowRight className="w-4 h-4" />
                  الرئيسية
                </button>
              )}

              <button
                onClick={handleNext}
                disabled={
                  isLoading ||
                  (currentStep === 1 && !canProceedStep1) ||
                  (currentStep === 2 && !canProceedStep2)
                }
                className="flex items-center gap-2 bg-[#0D9488] text-white px-6 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20 text-sm disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
              >
                {isLoading && currentStep === 2 ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    جاري التسجيل...
                  </>
                ) : (
                  <>
                    {currentStep === 2 ? "تسجيل البرج" : "التالي"}
                    <ArrowLeft className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-[#5f6b7a] mt-6">
          بالتسجيل أنت توافق على{" "}
          <a href="#" className="text-[#0D9488] underline">
            الشروط والأحكام
          </a>{" "}
          و{" "}
          <a href="#" className="text-[#0D9488] underline">
            سياسة الخصوصية
          </a>
        </p>
      </div>
    </div>
  );
}