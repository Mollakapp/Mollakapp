import { useState, useEffect, useCallback } from "react";
import { Download, X, Smartphone } from "lucide-react";

/**
 * PWA Install Banner — يظهر على Android/Chrome عندما يكون التطبيق قابل للتثبيت.
 * يلتقط event الـ `beforeinstallprompt` ويعرض بانر مخصص بتصميم مُلاك.
 * - لا يظهر لو التطبيق مثبّت فعلاً (standalone mode).
 * - لا يظهر لو المستخدم رفض التثبيت (يحفظ في localStorage لـ 7 أيام).
 * - يظهر بعد 3 ثوانٍ من فتح التطبيق عشان ما يزعجش المستخدم فوراً.
 */

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

const DISMISSED_KEY = "mollak-pwa-install-dismissed";
const DISMISS_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 days

function wasDismissedRecently(): boolean {
  try {
    const val = localStorage.getItem(DISMISSED_KEY);
    if (!val) return false;
    const ts = parseInt(val, 10);
    return Date.now() - ts < DISMISS_DURATION;
  } catch {
    return false;
  }
}

function isStandalone(): boolean {
  // Check if running in PWA standalone mode
  if (window.matchMedia("(display-mode: standalone)").matches) return true;
  if ((navigator as any).standalone === true) return true; // iOS Safari
  return false;
}

export function PwaInstallBanner() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [visible, setVisible] = useState(false);
  const [installing, setInstalling] = useState(false);

  useEffect(() => {
    // Don't show if already installed or dismissed recently
    if (isStandalone() || wasDismissedRecently()) return;

    const handler = (e: Event) => {
      // Prevent Chrome's default mini-infobar
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      // Show banner after a short delay for better UX
      setTimeout(() => setVisible(true), 3000);
    };

    window.addEventListener("beforeinstallprompt", handler);

    // Listen for successful install
    const installHandler = () => {
      setVisible(false);
      setDeferredPrompt(null);
    };
    window.addEventListener("appinstalled", installHandler);

    return () => {
      window.removeEventListener("beforeinstallprompt", handler);
      window.removeEventListener("appinstalled", installHandler);
    };
  }, []);

  const handleInstall = useCallback(async () => {
    if (!deferredPrompt) return;
    setInstalling(true);
    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "dismissed") {
        localStorage.setItem(DISMISSED_KEY, String(Date.now()));
      }
    } catch (err) {
      console.error("PWA install error:", err);
    } finally {
      setVisible(false);
      setDeferredPrompt(null);
      setInstalling(false);
    }
  }, [deferredPrompt]);

  const handleDismiss = useCallback(() => {
    setVisible(false);
    localStorage.setItem(DISMISSED_KEY, String(Date.now()));
  }, []);

  if (!visible || !deferredPrompt) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-[9998]"
        style={{ backgroundColor: "rgba(0,0,0,0.25)" }}
        onClick={handleDismiss}
      />

      {/* Banner — Bottom Sheet style */}
      <div
        className="fixed bottom-0 left-0 right-0 z-[9999] bg-white rounded-t-2xl shadow-2xl"
        style={{
          animation: "slideUpBanner 0.35s cubic-bezier(0.32, 0.72, 0, 1) forwards",
        }}
      >
        {/* Handle bar */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full bg-gray-200" />
        </div>

        <div className="px-5 pb-5">
          {/* Header */}
          <div className="flex items-start gap-3.5 mb-4">
            {/* App Icon */}
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-sm"
              style={{ background: "linear-gradient(135deg, #0fa89b, #0D9488)" }}
            >
              <Smartphone className="w-7 h-7 text-white" />
            </div>

            <div className="flex-1 min-w-0">
              <h3 className="text-base font-bold text-[#1a1a2e] mb-0.5">تثبيت مُلاك</h3>
              <p className="text-xs text-[#5f6b7a] leading-relaxed">
                ثبّت التطبيق على جهازك للوصول السريع بدون متصفح
              </p>
            </div>

            {/* Close */}
            <button
              onClick={handleDismiss}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-[#5f6b7a] hover:bg-gray-100 transition-colors shrink-0 mt-0.5"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Features row */}
          <div className="flex items-center gap-3 mb-4 text-[11px] text-[#5f6b7a]">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#0D9488]" />
              وصول فوري
            </span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
              بدون متصفح
            </span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#22c55e]" />
              مساحة صغيرة
            </span>
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleDismiss}
              className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm font-medium transition-colors hover:bg-gray-50"
            >
              لاحقاً
            </button>
            <button
              onClick={handleInstall}
              disabled={installing}
              className="flex-1 py-3 rounded-xl text-white text-sm font-medium flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.97]"
              style={{
                background: "linear-gradient(135deg, #0fa89b, #0D9488)",
                boxShadow: "0 4px 14px rgba(13, 148, 136, 0.3)",
              }}
            >
              {installing ? (
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              {installing ? "جاري التثبيت..." : "تثبيت التطبيق"}
            </button>
          </div>
        </div>

        {/* Safe area bottom */}
        <div style={{ height: "env(safe-area-inset-bottom)" }} />

        {/* Inline animation keyframes */}
        <style>{`
          @keyframes slideUpBanner {
            from { transform: translateY(100%); }
            to { transform: translateY(0); }
          }
        `}</style>
      </div>
    </>
  );
}
