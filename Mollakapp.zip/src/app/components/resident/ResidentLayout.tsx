import { useState, useEffect, useCallback } from "react";
import { Outlet, useNavigate, useLocation, Navigate } from "react-router";
import {
  LayoutDashboard,
  FileText,
  MessageCircle,
  Megaphone,
  Phone,
  CalendarHeart,
  Heart,
  Vote,
  Settings,
  LogOut,
  Menu,
  X,
  Bell,
  Home,
  Loader2,
  Banknote,
  Zap,
  Flame,
  Droplets,
  ArrowLeftRight,
  ClipboardList,
  Check,
  CheckCircle2,
  UserCheck,
  AlertTriangle,
  PartyPopper,
  FilePlus,
} from "lucide-react";
import { useAuth } from "../../lib/auth";
import * as api from "../../lib/api";

const iconMap: Record<string, typeof Bell> = {
  CheckCircle: CheckCircle2,
  Heart: Heart,
  Megaphone: Megaphone,
  UserCheck: UserCheck,
  FileText: FileText,
  FilePlus: FilePlus,
  MessageCircle: MessageCircle,
  Vote: Vote,
  Banknote: Banknote,
  AlertTriangle: AlertTriangle,
  CalendarHeart: CalendarHeart,
  ClipboardList: ClipboardList,
  PartyPopper: PartyPopper,
};

// Map notification types to resident routes
const notifRouteMap: Record<string, string> = {
  invoice: "/resident/invoices",
  invoice_paid: "/resident/invoices",
  announcement: "/resident",
  event: "/resident/events",
  donation: "/resident/donations",
  donation_confirmed: "/resident/donations",
  poll: "/resident/voting",
  dm: "/resident/chat",
  service_request: "/resident/service-requests",
  service_request_update: "/resident/service-requests",
  join_approved: "/resident",
  role_changed: "/resident",
};

function timeAgo(timestamp: string): string {
  const diff = Date.now() - new Date(timestamp).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "الآن";
  if (mins < 60) return `منذ ${mins} د`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `منذ ${hours} س`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `منذ ${days} يوم`;
  return new Date(timestamp).toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "short" });
}

const residentMenuItems = [
  { id: "overview", label: "الرئيسية", icon: LayoutDashboard, path: "/resident" },
  { id: "invoices", label: "فواتيري", icon: FileText, path: "/resident/invoices" },
  { id: "residents", label: "المُلاك", icon: UserCheck, path: "/resident/residents" },
  { id: "service-requests", label: "طلباتي", icon: ClipboardList, path: "/resident/service-requests" },
  { id: "voting", label: "التصويت", icon: Vote, path: "/resident/voting" },
  { id: "directory", label: "الأرقام", icon: Phone, path: "/resident/directory" },
  { id: "events", label: "المناسبات", icon: CalendarHeart, path: "/resident/events" },
  { id: "donations", label: "التبرعات", icon: Heart, path: "/resident/donations" },
];

export function ResidentLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isLargeScreen, setIsLargeScreen] = useState(() =>
    typeof window !== "undefined" ? window.matchMedia("(min-width: 1024px)").matches : false
  );
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState<api.AppNotification[]>([]);
  const [notifLoading, setNotifLoading] = useState(false);
  const [unreadChatCount, setUnreadChatCount] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();
  const { session, profile, loading, logout } = useAuth();

  // Track screen size for sidebar behavior
  useEffect(() => {
    const mql = window.matchMedia("(min-width: 1024px)");
    const handler = (e: MediaQueryListEvent) => setIsLargeScreen(e.matches);
    mql.addEventListener("change", handler);
    setIsLargeScreen(mql.matches);
    return () => mql.removeEventListener("change", handler);
  }, []);

  const isActive = (path: string) => {
    if (path === "/resident") return location.pathname === "/resident";
    return location.pathname.startsWith(path);
  };

  // Load notifications
  const loadNotifications = useCallback(async () => {
    if (!profile?.phone) return;
    try {
      setNotifLoading(true);
      const data = await api.getNotifications(profile.phone);
      setNotifications(data);
    } catch (err) {
      console.error("Error loading notifications:", err);
    } finally {
      setNotifLoading(false);
    }
  }, [profile?.phone]);

  useEffect(() => {
    if (loading || !session || !profile?.phone) return;
    loadNotifications();
    const interval = setInterval(loadNotifications, 30000);
    return () => clearInterval(interval);
  }, [loadNotifications, loading, session, profile?.phone]);

  // Reload when dropdown opens
  useEffect(() => {
    if (notifOpen) loadNotifications();
  }, [notifOpen, loadNotifications]);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleMarkRead = async (id: string) => {
    if (!profile?.phone) return;
    try {
      await api.markNotificationRead(id, profile.phone);
      setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, read: true } : n));
    } catch (err) {
      console.error("Error marking notification read:", err);
    }
  };

  const handleNotifClick = async (notif: api.AppNotification) => {
    // Mark as read if unread
    if (!notif.read) {
      handleMarkRead(notif.id);
    }
    // Navigate to relevant page
    const route = notifRouteMap[notif.type];
    if (route) {
      setNotifOpen(false);
      navigate(route);
    }
  };

  const handleMarkAllRead = async () => {
    if (!profile?.phone) return;
    try {
      await api.markAllNotificationsRead(profile.phone);
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    } catch (err) {
      console.error("Error marking all notifications read:", err);
    }
  };

  // Check for unread chat messages — MUST be before any early returns
  useEffect(() => {
    if (loading || !session || !profile?.phone) return;
    const loadUnreadDm = async () => {
      try {
        const conversations = await api.getDMList(profile.phone);
        const totalUnread = conversations.reduce((sum, c) => sum + (c.unread || 0), 0);
        setUnreadChatCount(totalUnread);
      } catch (err) {
        console.error("Error loading DM unread count:", err);
      }
    };
    loadUnreadDm();
    const chatInterval = setInterval(loadUnreadDm, 30000);
    return () => clearInterval(chatInterval);
  }, [loading, session, profile?.phone]);

  // Mark chat as seen when navigating to chat — MUST be before any early returns
  useEffect(() => {
    if (location.pathname.startsWith("/resident/chat")) {
      setUnreadChatCount(0);
    }
  }, [location.pathname]);

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-[#fffcf5] flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <Loader2 className="w-10 h-10 text-[#F59E0B] animate-spin mx-auto mb-4" />
          <p className="text-sm text-[#5f6b7a]">جاري التحقق من الحساب...</p>
        </div>
      </div>
    );
  }

  // Auth guard — redirect to login if no session
  if (!session) {
    return <Navigate to="/login" replace />;
  }

  // Determine if user is a board/admin member (can switch to dashboard)
  const isBoardMember = profile?.role === "admin" || profile?.role === "board_member" || profile?.role === "treasurer";

  // Profile display
  const displayName = profile?.name || "ساكن";
  const initials = displayName.slice(0, 2);
  const unitInfo = profile?.unitCode ? `شقة ${profile.unitCode}` : "";
  const buildingName = profile?.buildingName || "مُلاك";
  const residentType = isBoardMember
    ? (profile?.adminRole || "عضو اتحاد")
    : (profile?.type || "ساكن");

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-[#fffcf5] flex" dir="rtl">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Notification overlay */}
      {notifOpen && (
        <div
          className="fixed inset-0 z-20"
          onClick={() => setNotifOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className="w-[280px] sm:w-72 bg-[#ffffff] border-l border-[#F59E0B]/10 z-50 transition-transform duration-300"
        style={{
          position: isLargeScreen ? 'static' : 'fixed',
          top: 0,
          right: 0,
          bottom: 0,
          transform: isLargeScreen ? 'translateX(0)' : sidebarOpen ? 'translateX(0)' : 'translateX(100%)',
          zIndex: isLargeScreen ? 'auto' : 50,
        }}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between p-5 border-b border-[#F59E0B]/10">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-[#F59E0B] rounded-xl flex items-center justify-center">
                <Home className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="text-sm text-[#1a1a2e]">{buildingName}</span>
                {unitInfo && (
                  <span className="text-[10px] text-[#5f6b7a] block -mt-0.5">{unitInfo} — الدور {profile?.floor}</span>
                )}
              </div>
            </div>
            <button
              className="lg:hidden text-[#5f6b7a]"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-1 mt-2">
            {residentMenuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  navigate(item.path);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 sm:px-4 py-3 rounded-xl text-sm transition-all ${
                  isActive(item.path)
                    ? "bg-[#F59E0B] text-white shadow-md shadow-[#F59E0B]/20"
                    : "text-[#5f6b7a] hover:bg-[#F59E0B]/5 hover:text-[#F59E0B]"
                }`}
              >
                <item.icon className="w-5 h-5 shrink-0" />
                <span className="flex-1 text-right">{item.label}</span>
                {item.badge != null && item.badge > 0 && (
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    isActive(item.path)
                      ? "bg-white/20 text-white"
                      : "bg-[#F59E0B] text-white"
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            ))}

            {/* Coming Soon — Utility Bills */}
            <div className="mt-4 pt-4 border-t border-dashed border-[#F59E0B]/15">
              <div className="px-3 sm:px-4 mb-2">
                <span className="text-[10px] text-[#5f6b7a]/60 font-medium tracking-wide">دفع الفواتير — قريباً</span>
              </div>
              {[
                { id: "electricity", label: "الكهرباء", icon: Zap },
                { id: "gas", label: "الغاز", icon: Flame },
                { id: "water", label: "المياه", icon: Droplets },
              ].map((item) => (
                <div
                  key={item.id}
                  className="w-full flex items-center gap-3 px-3 sm:px-4 py-3 rounded-xl text-sm text-[#5f6b7a]/40 cursor-default select-none"
                >
                  <item.icon className="w-5 h-5 shrink-0" />
                  <span className="flex-1 text-right">{item.label}</span>
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-[#0D9488]/8 text-[#0D9488]/60 font-medium">
                    قريباً
                  </span>
                </div>
              ))}
            </div>
          </nav>

          {/* User */}
          <div className="px-3 py-2.5 border-t border-[#F59E0B]/10">
            {/* Switch to Dashboard — only for board members */}
            {isBoardMember && (
              <button
                onClick={() => { navigate("/dashboard"); setSidebarOpen(false); }}
                className="w-full flex items-center justify-center gap-1.5 text-xs text-[#0D9488] px-2 py-1.5 rounded-lg bg-[#0D9488]/5 hover:bg-[#0D9488]/10 transition-colors mb-2 font-medium"
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                لوحة التحكم
              </button>
            )}
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 bg-[#F59E0B]/10 rounded-full flex items-center justify-center shrink-0">
                <span className="text-[10px] text-[#F59E0B] font-medium">{initials}</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-[#1a1a2e] truncate leading-tight">{displayName}</div>
                <div className="text-[10px] text-[#5f6b7a] truncate leading-tight">{residentType}</div>
              </div>
              <button
                onClick={() => { navigate("/resident/settings"); setSidebarOpen(false); }}
                className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors shrink-0 ${
                  isActive("/resident/settings")
                    ? "bg-[#F59E0B] text-white"
                    : "text-[#5f6b7a] hover:bg-[#F59E0B]/10 hover:text-[#F59E0B]"
                }`}
                title="الإعدادات"
              >
                <Settings className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleLogout}
                className="w-7 h-7 rounded-lg flex items-center justify-center text-[#5f6b7a] hover:text-red-500 hover:bg-red-50 transition-colors shrink-0"
                title="تسجيل الخروج"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-h-screen min-w-0 overflow-x-hidden">
        {/* Top bar */}
        <header className="sticky top-0 z-30 border-b border-[#F59E0B]/10" style={{ backgroundColor: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}>
          <div className="flex items-center justify-between px-4 sm:px-6 h-16">
            <div className="flex items-center gap-3">
              <button
                className="lg:hidden text-[#5f6b7a]"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="w-6 h-6" />
              </button>
              <h2 className="text-[#1a1a2e]">
                {location.pathname.startsWith("/resident/chat")
                  ? "المحادثات"
                  : residentMenuItems.find((item) => isActive(item.path))?.label || "الرئيسية"}
              </h2>
            </div>
            <div className="flex items-center gap-3">
              {/* Chat Icon */}
              <button
                onClick={() => navigate("/resident/chat")}
                className={`relative p-2 rounded-xl transition-colors ${
                  isActive("/resident/chat")
                    ? "text-[#F59E0B] bg-[#F59E0B]/10"
                    : "text-[#5f6b7a] hover:text-[#F59E0B] hover:bg-[#F59E0B]/5"
                }`}
                title="المحادثات"
              >
                <MessageCircle className="w-5 h-5" />
                {unreadChatCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] bg-[#F59E0B] text-white text-[10px] rounded-full flex items-center justify-center px-1">
                    {unreadChatCount}
                  </span>
                )}
              </button>
              {/* Notifications Bell */}
              <div className="relative">
                <button
                  onClick={() => setNotifOpen(!notifOpen)}
                  className={`relative p-2 rounded-xl transition-colors ${
                    notifOpen
                      ? "text-[#F59E0B] bg-[#F59E0B]/10"
                      : "text-[#5f6b7a] hover:text-[#F59E0B] hover:bg-[#F59E0B]/5"
                  }`}
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] bg-[#F59E0B] text-white text-[10px] rounded-full flex items-center justify-center px-1">
                      {unreadCount > 9 ? "9+" : unreadCount}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown */}
                {notifOpen && (
                  <div className="absolute left-0 sm:left-auto sm:right-0 top-12 w-[340px] sm:w-[380px] bg-white rounded-2xl border border-[#F59E0B]/10 shadow-xl z-50 overflow-hidden">
                    <div className="px-4 py-3 border-b border-[#F59E0B]/10 flex items-center justify-between">
                      <h3 className="text-sm text-[#1a1a2e]">الإشعارات</h3>
                      <div className="flex items-center gap-2">
                        {unreadCount > 0 && (
                          <span className="text-[10px] bg-[#F59E0B]/10 text-[#F59E0B] px-2 py-0.5 rounded-full">
                            {unreadCount} جديد
                          </span>
                        )}
                        {unreadCount > 0 && (
                          <button
                            onClick={handleMarkAllRead}
                            className="text-[10px] text-[#0D9488] bg-[#0D9488]/5 px-2 py-0.5 rounded-full hover:bg-[#0D9488]/10 transition-colors"
                          >
                            قراءة الكل
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="max-h-[70vh] overflow-y-auto">
                      {notifLoading && notifications.length === 0 ? (
                        <div className="flex items-center justify-center py-12">
                          <Loader2 className="w-6 h-6 text-[#F59E0B] animate-spin" />
                        </div>
                      ) : notifications.length === 0 ? (
                        <div className="p-6 text-center text-sm text-[#5f6b7a]">لا توجد إشعارات</div>
                      ) : (
                        <div className="divide-y divide-gray-50">
                          {notifications.map((notif) => {
                            const Icon = iconMap[notif.icon] || Bell;
                            return (
                              <div
                                key={notif.id}
                                className={`flex items-start gap-3 px-4 py-3.5 transition-colors cursor-pointer hover:bg-[#F59E0B]/5 ${
                                  !notif.read ? "bg-[#F59E0B]/[0.03]" : ""
                                }`}
                                onClick={() => handleNotifClick(notif)}
                              >
                                <div
                                  className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
                                  style={{ backgroundColor: `${notif.color || "#F59E0B"}15` }}
                                >
                                  <Icon className="w-5 h-5" style={{ color: notif.color || "#F59E0B" }} />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm text-[#1a1a2e]">{notif.title}</span>
                                    <span className="text-[10px] text-[#5f6b7a]">{timeAgo(notif.timestamp)}</span>
                                  </div>
                                  <p className="text-xs text-[#5f6b7a] mt-0.5 line-clamp-2">{notif.body}</p>
                                </div>
                                {!notif.read && (
                                  <span className="w-2.5 h-2.5 bg-[#F59E0B] rounded-full shrink-0 mt-2" />
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 sm:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}