import { useState, useEffect, useCallback, useMemo } from "react";
import {
  Users, Search, Loader2, MessageCircle, Phone, Home,
  Layers, X, Filter,
} from "lucide-react";
import { useNavigate } from "react-router";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";
import { displayName } from "../../lib/titles";

interface PublicResident {
  id: string;
  title?: string;
  name: string;
  phone: string;
  unitCode: string;
  floor: string;
  type: string;
  bio?: string;
  avatarBase64?: string;
}

export function ResidentResidents() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [residents, setResidents] = useState<PublicResident[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("الكل");
  const [floorFilter, setFloorFilter] = useState<string>("الكل");
  const [searchOpen, setSearchOpen] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const loadResidents = useCallback(async () => {
    try {
      const data = await api.getResidentsPublic();
      setResidents(data);
    } catch (err) {
      console.error("Error loading residents:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadResidents();
  }, [loadResidents]);

  const myPhone = profile?.phone || "";

  // Exclude self
  const othersOnly = useMemo(
    () => residents.filter((r) => r.phone !== myPhone),
    [residents, myPhone]
  );

  // Extract unique types & floors for filter chips
  const types = useMemo(() => {
    const set = new Set(othersOnly.map((r) => r.type));
    return ["الكل", ...Array.from(set)];
  }, [othersOnly]);

  const floors = useMemo(() => {
    const set = new Set(othersOnly.map((r) => r.floor));
    const sorted = Array.from(set).sort((a, b) => {
      const na = parseInt(a, 10);
      const nb = parseInt(b, 10);
      if (!isNaN(na) && !isNaN(nb)) return na - nb;
      return a.localeCompare(b);
    });
    return ["الكل", ...sorted];
  }, [othersOnly]);

  // Apply all filters
  const filtered = useMemo(() => {
    return othersOnly.filter((r) => {
      // Type filter
      if (typeFilter !== "الكل" && r.type !== typeFilter) return false;
      // Floor filter
      if (floorFilter !== "الكل" && r.floor !== floorFilter) return false;
      // Search
      if (search.trim()) {
        const q = search.trim().toLowerCase();
        const fullName = displayName(r.title, r.name).toLowerCase();
        return (
          fullName.includes(q) ||
          r.phone.includes(q) ||
          r.unitCode.includes(q) ||
          r.floor.includes(q)
        );
      }
      return true;
    });
  }, [othersOnly, typeFilter, floorFilter, search]);

  const hasActiveFilters = typeFilter !== "الكل" || floorFilter !== "الكل" || search.trim() !== "";

  const clearAllFilters = () => {
    setTypeFilter("الكل");
    setFloorFilter("الكل");
    setSearch("");
  };

  const openDm = (phone: string, name: string, unitCode: string) => {
    navigate(`/resident/chat?dm=${encodeURIComponent(phone)}&name=${encodeURIComponent(name)}&unit=${encodeURIComponent(unitCode)}`);
  };

  const roleColor = (type: string) => {
    if (type === "مالك") return { bg: "#0D9488", text: "#0D9488" };
    return { bg: "#F59E0B", text: "#F59E0B" };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-[#F59E0B] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl text-[#1a1a2e]">المُلاك</h1>
          <p className="text-sm text-[#5f6b7a]">
            تواصل مع سكان المبنى — {filtered.length.toLocaleString("en-US")} ساكن
          </p>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Search icon */}
          <button
            onClick={() => { setSearchOpen(true); setTimeout(() => document.getElementById("resident-residents-search")?.focus(), 50); }}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              search ? "bg-[#F59E0B] text-white shadow-sm" : "bg-white text-[#5f6b7a] border border-[#F59E0B]/10 hover:border-[#F59E0B]/30"
            }`}
          >
            <Search className="w-4 h-4" />
          </button>
          {/* Filter icon */}
          <button
            onClick={() => setFiltersOpen(!filtersOpen)}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              (typeFilter !== "الكل" || floorFilter !== "الكل")
                ? "bg-[#F59E0B] text-white shadow-sm"
                : "bg-white text-[#5f6b7a] border border-[#F59E0B]/10 hover:border-[#F59E0B]/30"
            }`}
          >
            <Filter className="w-4 h-4" />
          </button>
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="text-[10px] text-[#F59E0B] bg-[#F59E0B]/10 px-2 py-1.5 rounded-lg hover:bg-[#F59E0B]/20 transition-colors shrink-0"
            >
              مسح
            </button>
          )}
        </div>
      </div>

      {/* Expandable Search Bar */}
      {searchOpen && (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#5f6b7a]" />
            <input
              id="resident-residents-search"
              type="text"
              placeholder="بحث بالاسم، الشقة، الدور..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 bg-white border border-[#F59E0B]/15 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20 text-sm"
            />
          </div>
          <button
            onClick={() => { setSearchOpen(false); setSearch(""); }}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#5f6b7a] bg-white border border-gray-100 hover:bg-gray-50 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Filters Section */}
      {filtersOpen && (
        <div className="space-y-3">
          {/* Type Filter */}
          {types.length > 2 && (
            <div>
              <div className="flex items-center gap-1.5 mb-1.5">
                <Filter className="w-3 h-3 text-[#5f6b7a]" />
                <span className="text-[10px] text-[#5f6b7a] font-medium">النوع</span>
              </div>
              <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-1" style={{ WebkitOverflowScrolling: "touch" }}>
                {types.map((t) => (
                  <button
                    key={t}
                    onClick={() => setTypeFilter(t)}
                    className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all shrink-0 ${
                      typeFilter === t
                        ? "bg-[#F59E0B] text-white shadow-sm"
                        : "bg-white text-[#5f6b7a] border border-gray-100 hover:border-[#F59E0B]/30 hover:text-[#F59E0B]"
                    }`}
                  >
                    {t}
                    {t !== "الكل" && (
                      <span className={`mr-1 text-[10px] ${typeFilter === t ? "text-white/70" : "text-[#5f6b7a]/50"}`}>
                        ({othersOnly.filter((r) => r.type === t).length.toLocaleString("en-US")})
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Floor Filter */}
          {floors.length > 2 && (
            <div>
              <div className="flex items-center gap-1.5 mb-1.5">
                <Layers className="w-3 h-3 text-[#5f6b7a]" />
                <span className="text-[10px] text-[#5f6b7a] font-medium">الدور</span>
              </div>
              <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-1" style={{ WebkitOverflowScrolling: "touch" }}>
                {floors.map((f) => (
                  <button
                    key={f}
                    onClick={() => setFloorFilter(f)}
                    className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all shrink-0 ${
                      floorFilter === f
                        ? "bg-[#F59E0B] text-white shadow-sm"
                        : "bg-white text-[#5f6b7a] border border-gray-100 hover:border-[#F59E0B]/30 hover:text-[#F59E0B]"
                    }`}
                  >
                    {f === "الكل" ? "الكل" : `الدور ${f}`}
                    {f !== "الكل" && (
                      <span className={`mr-1 text-[10px] ${floorFilter === f ? "text-white/70" : "text-[#5f6b7a]/50"}`}>
                        ({othersOnly.filter((r) => r.floor === f).length.toLocaleString("en-US")})
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Residents Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 bg-[#F59E0B]/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-[#F59E0B]" />
          </div>
          <p className="text-sm text-[#5f6b7a]">
            {hasActiveFilters ? "لا توجد نتائج — جرّب تعديل الفلاتر" : "لا يوجد سكان حالياً"}
          </p>
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="mt-3 text-xs text-[#F59E0B] underline hover:no-underline"
            >
              مسح جميع الفلاتر
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((resident) => {
            const fullName = displayName(resident.title, resident.name);
            const initials = resident.name.slice(0, 2);
            const rc = roleColor(resident.type);

            return (
              <div
                key={resident.id}
                className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm"
              >
                <div className="p-4" style={{ backgroundColor: `${rc.bg}04` }}>

                  {/* ── Header: Avatar + Name + Type badge ── */}
                  <div className="flex items-start gap-3 mb-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 overflow-hidden"
                      style={{ backgroundColor: `${rc.bg}15` }}
                    >
                      {resident.avatarBase64 ? (
                        <img
                          src={resident.avatarBase64}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span
                          className="text-sm font-bold"
                          style={{ color: rc.text }}
                        >
                          {initials}
                        </span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-sm font-semibold text-[#1a1a2e] truncate block">
                        {fullName}
                      </span>
                      <span
                        className="text-[10px] px-1.5 py-px rounded-full inline-block mt-1 font-medium"
                        style={{
                          backgroundColor: `${rc.bg}12`,
                          color: rc.text,
                        }}
                      >
                        {resident.type}
                      </span>
                    </div>
                  </div>

                  {/* ── Info Grid — notification card style ── */}
                  <div className="grid grid-cols-3 gap-2 mb-3">
                    <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                      <div className="text-[9px] text-[#5f6b7a]">الشقة</div>
                      <div className="text-xs text-[#1a1a2e] font-medium">{resident.unitCode}</div>
                    </div>
                    <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                      <div className="text-[9px] text-[#5f6b7a]">الدور</div>
                      <div className="text-xs text-[#1a1a2e] font-medium">{resident.floor || "—"}</div>
                    </div>
                    <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                      <div className="text-[9px] text-[#5f6b7a]">الهاتف</div>
                      <div className="text-[10px] text-[#1a1a2e]" dir="ltr">{resident.phone}</div>
                    </div>
                  </div>

                  {/* ── Bio ── */}
                  {resident.bio && (
                    <p className="text-xs text-[#5f6b7a] leading-relaxed mb-3 line-clamp-2 italic bg-white rounded-lg px-3 py-2 border border-gray-100">
                      "{resident.bio}"
                    </p>
                  )}

                  {/* ── DM Button — matching notification accept button ── */}
                  <button
                    onClick={() => openDm(resident.phone, fullName, resident.unitCode)}
                    className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#F59E0B] text-white text-xs hover:bg-[#F59E0B]/90 transition-all shadow-sm"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    محادثة
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}