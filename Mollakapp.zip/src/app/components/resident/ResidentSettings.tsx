import { useState, useRef, useCallback } from "react";
import {
  User, Phone, Home, Bell, Shield, LogOut, CheckCircle2, Edit3,
  Camera, X, Loader2, Calendar, Heart, AlertTriangle, FileText,
  UserCircle2, Save, ChevronLeft, CreditCard,
} from "lucide-react";
import { useNavigate } from "react-router";
import { useAuth } from "../../lib/auth";
import { normalizeToEnglishDigits } from "../../lib/phoneUtils";
import * as api from "../../lib/api";
import { ResidentIdCard } from "./ResidentIdCard";

// Compress image to base64 — max 200x200, JPEG 0.7 quality
function compressImage(file: File, maxSize = 200): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let w = img.width;
        let h = img.height;
        if (w > h) { h = (maxSize * h) / w; w = maxSize; }
        else { w = (maxSize * w) / h; h = maxSize; }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.7));
      };
      img.onerror = reject;
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function ResidentSettings() {
  const navigate = useNavigate();
  const { session, profile, logout, refreshProfile } = useAuth();

  // Edit mode
  const [editMode, setEditMode] = useState(false);
  const [showIdCard, setShowIdCard] = useState(false);

  // Form fields
  const [name, setName] = useState(profile?.name || "");
  const [phone, setPhone] = useState(profile?.phone || "");
  const [gender, setGender] = useState(profile?.gender || "");
  const [birthDate, setBirthDate] = useState(profile?.birthDate || "");
  const [bio, setBio] = useState(profile?.bio || "");
  const [emergencyContact, setEmergencyContact] = useState(profile?.emergencyContact || "");
  const [emergencyPhone, setEmergencyPhone] = useState(profile?.emergencyPhone || "");
  const [nationalId, setNationalId] = useState(profile?.nationalId || "");
  const [avatarBase64, setAvatarBase64] = useState<string | null>(profile?.avatarBase64 || null);

  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [notifications, setNotifications] = useState({
    invoices: true,
    announcements: true,
    chat: true,
    voting: false,
    events: true,
  });

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 3000);
  };

  const showError = (msg: string) => {
    setErrorMsg(msg);
    setTimeout(() => setErrorMsg(""), 4000);
  };

  const handleOpenEdit = () => {
    // Reset form to current profile values
    setName(profile?.name || "");
    setPhone(profile?.phone || "");
    setGender(profile?.gender || "");
    setBirthDate(profile?.birthDate || "");
    setBio(profile?.bio || "");
    setEmergencyContact(profile?.emergencyContact || "");
    setEmergencyPhone(profile?.emergencyPhone || "");
    setNationalId(profile?.nationalId || "");
    setAvatarBase64(profile?.avatarBase64 || null);
    setEditMode(true);
  };

  const handleAvatarPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      showError("حجم الصورة يجب أن يكون أقل من 5 ميجا");
      return;
    }
    try {
      const base64 = await compressImage(file);
      setAvatarBase64(base64);
    } catch {
      showError("فشل في تحميل الصورة");
    }
  };

  const handleSave = async () => {
    if (!session?.access_token) {
      showError("يرجى تسجيل الدخول أولاً");
      return;
    }
    setSaving(true);
    try {
      const res = await api.updateProfile({
        token: session.access_token,
        name: name.trim(),
        phone: normalizeToEnglishDigits(phone.trim()),
        gender: gender || undefined,
        birthDate: birthDate || undefined,
        bio: bio.trim() || undefined,
        emergencyContact: emergencyContact.trim() || undefined,
        emergencyPhone: emergencyPhone.trim() ? normalizeToEnglishDigits(emergencyPhone.trim()) : undefined,
        nationalId: nationalId.trim() || undefined,
        avatarBase64,
      });
      console.log("Profile updated:", res);
      await refreshProfile();
      showSuccess("تم تحديث البروفايل بنجاح");
      setEditMode(false);
    } catch (err: any) {
      console.error("Profile update error:", err);
      showError(err.message || "حدث خطأ أثناء حفظ البيانات");
    } finally {
      setSaving(false);
    }
  };

  const avatarDisplay = avatarBase64 || profile?.avatarBase64;
  const genderLabel = (g: string) => g === "male" ? "ذكر" : g === "female" ? "أنثى" : "—";
  const formatBirthDate = (d: string) => {
    try {
      return new Date(d).toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });
    } catch { return d; }
  };

  return (
    <div className="space-y-5 max-w-2xl pb-8">
      {/* Toast Messages */}
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}
      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
        </div>
      )}

      {/* ===== PROFILE HEADER CARD ===== */}
      <div className="bg-white rounded-2xl border border-[#F59E0B]/10 overflow-hidden shadow-sm">
        {/* Gradient banner */}
        <div className="h-20 relative" style={{ background: 'linear-gradient(to left, #0D9488, rgba(13,148,136,0.8), rgba(245,158,11,0.6))' }}>
          {/* Avatar */}
          <div className="absolute -bottom-10 right-5">
            <div className="w-20 h-20 rounded-full border-4 border-white shadow-md overflow-hidden bg-[#F59E0B]">
              {avatarDisplay ? (
                <img src={avatarDisplay} alt="avatar" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <span className="text-2xl text-white font-bold">{profile?.name?.slice(0, 2) || "—"}</span>
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="pt-12 px-5 pb-5">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-lg text-[#1a1a2e] font-semibold">{profile?.name || "—"}</h2>
              <p className="text-xs text-[#5f6b7a] mt-0.5">{profile?.type || "ساكن"} — شقة {profile?.unitCode || "—"} — الدور {profile?.floor || "—"}</p>
              <p className="text-xs text-[#0D9488] mt-1">{profile?.buildingName || "—"}</p>
              {profile?.bio && (
                <p className="text-xs text-[#5f6b7a] mt-2 leading-relaxed italic">"{profile.bio}"</p>
              )}
            </div>
            <button
              onClick={handleOpenEdit}
              className="flex items-center gap-1.5 px-3 py-2 bg-[#F59E0B] text-white text-[11px] rounded-xl hover:bg-[#F59E0B]/90 transition-colors shadow-sm"
            >
              <Edit3 className="w-3.5 h-3.5" />
              تعديل الملف الشخصي
            </button>
          </div>

          {/* Quick info chips */}
          <div className="flex flex-wrap gap-2 mt-4">
            {profile?.gender && (
              <span className="inline-flex items-center gap-1 text-[10px] px-2.5 py-1 bg-[#0D9488]/5 text-[#0D9488] rounded-lg border border-[#0D9488]/10">
                <UserCircle2 className="w-3 h-3" />
                {genderLabel(profile.gender)}
              </span>
            )}
            {profile?.birthDate && (
              <span className="inline-flex items-center gap-1 text-[10px] px-2.5 py-1 bg-[#6366f1]/5 text-[#6366f1] rounded-lg border border-[#6366f1]/10">
                <Calendar className="w-3 h-3" />
                {formatBirthDate(profile.birthDate)}
              </span>
            )}
            {profile?.phone && (
              <span dir="ltr" className="inline-flex items-center gap-1 text-[10px] px-2.5 py-1 bg-gray-50 text-[#5f6b7a] rounded-lg border border-gray-100">
                <Phone className="w-3 h-3" />
                {profile.phone}
              </span>
            )}
            {profile?.adminRole && profile.adminRole !== "ساكن" && (
              <span className="inline-flex items-center gap-1 text-[10px] px-2.5 py-1 bg-[#F59E0B]/10 text-[#F59E0B] rounded-lg border border-[#F59E0B]/10">
                <Shield className="w-3 h-3" />
                {profile.adminRole}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Delivery ID Card Button */}
      <button
        onClick={() => setShowIdCard(true)}
        className="w-full text-white rounded-2xl p-4 flex items-center gap-4 hover:shadow-lg hover:shadow-[#F59E0B]/15 transition-all group"
        style={{ background: 'linear-gradient(to left, #F59E0B, rgba(245,158,11,0.8))' }}
      >
        <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
          <CreditCard className="w-6 h-6" />
        </div>
        <div className="flex-1 text-right">
          <div className="text-sm font-semibold">بطاقة تعريفية</div>
          <div className="text-xs text-white/70 mt-0.5">بيانات الساكن في بطاقة جاهزة للمشاركة</div>
        </div>
        <ChevronLeft className="w-5 h-5 text-white/50 group-hover:text-white transition-colors" />
      </button>

      {/* Unit Info */}
      <div className="bg-white rounded-2xl border border-[#F59E0B]/10 p-5 sm:p-6">
        <h3 className="text-[#1a1a2e] mb-4 flex items-center gap-2 text-sm font-semibold">
          <Home className="w-5 h-5 text-[#F59E0B]" />
          بيانات الوحدة
        </h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <div className="p-3 bg-[#fffcf5] rounded-xl">
            <div className="text-[10px] text-[#5f6b7a]">المبنى</div>
            <div className="text-sm text-[#1a1a2e]">{profile?.buildingName || "—"}</div>
          </div>
          <div className="p-3 bg-[#fffcf5] rounded-xl">
            <div className="text-[10px] text-[#5f6b7a]">الشقة</div>
            <div className="text-sm text-[#1a1a2e]">{profile?.unitCode || "—"} — الدور {profile?.floor || "—"}</div>
          </div>
          <div className="p-3 bg-[#fffcf5] rounded-xl">
            <div className="text-[10px] text-[#5f6b7a]">نوع الملكية</div>
            <div className="text-sm text-[#1a1a2e]">{profile?.type || "—"}</div>
          </div>
          {profile?.emergencyContact && (
            <div className="p-3 bg-red-50/50 rounded-xl border border-red-100/50">
              <div className="text-[10px] text-red-400">جهة اتصال الطوارئ</div>
              <div className="text-sm text-[#1a1a2e]">{profile.emergencyContact}</div>
              {profile.emergencyPhone && (
                <div dir="ltr" className="text-xs text-[#5f6b7a] mt-0.5">{profile.emergencyPhone}</div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Notifications */}
      <div className="bg-white rounded-2xl border border-[#F59E0B]/10 p-5 sm:p-6">
        <h3 className="text-[#1a1a2e] mb-4 flex items-center gap-2 text-sm font-semibold">
          <Bell className="w-5 h-5 text-[#F59E0B]" />
          إعدادات الإشعارات
        </h3>
        <div className="space-y-3">
          {[
            { key: "invoices" as const, label: "الفواتير الجديدة", desc: "إشعار عند إصدار فاتورة جديدة" },
            { key: "announcements" as const, label: "الإعلانات", desc: "إشعار بإعلانات المبنى" },
            { key: "chat" as const, label: "الرسائل", desc: "إشعار بالرسائل الجديدة" },
            { key: "voting" as const, label: "التصويتات", desc: "إشعار بتصويتات جديدة" },
            { key: "events" as const, label: "المناسبات", desc: "إشعار بمناسبات السكان" },
          ].map((item) => (
            <div key={item.key} className="flex items-center justify-between p-3 rounded-xl hover:bg-[#fffcf5] transition-colors">
              <div>
                <div className="text-sm text-[#1a1a2e]">{item.label}</div>
                <div className="text-xs text-[#5f6b7a]">{item.desc}</div>
              </div>
              <button
                onClick={() =>
                  setNotifications((prev) => ({ ...prev, [item.key]: !prev[item.key] }))
                }
                className={`w-12 h-7 rounded-full transition-all relative ${
                  notifications[item.key] ? "bg-[#0D9488]" : "bg-gray-200"
                }`}
              >
                <div
                  className={`w-5 h-5 bg-white rounded-full absolute top-1 transition-all shadow-sm ${
                    notifications[item.key] ? "left-1" : "left-6"
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={async () => { await logout(); navigate("/login"); }}
        className="w-full flex items-center justify-center gap-2 text-sm text-red-500 hover:bg-red-50 py-3 rounded-xl transition-colors"
      >
        <LogOut className="w-4 h-4" />
        تسجيل الخروج
      </button>

      {/* ===== EDIT PROFILE MODAL / BOTTOM SHEET ===== */}
      {editMode && (
        <div
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center"
          onClick={() => setEditMode(false)}
        >
          <div
            className="bg-white rounded-t-3xl sm:rounded-2xl w-full sm:max-w-lg sm:mx-4 max-h-[92vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Drag handle — mobile */}
            <div className="sm:hidden flex justify-center pt-3">
              <div className="w-10 h-1 bg-gray-300 rounded-full" />
            </div>

            {/* Header */}
            <div className="sticky top-0 bg-white z-10 px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-base text-[#1a1a2e] font-semibold flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-[#F59E0B]" />
                تعديل الملف الشخصي
              </h3>
              <button
                onClick={() => setEditMode(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-4 h-4 text-[#5f6b7a]" />
              </button>
            </div>

            <div className="p-5 space-y-6">
              {/* Avatar section */}
              <div className="flex flex-col items-center">
                <div className="relative">
                  <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-[#F59E0B]/20 shadow-md bg-[#F59E0B]">
                    {avatarBase64 ? (
                      <img src={avatarBase64} alt="avatar" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <span className="text-3xl text-white font-bold">{name?.slice(0, 2) || "—"}</span>
                      </div>
                    )}
                  </div>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute -bottom-1 -left-1 w-8 h-8 bg-[#0D9488] text-white rounded-full flex items-center justify-center shadow-md hover:bg-[#0D9488]/90 transition-colors"
                  >
                    <Camera className="w-3.5 h-3.5" />
                  </button>
                  {avatarBase64 && (
                    <button
                      onClick={() => setAvatarBase64(null)}
                      className="absolute -top-1 -left-1 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center shadow-sm hover:bg-red-600 transition-colors"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarPick}
                />
                <p className="text-[10px] text-[#5f6b7a] mt-2">اضغط على الكاميرا لتغيير الصورة</p>
              </div>

              {/* Basic Info */}
              <div>
                <h4 className="text-xs font-semibold text-[#1a1a2e] mb-3 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-[#F59E0B]" />
                  البيانات الأساسية
                </h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] text-[#5f6b7a] mb-1 block">الاسم</label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-4 py-3 bg-[#fffcf5] border border-[#F59E0B]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#5f6b7a] mb-1 block">رقم الهاتف</label>
                    <input
                      type="tel"
                      dir="ltr"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      onInput={(e) => {
                        const input = e.target as HTMLInputElement;
                        input.value = normalizeToEnglishDigits(input.value);
                      }}
                      className="w-full px-4 py-3 bg-[#fffcf5] border border-[#F59E0B]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20 text-right"
                    />
                  </div>
                </div>
              </div>

              {/* Personal Details (all optional) */}
              <div>
                <h4 className="text-xs font-semibold text-[#1a1a2e] mb-3 flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 text-[#F59E0B]" />
                  بيانات شخصية
                  <span className="text-[9px] text-[#5f6b7a] font-normal bg-gray-100 px-1.5 py-0.5 rounded">(اختياري)</span>
                </h4>
                <div className="space-y-3">
                  {/* Gender */}
                  <div>
                    <label className="text-[11px] text-[#5f6b7a] mb-1.5 block">النوع</label>
                    <div className="flex gap-2">
                      {[
                        { value: "male", label: "ذكر" },
                        { value: "female", label: "أنثى" },
                      ].map((opt) => (
                        <button
                          key={opt.value}
                          onClick={() => setGender(gender === opt.value ? "" : opt.value)}
                          className={`flex-1 py-3 rounded-xl border-2 text-sm transition-all ${
                            gender === opt.value
                              ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488] font-medium"
                              : "border-gray-100 text-[#5f6b7a] hover:border-[#0D9488]/30"
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Birth Date */}
                  <div>
                    <label className="text-[11px] text-[#5f6b7a] mb-1 block">تاريخ الميلاد</label>
                    <input
                      type="date"
                      value={birthDate}
                      onChange={(e) => setBirthDate(e.target.value)}
                      className="w-full px-4 py-3 bg-[#fffcf5] border border-[#F59E0B]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20"
                    />
                  </div>

                  {/* Bio */}
                  <div>
                    <label className="text-[11px] text-[#5f6b7a] mb-1 block">نبذة عنك</label>
                    <textarea
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      rows={2}
                      maxLength={200}
                      placeholder="مثال: مهندس مدني، أحب الأنشطة الاجتماعية..."
                      className="w-full px-4 py-3 bg-[#fffcf5] border border-[#F59E0B]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20 resize-none"
                    />
                    <div className="text-[9px] text-[#5f6b7a] text-left mt-0.5">{bio.length}/200</div>
                  </div>

                  {/* National ID */}
                  <div>
                    <label className="text-[11px] text-[#5f6b7a] mb-1 block">الرقم القومي</label>
                    <input
                      type="text"
                      dir="ltr"
                      value={nationalId}
                      onChange={(e) => setNationalId(e.target.value)}
                      onInput={(e) => {
                        const input = e.target as HTMLInputElement;
                        input.value = normalizeToEnglishDigits(input.value);
                      }}
                      placeholder="اختياري"
                      className="w-full px-4 py-3 bg-[#fffcf5] border border-[#F59E0B]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20 text-right"
                    />
                  </div>
                </div>
              </div>

              {/* Emergency Contact */}
              <div>
                <h4 className="text-xs font-semibold text-[#1a1a2e] mb-3 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                  جهة اتصال الطوارئ
                  <span className="text-[9px] text-[#5f6b7a] font-normal bg-gray-100 px-1.5 py-0.5 rounded">(اختياري)</span>
                </h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] text-[#5f6b7a] mb-1 block">اسم الشخص</label>
                    <input
                      type="text"
                      value={emergencyContact}
                      onChange={(e) => setEmergencyContact(e.target.value)}
                      placeholder="مثال: أحمد محمد"
                      className="w-full px-4 py-3 bg-[#fffcf5] border border-[#F59E0B]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-[#5f6b7a] mb-1 block">رقم هاتف الطوارئ</label>
                    <input
                      type="tel"
                      dir="ltr"
                      value={emergencyPhone}
                      onChange={(e) => setEmergencyPhone(e.target.value)}
                      onInput={(e) => {
                        const input = e.target as HTMLInputElement;
                        input.value = normalizeToEnglishDigits(input.value);
                      }}
                      placeholder="01xxxxxxxxx"
                      className="w-full px-4 py-3 bg-[#fffcf5] border border-[#F59E0B]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20 text-right"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Save buttons — sticky bottom */}
            <div className="sticky bottom-0 bg-white border-t border-gray-100 px-5 py-4 flex gap-2">
              <button
                onClick={() => setEditMode(false)}
                className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm hover:bg-gray-50 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={handleSave}
                disabled={saving || !name.trim()}
                className="flex-1 py-3 rounded-xl bg-[#F59E0B] text-white text-sm hover:bg-[#F59E0B]/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2 shadow-md shadow-[#F59E0B]/20"
              >
                {saving ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Save className="w-4 h-4" />
                )}
                {saving ? "جاري الحفظ..." : "حفظ التعديلات"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ID Card Modal */}
      <ResidentIdCard
        isOpen={showIdCard}
        onClose={() => setShowIdCard(false)}
        name={profile?.name || "—"}
        buildingName={profile?.buildingName || "—"}
        floor={profile?.floor || "—"}
        unitCode={profile?.unitCode || "—"}
        phone={profile?.phone || "—"}
        avatarBase64={profile?.avatarBase64}
        type={profile?.type}
      />
    </div>
  );
}