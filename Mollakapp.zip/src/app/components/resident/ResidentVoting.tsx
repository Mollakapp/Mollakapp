import { useState, useEffect, useCallback } from "react";
import { Vote, CheckCircle2, Clock, Users, Loader2, BarChart3, RefreshCw, Trophy, Eye, ChevronDown, ChevronUp, UserCircle2 } from "lucide-react";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";

export function ResidentVoting() {
  const { profile } = useAuth();
  const [polls, setPolls] = useState<api.Poll[]>([]);
  const [loading, setLoading] = useState(true);
  const [votingPollId, setVotingPollId] = useState<string | null>(null);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [submittingVote, setSubmittingVote] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [expandedVoters, setExpandedVoters] = useState<Record<string, boolean>>({});

  const myName = profile?.name || "ساكن";

  const loadPolls = useCallback(async () => {
    try {
      const data = await api.getPolls();
      setPolls(data);
    } catch (err) {
      console.error("Error loading polls:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPolls();
  }, [loadPolls]);

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };

  const handleVote = async () => {
    if (!votingPollId || selectedOption === null) return;
    setSubmittingVote(true);
    try {
      const res = await api.votePoll(votingPollId, {
        optionIndex: selectedOption,
        voterName: myName,
      });
      // Update poll in state
      setPolls((prev) =>
        prev.map((p) => (p.id === votingPollId ? res.poll : p))
      );
      showSuccess("تم تسجيل تصويتك بنجاح ✓");
      setVotingPollId(null);
      setSelectedOption(null);
    } catch (err: any) {
      console.error("Error voting:", err);
      showSuccess(err.message || "حدث خطأ أثناء التصويت");
    } finally {
      setSubmittingVote(false);
    }
  };

  const hasVoted = (poll: api.Poll) => {
    return poll.options.some((o) => o.voters?.includes(myName));
  };

  const myVoteLabel = (poll: api.Poll) => {
    const opt = poll.options.find((o) => o.voters?.includes(myName));
    return opt?.label || "";
  };

  const activePollsCount = polls.filter((p) => p.status === "active").length;

  const formatDeadline = (d: string) => {
    try {
      return new Date(d).toLocaleDateString("ar-u-nu-latn", {
        day: "numeric",
        month: "short",
        year: "numeric",
      });
    } catch {
      return d;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin mx-auto mb-3" />
          <p className="text-sm text-[#5f6b7a]">جاري تحميل التصويتات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl text-[#1a1a2e]">التصويت</h1>
          <p className="text-xs sm:text-sm text-[#5f6b7a]">شارك برأيك في قرارات المبنى</p>
        </div>
        <button
          onClick={() => { setLoading(true); loadPolls(); }}
          className="p-2 text-[#5f6b7a] hover:text-[#0D9488] hover:bg-[#0D9488]/5 rounded-xl transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="bg-white rounded-xl border border-gray-100 p-3 shadow-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#0D9488]/10 flex items-center justify-center">
              <Vote className="w-4 h-4 text-[#0D9488]" />
            </div>
            <div>
              <div className="text-[10px] text-[#5f6b7a]">نشطة</div>
              <div className="text-sm font-semibold text-[#1a1a2e]">{activePollsCount}</div>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-3 shadow-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#6366f1]/10 flex items-center justify-center">
              <BarChart3 className="w-4 h-4 text-[#6366f1]" />
            </div>
            <div>
              <div className="text-[10px] text-[#5f6b7a]">إجمالي</div>
              <div className="text-sm font-semibold text-[#1a1a2e]">{polls.length}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Polls List */}
      <div className="space-y-3">
        {polls.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center">
            <div className="w-16 h-16 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto mb-3">
              <Vote className="w-8 h-8 text-[#0D9488]" />
            </div>
            <p className="text-sm text-[#5f6b7a]">لا توجد تصويتات حالياً</p>
            <p className="text-xs text-[#5f6b7a]/50 mt-1">ستظهر هنا عند إضافة تصويت من الإدارة</p>
          </div>
        ) : (
          polls.map((poll) => {
            const totalVotes = poll.options.reduce((s, o) => s + o.votes, 0);
            const voted = hasVoted(poll);
            const myLabel = myVoteLabel(poll);
            const isActive = poll.status === "active";
            const isExpired = new Date(poll.deadline) < new Date();
            const isEnded = !isActive || isExpired;
            const showResults = voted || isEnded;
            // Find the winning option(s)
            const maxVotes = Math.max(...poll.options.map((o) => o.votes));
            const votersKey = `voters-${poll.id}`;
            const isVotersExpanded = expandedVoters[votersKey] ?? false;

            // ========== ENDED POLL — full transparency results card ==========
            if (isEnded) {
              return (
                <div
                  key={poll.id}
                  className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm"
                >
                  {/* Results banner */}
                  <div
                    className="px-4 py-3 border-b"
                    style={{ background: 'linear-gradient(to left, rgba(13,148,136,0.1), rgba(13,148,136,0.05), transparent)', borderColor: 'rgba(13,148,136,0.1)' }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-[#0D9488]/15 flex items-center justify-center">
                          <BarChart3 className="w-4 h-4 text-[#0D9488]" />
                        </div>
                        <div>
                          <span className="text-[11px] text-[#0D9488] font-semibold">نتيجة التصويت</span>
                          <span className="text-[10px] text-[#5f6b7a] block">انتهى {formatDeadline(poll.deadline)}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {voted && (
                          <span className="flex items-center gap-0.5 text-[10px] bg-[#22c55e]/10 text-[#22c55e] px-2 py-0.5 rounded-full">
                            <CheckCircle2 className="w-2.5 h-2.5" />شاركت
                          </span>
                        )}
                        <span className="flex items-center gap-0.5 text-[10px] bg-gray-100 text-[#5f6b7a] px-2 py-0.5 rounded-full">
                          <Clock className="w-2.5 h-2.5" />منتهي
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Title */}
                  <div className="px-4 pt-3 pb-2">
                    <h3 className="text-sm font-medium text-[#1a1a2e]">{poll.title}</h3>
                    {poll.description && (
                      <p className="text-xs text-[#5f6b7a] leading-relaxed mt-1">{poll.description}</p>
                    )}
                  </div>

                  {/* Results bars */}
                  <div className="px-4 pb-3 space-y-3">
                    {poll.options.map((opt, i) => {
                      const pct = totalVotes > 0 ? Math.round((opt.votes / totalVotes) * 100) : 0;
                      const isMyVote = myLabel === opt.label;
                      const isWinner = opt.votes === maxVotes && maxVotes > 0;

                      return (
                        <div key={i} className="relative">
                          {/* Option row */}
                          <div className="flex items-center justify-between mb-1.5">
                            <div className="flex items-center gap-1.5">
                              {isWinner && (
                                <Trophy className="w-3.5 h-3.5 text-[#F59E0B]" />
                              )}
                              <span className={`text-xs font-medium ${
                                isWinner ? "text-[#1a1a2e]" : isMyVote ? "text-[#0D9488]" : "text-[#5f6b7a]"
                              }`}>
                                {opt.label}
                              </span>
                              {isMyVote && (
                                <span className="text-[9px] bg-[#0D9488]/10 text-[#0D9488] px-1.5 py-0.5 rounded-full">
                                  تصويتك
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-1.5">
                              <span className={`text-xs font-semibold ${isWinner ? "text-[#0D9488]" : "text-[#5f6b7a]"}`}>
                                {pct}%
                              </span>
                              <span className="text-[10px] text-[#5f6b7a]/60">
                                ({opt.votes.toLocaleString("en-US")})
                              </span>
                            </div>
                          </div>
                          {/* Progress bar */}
                          <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full transition-all duration-700 ease-out"
                              style={{
                                width: `${pct}%`,
                                background: isWinner
                                  ? 'linear-gradient(to left, #0D9488, rgba(13,148,136,0.7))'
                                  : isMyVote
                                    ? 'rgba(13,148,136,0.5)'
                                    : '#d1d5db',
                              }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Voter details — toggle */}
                  {totalVotes > 0 && (
                    <div className="border-t border-gray-100">
                      <button
                        onClick={() => setExpandedVoters((prev) => ({ ...prev, [votersKey]: !isVotersExpanded }))}
                        className="w-full flex items-center justify-center gap-1.5 py-2.5 text-[11px] text-[#0D9488] hover:bg-[#0D9488]/5 transition-colors active:bg-[#0D9488]/10"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        {isVotersExpanded ? "إخفاء تفاصيل التصويت" : "عرض تفاصيل التصويت"}
                        {isVotersExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>

                      {isVotersExpanded && (
                        <div className="px-4 pb-3 space-y-3">
                          {poll.options.map((opt, i) => {
                            if (!opt.voters || opt.voters.length === 0) return null;
                            const isWinner = opt.votes === maxVotes && maxVotes > 0;
                            return (
                              <div key={i} className={`rounded-xl p-3 ${isWinner ? "bg-[#0D9488]/5 border border-[#0D9488]/10" : "bg-gray-50 border border-gray-100"}`}>
                                <div className="flex items-center gap-1.5 mb-2">
                                  <span className={`text-[11px] font-semibold ${isWinner ? "text-[#0D9488]" : "text-[#5f6b7a]"}`}>
                                    {opt.label}
                                  </span>
                                  <span className="text-[10px] text-[#5f6b7a]/50">— {opt.voters.length} صوت</span>
                                </div>
                                <div className="flex flex-wrap gap-1.5">
                                  {opt.voters.map((voter, vi) => (
                                    <span
                                      key={vi}
                                      className={`inline-flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg ${
                                        voter === myName
                                          ? "bg-[#0D9488]/15 text-[#0D9488] font-medium border border-[#0D9488]/20"
                                          : "bg-white text-[#5f6b7a] border border-gray-100"
                                      }`}
                                    >
                                      <UserCircle2 className="w-3 h-3" />
                                      {voter}
                                      {voter === myName && <span className="text-[8px]">(أنت)</span>}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Footer */}
                  <div className="px-4 py-2.5 bg-gray-50/80 border-t border-gray-100 flex items-center justify-between">
                    <div className="flex items-center gap-3 text-[10px] text-[#5f6b7a]">
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {totalVotes.toLocaleString("en-US")} صوت
                      </span>
                      <span className="flex items-center gap-1">
                        <Trophy className="w-3 h-3 text-[#F59E0B]" />
                        {poll.options.find((o) => o.votes === maxVotes && maxVotes > 0)?.label || "—"}
                      </span>
                    </div>
                  </div>
                </div>
              );
            }

            // ========== ACTIVE POLL (not expired) ==========
            return (
              <div
                key={poll.id}
                className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-all"
              >
                {/* Header */}
                <div className="p-4 pb-3">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="text-sm font-medium text-[#1a1a2e] flex-1">{poll.title}</h3>
                    <div className="flex items-center gap-1.5 shrink-0">
                      {voted && (
                        <span className="flex items-center gap-0.5 text-[10px] bg-[#22c55e]/10 text-[#22c55e] px-2 py-0.5 rounded-full">
                          <CheckCircle2 className="w-2.5 h-2.5" />صوّتت
                        </span>
                      )}
                      <span className="flex items-center gap-0.5 text-[10px] px-2 py-0.5 rounded-full bg-[#0D9488]/10 text-[#0D9488]">
                        <Clock className="w-2.5 h-2.5" />
                        نشط
                      </span>
                    </div>
                  </div>
                  {poll.description && (
                    <p className="text-xs text-[#5f6b7a] leading-relaxed">{poll.description}</p>
                  )}
                </div>

                {/* Options */}
                <div className="px-4 pb-3 space-y-2">
                  {poll.options.map((opt, i) => {
                    const pct = totalVotes > 0 ? Math.round((opt.votes / totalVotes) * 100) : 0;
                    const isMyVote = myLabel === opt.label;

                    return (
                      <div key={i}>
                        <div className="flex items-center justify-between mb-1">
                          <span className={`text-xs ${isMyVote ? "text-[#0D9488] font-medium" : "text-[#1a1a2e]"}`}>
                            {isMyVote && <CheckCircle2 className="w-3 h-3 inline ml-1" />}
                            {opt.label}
                          </span>
                          {showResults && (
                            <span className="text-[10px] text-[#5f6b7a]">{pct}% ({opt.votes})</span>
                          )}
                        </div>
                        {showResults && (
                          <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all duration-500 ${
                                isMyVote ? "bg-[#0D9488]" : "bg-gray-300"
                              }`}
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Footer */}
                <div className="px-4 py-2.5 bg-gray-50/80 border-t border-gray-100 flex items-center justify-between">
                  <div className="flex items-center gap-3 text-[10px] text-[#5f6b7a]">
                    <span className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {totalVotes.toLocaleString("en-US")} صوت
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatDeadline(poll.deadline)}
                    </span>
                  </div>
                  {!voted && (
                    <button
                      onClick={() => {
                        setVotingPollId(poll.id);
                        setSelectedOption(null);
                      }}
                      className="px-3 py-1.5 bg-[#0D9488] text-white text-[11px] rounded-lg hover:bg-[#0D9488]/90 transition-colors shadow-sm"
                    >
                      صوّت الآن
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Vote Modal */}
      {votingPollId && (() => {
        const poll = polls.find((p) => p.id === votingPollId);
        if (!poll) return null;
        return (
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center"
            onClick={() => { setVotingPollId(null); setSelectedOption(null); }}
          >
            <div
              className="bg-white rounded-t-3xl sm:rounded-2xl w-full sm:max-w-sm sm:mx-4 p-5 sm:p-6"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Drag handle — mobile */}
              <div className="sm:hidden flex justify-center mb-3">
                <div className="w-10 h-1 bg-gray-300 rounded-full" />
              </div>

              <div className="text-center mb-5">
                <div className="w-14 h-14 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Vote className="w-7 h-7 text-[#0D9488]" />
                </div>
                <h3 className="text-base sm:text-lg text-[#1a1a2e] mb-1">{poll.title}</h3>
                {poll.description && (
                  <p className="text-xs text-[#5f6b7a]">{poll.description}</p>
                )}
              </div>

              <div className="space-y-2 mb-5">
                {poll.options.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedOption(i)}
                    className={`w-full flex items-center gap-3 p-3.5 rounded-xl border-2 transition-all text-right ${
                      selectedOption === i
                        ? "border-[#0D9488] bg-[#0D9488]/5"
                        : "border-gray-100 hover:border-[#0D9488]/30"
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                      selectedOption === i ? "border-[#0D9488] bg-[#0D9488]" : "border-gray-300"
                    }`}>
                      {selectedOption === i && (
                        <div className="w-2 h-2 bg-white rounded-full" />
                      )}
                    </div>
                    <span className={`text-sm flex-1 ${selectedOption === i ? "text-[#0D9488] font-medium" : "text-[#1a1a2e]"}`}>
                      {opt.label}
                    </span>
                  </button>
                ))}
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => { setVotingPollId(null); setSelectedOption(null); }}
                  className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm hover:bg-gray-50 transition-colors"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleVote}
                  disabled={selectedOption === null || submittingVote}
                  className="flex-1 py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {submittingVote ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4" />
                  )}
                  {submittingVote ? "جاري التسجيل..." : "تأكيد التصويت"}
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}