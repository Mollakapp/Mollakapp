import { useState, useEffect, useCallback, useMemo } from "react";
import { Search, Phone, MapPin, Loader2, Wrench, Zap, Droplets, PaintBucket, Wind, Sparkles, HelpCircle, X, Filter } from "lucide-react";
import * as api from "../../lib/api";

const iconMap: Record<string, typeof Wrench> = {
  "سباكة": Droplets,
  "كهرباء": Zap,
  "نجارة": Wrench,
  "دهانات": PaintBucket,
  "تكييف": Wind,
  "نظافة": Sparkles,
  "أخرى": HelpCircle,
};

const colorMap: Record<string, string> = {
  "سباكة": "#3b82f6",
  "كهرباء": "#F59E0B",
  "نجارة": "#8b5cf6",
  "دهانات": "#ec4899",
  "تكييف": "#0D9488",
  "نظافة": "#10b981",
  "أخرى": "#6b7280",
};

const specialties = ["الكل", "سباكة", "كهرباء", "نجارة", "دهانات", "تكييف", "نظافة", "أخرى"];

export function ResidentDirectory() {
  const [contacts, setContacts] = useState<api.DirectoryContact[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [activeSpecialty, setActiveSpecialty] = useState("الكل");
  const [searchOpen, setSearchOpen] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const fetchContacts = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getDirectory();
      setContacts(data);
    } catch (err: any) {
      console.error("Error fetching directory:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchContacts();
  }, [fetchContacts]);

  const filtered = useMemo(() => contacts.filter(
    (c) =>
      (activeSpecialty === "الكل" || c.specialty === activeSpecialty) &&
      (!search || c.name.includes(search) || c.specialty.includes(search) || c.phone.includes(search) || (c.area || "").includes(search))
  ), [contacts, activeSpecialty, search]);

  const hasActiveFilters = activeSpecialty !== "الكل" || search.trim() !== "";

  const clearAllFilters = () => {
    setActiveSpecialty("الكل");
    setSearch("");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-[#F59E0B] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl text-[#1a1a2e]">الأرقام</h1>
          <p className="text-sm text-[#5f6b7a]">
            أرقام الحرفيين ومقدمي الخدمات — {filtered.length.toLocaleString("en-US")} جهة
          </p>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Search icon */}
          <button
            onClick={() => { setSearchOpen(true); setTimeout(() => document.getElementById("resident-directory-search")?.focus(), 50); }}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              search ? "bg-[#F59E0B] text-white shadow-sm" : "bg-white text-[#5f6b7a] border border-[#F59E0B]/10 hover:border-[#F59E0B]/30"
            }`}
          >
            <Search className="w-4 h-4" />
          </button>
          {/* Filter icon */}
          <button
            onClick={() => setFiltersOpen(!filtersOpen)}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              activeSpecialty !== "الكل"
                ? "bg-[#F59E0B] text-white shadow-sm"
                : "bg-white text-[#5f6b7a] border border-[#F59E0B]/10 hover:border-[#F59E0B]/30"
            }`}
          >
            <Filter className="w-4 h-4" />
          </button>
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="text-[10px] text-[#F59E0B] bg-[#F59E0B]/10 px-2 py-1.5 rounded-lg hover:bg-[#F59E0B]/20 transition-colors shrink-0"
            >
              مسح
            </button>
          )}
        </div>
      </div>

      {/* Expandable Search Bar */}
      {searchOpen && (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#5f6b7a]" />
            <input
              id="resident-directory-search"
              type="text"
              placeholder="ابحث عن حرفي أو تخصص..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 bg-white border border-[#F59E0B]/15 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20 text-sm"
            />
          </div>
          <button
            onClick={() => { setSearchOpen(false); setSearch(""); }}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#5f6b7a] bg-white border border-gray-100 hover:bg-gray-50 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Filters Section */}
      {filtersOpen && (
        <div>
          <div className="flex items-center gap-1.5 mb-1.5">
            <Filter className="w-3 h-3 text-[#5f6b7a]" />
            <span className="text-[10px] text-[#5f6b7a] font-medium">التخصص</span>
          </div>
          <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-1" style={{ WebkitOverflowScrolling: "touch" }}>
            {specialties.map((spec) => (
              <button
                key={spec}
                onClick={() => setActiveSpecialty(spec)}
                className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all shrink-0 ${
                  activeSpecialty === spec
                    ? "bg-[#F59E0B] text-white shadow-sm"
                    : "bg-white text-[#5f6b7a] border border-gray-100 hover:border-[#F59E0B]/30 hover:text-[#F59E0B]"
                }`}
              >
                {spec}
                {spec !== "الكل" && (
                  <span className={`mr-1 text-[10px] ${activeSpecialty === spec ? "text-white/70" : "text-[#5f6b7a]/50"}`}>
                    ({contacts.filter((c) => c.specialty === spec).length.toLocaleString("en-US")})
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Contacts List */}
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 bg-[#F59E0B]/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Phone className="w-8 h-8 text-[#F59E0B]" />
          </div>
          <p className="text-sm text-[#5f6b7a]">
            {hasActiveFilters ? "لا توجد نتائج — جرّب تعديل الفلاتر" : "لا توجد جهات اتصال"}
          </p>
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="mt-3 text-xs text-[#F59E0B] underline hover:no-underline"
            >
              مسح جميع الفلاتر
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((contact) => {
            const Icon = iconMap[contact.specialty] || HelpCircle;
            const color = colorMap[contact.specialty] || "#6b7280";

            return (
              <div
                key={contact.id}
                className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm"
              >
                <div className="p-4" style={{ backgroundColor: `${color}04` }}>

                  {/* ── Header: Icon + Name + Specialty badge ── */}
                  <div className="flex items-start gap-3 mb-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
                      style={{ backgroundColor: `${color}15` }}
                    >
                      <Icon className="w-5 h-5" style={{ color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-sm font-semibold text-[#1a1a2e] truncate block">
                        {contact.name}
                      </span>
                      <span
                        className="text-[10px] px-1.5 py-px rounded-full inline-block mt-1 font-medium"
                        style={{
                          backgroundColor: `${color}12`,
                          color: color,
                        }}
                      >
                        {contact.specialty}
                      </span>
                    </div>
                  </div>

                  {/* ── Info Grid ── */}
                  <div className={`grid ${contact.area ? "grid-cols-2" : "grid-cols-1"} gap-2 mb-3`}>
                    <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                      <div className="text-[9px] text-[#5f6b7a]">الهاتف</div>
                      <div className="text-xs text-[#1a1a2e] font-medium" dir="ltr">{contact.phone}</div>
                    </div>
                    {contact.area && (
                      <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                        <div className="text-[9px] text-[#5f6b7a]">المنطقة</div>
                        <div className="text-xs text-[#1a1a2e] font-medium">{contact.area}</div>
                      </div>
                    )}
                  </div>

                  {/* ── Call Button ── */}
                  <a
                    href={`tel:${contact.phone.replace(/-/g, "")}`}
                    className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#F59E0B] text-white text-xs hover:bg-[#F59E0B]/90 transition-all shadow-sm"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    اتصال
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
