import { useState, useEffect, useCallback, useMemo } from "react";
import {
  FileText,
  CreditCard,
  AlertCircle,
  Megaphone,
  Clock,
  CheckCircle2,
  XCircle,
  TrendingDown,
  Wallet,
  CalendarDays,
  ArrowLeft,
  Banknote,
  Hourglass,
  ShieldCheck,
  Smartphone,
  Loader2,
  X,
  AlertTriangle,
  Home,
  Wrench,
  Zap,
  Info,
  Calendar,
} from "lucide-react";
import { motion } from "motion/react";
import { useNavigate } from "react-router";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";
import { getFirstName } from "../../lib/titles";

const annCategoryConfig: Record<string, { icon: typeof Megaphone; color: string }> = {
  "صيانة": { icon: Wrench, color: "#F59E0B" },
  "طوارئ": { icon: Zap, color: "#dc2626" },
  "عام": { icon: Info, color: "#0D9488" },
  "مالي": { icon: Megaphone, color: "#6366f1" },
};

const statusConfig: Record<string, { label: string; color: string; icon: typeof CheckCircle2 }> = {
  paid: { label: "مدفوعة", color: "#22c55e", icon: CheckCircle2 },
  pending: { label: "معلقة", color: "#F59E0B", icon: Clock },
  overdue: { label: "متأخرة", color: "#dc2626", icon: XCircle },
  awaiting_collection: { label: "بانتظار التحصيل", color: "#6366f1", icon: Hourglass },
};

const quickActions = [
  { label: "عرض فواتيري", icon: CreditCard, color: "#0D9488", path: "/resident/invoices" },
  { label: "تواصل مع الإدارة", icon: Megaphone, color: "#F59E0B", path: "/resident/chat" },
  { label: "صوّت على قرار", icon: CalendarDays, color: "#6366f1", path: "/resident/voting" },
  { label: "تبرّع", icon: TrendingDown, color: "#ec4899", path: "/resident/donations" },
];

export function ResidentOverview() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [invoices, setInvoices] = useState<api.ResidentInvoice[]>([]);
  const [loadingInvoices, setLoadingInvoices] = useState(true);
  const [announcements, setAnnouncements] = useState<api.Announcement[]>([]);
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(() => {
    try {
      const stored = localStorage.getItem("mollak-dismissed-announcements");
      return stored ? new Set(JSON.parse(stored)) : new Set();
    } catch { return new Set(); }
  });

  const myUnitCode = profile?.unitCode || "";

  const firstName = getFirstName(profile?.name, "ساكن");
  const buildingName = profile?.buildingName || "المبنى";
  const unitCode = profile?.unitCode || "—";

  const loadInvoices = useCallback(async () => {
    if (!myUnitCode) {
      setLoadingInvoices(false);
      return;
    }
    try {
      setLoadingInvoices(true);
      const data = await api.getResidentInvoices(myUnitCode);
      setInvoices(data);
    } catch (err) {
      console.error("Error loading resident invoices:", err);
    } finally {
      setLoadingInvoices(false);
    }
  }, [myUnitCode]);

  useEffect(() => {
    loadInvoices();
  }, [loadInvoices]);

  // Show latest 5 invoices
  const recentInvoices = invoices.slice(0, 5);

  // Compute dynamic stats from loaded invoices
  const unitStats = useMemo(() => {
    const pendingInvoices = invoices.filter((i) => i.status === "pending" || i.status === "overdue");
    const totalOwed = pendingInvoices.reduce((sum, i) => sum + (i.amount || 0), 0);
    const pendingCount = pendingInvoices.length;

    const paidInvoices = invoices
      .filter((i) => i.status === "paid" && i.paidDate)
      .sort((a, b) => (b.paidDate || "").localeCompare(a.paidDate || ""));
    const lastPaid = paidInvoices[0];
    const lastPaidValue = lastPaid ? `${lastPaid.amount.toLocaleString("en-US")} ج.م` : "—";
    const lastPaidSubtitle = lastPaid ? lastPaid.paidDate!.split("T")[0] : "لا توجد";

    const totalAll = invoices.reduce((sum, i) => sum + (i.amount || 0), 0);

    return [
      {
        label: "مطلوب سداده",
        value: totalOwed > 0 ? `${totalOwed.toLocaleString("en-US")} ج.م` : "0 ج.م",
        subtitle: pendingCount > 0 ? `${pendingCount} فاتورة` : "لا يوجد مستحقات",
        icon: Wallet,
        color: totalOwed > 0 ? "#dc2626" : "#22c55e",
      },
      {
        label: "آخر دفعة",
        value: lastPaidValue,
        subtitle: lastPaidSubtitle,
        icon: CreditCard,
        color: "#0D9488",
      },
      {
        label: "فواتير غير مدفوعة",
        value: `${pendingCount}`,
        subtitle: pendingCount > 0 ? "بانتظار السداد" : "لا يوجد",
        icon: FileText,
        color: "#F59E0B",
      },
      {
        label: "إجمالي الفواتير",
        value: totalAll > 0 ? `${totalAll.toLocaleString("en-US")} ج.م` : "—",
        subtitle: `${invoices.length} فاتورة`,
        icon: Banknote,
        color: "#6366f1",
      },
    ];
  }, [invoices]);

  const loadAnnouncements = useCallback(async () => {
    try {
      const data = await api.getAnnouncements();
      // Sort: urgent first, then by date descending
      data.sort((a, b) => {
        if (a.urgent && !b.urgent) return -1;
        if (!a.urgent && b.urgent) return 1;
        return new Date(b.createdAt || b.date || "").getTime() - new Date(a.createdAt || a.date || "").getTime();
      });
      setAnnouncements(data);
    } catch (err) {
      console.error("Error loading announcements:", err);
    }
  }, []);

  useEffect(() => {
    loadAnnouncements();
  }, [loadAnnouncements]);

  const handleDismiss = useCallback((id: string) => {
    setDismissedIds((prev) => {
      const newSet = new Set(prev);
      newSet.add(id);
      localStorage.setItem("mollak-dismissed-announcements", JSON.stringify(Array.from(newSet)));
      return newSet;
    });
  }, []);

  const visibleAnnouncements = announcements.filter((ann) => !dismissedIds.has(ann.id));

  return (
    <div className="space-y-5">
      {/* Welcome */}
      <div
        className="rounded-2xl p-5 sm:p-6 lg:p-8"
        style={{ background: 'linear-gradient(to left, #F59E0B, #d97706)' }}
      >
        <h1 className="text-xl sm:text-2xl lg:text-3xl mb-2" style={{ color: '#ffffff' }}>أهلاً {firstName}! 👋</h1>
        <p className="text-sm sm:text-base" style={{ color: 'rgba(255,255,255,0.8)' }}>
          إليك ملخص وحدتك في {buildingName} — شقة {unitCode}
        </p>
      </div>

      {/* No unit assigned banner — for board members who haven't set their unit */}
      {!myUnitCode && (
        <div className="bg-[#F59E0B]/10 border border-[#F59E0B]/30 rounded-2xl p-4 flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#F59E0B]/20 flex items-center justify-center shrink-0 mt-0.5">
            <Home className="w-5 h-5 text-[#F59E0B]" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm text-[#1a1a2e] font-semibold mb-1">لم يتم ربط حسابك بشقة</h3>
            <p className="text-xs text-[#5f6b7a] leading-relaxed">
              لعرض فواتيرك وبياناتك كساكن، يجب تحديد الشقة التي تسكن فيها من
              {" "}<button onClick={() => navigate("/dashboard/settings")} className="text-[#0D9488] underline font-medium">الملف الشخصي في لوحة التحكم</button>.
            </p>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
        {unitStats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl px-3 py-2.5 border border-gray-100 flex items-center gap-2.5"
          >
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
              style={{ backgroundColor: `${stat.color}10` }}
            >
              <stat.icon className="w-4 h-4" style={{ color: stat.color }} />
            </div>
            <div className="min-w-0">
              <div className="text-[10px] text-[#5f6b7a]">{stat.label}</div>
              <div className="text-sm text-[#1a1a2e]">{stat.value}</div>
              <div className="text-[9px] text-[#5f6b7a]/70">{stat.subtitle}</div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions — Horizontal scrollable strip */}
      <div className="relative">
        <div
          className="flex gap-2.5 overflow-x-auto scrollbar-hide pb-1 -mx-1 px-1"
          style={{ scrollBehavior: "smooth", WebkitOverflowScrolling: "touch" }}
        >
          {quickActions.map((action) => (
            <button
              key={action.label}
              onClick={() => navigate(action.path)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-gray-100 bg-white hover:shadow-md transition-all hover:-translate-y-0.5 shrink-0"
            >
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: `${action.color}12` }}
              >
                <action.icon className="w-3.5 h-3.5" style={{ color: action.color }} />
              </div>
              <span className="text-xs text-[#5f6b7a] whitespace-nowrap">{action.label}</span>
            </button>
          ))}
        </div>
        {/* Fade edge */}
        <div className="absolute left-0 top-0 bottom-1 w-6 pointer-events-none" style={{ background: 'linear-gradient(to right, #f8fffe, transparent)' }} />
      </div>

      {/* Announcements — dismissible banners */}
      {visibleAnnouncements.length > 0 && (
        <div className="space-y-2.5">
          {visibleAnnouncements.map((announcement) => {
            const isUrgent = announcement.urgent;
            const catConfig = annCategoryConfig[announcement.category] || { icon: Info, color: "#0D9488" };
            const AnnIcon = isUrgent ? AlertTriangle : catConfig.icon;
            const borderColor = isUrgent ? "#F59E0B" : catConfig.color;
            const bgColor = isUrgent ? "#FFF7ED" : "#f8fffe";

            return (
              <motion.div
                key={announcement.id}
                initial={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="rounded-xl p-3.5 border"
                style={{
                  backgroundColor: bgColor,
                  borderColor: `${borderColor}30`,
                }}
              >
                <div className="flex items-start gap-2.5">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                    style={{ backgroundColor: `${borderColor}15` }}
                  >
                    <AnnIcon className="w-4 h-4" style={{ color: borderColor }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-[#1a1a2e] font-medium">{announcement.title}</div>
                    {announcement.description && (
                      <p className="text-xs text-[#5f6b7a] mt-1 leading-relaxed line-clamp-2">{announcement.description}</p>
                    )}
                    <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                      {isUrgent && (
                        <span className="text-[10px] px-2 py-0.5 rounded" style={{ backgroundColor: `${borderColor}15`, color: borderColor }}>
                          <AlertCircle className="w-3 h-3 inline-block ml-0.5 -mt-0.5" />عاجل
                        </span>
                      )}
                      <span className="text-[10px] px-2 py-0.5 rounded" style={{ backgroundColor: `${catConfig.color}12`, color: catConfig.color }}>
                        {announcement.category}
                      </span>
                      <span className="text-[10px] text-[#5f6b7a] flex items-center gap-1">
                        <Calendar className="w-3 h-3" />{announcement.date}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDismiss(announcement.id)}
                    className="p-1.5 text-[#5f6b7a] hover:text-[#1a1a2e] rounded-lg transition-colors shrink-0"
                    style={{ backgroundColor: 'transparent' }}
                    onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = `${borderColor}15`; }}
                    onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Recent Invoices */}
      <div className="bg-white rounded-2xl border border-[#F59E0B]/10">
        <div className="flex items-center justify-between p-5 border-b border-[#F59E0B]/10">
          <h3 className="text-[#1a1a2e]">آخر الفواتير</h3>
          <button
            onClick={() => navigate("/resident/invoices")}
            className="text-sm text-[#F59E0B] hover:underline flex items-center gap-1"
          >
            عرض الكل
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>

        {loadingInvoices ? (
          <div className="flex items-center justify-center py-10">
            <Loader2 className="w-5 h-5 text-[#0D9488] animate-spin" />
          </div>
        ) : recentInvoices.length === 0 ? (
          <div className="text-center py-10">
            <FileText className="w-10 h-10 text-[#0D9488]/15 mx-auto mb-2" />
            <div className="text-sm text-[#5f6b7a]">لا توجد فواتير حالياً</div>
          </div>
        ) : (
          <div className="divide-y divide-[#F59E0B]/5">
            {recentInvoices.map((invoice) => {
              const st = statusConfig[invoice.status] || statusConfig.pending;
              const StIcon = st.icon;
              return (
                <div
                  key={invoice.id}
                  className="flex items-center gap-3 p-4 hover:bg-[#F59E0B]/3 transition-colors cursor-pointer"
                  onClick={() => navigate("/resident/invoices")}
                >
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                    style={{ backgroundColor: `${st.color}15` }}
                  >
                    <StIcon className="w-4 h-4" style={{ color: st.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-[#1a1a2e] truncate">{invoice.description}</div>
                    <div className="text-[11px] text-[#5f6b7a] mt-0.5">
                      {invoice.category} · استحقاق: {invoice.dueDate}
                    </div>
                  </div>
                  <div className="text-left shrink-0">
                    <div className="text-sm text-[#1a1a2e] font-medium">{invoice.amount.toLocaleString("en-US")} ج.م</div>
                    <span
                      className="text-[10px] px-1.5 py-0.5 rounded-full inline-flex items-center gap-0.5"
                      style={{ backgroundColor: `${st.color}12`, color: st.color }}
                    >
                      {st.label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}