import { useState, useEffect, useCallback, useMemo } from "react";
import { FileText, Clock, CheckCircle2, XCircle, CreditCard, X, Loader2, ShieldCheck, Smartphone, Banknote, Hourglass, ArrowLeft, Repeat, Search, Filter, Receipt, CalendarDays, Tag, Wallet } from "lucide-react";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";

const statusMap: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  pending: { label: "معلقة", color: "#F59E0B", icon: Clock },
  paid: { label: "مدفوعة", color: "#22c55e", icon: CheckCircle2 },
  overdue: { label: "متأخرة", color: "#dc2626", icon: XCircle },
  awaiting_collection: { label: "بانتظار التحصيل", color: "#6366f1", icon: Hourglass },
};

export function ResidentInvoices() {
  const { profile } = useAuth();
  const [invoices, setInvoices] = useState<api.ResidentInvoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>("الكل");
  const [payingInvoice, setPayingInvoice] = useState<api.ResidentInvoice | null>(null);
  const [payStep, setPayStep] = useState<"methods" | "confirm" | "success">("methods");
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const myUnitCode = profile?.unitCode || "";
  const myName = profile?.name || "ساكن";

  const loadInvoices = useCallback(async () => {
    if (!myUnitCode) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      const data = await api.getResidentInvoices(myUnitCode);
      setInvoices(data);
    } catch (err) {
      console.error("Error loading resident invoices:", err);
    } finally {
      setLoading(false);
    }
  }, [myUnitCode]);

  useEffect(() => {
    loadInvoices();
  }, [loadInvoices]);

  const filtered = useMemo(() => invoices.filter((inv) => {
    if (filterStatus !== "الكل" && inv.status !== filterStatus) return false;
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      return (
        inv.description.toLowerCase().includes(q) ||
        inv.category.toLowerCase().includes(q) ||
        String(inv.amount).includes(q)
      );
    }
    return true;
  }), [invoices, filterStatus, search]);

  const totalPending = invoices.filter((i) => i.status === "pending" || i.status === "overdue").reduce((s, i) => s + i.amount, 0);
  const totalAwaiting = invoices.filter((i) => i.status === "awaiting_collection").reduce((s, i) => s + i.amount, 0);
  const totalPaid = invoices.filter((i) => i.status === "paid").reduce((s, i) => s + i.amount, 0);

  const statCards = [
    { label: "مستحقة", value: `${totalPending.toLocaleString("en-US")} ج.م`, color: "#F59E0B", icon: Clock },
    { label: "بانتظار التحصيل", value: `${totalAwaiting.toLocaleString("en-US")} ج.م`, color: "#6366f1", icon: Hourglass },
    { label: "مدفوعة", value: `${totalPaid.toLocaleString("en-US")} ج.م`, color: "#22c55e", icon: CheckCircle2 },
  ];

  const hasActiveFilters = filterStatus !== "الكل" || search.trim() !== "";

  const clearAllFilters = () => {
    setFilterStatus("الكل");
    setSearch("");
  };

  const openPayment = (inv: api.ResidentInvoice) => {
    setPayingInvoice(inv);
    setPayStep("methods");
  };

  const handleCashPayment = async () => {
    if (!payingInvoice) return;
    setSubmitting(true);
    try {
      await api.requestCashPayment(
        payingInvoice.batchId,
        payingInvoice.id,
        myName,
        myUnitCode,
        payingInvoice.amount
      );
      setPayStep("success");
      setInvoices((prev) =>
        prev.map((inv) =>
          inv.id === payingInvoice.id
            ? { ...inv, status: "awaiting_collection" as const, method: "كاش عبر الأمن" }
            : inv
        )
      );
    } catch (err) {
      console.error("Error requesting cash payment:", err);
      setSuccessMsg("حدث خطأ أثناء تسجيل الدفع");
      setTimeout(() => setSuccessMsg(""), 2500);
    } finally {
      setSubmitting(false);
    }
  };

  const closePaymentModal = () => {
    setPayingInvoice(null);
    setPayStep("methods");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-[#F59E0B] animate-spin mx-auto mb-3" />
          <p className="text-sm text-[#5f6b7a]">جاري تحميل الفواتير...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-[60] bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <XCircle className="w-4 h-4 shrink-0" />{successMsg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl text-[#1a1a2e]">فواتيري</h1>
          <p className="text-sm text-[#5f6b7a]">
            شقة {myUnitCode} — {filtered.length.toLocaleString("en-US")} فاتورة
          </p>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => { setSearchOpen(true); setTimeout(() => document.getElementById("resident-inv-search")?.focus(), 50); }}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              search ? "bg-[#F59E0B] text-white shadow-sm" : "bg-white text-[#5f6b7a] border border-[#F59E0B]/10 hover:border-[#F59E0B]/30"
            }`}
          >
            <Search className="w-4 h-4" />
          </button>
          <button
            onClick={() => setFiltersOpen(!filtersOpen)}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              filterStatus !== "الكل"
                ? "bg-[#F59E0B] text-white shadow-sm"
                : "bg-white text-[#5f6b7a] border border-[#F59E0B]/10 hover:border-[#F59E0B]/30"
            }`}
          >
            <Filter className="w-4 h-4" />
          </button>
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="text-[10px] text-[#F59E0B] bg-[#F59E0B]/10 px-2 py-1.5 rounded-lg hover:bg-[#F59E0B]/20 transition-colors shrink-0"
            >
              مسح
            </button>
          )}
        </div>
      </div>

      {/* Expandable Search Bar */}
      {searchOpen && (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#5f6b7a]" />
            <input
              id="resident-inv-search"
              type="text"
              placeholder="ابحث عن فاتورة..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 bg-white border border-[#F59E0B]/15 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20 text-sm"
            />
          </div>
          <button
            onClick={() => { setSearchOpen(false); setSearch(""); }}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#5f6b7a] bg-white border border-gray-100 hover:bg-gray-50 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        {statCards.map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-100 px-3 py-2.5 shadow-sm text-center">
            <s.icon className="w-4 h-4 mx-auto mb-1" style={{ color: s.color }} />
            <div className="text-base font-semibold text-[#1a1a2e]">{s.value.replace(" ج.م", "")}</div>
            <div className="text-xs text-[#5f6b7a]">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters Section */}
      {filtersOpen && (
        <div>
          <div className="flex items-center gap-1.5 mb-1.5">
            <Filter className="w-3 h-3 text-[#5f6b7a]" />
            <span className="text-[10px] text-[#5f6b7a] font-medium">الحالة</span>
          </div>
          <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-1" style={{ WebkitOverflowScrolling: "touch" }}>
            {[
              { key: "الكل", label: "الكل" },
              { key: "pending", label: "معلقة" },
              { key: "awaiting_collection", label: "تحصيل" },
              { key: "paid", label: "مدفوعة" },
              { key: "overdue", label: "متأخرة" },
            ].map((f) => {
              const isActive = filterStatus === f.key;
              const count = f.key === "الكل" ? invoices.length : invoices.filter((i) => i.status === f.key).length;
              return (
                <button
                  key={f.key}
                  onClick={() => setFilterStatus(f.key)}
                  className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all shrink-0 ${
                    isActive
                      ? "bg-[#F59E0B] text-white shadow-sm"
                      : "bg-white text-[#5f6b7a] border border-gray-100 hover:border-[#F59E0B]/30 hover:text-[#F59E0B]"
                  }`}
                >
                  {f.label}
                  {count > 0 && (
                    <span className={`mr-1 text-[10px] ${isActive ? "text-white/70" : "text-[#5f6b7a]/50"}`}>
                      ({count.toLocaleString("en-US")})
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Invoices List */}
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 bg-[#F59E0B]/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Receipt className="w-8 h-8 text-[#F59E0B]" />
          </div>
          <p className="text-sm text-[#5f6b7a]">
            {hasActiveFilters ? "لا توجد نتائج — جرّب تعديل الفلاتر" : "لا توجد فواتير"}
          </p>
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="mt-3 text-xs text-[#F59E0B] underline hover:no-underline"
            >
              مسح جميع الفلاتر
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((inv) => {
            const st = statusMap[inv.status] || statusMap.pending;
            const StIcon = st.icon;
            const isPayable = inv.status === "pending" || inv.status === "overdue";

            return (
              <div
                key={inv.id}
                className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm"
              >
                <div className="p-4" style={{ backgroundColor: `${st.color}04` }}>

                  {/* ── Header: Icon + Description + Status badge ── */}
                  <div className="flex items-start gap-3 mb-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
                      style={{ backgroundColor: `${st.color}15` }}
                    >
                      <StIcon className="w-5 h-5" style={{ color: st.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-sm font-semibold text-[#1a1a2e] truncate block">
                        {inv.description}
                      </span>
                      <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                        <span
                          className="text-[10px] px-1.5 py-px rounded-full font-medium"
                          style={{
                            backgroundColor: `${st.color}12`,
                            color: st.color,
                          }}
                        >
                          {st.label}
                        </span>
                        {inv.type === "دائم" && (
                          <span className="flex items-center gap-0.5 text-[10px] px-1.5 py-px rounded-full bg-[#0D9488]/10 text-[#0D9488] font-medium">
                            <Repeat className="w-2.5 h-2.5" />شهرية
                          </span>
                        )}
                        <span className="text-[10px] px-1.5 py-px rounded-full bg-gray-50 text-[#5f6b7a]">
                          {inv.category}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* ── Info Grid ── */}
                  <div className={`grid ${inv.paidDate ? "grid-cols-3" : "grid-cols-2"} gap-2 mb-3`}>
                    <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                      <div className="text-[9px] text-[#5f6b7a]">المبلغ</div>
                      <div className="text-xs font-bold" style={{ color: isPayable ? '#dc2626' : '#22c55e' }}>
                        {inv.amount.toLocaleString("en-US")} <span className="text-[9px] font-normal text-[#5f6b7a]">ج.م</span>
                      </div>
                    </div>
                    <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                      <div className="text-[9px] text-[#5f6b7a]">الاستحقاق</div>
                      <div className="text-[10px] text-[#1a1a2e] font-medium">{inv.dueDate}</div>
                    </div>
                    {inv.paidDate && (
                      <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                        <div className="text-[9px] text-[#5f6b7a]">دُفعت</div>
                        <div className="text-[10px] text-[#1a1a2e] font-medium">{inv.paidDate}</div>
                      </div>
                    )}
                  </div>

                  {/* ── Awaiting collection hint ── */}
                  {inv.status === "awaiting_collection" && (
                    <div className="flex items-center gap-1.5 mb-3 px-0.5">
                      <ShieldCheck className="w-3 h-3 text-[#6366f1]" />
                      <span className="text-[10px] text-[#6366f1]">تم تسليم المبلغ للأمن — بانتظار تأكيد أمين الصندوق</span>
                    </div>
                  )}

                  {/* ── Bottom action ── */}
                  {isPayable ? (
                    <button
                      onClick={() => openPayment(inv)}
                      className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#F59E0B] text-white text-xs hover:bg-[#F59E0B]/90 transition-all shadow-sm"
                    >
                      <Wallet className="w-3.5 h-3.5" />
                      ادفع الآن
                    </button>
                  ) : inv.status === "awaiting_collection" ? (
                    <div className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg border border-[#6366f1]/30 text-[#6366f1] text-xs">
                      <Hourglass className="w-3.5 h-3.5" />
                      بانتظار التحصيل
                    </div>
                  ) : (
                    <div className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg border border-[#22c55e]/30 text-[#22c55e] text-xs">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      تم الدفع
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ===== Payment Modal ===== */}
      {payingInvoice && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={closePaymentModal}>
          <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden" onClick={(e) => e.stopPropagation()}>

            {/* Step 1: Payment Methods */}
            {payStep === "methods" && (
              <>
                <div className="p-6 text-center border-b border-gray-100">
                  <div className="w-14 h-14 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto mb-3">
                    <CreditCard className="w-7 h-7 text-[#0D9488]" />
                  </div>
                  <h3 className="text-lg text-[#1a1a2e] mb-1">طريقة الدفع</h3>
                  <p className="text-sm text-[#5f6b7a]">اختر طريقة الدفع لفاتورة <span className="text-[#1a1a2e]">{payingInvoice.description}</span></p>
                  <div className="mt-2 text-xl text-[#0D9488] font-semibold">{payingInvoice.amount.toLocaleString("en-US")} ج.م</div>
                </div>
                <div className="p-4 space-y-2">
                  {/* Cash to Security — Active */}
                  <button
                    onClick={() => setPayStep("confirm")}
                    className="w-full flex items-center gap-3 p-4 rounded-xl border-2 border-[#0D9488]/20 bg-[#0D9488]/5 hover:bg-[#0D9488]/10 transition-all text-right"
                  >
                    <div className="w-11 h-11 bg-[#0D9488]/10 rounded-xl flex items-center justify-center shrink-0">
                      <ShieldCheck className="w-5 h-5 text-[#0D9488]" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-[#1a1a2e]">كاش للأمن</div>
                      <div className="text-[11px] text-[#5f6b7a]">سلّم المبلغ للأمن وسيصل إشعار لأمين الصندوق</div>
                    </div>
                    <ArrowLeft className="w-4 h-4 text-[#0D9488]" />
                  </button>

                  {/* InstaPay — Coming Soon */}
                  <div className="w-full flex items-center gap-3 p-4 rounded-xl border border-gray-100 bg-gray-50/50 opacity-60 cursor-not-allowed">
                    <div className="w-11 h-11 bg-blue-50 rounded-xl flex items-center justify-center shrink-0">
                      <Smartphone className="w-5 h-5 text-blue-500" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-[#1a1a2e]">إنستا باي</div>
                      <div className="text-[11px] text-[#5f6b7a]">دفع فوري من محفظتك</div>
                    </div>
                    <span className="text-[10px] bg-gray-200 text-[#5f6b7a] px-2 py-0.5 rounded-full shrink-0">قريباً</span>
                  </div>

                  {/* Vodafone Cash — Coming Soon */}
                  <div className="w-full flex items-center gap-3 p-4 rounded-xl border border-gray-100 bg-gray-50/50 opacity-60 cursor-not-allowed">
                    <div className="w-11 h-11 bg-red-50 rounded-xl flex items-center justify-center shrink-0">
                      <Banknote className="w-5 h-5 text-red-500" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-[#1a1a2e]">فودافون كاش</div>
                      <div className="text-[11px] text-[#5f6b7a]">دفع من محفظة فودافون كاش</div>
                    </div>
                    <span className="text-[10px] bg-gray-200 text-[#5f6b7a] px-2 py-0.5 rounded-full shrink-0">قريباً</span>
                  </div>

                  {/* Fawry — Coming Soon */}
                  <div className="w-full flex items-center gap-3 p-4 rounded-xl border border-gray-100 bg-gray-50/50 opacity-60 cursor-not-allowed">
                    <div className="w-11 h-11 bg-amber-50 rounded-xl flex items-center justify-center shrink-0">
                      <CreditCard className="w-5 h-5 text-amber-500" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-[#1a1a2e]">فوري</div>
                      <div className="text-[11px] text-[#5f6b7a]">دفع من أي منفذ فوري</div>
                    </div>
                    <span className="text-[10px] bg-gray-200 text-[#5f6b7a] px-2 py-0.5 rounded-full shrink-0">قريباً</span>
                  </div>
                </div>
                <div className="p-4 pt-0">
                  <button onClick={closePaymentModal} className="w-full py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إغلاق</button>
                </div>
              </>
            )}

            {/* Step 2: Confirm Cash to Security */}
            {payStep === "confirm" && (
              <div className="p-6">
                <div className="text-center mb-5">
                  <div className="w-16 h-16 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <ShieldCheck className="w-8 h-8 text-[#0D9488]" />
                  </div>
                  <h3 className="text-lg text-[#1a1a2e] mb-2">تأكيد الدفع كاش للأمن</h3>
                  <p className="text-sm text-[#5f6b7a] leading-relaxed">
                    بالضغط على "تأكيد"، أنت بتأكد إنك سلّمت مبلغ
                    <span className="text-[#0D9488] font-semibold mx-1">{payingInvoice.amount.toLocaleString("en-US")} ج.م</span>
                    لأمن المبنى.
                  </p>
                </div>

                <div className="bg-[#F59E0B]/5 border border-[#F59E0B]/20 rounded-xl p-3 mb-5">
                  <div className="flex items-start gap-2">
                    <Clock className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                    <div className="text-xs text-[#5f6b7a] leading-relaxed">
                      سيصل <span className="text-[#1a1a2e]">إشعار فوري لأمين الصندوق</span> بأنك تركت المبلغ مع الأمن.
                      بمجرد ما يستلمه أمين الصندوق ويؤكد التحصيل، هتتقفل الفاتورة تلقائياً.
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-xl p-3 mb-5 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-[#5f6b7a]">الفاتورة</span>
                    <span className="text-[#1a1a2e]">{payingInvoice.description}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[#5f6b7a]">المبلغ</span>
                    <span className="text-[#0D9488] font-semibold">{payingInvoice.amount.toLocaleString("en-US")} ج.م</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[#5f6b7a]">طريقة الدفع</span>
                    <span className="text-[#1a1a2e]">كاش عبر الأمن</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button onClick={() => setPayStep("methods")} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">رجوع</button>
                  <button
                    onClick={handleCashPayment}
                    disabled={submitting}
                    className="flex-1 py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-all flex items-center justify-center gap-2 shadow-md shadow-[#0D9488]/20 disabled:opacity-60"
                  >
                    {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                    {submitting ? "جاري التأكيد..." : "تأكيد الدفع"}
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Success */}
            {payStep === "success" && (
              <div className="p-6 text-center">
                <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-10 h-10 text-green-500" />
                </div>
                <h3 className="text-lg text-[#1a1a2e] mb-2">تم تسجيل الدفع بنجاح!</h3>
                <p className="text-sm text-[#5f6b7a] leading-relaxed mb-2">
                  تم إرسال إشعار لأمين الصندوق بأنك سلّمت مبلغ
                  <span className="text-[#0D9488] font-semibold mx-1">{payingInvoice.amount.toLocaleString("en-US")} ج.م</span>
                  لأمن المبنى.
                </p>
                <div className="bg-[#6366f1]/5 border border-[#6366f1]/10 rounded-xl p-3 mb-5">
                  <div className="flex items-center justify-center gap-2 text-sm text-[#6366f1]">
                    <Hourglass className="w-4 h-4" />
                    <span>حالة الفاتورة: بانتظار التحصيل</span>
                  </div>
                </div>
                <button onClick={closePaymentModal} className="w-full py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-all">تم</button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
