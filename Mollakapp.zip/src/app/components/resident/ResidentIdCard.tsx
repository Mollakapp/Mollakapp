import { useState, useRef } from "react";
import {
  X, Download, Loader2, Building2, Phone, Layers, DoorOpen,
  User, Share2, CheckCircle2, ShieldCheck,
} from "lucide-react";
import html2canvas from "html2canvas";

interface IdCardProps {
  isOpen: boolean;
  onClose: () => void;
  name: string;
  buildingName: string;
  floor: string;
  unitCode: string;
  phone: string;
  avatarBase64?: string | null;
  type?: string; // مالك | مستأجر
}

export function ResidentIdCard({
  isOpen,
  onClose,
  name,
  buildingName,
  floor,
  unitCode,
  phone,
  avatarBase64,
  type,
}: IdCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleDownload = async () => {
    if (!cardRef.current) return;
    setDownloading(true);
    try {
      const canvas = await html2canvas(cardRef.current, {
        scale: 3,
        backgroundColor: "#ffffff",
        useCORS: true,
        allowTaint: true,
        logging: false,
        removeContainer: true,
      });
      // Convert to blob for better mobile support
      canvas.toBlob((blob) => {
        if (!blob) {
          console.error("Failed to create blob from canvas");
          setDownloading(false);
          return;
        }
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `mollak-card-${unitCode}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        setDownloading(false);
      }, "image/png");
    } catch (err) {
      console.error("Error downloading card:", err);
      setDownloading(false);
    }
  };

  const handleCopyText = () => {
    const text = `🏠 بطاقة تعريفية — مُلاك\n\n👤 الاسم: ${name}\n🏢 المبنى: ${buildingName}\n🔢 الدور: ${floor}\n🚪 الشقة: ${unitCode}\n📱 الجوال: ${phone}\n\n⚠️ يُرجى إبراز هذه البطاقة لأمن المبنى عند الوصول`;
    // Use execCommand for better mobile support
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    document.body.removeChild(textarea);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const initials = name?.slice(0, 2) || "—";

  return (
    <div
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-t-3xl sm:rounded-2xl w-full sm:max-w-md sm:mx-4 max-h-[95vh] overflow-y-auto"
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Mobile drag handle */}
        <div className="sm:hidden flex justify-center pt-3">
          <div className="w-10 h-1 bg-gray-300 rounded-full" />
        </div>

        {/* Header */}
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="text-base text-[#1a1a2e] font-semibold flex items-center gap-2">
            <User className="w-4 h-4 text-[#F59E0B]" />
            بطاقة تعريفية
          </h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-[#5f6b7a]" />
          </button>
        </div>

        <div className="p-5 space-y-5">
          {/* ====== THE CARD ====== */}
          <div ref={cardRef} className="mx-auto" style={{ maxWidth: 380, padding: 2 }}>
            <div
              className="rounded-2xl overflow-hidden"
              style={{ background: "#ffffff", border: "2px solid #F5CE6B" }}
            >
              {/* Top accent bar */}
              <div style={{ height: 6, background: "linear-gradient(90deg, #F59E0B, #0D9488)" }} />

              {/* Card body */}
              <div style={{ padding: "20px 20px 16px" }}>
                {/* Logo + Title row */}
                <div className="flex items-center justify-between" style={{ marginBottom: 20 }}>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center justify-center" style={{ width: 32, height: 32, background: "#F59E0B", borderRadius: 8 }}>
                      <Building2 className="text-white" style={{ width: 18, height: 18 }} />
                    </div>
                    <div>
                      <div style={{ color: "#1a1a2e", fontSize: 14, fontWeight: 700, letterSpacing: "0.025em" }}>مُلاك</div>
                      <div style={{ color: "#9ca3af", fontSize: 9 }}>Mollak</div>
                    </div>
                  </div>
                  <div style={{ border: "1px solid #b2dfdb", background: "#e0f2f1", padding: "4px 12px", borderRadius: 999 }}>
                    <span style={{ color: "#0D9488", fontSize: 10, fontWeight: 500 }}>بطاقة تعريفية</span>
                  </div>
                </div>

                {/* Avatar + Name */}
                <div className="flex items-center gap-4" style={{ marginBottom: 20 }}>
                  <div className="overflow-hidden shrink-0" style={{ width: 64, height: 64, borderRadius: 12, border: "2px solid #F5CE6B", background: "#FFF8E7" }}>
                    {avatarBase64 ? (
                      <img src={avatarBase64} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <span style={{ fontSize: 20, color: "#F59E0B", fontWeight: 700 }}>{initials}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="truncate" style={{ color: "#1a1a2e", fontSize: 18, fontWeight: 700, lineHeight: 1.3 }}>
                      {name}
                    </div>
                    <div style={{ marginTop: 4, color: "#5f6b7a", fontSize: 12, fontWeight: 500 }}>
                      {type === "مستأجر" ? "مستأجر" : "مالك"}
                    </div>
                  </div>
                </div>

                {/* Info Grid */}
                <div className="grid grid-cols-2" style={{ gap: 10 }}>
                  <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 12, padding: 12 }}>
                    <div className="flex items-center gap-1.5" style={{ marginBottom: 6 }}>
                      <Building2 style={{ width: 12, height: 12, color: "#F59E0B" }} />
                      <span style={{ color: "#5f6b7a", fontSize: 10 }}>المبنى</span>
                    </div>
                    <div className="truncate" style={{ color: "#1a1a2e", fontSize: 14, fontWeight: 600 }}>{buildingName}</div>
                  </div>

                  <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 12, padding: 12 }}>
                    <div className="flex items-center gap-1.5" style={{ marginBottom: 6 }}>
                      <Layers style={{ width: 12, height: 12, color: "#F59E0B" }} />
                      <span style={{ color: "#5f6b7a", fontSize: 10 }}>الدور</span>
                    </div>
                    <div style={{ color: "#1a1a2e", fontSize: 14, fontWeight: 600 }}>{floor}</div>
                  </div>

                  <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 12, padding: 12 }}>
                    <div className="flex items-center gap-1.5" style={{ marginBottom: 6 }}>
                      <DoorOpen style={{ width: 12, height: 12, color: "#0D9488" }} />
                      <span style={{ color: "#5f6b7a", fontSize: 10 }}>الشقة</span>
                    </div>
                    <div style={{ color: "#1a1a2e", fontSize: 14, fontWeight: 600 }}>{unitCode}</div>
                  </div>

                  <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 12, padding: 12 }}>
                    <div className="flex items-center gap-1.5" style={{ marginBottom: 6 }}>
                      <Phone style={{ width: 12, height: 12, color: "#0D9488" }} />
                      <span style={{ color: "#5f6b7a", fontSize: 10 }}>الجوال</span>
                    </div>
                    <div dir="ltr" style={{ color: "#1a1a2e", fontSize: 14, fontWeight: 600, textAlign: "right" }}>
                      {phone}
                    </div>
                  </div>
                </div>

              </div>

              {/* Note strip */}
              <div className="flex items-center gap-2" style={{ margin: "0 16px 16px", background: "#e6f7f5", border: "1px solid #b2dfdb", borderRadius: 12, padding: "10px 16px" }}>
                <ShieldCheck className="shrink-0" style={{ width: 14, height: 14, color: "#0D9488" }} />
                <span style={{ color: "#0D9488", fontSize: 10, lineHeight: 1.6, fontWeight: 500 }}>يُرجى إبراز هذه البطاقة لأمن المبنى عند الوصول</span>
              </div>

              {/* Bottom bar */}
              <div className="flex items-center justify-between" style={{ background: "#f8fafc", borderTop: "1px solid #e2e8f0", padding: "8px 20px" }}>
                <span style={{ color: "#9ca3af", fontSize: 9 }}>mollak.app</span>
                <span style={{ color: "#9ca3af", fontSize: 9 }}>بطاقة تعريفية</span>
              </div>
            </div>
          </div>

          {/* Hint */}
          <p className="text-center text-xs text-[#5f6b7a] leading-relaxed">
            أرسل هذه البطاقة لمندوب التوصيل ليصل إليك بسهولة
          </p>

          {/* Actions */}
          <div className="flex gap-2">
            <button
              onClick={handleCopyText}
              className="flex-1 py-3 rounded-xl border border-[#0D9488]/20 text-[#0D9488] text-sm hover:bg-[#0D9488]/5 transition-colors flex items-center justify-center gap-2"
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  تم النسخ
                </>
              ) : (
                <>
                  <Share2 className="w-4 h-4" />
                  نسخ النص
                </>
              )}
            </button>
            <button
              onClick={handleDownload}
              disabled={downloading}
              className="flex-1 py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-colors flex items-center justify-center gap-2 shadow-md shadow-[#0D9488]/20 disabled:opacity-50"
            >
              {downloading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              {downloading ? "جاري التحميل..." : "تحميل كصورة"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}