import { useState, useEffect, useCallback } from "react";
import {
  Heart,
  Users,
  CheckCircle2,
  X,
  Gift,
  Loader2,
  Clock,
  Banknote,
  Calendar,
  ShieldCheck,
  EyeOff,
} from "lucide-react";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";

function formatDate(iso: string): string {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });
  } catch {
    return iso;
  }
}

export function ResidentDonations() {
  const { profile } = useAuth();
  const [campaigns, setCampaigns] = useState<api.DonationCampaign[]>([]);
  const [myRequests, setMyRequests] = useState<api.DonationCashRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [donatingCampaign, setDonatingCampaign] = useState<api.DonationCampaign | null>(null);
  const [donateStep, setDonateStep] = useState<"amount" | "methods" | "confirm" | "success">("amount");
  const [donationAmount, setDonationAmount] = useState("");
  const [anonymous, setAnonymous] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const myName = profile?.name || "ساكن";
  const myUnitCode = profile?.unitCode || "";
  const myPhone = profile?.phone || "";

  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      const [campaignsData, requestsData] = await Promise.allSettled([
        api.getDonations(),
        api.getDonationCashRequests(),
      ]);
      if (campaignsData.status === "fulfilled") {
        setCampaigns(campaignsData.value);
      }
      if (requestsData.status === "fulfilled") {
        // Filter to only show my requests
        const all: api.DonationCashRequest[] = requestsData.value;
        setMyRequests(all.filter((r) => r.phone === myPhone || r.residentName === myName));
      }
    } catch (err) {
      console.error("Error loading donations:", err);
    } finally {
      setLoading(false);
    }
  }, [myPhone, myName]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const activeCampaigns = campaigns.filter((c) => c.status === "active");
  const totalCollected = campaigns.reduce((s, c) => s + c.collected, 0);
  const totalDonors = campaigns.reduce((s, c) => s + c.donors.length, 0);
  const myPendingRequests = myRequests.filter((r) => r.status === "pending");
  const myCollectedRequests = myRequests.filter((r) => r.status === "collected");
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  const handleCancelRequest = async (requestId: string) => {
    setCancellingId(requestId);
    try {
      await api.cancelDonationCash(requestId);
      setMyRequests((prev) => prev.filter((r) => r.id !== requestId));
      showSuccess("تم إلغاء نية التبرع");
    } catch (err: any) {
      console.error("Error cancelling donation:", err);
      showError(err.message || "فشل إلغاء الطلب");
    } finally {
      setCancellingId(null);
    }
  };

  const openDonate = (campaign: api.DonationCampaign) => {
    setDonatingCampaign(campaign);
    setDonationAmount("");
    setAnonymous(false);
    setDonateStep("amount");
  };

  const goToMethods = () => {
    if (!donationAmount || Number(donationAmount) <= 0) return;
    setDonateStep("methods");
  };

  const handleCashDonation = async () => {
    if (!donatingCampaign || !donationAmount || Number(donationAmount) <= 0) return;
    setSubmitting(true);
    try {
      await api.requestDonationCash(donatingCampaign.id, {
        residentName: myName,
        unitCode: myUnitCode,
        phone: myPhone,
        amount: Number(donationAmount),
        anonymous,
      });
      setDonateStep("success");
      // Refresh data
      loadData();
    } catch (err: any) {
      console.error("Error requesting donation cash:", err);
      showError(err.message || "فشل إرسال طلب التبرع");
    } finally {
      setSubmitting(false);
    }
  };

  const closeDonateModal = () => {
    setDonatingCampaign(null);
    setDonateStep("amount");
    setDonationAmount("");
    setAnonymous(false);
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };
  const showError = (msg: string) => {
    setErrorMsg(msg);
    setTimeout(() => setErrorMsg(""), 3000);
  };

  const statCards = [
    { label: "إجمالي التبرعات", value: `${totalCollected.toLocaleString("en-US")} ج.م`, color: "#0D9488", icon: Heart },
    { label: "عدد المتبرعين", value: totalDonors, color: "#6366f1", icon: Users },
    { label: "حملات متاحة", value: activeCampaigns.length, color: "#F59E0B", icon: Gift },
  ];

  // Quick amount buttons
  const quickAmounts = [50, 100, 200, 500, 1000];

  return (
    <div className="space-y-6">
      {/* Success Toast */}
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}
      {/* Error Toast */}
      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <X className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
        </div>
      )}

      <div>
        <h1 className="text-2xl text-[#1a1a2e]">التبرعات</h1>
        <p className="text-sm text-[#5f6b7a]">شارك في حملات التبرع لخدمة البرج</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        {statCards.map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-100 px-2 py-2.5 sm:px-4 sm:py-3 shadow-sm text-center">
            <s.icon className="w-4 h-4 mx-auto mb-1" style={{ color: s.color }} />
            <div className="text-base font-semibold text-[#1a1a2e] truncate">{s.value}</div>
            <div className="text-[10px] sm:text-xs text-[#5f6b7a] truncate">{s.label}</div>
          </div>
        ))}
      </div>

      {/* My Pending Donation Requests */}
      {myPendingRequests.length > 0 && (
        <div className="space-y-2">
          <h2 className="text-sm text-[#1a1a2e] font-medium">بانتظار التحصيل</h2>
          {myPendingRequests.map((req) => (
            <div key={req.id} className="bg-[#F59E0B]/5 rounded-xl border border-[#F59E0B]/10 p-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-[#F59E0B]/10 rounded-full flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4 text-[#F59E0B]" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-[#1a1a2e]">{req.campaignTitle}</div>
                  <div className="text-[10px] text-[#5f6b7a]">بانتظار تحصيل أمين الصندوق</div>
                </div>
                <div className="text-sm text-[#F59E0B] font-semibold shrink-0">{req.amount.toLocaleString("en-US")} ج.م</div>
              </div>
              <button
                onClick={() => handleCancelRequest(req.id)}
                disabled={cancellingId === req.id}
                className="mt-2 w-full flex items-center justify-center gap-1.5 py-2 rounded-lg border border-gray-200 text-[#5f6b7a] text-xs hover:bg-gray-50 transition-all disabled:opacity-60"
              >
                {cancellingId === req.id ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <X className="w-3.5 h-3.5" />
                )}
                إلغاء نية التبرع
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Collected Requests Feedback */}
      {myCollectedRequests.length > 0 && (
        <div className="space-y-2">
          <h2 className="text-sm text-[#1a1a2e] font-medium">تبرعاتي المحصّلة</h2>
          {myCollectedRequests.map((req) => (
            <div key={req.id} className="bg-[#0D9488]/5 rounded-xl border border-[#0D9488]/10 p-3 flex items-center gap-3">
              <div className="w-9 h-9 bg-[#0D9488]/10 rounded-full flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-4 h-4 text-[#0D9488]" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-[#1a1a2e]">{req.campaignTitle}</div>
                <div className="text-[10px] text-[#0D9488]">تم تحصيل تبرعك — شكراً لك!</div>
              </div>
              <div className="text-sm text-[#0D9488] font-semibold shrink-0">{req.amount.toLocaleString("en-US")} ج.م</div>
            </div>
          ))}
        </div>
      )}

      {/* Loading */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin mx-auto mb-3" />
          <p className="text-sm text-[#5f6b7a]">جاري تحميل حملات التبرع...</p>
        </div>
      ) : (
        /* Campaigns */
        <div className="space-y-4">
          {campaigns.map((campaign) => {
            const pct = campaign.target > 0 ? Math.min(100, Math.round((campaign.collected / campaign.target) * 100)) : 0;
            const isActive = campaign.status === "active";
            return (
              <div key={campaign.id} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-all">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className="text-[#1a1a2e]">{campaign.title}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        isActive ? "bg-[#0D9488]/10 text-[#0D9488]" : "bg-gray-100 text-[#5f6b7a]"
                      }`}>
                        {isActive ? "نشطة" : "مكتملة"}
                      </span>
                    </div>
                    {campaign.description && (
                      <p className="text-sm text-[#5f6b7a]">{campaign.description}</p>
                    )}
                  </div>
                  {isActive && (
                    <button
                      onClick={() => openDonate(campaign)}
                      className="px-4 py-2 bg-[#0D9488] text-white text-sm rounded-xl hover:bg-[#0D9488]/90 transition-colors shadow-sm shrink-0 mr-2"
                    >
                      تبرّع
                    </button>
                  )}
                </div>

                {/* Progress */}
                <div className="mb-3">
                  <div className="flex justify-between text-xs text-[#5f6b7a] mb-1.5">
                    <span>{campaign.collected.toLocaleString("en-US")} ج.م</span>
                    <span>{campaign.target.toLocaleString("en-US")} ج.م</span>
                  </div>
                  <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${pct >= 100 ? "bg-[#F59E0B]" : "bg-[#0D9488]"}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="text-left text-[10px] text-[#5f6b7a] mt-1">{pct}%</div>
                </div>

                {/* Info */}
                <div className="flex items-center gap-4 text-xs text-[#5f6b7a] flex-wrap">
                  <span className="flex items-center gap-1"><Users className="w-3 h-3" />{campaign.donors.length} متبرع</span>
                  {campaign.deadline && (
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />{formatDate(campaign.deadline)}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
          {campaigns.length === 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center">
              <Heart className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="text-sm text-[#5f6b7a]">لا توجد حملات تبرع حالياً</p>
            </div>
          )}
        </div>
      )}

      {/* ===== Donate Modal ===== */}
      {donatingCampaign && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center" onClick={closeDonateModal}>
          <div
            className="bg-white rounded-t-2xl sm:rounded-2xl w-full sm:max-w-md max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">
                {donateStep === "success" ? "تم بنجاح" : "تبرّع"}
              </h3>
              <button onClick={closeDonateModal} className="text-[#5f6b7a]"><X className="w-5 h-5" /></button>
            </div>

            {/* Campaign Info */}
            {donateStep !== "success" && (
              <div className="mx-5 mt-5 bg-[#f8fffe] rounded-xl p-3 border border-[#0D9488]/5">
                <div className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-[#0D9488] shrink-0" />
                  <p className="text-sm text-[#1a1a2e] font-medium">{donatingCampaign.title}</p>
                </div>
                {donatingCampaign.description && (
                  <p className="text-xs text-[#5f6b7a] mt-1 mr-6">{donatingCampaign.description}</p>
                )}
                <div className="flex items-center gap-3 mt-2 mr-6 text-[10px] text-[#5f6b7a]">
                  <span>المتبقي: {(donatingCampaign.target - donatingCampaign.collected).toLocaleString("en-US")} ج.م</span>
                  <span>{Math.round((donatingCampaign.collected / donatingCampaign.target) * 100)}% محقق</span>
                </div>
              </div>
            )}

            {/* Step 1: Enter Amount */}
            {donateStep === "amount" && (
              <div className="p-5 space-y-4">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">مبلغ التبرع (ج.م) *</label>
                  <input
                    type="number"
                    value={donationAmount}
                    onChange={(e) => setDonationAmount(e.target.value)}
                    placeholder="أدخل المبلغ"
                    className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm text-center text-lg focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                    autoFocus
                  />
                </div>

                {/* Quick amount buttons */}
                <div className="flex flex-wrap gap-2">
                  {quickAmounts.map((amt) => (
                    <button
                      key={amt}
                      onClick={() => setDonationAmount(String(amt))}
                      className={`px-3 py-1.5 rounded-lg text-xs border transition-all ${
                        donationAmount === String(amt)
                          ? "bg-[#0D9488] text-white border-[#0D9488]"
                          : "border-[#0D9488]/20 text-[#5f6b7a] hover:bg-[#0D9488]/5"
                      }`}
                    >
                      {amt.toLocaleString("en-US")} ج.م
                    </button>
                  ))}
                </div>

                {/* Anonymous donation checkbox */}
                <label className="flex items-center gap-3 bg-[#F59E0B]/5 border border-[#F59E0B]/15 rounded-xl p-3 cursor-pointer hover:bg-[#F59E0B]/10 transition-colors">
                  <div className="relative">
                    <input
                      type="checkbox"
                      checked={anonymous}
                      onChange={(e) => setAnonymous(e.target.checked)}
                      className="sr-only"
                    />
                    <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${
                      anonymous ? "bg-[#F59E0B] border-[#F59E0B]" : "border-gray-300 bg-white"
                    }`}>
                      {anonymous && (
                        <svg className="w-3 h-3 text-white" viewBox="0 0 12 12" fill="none">
                          <path d="M2 6L5 9L10 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      )}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5">
                      <EyeOff className="w-3.5 h-3.5 text-[#F59E0B]" />
                      <span className="text-sm text-[#1a1a2e] font-medium">إخفاء الاسم (صدقة)</span>
                    </div>
                    <p className="text-[10px] text-[#5f6b7a] mt-0.5">لن يظهر اسمك لباقي السكان — سيظهر كـ "متبرع مجهول"</p>
                  </div>
                </label>

                <button
                  onClick={goToMethods}
                  disabled={!donationAmount || Number(donationAmount) <= 0}
                  className={`w-full py-3 rounded-xl text-white text-sm transition-all ${
                    donationAmount && Number(donationAmount) > 0
                      ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20"
                      : "bg-gray-300 cursor-not-allowed"
                  }`}
                >
                  التالي — اختيار طريقة الدفع
                </button>
              </div>
            )}

            {/* Step 2: Payment Methods */}
            {donateStep === "methods" && (
              <div className="p-5 space-y-3">
                <div className="bg-[#0D9488]/5 rounded-xl p-3 text-center mb-2">
                  <span className="text-xs text-[#5f6b7a]">مبلغ التبرع</span>
                  <div className="text-xl text-[#0D9488] font-bold">{Number(donationAmount).toLocaleString("en-US")} ج.م</div>
                </div>

                <p className="text-xs text-[#5f6b7a] text-center">اختر طريقة الدفع</p>

                {/* Cash via Security */}
                <button
                  onClick={() => setDonateStep("confirm")}
                  className="w-full flex items-center gap-3 p-4 bg-white border border-[#0D9488]/15 rounded-xl hover:bg-[#0D9488]/5 transition-all text-right"
                >
                  <div className="w-10 h-10 bg-[#6366f1]/10 rounded-xl flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-5 h-5 text-[#6366f1]" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm text-[#1a1a2e] font-medium">كاش عبر الأمن</div>
                    <div className="text-[10px] text-[#5f6b7a]">سلّم المبلغ للأمن وسيتم إخطار أمين الصندوق</div>
                  </div>
                </button>

                {/* Electronic - Coming Soon */}
                <div className="w-full flex items-center gap-3 p-4 bg-gray-50 border border-gray-100 rounded-xl opacity-50 cursor-not-allowed text-right">
                  <div className="w-10 h-10 bg-gray-200 rounded-xl flex items-center justify-center shrink-0">
                    <Banknote className="w-5 h-5 text-gray-400" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm text-gray-400 font-medium">تحويل إلكتروني</div>
                    <div className="text-[10px] text-gray-400">قريباً — فودافون كاش / إنستاباي</div>
                  </div>
                </div>

                <button
                  onClick={() => setDonateStep("amount")}
                  className="w-full py-2.5 text-[#5f6b7a] text-xs hover:underline"
                >
                  تعديل المبلغ
                </button>
              </div>
            )}

            {/* Step 3: Confirm Cash */}
            {donateStep === "confirm" && (
              <div className="p-5 space-y-4">
                <div className="bg-[#6366f1]/5 rounded-xl p-4 space-y-3">
                  <div className="text-center">
                    <ShieldCheck className="w-10 h-10 text-[#6366f1] mx-auto mb-2" />
                    <h4 className="text-sm text-[#1a1a2e] font-medium">تسجيل نية التبرع عبر الأمن</h4>
                  </div>
                  <div className="space-y-2 text-xs text-[#5f6b7a]">
                    <div className="flex justify-between bg-white rounded-lg px-3 py-2 border border-gray-100">
                      <span>الحملة</span>
                      <span className="text-[#1a1a2e]">{donatingCampaign.title}</span>
                    </div>
                    <div className="flex justify-between bg-white rounded-lg px-3 py-2 border border-gray-100">
                      <span>المبلغ</span>
                      <span className="text-[#0D9488] font-semibold">{Number(donationAmount).toLocaleString("en-US")} ج.م</span>
                    </div>
                    <div className="flex justify-between bg-white rounded-lg px-3 py-2 border border-gray-100">
                      <span>المتبرع</span>
                      <span className="text-[#1a1a2e]">
                        {anonymous ? (
                          <span className="flex items-center gap-1 text-[#F59E0B]">
                            <EyeOff className="w-3 h-3" /> متبرع مجهول (صدقة)
                          </span>
                        ) : (
                          <>{myName} — شقة {myUnitCode}</>
                        )}
                      </span>
                    </div>
                  </div>
                  <p className="text-[10px] text-[#6366f1] text-center leading-relaxed">
                    سلّم المبلغ لفرد الأمن وسيقوم أمين الصندوق بتسجيل التحصيل
                  </p>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setDonateStep("methods")}
                    className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm"
                  >
                    رجوع
                  </button>
                  <button
                    onClick={handleCashDonation}
                    disabled={submitting}
                    className="flex-1 py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20 flex items-center justify-center gap-2"
                  >
                    {submitting ? (
                      <><Loader2 className="w-4 h-4 animate-spin" />جاري الإرسال...</>
                    ) : (
                      "تسجيل نية التبرع"
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Success */}
            {donateStep === "success" && (
              <div className="p-5 text-center space-y-4">
                <div className="w-16 h-16 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8 text-[#0D9488]" />
                </div>
                <div>
                  <h4 className="text-lg text-[#1a1a2e] mb-1">تم تسجيل نية التبرع</h4>
                  <p className="text-sm text-[#5f6b7a]">
                    سلّم مبلغ <span className="text-[#0D9488] font-semibold">{Number(donationAmount).toLocaleString("en-US")} ج.م</span> لفرد الأمن
                  </p>
                  <p className="text-xs text-[#5f6b7a] mt-2">
                    سيقوم أمين الصندوق بتسجيل التحصيل وسيظهر تبرعك في الحملة
                  </p>
                </div>
                <button
                  onClick={closeDonateModal}
                  className="w-full py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20"
                >
                  تم
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}