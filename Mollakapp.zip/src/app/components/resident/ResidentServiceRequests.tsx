import { useState, useEffect, useCallback, useMemo } from "react";
import {
  ClipboardList,
  Plus,
  X,
  Loader2,
  Clock,
  CheckCircle,
  XCircle,
  Lock,
  Trash2,
  ChevronDown,
  Key,
  Wrench,
  ShieldCheck,
  PackageOpen,
  FileText,
  HelpCircle,
  AlertTriangle,
  Search,
  Filter,
  CalendarDays,
  MessageSquare,
} from "lucide-react";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";

const categories = [
  { id: "مفتاح أسانسير", label: "مفتاح أسانسير", icon: Key, color: "#F59E0B" },
  { id: "صيانة", label: "صيانة", icon: Wrench, color: "#3b82f6" },
  { id: "أمن", label: "أمن وسلامة", icon: ShieldCheck, color: "#ef4444" },
  { id: "نظافة", label: "نظافة", icon: PackageOpen, color: "#10b981" },
  { id: "مستندات", label: "مستندات وأوراق", icon: FileText, color: "#8b5cf6" },
  { id: "أخرى", label: "أخرى", icon: HelpCircle, color: "#6b7280" },
];

const statusConfig: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  pending: { label: "قيد المراجعة", color: "#F59E0B", icon: Clock },
  approved: { label: "تمت الموافقة", color: "#22c55e", icon: CheckCircle },
  rejected: { label: "مرفوض", color: "#ef4444", icon: XCircle },
  closed: { label: "مغلق", color: "#6b7280", icon: Lock },
};

export function ResidentServiceRequests() {
  const { profile } = useAuth();
  const [requests, setRequests] = useState<api.ServiceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [creating, setCreating] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>("all");
  const [successMsg, setSuccessMsg] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);

  // Form fields
  const [formTitle, setFormTitle] = useState("");
  const [formDesc, setFormDesc] = useState("");
  const [formCategory, setFormCategory] = useState("مفتاح أسانسير");

  const myPhone = profile?.phone || "";

  const loadRequests = useCallback(async () => {
    if (!myPhone) return;
    try {
      const data = await api.getServiceRequests(myPhone);
      setRequests(data);
    } catch (err) {
      console.error("Error loading service requests:", err);
    } finally {
      setLoading(false);
    }
  }, [myPhone]);

  useEffect(() => {
    loadRequests();
  }, [loadRequests]);

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 3000);
  };

  const handleCreate = async () => {
    if (!formTitle.trim() || creating) return;
    setCreating(true);
    try {
      await api.createServiceRequest({
        requesterPhone: myPhone,
        requesterName: profile?.name || "ساكن",
        unitCode: profile?.unitCode || "",
        title: formTitle.trim(),
        description: formDesc.trim(),
        category: formCategory,
      });
      showSuccess("تم إرسال طلبك بنجاح");
      setShowForm(false);
      setFormTitle("");
      setFormDesc("");
      setFormCategory("مفتاح أسانسير");
      await loadRequests();
    } catch (err) {
      console.error("Error creating service request:", err);
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await api.deleteServiceRequest(id, myPhone);
      showSuccess("تم حذف الطلب");
      await loadRequests();
    } catch (err) {
      console.error("Error deleting service request:", err);
    } finally {
      setDeletingId(null);
    }
  };

  const formatDate = (iso: string) => {
    try {
      return new Date(iso).toLocaleDateString("ar-u-nu-latn", {
        day: "numeric",
        month: "short",
        year: "numeric",
      });
    } catch {
      return "";
    }
  };

  const formatDateTime = (iso: string) => {
    try {
      return new Date(iso).toLocaleDateString("ar-u-nu-latn", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "";
    }
  };

  const filtered = useMemo(() => {
    let list = filter === "all" ? requests : requests.filter((r) => r.status === filter);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter(
        (r) =>
          r.title.toLowerCase().includes(q) ||
          r.category.toLowerCase().includes(q) ||
          (r.description || "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [requests, filter, search]);

  const counts = {
    all: requests.length,
    pending: requests.filter((r) => r.status === "pending").length,
    approved: requests.filter((r) => r.status === "approved").length,
    rejected: requests.filter((r) => r.status === "rejected").length,
    closed: requests.filter((r) => r.status === "closed").length,
  };

  const hasActiveFilters = filter !== "all" || search.trim() !== "";

  const clearAllFilters = () => {
    setFilter("all");
    setSearch("");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-[#F59E0B] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Success Toast */}
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#22c55e] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl text-[#1a1a2e]">طلباتي</h1>
          <p className="text-sm text-[#5f6b7a]">
            أرسل طلبك للاتحاد وتابع حالته — {filtered.length.toLocaleString("en-US")} طلب
          </p>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => { setSearchOpen(true); setTimeout(() => document.getElementById("resident-sr-search")?.focus(), 50); }}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              search ? "bg-[#F59E0B] text-white shadow-sm" : "bg-white text-[#5f6b7a] border border-[#F59E0B]/10 hover:border-[#F59E0B]/30"
            }`}
          >
            <Search className="w-4 h-4" />
          </button>
          <button
            onClick={() => setFiltersOpen(!filtersOpen)}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              filter !== "all"
                ? "bg-[#F59E0B] text-white shadow-sm"
                : "bg-white text-[#5f6b7a] border border-[#F59E0B]/10 hover:border-[#F59E0B]/30"
            }`}
          >
            <Filter className="w-4 h-4" />
          </button>
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="text-[10px] text-[#F59E0B] bg-[#F59E0B]/10 px-2 py-1.5 rounded-lg hover:bg-[#F59E0B]/20 transition-colors shrink-0"
            >
              مسح
            </button>
          )}
          <button
            onClick={() => setShowForm(true)}
            className="hidden sm:flex w-9 h-9 rounded-xl items-center justify-center bg-[#F59E0B] text-white hover:bg-[#F59E0B]/90 transition-colors shadow-sm"
            title="طلب جديد"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Expandable Search Bar */}
      {searchOpen && (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#5f6b7a]" />
            <input
              id="resident-sr-search"
              type="text"
              placeholder="ابحث عن طلب..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 bg-white border border-[#F59E0B]/15 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20 text-sm"
            />
          </div>
          <button
            onClick={() => { setSearchOpen(false); setSearch(""); }}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#5f6b7a] bg-white border border-gray-100 hover:bg-gray-50 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-4 gap-2">
        {([
          { label: "الكل", count: counts.all, color: "#0D9488", icon: ClipboardList },
          { label: "مراجعة", count: counts.pending, color: "#F59E0B", icon: Clock },
          { label: "موافق", count: counts.approved, color: "#22c55e", icon: CheckCircle },
          { label: "مرفوض", count: counts.rejected, color: "#ef4444", icon: XCircle },
        ]).map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-100 px-2 py-2.5 shadow-sm text-center">
            <s.icon className="w-3.5 h-3.5 mx-auto mb-1" style={{ color: s.color }} />
            <div className="text-base font-semibold text-[#1a1a2e]">{s.count.toLocaleString("en-US")}</div>
            <div className="text-[10px] text-[#5f6b7a]">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters Section */}
      {filtersOpen && (
        <div>
          <div className="flex items-center gap-1.5 mb-1.5">
            <Filter className="w-3 h-3 text-[#5f6b7a]" />
            <span className="text-[10px] text-[#5f6b7a] font-medium">الحالة</span>
          </div>
          <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-1" style={{ WebkitOverflowScrolling: "touch" }}>
            {([
              { key: "all", label: "الكل" },
              { key: "pending", label: "قيد المراجعة" },
              { key: "approved", label: "تمت الموافقة" },
              { key: "rejected", label: "مرفوض" },
              { key: "closed", label: "مغلق" },
            ] as const).map((f) => {
              const isActive = filter === f.key;
              const count = counts[f.key];
              return (
                <button
                  key={f.key}
                  onClick={() => setFilter(f.key)}
                  className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all shrink-0 ${
                    isActive
                      ? "bg-[#F59E0B] text-white shadow-sm"
                      : "bg-white text-[#5f6b7a] border border-gray-100 hover:border-[#F59E0B]/30 hover:text-[#F59E0B]"
                  }`}
                >
                  {f.label}
                  {count > 0 && (
                    <span className={`mr-1 text-[10px] ${isActive ? "text-white/70" : "text-[#5f6b7a]/50"}`}>
                      ({count.toLocaleString("en-US")})
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Requests List */}
      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 bg-[#F59E0B]/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <ClipboardList className="w-8 h-8 text-[#F59E0B]" />
          </div>
          <p className="text-sm text-[#5f6b7a]">
            {hasActiveFilters ? "لا توجد نتائج — جرّب تعديل الفلاتر" : "لم ترسل أي طلبات بعد"}
          </p>
          {hasActiveFilters ? (
            <button
              onClick={clearAllFilters}
              className="mt-3 text-xs text-[#F59E0B] underline hover:no-underline"
            >
              مسح جميع الفلاتر
            </button>
          ) : (
            <button
              onClick={() => setShowForm(true)}
              className="mt-3 text-xs text-[#F59E0B] underline hover:no-underline"
            >
              أرسل طلبك الأول
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((req) => {
            const st = statusConfig[req.status];
            const catItem = categories.find((c) => c.id === req.category);
            const CatIcon = catItem?.icon || HelpCircle;
            const catColor = catItem?.color || "#6b7280";
            const expanded = expandedId === req.id;

            return (
              <div
                key={req.id}
                className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm"
              >
                <div className="p-4" style={{ backgroundColor: `${catColor}04` }}>

                  {/* ── Header: Icon + Title + Badges ── */}
                  <div className="flex items-start gap-3 mb-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
                      style={{ backgroundColor: `${catColor}15` }}
                    >
                      <CatIcon className="w-5 h-5" style={{ color: catColor }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-sm font-semibold text-[#1a1a2e] truncate block">
                        {req.title}
                      </span>
                      <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                        <span
                          className="inline-flex items-center gap-0.5 text-[10px] px-1.5 py-px rounded-full font-medium"
                          style={{
                            backgroundColor: `${st.color}12`,
                            color: st.color,
                          }}
                        >
                          <st.icon className="w-2.5 h-2.5" />
                          {st.label}
                        </span>
                        <span className="text-[10px] px-1.5 py-px rounded-full bg-gray-50 text-[#5f6b7a]">
                          {catItem?.label || req.category}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* ── Info Grid ── */}
                  <div className={`grid ${req.adminNote ? "grid-cols-2" : "grid-cols-2"} gap-2 mb-3`}>
                    <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                      <div className="text-[9px] text-[#5f6b7a]">التاريخ</div>
                      <div className="text-[10px] text-[#1a1a2e] font-medium">{formatDate(req.createdAt)}</div>
                    </div>
                    <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                      <div className="text-[9px] text-[#5f6b7a]">الحالة</div>
                      <div className="text-[10px] font-bold" style={{ color: st.color }}>{st.label}</div>
                    </div>
                  </div>

                  {/* ── Admin note hint ── */}
                  {req.adminNote && (
                    <div className="flex items-center gap-1.5 mb-3 px-0.5">
                      <MessageSquare className="w-3 h-3 text-[#0D9488]" />
                      <span className="text-[10px] text-[#0D9488]">يوجد رد من الاتحاد</span>
                    </div>
                  )}

                  {/* ── Bottom action: عرض التفاصيل | حذف ── */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => setExpandedId(expanded ? null : req.id)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#F59E0B] text-white text-xs hover:bg-[#F59E0B]/90 transition-all shadow-sm"
                    >
                      <ChevronDown className={`w-3.5 h-3.5 transition-transform ${expanded ? "rotate-180" : ""}`} />
                      {expanded ? "إخفاء التفاصيل" : "عرض التفاصيل"}
                    </button>
                    {req.status === "pending" && (
                      <button
                        onClick={() => handleDelete(req.id)}
                        disabled={deletingId === req.id}
                        className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg border border-red-200 text-red-500 text-xs hover:bg-red-50 transition-all disabled:opacity-50"
                      >
                        {deletingId === req.id ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Trash2 className="w-3.5 h-3.5" />
                        )}
                        حذف
                      </button>
                    )}
                  </div>
                </div>

                {/* ── Expanded Details ── */}
                {expanded && (
                  <div className="px-4 pb-4 border-t border-gray-50 pt-3 space-y-3" style={{ backgroundColor: `${catColor}02` }}>
                    {req.description && (
                      <div>
                        <div className="text-[10px] text-[#5f6b7a] mb-1">تفاصيل الطلب</div>
                        <p className="text-xs text-[#1a1a2e] bg-white rounded-lg p-3 leading-relaxed border border-gray-100">
                          {req.description}
                        </p>
                      </div>
                    )}

                    {req.adminNote && (
                      <div>
                        <div className="text-[10px] text-[#0D9488] mb-1">رد الاتحاد</div>
                        <p className="text-xs text-[#1a1a2e] bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-lg p-3 leading-relaxed">
                          {req.adminNote}
                        </p>
                      </div>
                    )}

                    {req.closingNote && (
                      <div>
                        <div className="text-[10px] text-[#6b7280] mb-1">ملاحظة الإغلاق</div>
                        <p className="text-xs text-[#1a1a2e] bg-gray-50 border border-gray-100 rounded-lg p-3 leading-relaxed">
                          {req.closingNote}
                        </p>
                      </div>
                    )}

                    {req.updatedAt !== req.createdAt && (
                      <div className="text-[10px] text-[#5f6b7a]/60">
                        آخر تحديث: {formatDateTime(req.updatedAt)}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Mobile FAB */}
      <button
        onClick={() => setShowForm(true)}
        className="sm:hidden fixed bottom-20 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 px-5 py-3 bg-[#F59E0B] text-white rounded-full shadow-lg shadow-[#F59E0B]/30 hover:bg-[#F59E0B]/90 transition-all"
      >
        <Plus className="w-4.5 h-4.5" />
        <span className="text-sm">طلب جديد</span>
      </button>

      {/* Create Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center" onClick={() => setShowForm(false)}>
          <div
            className="bg-white rounded-t-3xl sm:rounded-2xl w-full sm:max-w-md max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Handle bar */}
            <div className="sm:hidden flex justify-center pt-3">
              <div className="w-10 h-1 bg-gray-300 rounded-full" />
            </div>

            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#F59E0B]/10">
              <h3 className="text-base text-[#1a1a2e] font-semibold">طلب خدمة جديد</h3>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-4 h-4 text-[#5f6b7a]" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Category */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-2 block">نوع الطلب</label>
                <div className="grid grid-cols-3 gap-2">
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setFormCategory(cat.id)}
                      className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border-2 transition-all ${
                        formCategory === cat.id
                          ? "border-[#F59E0B] bg-[#F59E0B]/5"
                          : "border-gray-100 hover:border-gray-200"
                      }`}
                    >
                      <cat.icon
                        className="w-5 h-5"
                        style={{ color: formCategory === cat.id ? cat.color : "#9ca3af" }}
                      />
                      <span className={`text-[10px] ${formCategory === cat.id ? "text-[#1a1a2e] font-medium" : "text-[#5f6b7a]"}`}>
                        {cat.label}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Title */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">عنوان الطلب *</label>
                <input
                  type="text"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="مثال: طلب مفتاح أسانسير إضافي"
                  className="w-full px-4 py-3 bg-[#fffcf5] border border-[#F59E0B]/15 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20"
                />
              </div>

              {/* Description */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">تفاصيل إضافية (اختياري)</label>
                <textarea
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  rows={3}
                  placeholder="اشرح طلبك بالتفصيل..."
                  className="w-full px-4 py-3 bg-[#fffcf5] border border-[#F59E0B]/15 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#F59E0B]/20 resize-none"
                />
              </div>

              {/* Info Banner */}
              <div className="bg-[#F59E0B]/5 border border-[#F59E0B]/15 rounded-xl p-3 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                <p className="text-[11px] text-[#5f6b7a] leading-relaxed">
                  سيتم إرسال طلبك لاتحاد الملاك وسيتم إشعارك عند الرد عليه
                </p>
              </div>
            </div>

            {/* Footer */}
            <div className="flex gap-3 p-5 border-t border-[#F59E0B]/10">
              <button
                onClick={() => setShowForm(false)}
                className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm"
              >
                إلغاء
              </button>
              <button
                onClick={handleCreate}
                disabled={!formTitle.trim() || creating}
                className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${
                  formTitle.trim() && !creating
                    ? "bg-[#F59E0B] hover:bg-[#F59E0B]/90 shadow-md shadow-[#F59E0B]/20"
                    : "bg-gray-300 cursor-not-allowed"
                }`}
              >
                {creating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    جاري الإرسال...
                  </>
                ) : (
                  <>
                    <ClipboardList className="w-4 h-4" />
                    إرسال الطلب
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
