import { useState, useEffect, useCallback, useRef } from "react";
import { Heart, PartyPopper, Calendar, Loader2, MessageCircle, Send, ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";
import { getFirstName } from "../../lib/titles";

function timeAgo(isoDate: string): string {
  const now = Date.now();
  const then = new Date(isoDate).getTime();
  const diff = Math.floor((now - then) / 1000);
  if (diff < 60) return "الآن";
  if (diff < 3600) return `منذ ${Math.floor(diff / 60)} د`;
  if (diff < 86400) return `منذ ${Math.floor(diff / 3600)} س`;
  if (diff < 604800) return `منذ ${Math.floor(diff / 86400)} ي`;
  return new Date(isoDate).toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "short" });
}

export function ResidentEvents() {
  const { profile } = useAuth();
  const [events, setEvents] = useState<api.MollakEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<string>("الكل");
  const [reactedIds, setReactedIds] = useState<Set<string>>(new Set());
  const [expandedComments, setExpandedComments] = useState<Set<string>>(new Set());
  const [commentText, setCommentText] = useState<Record<string, string>>({});
  const [sendingComment, setSendingComment] = useState<string | null>(null);
  const commentInputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const fetchEvents = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getEvents();
      setEvents(data);
    } catch (err: any) {
      console.error("Error fetching events:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const filtered = events.filter(
    (e) => filterType === "الكل" || (filterType === "تهنئة" && e.type === "congratulation") || (filterType === "تعزية" && e.type === "condolence")
  );

  const handleReact = async (eventId: string) => {
    if (reactedIds.has(eventId)) return;
    try {
      const result = await api.reactToEvent(eventId);
      setEvents((prev) =>
        prev.map((e) => e.id === eventId ? { ...e, reactions: result.reactions } : e)
      );
      setReactedIds((prev) => new Set(prev).add(eventId));
    } catch (err: any) {
      console.error("Error reacting to event:", err);
    }
  };

  const toggleComments = (eventId: string) => {
    setExpandedComments((prev) => {
      const next = new Set(prev);
      if (next.has(eventId)) {
        next.delete(eventId);
      } else {
        next.add(eventId);
        // Focus the input after expanding
        setTimeout(() => commentInputRefs.current[eventId]?.focus(), 100);
      }
      return next;
    });
  };

  const handleAddComment = async (eventId: string) => {
    const text = (commentText[eventId] || "").trim();
    if (!text || !profile) return;
    setSendingComment(eventId);
    try {
      const result = await api.addEventComment(eventId, {
        name: profile.name,
        unit: profile.unitCode,
        text,
      });
      setEvents((prev) =>
        prev.map((e) => e.id === eventId ? { ...e, comments: result.comments } : e)
      );
      setCommentText((prev) => ({ ...prev, [eventId]: "" }));
      // Auto-expand comments after posting
      setExpandedComments((prev) => new Set(prev).add(eventId));
    } catch (err: any) {
      console.error("Error adding comment:", err);
    } finally {
      setSendingComment(null);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl text-[#1a1a2e]">المناسبات</h1>
        <p className="text-sm text-[#5f6b7a]">تهنئة وتعزية سكان البرج</p>
      </div>

      {/* Filter */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide" style={{ WebkitOverflowScrolling: 'touch' }}>
        {["الكل", "تهنئة", "تعزية"].map((f) => (
          <button
            key={f}
            onClick={() => setFilterType(f)}
            className={`px-3 py-2 rounded-xl text-xs whitespace-nowrap transition-all shrink-0 ${
              filterType === f
                ? "bg-[#F59E0B] text-white shadow-md"
                : "bg-white text-[#5f6b7a] border border-[#F59E0B]/10 hover:bg-[#F59E0B]/5"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 text-[#F59E0B] animate-spin" />
        </div>
      )}

      {/* Events List */}
      {!loading && (
        <div className="space-y-4">
          {filtered.map((ev) => {
            const isCongrats = ev.type === "congratulation";
            const hasReacted = reactedIds.has(ev.id);
            const isExpanded = expandedComments.has(ev.id);
            const comments = ev.comments || [];
            const visibleComments = isExpanded ? comments : comments.slice(-2);

            return (
              <div key={ev.id} className={`bg-white rounded-2xl border shadow-sm overflow-hidden ${isCongrats ? "border-[#0D9488]/10" : "border-gray-200"}`}>
                {/* Event Content */}
                <div className="p-4 sm:p-5">
                  <div className="flex items-start gap-3 sm:gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${isCongrats ? "bg-[#0D9488]/10" : "bg-gray-100"}`}>
                      {isCongrats ? <PartyPopper className="w-5 h-5 text-[#0D9488]" /> : <Heart className="w-5 h-5 text-[#5f6b7a]" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <h3 className="text-sm font-medium text-[#1a1a2e]">{ev.title}</h3>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${isCongrats ? "bg-[#0D9488]/10 text-[#0D9488]" : "bg-gray-100 text-[#5f6b7a]"}`}>
                          {isCongrats ? "تهنئة" : "تعزية"}
                        </span>
                      </div>
                      <p className="text-sm text-[#5f6b7a] mb-2 leading-relaxed">{ev.message}</p>
                      <div className="flex items-center gap-3 text-xs text-[#5f6b7a]">
                        <span className="font-medium text-[#1a1a2e]">{ev.resident}</span>
                        {ev.unit && <span>وحدة {ev.unit}</span>}
                        <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{ev.date}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Reactions & Comments Count Bar */}
                <div className="flex items-center justify-between px-4 sm:px-5 py-2 text-xs text-[#5f6b7a]">
                  <div className="flex items-center gap-1">
                    {ev.reactions > 0 && (
                      <>
                        <span className="w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-white text-[10px]">❤️</span>
                        <span>{ev.reactions.toLocaleString("en-US")}</span>
                      </>
                    )}
                  </div>
                  {comments.length > 0 && (
                    <button onClick={() => toggleComments(ev.id)} className="hover:underline">
                      {comments.length.toLocaleString("en-US")} تعليق
                    </button>
                  )}
                </div>

                {/* Action Buttons — Like & Comment */}
                <div className="flex items-center border-t border-gray-100">
                  <button
                    onClick={() => handleReact(ev.id)}
                    disabled={hasReacted}
                    className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm transition-colors ${
                      hasReacted
                        ? "text-red-500 bg-red-50/50"
                        : "text-[#5f6b7a] hover:bg-gray-50 active:bg-gray-100"
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${hasReacted ? "fill-red-500" : ""}`} />
                    {hasReacted ? "أعجبني" : "إعجاب"}
                  </button>
                  <div className="w-px h-6 bg-gray-100" />
                  <button
                    onClick={() => toggleComments(ev.id)}
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 text-sm text-[#5f6b7a] hover:bg-gray-50 active:bg-gray-100 transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    تعليق
                  </button>
                </div>

                {/* Comments Section */}
                {(isExpanded || comments.length > 0) && (
                  <div className="border-t border-gray-100 bg-[#f8f9fa]">
                    {/* Show all / collapse toggle */}
                    {comments.length > 2 && (
                      <button
                        onClick={() => toggleComments(ev.id)}
                        className="w-full flex items-center gap-1 px-4 py-2 text-xs text-[#0D9488] hover:bg-[#0D9488]/5 transition-colors"
                      >
                        {isExpanded ? (
                          <>
                            <ChevronUp className="w-3.5 h-3.5" />
                            إخفاء التعليقات
                          </>
                        ) : (
                          <>
                            <ChevronDown className="w-3.5 h-3.5" />
                            عرض كل التعليقات ({comments.length.toLocaleString("en-US")})
                          </>
                        )}
                      </button>
                    )}

                    {/* Comments List */}
                    <div className="px-4 sm:px-5 py-2 space-y-3">
                      {visibleComments.map((comment) => (
                        <div key={comment.id} className="flex gap-2.5">
                          {/* Avatar */}
                          <div
                            className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-0.5"
                            style={{ background: 'linear-gradient(to bottom right, rgba(13,148,136,0.2), rgba(13,148,136,0.1))' }}
                          >
                            <span className="text-xs font-semibold text-[#0D9488]">
                              {getFirstName(comment.name).charAt(0)}
                            </span>
                          </div>
                          {/* Comment Bubble */}
                          <div className="flex-1 min-w-0">
                            <div className="bg-white rounded-2xl rounded-tr-md px-3.5 py-2.5 shadow-sm border border-gray-100">
                              <div className="flex items-center gap-2 mb-0.5">
                                <span className="text-xs font-semibold text-[#1a1a2e]">{getFirstName(comment.name)}</span>
                                {comment.unit && (
                                  <span className="text-[10px] bg-[#0D9488]/10 text-[#0D9488] px-1.5 py-0.5 rounded">
                                    وحدة {comment.unit}
                                  </span>
                                )}
                              </div>
                              <p className="text-sm text-[#1a1a2e] leading-relaxed">{comment.text}</p>
                            </div>
                            <div className="flex items-center gap-3 mt-1 px-1">
                              <span className="text-[10px] text-[#5f6b7a]">{timeAgo(comment.createdAt)}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Comment Input */}
                    <div className="flex items-center gap-2 px-4 sm:px-5 py-3 border-t border-gray-100">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center shrink-0"
                        style={{ background: 'linear-gradient(to bottom right, #0D9488, rgba(13,148,136,0.8))' }}
                      >
                        <span className="text-xs font-semibold text-white">
                          {profile ? getFirstName(profile.name).charAt(0) : "؟"}
                        </span>
                      </div>
                      <div className="flex-1 relative">
                        <input
                          ref={(el) => { commentInputRefs.current[ev.id] = el; }}
                          type="text"
                          value={commentText[ev.id] || ""}
                          onChange={(e) => setCommentText((prev) => ({ ...prev, [ev.id]: e.target.value }))}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" && !e.shiftKey) {
                              e.preventDefault();
                              handleAddComment(ev.id);
                            }
                          }}
                          placeholder="اكتب تعليقاً..."
                          className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 focus:border-[#0D9488]/30"
                          disabled={!profile || sendingComment === ev.id}
                        />
                        <button
                          onClick={() => handleAddComment(ev.id)}
                          disabled={!profile || !(commentText[ev.id] || "").trim() || sendingComment === ev.id}
                          className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full flex items-center justify-center text-[#0D9488] hover:bg-[#0D9488]/10 transition-colors disabled:opacity-30 disabled:hover:bg-transparent"
                        >
                          {sendingComment === ev.id ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Send className="w-4 h-4 rotate-180" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center text-sm text-[#5f6b7a]">لا توجد مناسبات حالياً</div>
          )}
        </div>
      )}
    </div>
  );
}