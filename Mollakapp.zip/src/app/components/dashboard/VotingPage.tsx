import { useState, useEffect, useCallback, useRef } from "react";
import {
  Plus,
  CheckCircle2,
  Clock,
  Users,
  X,
  Trash2,
  Ban,
  Loader2,
  ChevronLeft,
  ChevronRight,
  Calendar,
  Vote,
  Play,
  Eye,
} from "lucide-react";
import * as api from "../../lib/api";
import { MobileFAB } from "./MobileFAB";

// ===== Inline Calendar Picker =====
const AR_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];
const AR_DAYS = ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"];

function CalendarPicker({
  value,
  onChange,
  onClose,
}: {
  value: string;
  onChange: (iso: string) => void;
  onClose: () => void;
}) {
  const today = new Date();
  const initial = value ? new Date(value) : today;
  const [year, setYear] = useState(initial.getFullYear());
  const [month, setMonth] = useState(initial.getMonth());
  const selected = value ? new Date(value) : null;
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [onClose]);

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const prevMonth = () => {
    if (month === 0) { setMonth(11); setYear(year - 1); }
    else setMonth(month - 1);
  };
  const nextMonth = () => {
    if (month === 11) { setMonth(0); setYear(year + 1); }
    else setMonth(month + 1);
  };

  const pick = (day: number) => {
    const d = new Date(year, month, day);
    onChange(d.toISOString().split("T")[0]);
    onClose();
  };

  const isSelected = (day: number) =>
    selected && selected.getFullYear() === year && selected.getMonth() === month && selected.getDate() === day;
  const isToday = (day: number) =>
    today.getFullYear() === year && today.getMonth() === month && today.getDate() === day;
  const isPast = (day: number) => {
    const d = new Date(year, month, day);
    d.setHours(0, 0, 0, 0);
    const t = new Date();
    t.setHours(0, 0, 0, 0);
    return d < t;
  };

  return (
    <div ref={ref} className="absolute top-full mt-1 right-0 z-50 bg-white rounded-xl border border-[#0D9488]/10 shadow-xl p-3 w-[280px]">
      <div className="flex items-center justify-between mb-3">
        <button onClick={nextMonth} className="p-1 hover:bg-gray-100 rounded-lg"><ChevronRight className="w-4 h-4 text-[#5f6b7a]" /></button>
        <span className="text-sm text-[#1a1a2e]">{AR_MONTHS[month]} {year}</span>
        <button onClick={prevMonth} className="p-1 hover:bg-gray-100 rounded-lg"><ChevronLeft className="w-4 h-4 text-[#5f6b7a]" /></button>
      </div>
      <div className="grid grid-cols-7 gap-0.5 mb-1">
        {AR_DAYS.map((d) => (<div key={d} className="text-center text-[10px] text-[#5f6b7a] py-1">{d}</div>))}
      </div>
      <div className="grid grid-cols-7 gap-0.5">
        {cells.map((day, i) => (
          <button key={i} disabled={day === null || isPast(day)} onClick={() => day && pick(day)}
            className={`h-8 rounded-lg text-xs transition-all ${
              day === null ? "" :
              isSelected(day) ? "bg-[#0D9488] text-white font-semibold" :
              isToday(day) ? "bg-[#0D9488]/10 text-[#0D9488] font-semibold" :
              isPast(day) ? "text-gray-300 cursor-not-allowed" :
              "text-[#1a1a2e] hover:bg-[#0D9488]/5"
            }`}
          >{day || ""}</button>
        ))}
      </div>
    </div>
  );
}

function formatDate(iso: string): string {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });
  } catch { return iso; }
}

export function VotingPage() {
  const [polls, setPolls] = useState<api.Poll[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [showVoteModal, setShowVoteModal] = useState<string | null>(null);
  const [showVotersModal, setShowVotersModal] = useState<{ pollId: string; optionIdx: number } | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [endingId, setEndingId] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("الكل");
  const [form, setForm] = useState({ title: "", description: "", deadline: "", options: ["", ""] });
  const [voteForm, setVoteForm] = useState({ optionIndex: -1, voterName: "" });
  const [showCalendar, setShowCalendar] = useState(false);

  const filtered = polls.filter(
    (p) => filterStatus === "الكل" || (filterStatus === "نشط" && p.status === "active") || (filterStatus === "منتهي" && p.status === "ended")
  );

  const loadPolls = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getPolls();
      setPolls(data);
    } catch (err) {
      console.error("Error loading polls:", err);
      showError("فشل تحميل التصويتات");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadPolls(); }, [loadPolls]);

  const openAdd = () => {
    setForm({ title: "", description: "", deadline: "", options: ["", ""] });
    setShowModal(true);
  };

  const addOption = () => setForm({ ...form, options: [...form.options, ""] });
  const removeOption = (i: number) => {
    if (form.options.length <= 2) return;
    setForm({ ...form, options: form.options.filter((_, idx) => idx !== i) });
  };
  const updateOption = (i: number, val: string) => {
    const opts = [...form.options];
    opts[i] = val;
    setForm({ ...form, options: opts });
  };

  const handleSave = async () => {
    const validOptions = form.options.filter((o) => o.trim());
    if (!form.title || validOptions.length < 2) return;
    setSaving(true);
    try {
      const res = await api.createPoll({
        title: form.title,
        description: form.description,
        options: validOptions,
        deadline: form.deadline,
      });
      setPolls((prev) => [res.poll, ...prev]);
      setShowModal(false);
      showSuccess("تم إنشاء التصويت بنجاح");
    } catch (err: any) {
      console.error("Error creating poll:", err);
      showError(err.message || "فشل إنشاء التصويت");
    } finally {
      setSaving(false);
    }
  };

  const handleEndPoll = async (id: string) => {
    setEndingId(id);
    try {
      const res = await api.endPoll(id);
      setPolls((prev) => prev.map((p) => (p.id === id ? res.poll : p)));
      showSuccess("تم إنهاء التصويت");
    } catch (err: any) {
      console.error("Error ending poll:", err);
      showError(err.message || "فشل إنهاء التصويت");
    } finally {
      setEndingId(null);
    }
  };

  const handleReactivatePoll = async (id: string) => {
    setEndingId(id);
    try {
      const res = await api.reactivatePoll(id);
      setPolls((prev) => prev.map((p) => (p.id === id ? res.poll : p)));
      showSuccess("تم إعادة تفعيل التصويت");
    } catch (err: any) {
      console.error("Error reactivating poll:", err);
      showError(err.message || "فشل إعادة التفعيل");
    } finally {
      setEndingId(null);
    }
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await api.deletePoll(id);
      setPolls((prev) => prev.filter((p) => p.id !== id));
      setDeleteConfirm(null);
      showSuccess("تم حذف التصويت");
    } catch (err: any) {
      console.error("Error deleting poll:", err);
      showError(err.message || "فشل حذف التصويت");
    } finally {
      setDeletingId(null);
    }
  };

  const handleVote = async () => {
    if (!showVoteModal || voteForm.optionIndex < 0 || !voteForm.voterName.trim()) return;
    setSaving(true);
    try {
      const res = await api.votePoll(showVoteModal, {
        optionIndex: voteForm.optionIndex,
        voterName: voteForm.voterName.trim(),
      });
      setPolls((prev) => prev.map((p) => (p.id === showVoteModal ? res.poll : p)));
      setShowVoteModal(null);
      setVoteForm({ optionIndex: -1, voterName: "" });
      showSuccess("تم تسجيل التصويت بنجاح");
    } catch (err: any) {
      console.error("Error voting:", err);
      showError(err.message || "فشل تسجيل التصويت");
    } finally {
      setSaving(false);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };
  const showError = (msg: string) => {
    setErrorMsg(msg);
    setTimeout(() => setErrorMsg(""), 3000);
  };

  const votePoll = showVoteModal ? polls.find((p) => p.id === showVoteModal) : null;
  const votersPoll = showVotersModal ? polls.find((p) => p.id === showVotersModal.pollId) : null;
  const votersOption = votersPoll && showVotersModal ? votersPoll.options[showVotersModal.optionIdx] : null;

  return (
    <div className="space-y-6">
      {/* Success Toast */}
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}
      {/* Error Toast */}
      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <X className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl text-[#1a1a2e]">التصويت</h1>
          <p className="text-sm text-[#5f6b7a]">إنشاء استطلاعات رأي للسكان</p>
        </div>
        <button onClick={openAdd} className="hidden sm:inline-flex items-center gap-2 bg-[#0D9488] text-white px-5 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20">
          <Plus className="w-5 h-5" />تصويت جديد
        </button>
      </div>

      {/* Filter */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
        {["الكل", "نشط", "منتهي"].map((f) => (
          <button key={f} onClick={() => setFilterStatus(f)} className={`px-3 py-2 rounded-xl text-xs whitespace-nowrap transition-all ${filterStatus === f ? "bg-[#0D9488] text-white shadow-md" : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:bg-[#0D9488]/5"}`}>
            {f}
          </button>
        ))}
      </div>

      {/* Loading */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin mx-auto mb-3" />
          <p className="text-sm text-[#5f6b7a]">جاري تحميل التصويتات...</p>
        </div>
      ) : (
        /* Polls List */
        <div className="space-y-4">
          {filtered.map((poll) => {
            const totalVotes = poll.options.reduce((s, o) => s + o.votes, 0);
            const winnerIdx = poll.status === "ended" && totalVotes > 0
              ? poll.options.reduce((best, opt, i, arr) => opt.votes > arr[best].votes ? i : best, 0)
              : -1;
            return (
              <div key={poll.id} className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-all">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className="text-[#1a1a2e]">{poll.title}</h3>
                      <span className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${poll.status === "active" ? "bg-[#0D9488]/10 text-[#0D9488]" : "bg-gray-100 text-[#5f6b7a]"}`}>
                        {poll.status === "active" ? <><Clock className="w-3 h-3" />نشط</> : <><Ban className="w-3 h-3" />منتهي</>}
                      </span>
                    </div>
                    {poll.description && <p className="text-sm text-[#5f6b7a]">{poll.description}</p>}
                  </div>
                  <div className="flex gap-1 shrink-0 mr-2">
                    {poll.status === "active" ? (
                      <button
                        onClick={() => handleEndPoll(poll.id)}
                        disabled={endingId === poll.id}
                        className="p-2 text-[#F59E0B] hover:bg-[#F59E0B]/10 rounded-lg transition-colors text-xs"
                      >
                        {endingId === poll.id ? <Loader2 className="w-4 h-4 animate-spin" /> : "إنهاء"}
                      </button>
                    ) : (
                      <button
                        onClick={() => handleReactivatePoll(poll.id)}
                        disabled={endingId === poll.id}
                        className="p-2 text-[#0D9488] hover:bg-[#0D9488]/10 rounded-lg transition-colors"
                        title="إعادة تفعيل"
                      >
                        {endingId === poll.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                      </button>
                    )}
                    <button onClick={() => setDeleteConfirm(poll.id)} className="p-2 text-[#5f6b7a] hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Options with bars */}
                <div className="space-y-2 mb-3">
                  {poll.options.map((opt, i) => {
                    const pct = totalVotes > 0 ? Math.round((opt.votes / totalVotes) * 100) : 0;
                    const isWinner = i === winnerIdx;
                    return (
                      <div key={i}>
                        <div className="flex items-center justify-between text-sm mb-1">
                          <div className="flex items-center gap-1.5">
                            <span className={`text-[#1a1a2e] ${isWinner ? "font-semibold" : ""}`}>{opt.label}</span>
                            {isWinner && <span className="text-[10px] bg-[#F59E0B]/10 text-[#F59E0B] px-1.5 py-0.5 rounded-full">الأعلى</span>}
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[#5f6b7a] text-xs">{pct}% ({opt.votes})</span>
                            {opt.voters.length > 0 && (
                              <button
                                onClick={() => setShowVotersModal({ pollId: poll.id, optionIdx: i })}
                                className="text-[#0D9488] hover:bg-[#0D9488]/5 rounded p-0.5"
                                title="عرض المصوتين"
                              >
                                <Eye className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                        <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${isWinner ? "bg-[#F59E0B]" : "bg-[#0D9488]"}`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Info + vote button */}
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-4 text-xs text-[#5f6b7a]">
                    <span className="flex items-center gap-1"><Users className="w-3 h-3" />{totalVotes} صوت</span>
                    {poll.deadline && (
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />{formatDate(poll.deadline)}
                      </span>
                    )}
                    <span>بواسطة: {poll.createdBy}</span>
                  </div>
                  {poll.status === "active" && (
                    <button
                      onClick={() => {
                        setVoteForm({ optionIndex: -1, voterName: "" });
                        setShowVoteModal(poll.id);
                      }}
                      className="flex items-center gap-1.5 px-4 py-2 bg-[#0D9488] text-white text-xs rounded-lg hover:bg-[#0D9488]/90 transition-all shadow-sm"
                    >
                      <Vote className="w-3.5 h-3.5" />تسجيل صوت
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center">
              <Vote className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="text-sm text-[#5f6b7a]">لا توجد تصويتات</p>
              <p className="text-xs text-[#5f6b7a]/60 mt-1">أنشئ تصويت جديد لاستطلاع رأي السكان</p>
            </div>
          )}
        </div>
      )}

      {/* ===== Add Poll Modal ===== */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">تصويت جديد</h3>
              <button onClick={() => setShowModal(false)} className="text-[#5f6b7a]"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">السؤال *</label>
                <input type="text" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="مثال: هل توافقون على تجديد المصعد؟" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">الوصف</label>
                <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 resize-none" />
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">الخيارات * (حد أدنى 2)</label>
                <div className="space-y-2">
                  {form.options.map((opt, i) => (
                    <div key={i} className="flex gap-2">
                      <input type="text" value={opt} onChange={(e) => updateOption(i, e.target.value)} placeholder={`الخيار ${i + 1}`} className="flex-1 px-4 py-2.5 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                      {form.options.length > 2 && (
                        <button onClick={() => removeOption(i)} className="px-2 text-red-400 hover:text-red-500"><X className="w-4 h-4" /></button>
                      )}
                    </div>
                  ))}
                </div>
                <button onClick={addOption} className="mt-2 text-xs text-[#0D9488] hover:underline">+ إضافة خيار</button>
              </div>
              <div className="relative">
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">الموعد النهائي</label>
                {/* Quick deadline shortcuts */}
                <div className="flex gap-1.5 mb-2 flex-wrap">
                  {[
                    { label: "يوم", days: 1 },
                    { label: "يومين", days: 2 },
                    { label: "أسبوع", days: 7 },
                    { label: "شهر", days: 30 },
                  ].map((shortcut) => {
                    const target = new Date();
                    target.setDate(target.getDate() + shortcut.days);
                    const iso = target.toISOString().split("T")[0];
                    const isActive = form.deadline === iso;
                    return (
                      <button
                        key={shortcut.label}
                        type="button"
                        onClick={() => setForm({ ...form, deadline: iso })}
                        className={`px-3 py-1.5 rounded-lg text-xs transition-all ${
                          isActive
                            ? "bg-[#0D9488] text-white"
                            : "bg-[#0D9488]/5 text-[#0D9488] hover:bg-[#0D9488]/10"
                        }`}
                      >
                        {shortcut.label}
                      </button>
                    );
                  })}
                </div>
                <button
                  type="button"
                  onClick={() => setShowCalendar(!showCalendar)}
                  className="w-full flex items-center justify-between px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-right"
                >
                  <span className={form.deadline ? "text-[#1a1a2e]" : "text-[#5f6b7a]/50"}>
                    {form.deadline ? formatDate(form.deadline) : "اختر تاريخ"}
                  </span>
                  <Calendar className="w-4 h-4 text-[#5f6b7a] shrink-0" />
                </button>
                {showCalendar && (
                  <CalendarPicker
                    value={form.deadline}
                    onChange={(iso) => setForm({ ...form, deadline: iso })}
                    onClose={() => setShowCalendar(false)}
                  />
                )}
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button onClick={() => setShowModal(false)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button
                onClick={handleSave}
                disabled={!form.title || form.options.filter((o) => o.trim()).length < 2 || saving}
                className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${
                  form.title && form.options.filter((o) => o.trim()).length >= 2 && !saving
                    ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20"
                    : "bg-gray-300 cursor-not-allowed"
                }`}
              >
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                إنشاء التصويت
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Vote Modal ===== */}
      {showVoteModal && votePoll && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowVoteModal(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">تسجيل صوت</h3>
              <button onClick={() => setShowVoteModal(null)} className="text-[#5f6b7a]"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div className="bg-[#f8fffe] rounded-xl p-3 border border-[#0D9488]/5">
                <p className="text-sm text-[#1a1a2e] font-medium">{votePoll.title}</p>
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">اسم المُصوِّت *</label>
                <input
                  type="text"
                  value={voteForm.voterName}
                  onChange={(e) => setVoteForm({ ...voteForm, voterName: e.target.value })}
                  placeholder="اسم الساكن"
                  className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                />
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-2 block">اختر الخيار *</label>
                <div className="space-y-2">
                  {votePoll.options.map((opt, i) => (
                    <button
                      key={i}
                      onClick={() => setVoteForm({ ...voteForm, optionIndex: i })}
                      className={`w-full text-right px-4 py-3 rounded-xl text-sm border transition-all ${
                        voteForm.optionIndex === i
                          ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488] font-medium"
                          : "border-gray-200 text-[#1a1a2e] hover:border-[#0D9488]/30"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 ${
                          voteForm.optionIndex === i ? "border-[#0D9488]" : "border-gray-300"
                        }`}>
                          {voteForm.optionIndex === i && <div className="w-2 h-2 rounded-full bg-[#0D9488]" />}
                        </div>
                        {opt.label}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button onClick={() => setShowVoteModal(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button
                onClick={handleVote}
                disabled={voteForm.optionIndex < 0 || !voteForm.voterName.trim() || saving}
                className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${
                  voteForm.optionIndex >= 0 && voteForm.voterName.trim() && !saving
                    ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20"
                    : "bg-gray-300 cursor-not-allowed"
                }`}
              >
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                تأكيد التصويت
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Voters List Modal ===== */}
      {showVotersModal && votersPoll && votersOption && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowVotersModal(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm max-h-[70vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10 shrink-0">
              <div>
                <h3 className="text-lg text-[#1a1a2e]">المصوتين</h3>
                <p className="text-xs text-[#5f6b7a]">خيار: {votersOption.label}</p>
              </div>
              <button onClick={() => setShowVotersModal(null)} className="text-[#5f6b7a]"><X className="w-5 h-5" /></button>
            </div>
            <div className="overflow-y-auto flex-1 p-5">
              {votersOption.voters.length === 0 ? (
                <p className="text-sm text-[#5f6b7a] text-center py-6">لا يوجد مصوتين بعد</p>
              ) : (
                <div className="space-y-2">
                  {votersOption.voters.map((name, i) => (
                    <div key={i} className="flex items-center gap-3 p-3 bg-[#f8fffe] rounded-xl border border-[#0D9488]/5">
                      <div className="w-8 h-8 bg-[#0D9488]/10 rounded-full flex items-center justify-center">
                        <Users className="w-4 h-4 text-[#0D9488]" />
                      </div>
                      <span className="text-sm text-[#1a1a2e]">{name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="p-4 border-t border-[#0D9488]/10 shrink-0 text-center">
              <span className="text-xs text-[#5f6b7a]">{votersOption.voters.length} مصوت</span>
            </div>
          </div>
        </div>
      )}

      {/* ===== Delete Confirmation ===== */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-5">
              <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3"><Trash2 className="w-7 h-7 text-red-500" /></div>
              <h3 className="text-lg text-[#1a1a2e] mb-1">حذف التصويت</h3>
              <p className="text-sm text-[#5f6b7a]">هل أنت متأكد من حذف هذا التصويت؟</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                disabled={deletingId === deleteConfirm}
                className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm hover:bg-red-600 flex items-center justify-center gap-2"
              >
                {deletingId === deleteConfirm && <Loader2 className="w-4 h-4 animate-spin" />}
                نعم، احذف
              </button>
            </div>
          </div>
        </div>
      )}
      <MobileFAB onClick={openAdd} label="تصويت جديد" />
    </div>
  );
}