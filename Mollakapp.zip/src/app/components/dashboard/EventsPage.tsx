import { useState, useEffect, useCallback, useRef } from "react";
import { Plus, Heart, PartyPopper, X, Trash2, CheckCircle2, Pencil, Loader2, AlertCircle, MessageCircle, Send, ChevronDown, ChevronUp } from "lucide-react";
import * as api from "../../lib/api";
import { MobileFAB } from "./MobileFAB";
import { useAuth } from "../../lib/auth";
import { getFirstName } from "../../lib/titles";

const emptyForm = { type: "congratulation" as "congratulation" | "condolence", title: "", resident: "", unit: "", message: "", date: "" };

function timeAgo(isoDate: string): string {
  const now = Date.now();
  const then = new Date(isoDate).getTime();
  const diff = Math.floor((now - then) / 1000);
  if (diff < 60) return "الآن";
  if (diff < 3600) return `منذ ${Math.floor(diff / 60)} د`;
  if (diff < 86400) return `منذ ${Math.floor(diff / 3600)} س`;
  if (diff < 604800) return `منذ ${Math.floor(diff / 86400)} ي`;
  return new Date(isoDate).toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "short" });
}

export function EventsPage() {
  const { profile } = useAuth();
  const [events, setEvents] = useState<api.MollakEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [filterType, setFilterType] = useState<string>("الكل");
  const [expandedComments, setExpandedComments] = useState<Set<string>>(new Set());
  const [commentText, setCommentText] = useState<Record<string, string>>({});
  const [sendingComment, setSendingComment] = useState<string | null>(null);
  const commentInputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const fetchEvents = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getEvents();
      setEvents(data);
    } catch (err: any) {
      console.error("Error fetching events:", err);
      setErrorMsg("خطأ في تحميل المناسبات");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const filtered = events.filter(
    (e) => filterType === "الكل" || (filterType === "تهنئة" && e.type === "congratulation") || (filterType === "تعزية" && e.type === "condolence")
  );

  const openAdd = () => {
    setForm({ ...emptyForm, date: new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" }) });
    setEditingId(null);
    setShowModal(true);
  };

  const openEdit = (ev: api.MollakEvent) => {
    setForm({ type: ev.type, title: ev.title, resident: ev.resident, unit: ev.unit, message: ev.message, date: ev.date });
    setEditingId(ev.id);
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.title || !form.resident) return;
    try {
      setSaving(true);
      if (editingId) {
        await api.updateEvent(editingId, form);
        showSuccess("تم تحديث المناسبة بنجاح");
      } else {
        await api.createEvent(form);
        showSuccess("تم إضافة المناسبة بنجاح");
      }
      setShowModal(false);
      fetchEvents();
    } catch (err: any) {
      console.error("Error saving event:", err);
      setErrorMsg(err.message || "خطأ في حفظ المناسبة");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteEvent(id);
      setDeleteConfirm(null);
      showSuccess("تم حذف المناسبة");
      fetchEvents();
    } catch (err: any) {
      console.error("Error deleting event:", err);
      setErrorMsg(err.message || "خطأ في حذف المناسبة");
    }
  };

  const toggleComments = (eventId: string) => {
    setExpandedComments((prev) => {
      const next = new Set(prev);
      if (next.has(eventId)) {
        next.delete(eventId);
      } else {
        next.add(eventId);
        setTimeout(() => commentInputRefs.current[eventId]?.focus(), 100);
      }
      return next;
    });
  };

  const handleAddComment = async (eventId: string) => {
    const text = (commentText[eventId] || "").trim();
    if (!text || !profile) return;
    setSendingComment(eventId);
    try {
      const result = await api.addEventComment(eventId, {
        name: profile.name,
        unit: profile.unitCode,
        text,
      });
      setEvents((prev) =>
        prev.map((e) => e.id === eventId ? { ...e, comments: result.comments } : e)
      );
      setCommentText((prev) => ({ ...prev, [eventId]: "" }));
      setExpandedComments((prev) => new Set(prev).add(eventId));
    } catch (err: any) {
      console.error("Error adding comment:", err);
      setErrorMsg("خطأ في إضافة التعليق");
    } finally {
      setSendingComment(null);
    }
  };

  const handleDeleteComment = async (eventId: string, commentId: string) => {
    try {
      const result = await api.deleteEventComment(eventId, commentId);
      setEvents((prev) =>
        prev.map((e) => e.id === eventId ? { ...e, comments: result.comments } : e)
      );
    } catch (err: any) {
      console.error("Error deleting comment:", err);
      setErrorMsg("خطأ في حذف التعليق");
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };

  return (
    <div className="space-y-6">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}

      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
          <button onClick={() => setErrorMsg("")} className="mr-2"><X className="w-4 h-4" /></button>
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl text-[#1a1a2e]">المناسبات</h1>
          <p className="text-sm text-[#5f6b7a]">تهنئة وتعزية سكان البرج</p>
        </div>
        <button onClick={openAdd} className="hidden sm:inline-flex items-center gap-2 bg-[#0D9488] text-white px-5 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20">
          <Plus className="w-5 h-5" />مناسبة جديدة
        </button>
      </div>

      {/* Filter */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
        {["الكل", "تهنئة", "تعزية"].map((f) => (
          <button key={f} onClick={() => setFilterType(f)} className={`px-3 py-2 rounded-xl text-xs whitespace-nowrap transition-all ${filterType === f ? "bg-[#0D9488] text-white shadow-md" : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:bg-[#0D9488]/5"}`}>
            {f}
          </button>
        ))}
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin" />
        </div>
      )}

      {/* Events List */}
      {!loading && (
        <div className="space-y-4">
          {filtered.map((ev) => {
            const isCongrats = ev.type === "congratulation";
            const isExpanded = expandedComments.has(ev.id);
            const comments = ev.comments || [];
            const visibleComments = isExpanded ? comments : comments.slice(-2);

            return (
              <div key={ev.id} className={`bg-white rounded-2xl border shadow-sm overflow-hidden hover:shadow-md transition-all ${isCongrats ? "border-[#0D9488]/10" : "border-gray-200"}`}>
                {/* Event Content */}
                <div className="p-4 sm:p-5">
                  <div className="flex items-start gap-3 sm:gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${isCongrats ? "bg-[#0D9488]/10" : "bg-gray-100"}`}>
                      {isCongrats ? <PartyPopper className="w-5 h-5 text-[#0D9488]" /> : <Heart className="w-5 h-5 text-[#5f6b7a]" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <h3 className="text-sm font-medium text-[#1a1a2e]">{ev.title}</h3>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${isCongrats ? "bg-[#0D9488]/10 text-[#0D9488]" : "bg-gray-100 text-[#5f6b7a]"}`}>
                          {isCongrats ? "تهنئة" : "تعزية"}
                        </span>
                      </div>
                      <p className="text-sm text-[#5f6b7a] mb-2 leading-relaxed">{ev.message}</p>
                      <div className="flex items-center gap-3 text-xs text-[#5f6b7a]">
                        <span className="font-medium text-[#1a1a2e]">{ev.resident}</span>
                        {ev.unit && <span>وحدة {ev.unit}</span>}
                        <span>📅 {ev.date}</span>
                      </div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <button onClick={() => openEdit(ev)} className="p-2 text-[#5f6b7a] hover:text-[#0D9488] hover:bg-[#0D9488]/5 rounded-lg transition-colors">
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button onClick={() => setDeleteConfirm(ev.id)} className="p-2 text-[#5f6b7a] hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Reactions & Comments Count */}
                <div className="flex items-center justify-between px-4 sm:px-5 py-2 text-xs text-[#5f6b7a]">
                  <div className="flex items-center gap-1">
                    {ev.reactions > 0 && (
                      <>
                        <span className="w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-white text-[10px]">❤️</span>
                        <span>{ev.reactions.toLocaleString("en-US")}</span>
                      </>
                    )}
                  </div>
                  {comments.length > 0 && (
                    <button onClick={() => toggleComments(ev.id)} className="hover:underline">
                      {comments.length.toLocaleString("en-US")} تعليق
                    </button>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center border-t border-gray-100">
                  <button
                    onClick={() => toggleComments(ev.id)}
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 text-sm text-[#5f6b7a] hover:bg-gray-50 active:bg-gray-100 transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    تعليق {comments.length > 0 ? `(${comments.length.toLocaleString("en-US")})` : ""}
                  </button>
                </div>

                {/* Comments Section */}
                {(isExpanded || comments.length > 0) && (
                  <div className="border-t border-gray-100 bg-[#f8f9fa]">
                    {/* Show all / collapse */}
                    {comments.length > 2 && (
                      <button
                        onClick={() => toggleComments(ev.id)}
                        className="w-full flex items-center gap-1 px-4 py-2 text-xs text-[#0D9488] hover:bg-[#0D9488]/5 transition-colors"
                      >
                        {isExpanded ? (
                          <><ChevronUp className="w-3.5 h-3.5" />إخفاء التعليقات</>
                        ) : (
                          <><ChevronDown className="w-3.5 h-3.5" />عرض كل التعليقات ({comments.length.toLocaleString("en-US")})</>
                        )}
                      </button>
                    )}

                    {/* Comments List */}
                    <div className="px-4 sm:px-5 py-2 space-y-3 max-h-48 overflow-y-auto">
                      {visibleComments.map((comment) => (
                        <div key={comment.id} className="flex gap-2.5 group">
                          {/* Avatar */}
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#0D9488]/20 to-[#0D9488]/10 flex items-center justify-center shrink-0 mt-0.5">
                            <span className="text-xs font-semibold text-[#0D9488]">
                              {getFirstName(comment.name).charAt(0)}
                            </span>
                          </div>
                          {/* Comment Bubble */}
                          <div className="flex-1 min-w-0">
                            <div className="bg-white rounded-2xl rounded-tr-md px-3.5 py-2.5 shadow-sm border border-gray-100 relative">
                              <div className="flex items-center gap-2 mb-0.5">
                                <span className="text-xs font-semibold text-[#1a1a2e]">{getFirstName(comment.name)}</span>
                                {comment.unit && (
                                  <span className="text-[10px] bg-[#0D9488]/10 text-[#0D9488] px-1.5 py-0.5 rounded">
                                    وحدة {comment.unit}
                                  </span>
                                )}
                              </div>
                              <p className="text-sm text-[#1a1a2e] leading-relaxed">{comment.text}</p>
                            </div>
                            <div className="flex items-center gap-3 mt-1 px-1">
                              <span className="text-[10px] text-[#5f6b7a]">{timeAgo(comment.createdAt)}</span>
                              {/* Admin can delete any comment */}
                              <button
                                onClick={() => handleDeleteComment(ev.id, comment.id)}
                                className="text-[10px] text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                حذف
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Comment Input */}
                    <div className="flex items-center gap-2 px-4 sm:px-5 py-3 border-t border-gray-100">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#0D9488] to-[#0D9488]/80 flex items-center justify-center shrink-0">
                        <span className="text-xs font-semibold text-white">
                          {profile ? getFirstName(profile.name).charAt(0) : "؟"}
                        </span>
                      </div>
                      <div className="flex-1 relative">
                        <input
                          ref={(el) => { commentInputRefs.current[ev.id] = el; }}
                          type="text"
                          value={commentText[ev.id] || ""}
                          onChange={(e) => setCommentText((prev) => ({ ...prev, [ev.id]: e.target.value }))}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" && !e.shiftKey) {
                              e.preventDefault();
                              handleAddComment(ev.id);
                            }
                          }}
                          placeholder="اكتب تعليقاً..."
                          className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 focus:border-[#0D9488]/30"
                          disabled={!profile || sendingComment === ev.id}
                        />
                        <button
                          onClick={() => handleAddComment(ev.id)}
                          disabled={!profile || !(commentText[ev.id] || "").trim() || sendingComment === ev.id}
                          className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full flex items-center justify-center text-[#0D9488] hover:bg-[#0D9488]/10 transition-colors disabled:opacity-30 disabled:hover:bg-transparent"
                        >
                          {sendingComment === ev.id ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Send className="w-4 h-4 rotate-180" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center text-sm text-[#5f6b7a]">لا توجد مناسبات مسجلة</div>
          )}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">{editingId ? "تعديل المناسبة" : "مناسبة جديدة"}</h3>
              <button onClick={() => setShowModal(false)} className="text-[#5f6b7a]"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">النوع</label>
                <div className="flex gap-2">
                  {(["congratulation", "condolence"] as const).map((t) => (
                    <button key={t} onClick={() => setForm({ ...form, type: t })} className={`flex-1 py-2.5 rounded-xl text-sm border-2 transition-all ${form.type === t ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-100 text-[#5f6b7a]"}`}>
                      {t === "congratulation" ? "🎉 تهنئة" : "🖤 تعزية"}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">العنوان *</label>
                <input type="text" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="مثال: مبروك المولود الجديد" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">اسم الساكن *</label>
                  <input type="text" value={form.resident} onChange={(e) => setForm({ ...form, resident: e.target.value })} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">رقم الوحدة</label>
                  <input type="text" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} placeholder="مثال: 301" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">الرسالة</label>
                <textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} rows={3} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 resize-none" />
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button onClick={() => setShowModal(false)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={handleSave} disabled={!form.title || !form.resident || saving} className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${form.title && form.resident && !saving ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20" : "bg-gray-300 cursor-not-allowed"}`}>
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                {editingId ? "حفظ التعديلات" : "نشر المناسبة"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-5">
              <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3"><Trash2 className="w-7 h-7 text-red-500" /></div>
              <h3 className="text-lg text-[#1a1a2e] mb-1">حذف المناسبة</h3>
              <p className="text-sm text-[#5f6b7a]">هل أنت متأكد من حذف هذه المناسبة؟</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm hover:bg-red-600">نعم، احذف</button>
            </div>
          </div>
        </div>
      )}

      <MobileFAB onClick={openAdd} label="مناسبة جديدة" />
    </div>
  );
}