import { useState, useEffect, useCallback } from "react";
import {
  Building2,
  Users,
  Home,
  CheckCircle2,
  Copy,
  Link2,
  Send,
  Loader2,
  MapPin,
  Layers,
  Plus,
  Minus,
  ArrowLeft,
  Edit3,
  Save,
  X,
  User,
  Phone,
  Mail,
  Shield,
  ExternalLink,
  Wallet,
  AlertTriangle,
  Trash2,
  Store,
  Sparkles,
  ChevronDown,
  Crown,
  KeyRound,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useNavigate } from "react-router";
import * as api from "../../lib/api";
import { normalizeToEnglishDigits } from "../../lib/phoneUtils";

type PageState = "loading" | "register" | "view";
type Tab = "info" | "association" | "invite" | "units";

const roleOptions = ["رئيس الاتحاد", "أمين الصندوق", "عضو"];

export function BuildingPage() {
  const navigate = useNavigate();
  const [pageState, setPageState] = useState<PageState>("loading");
  const [building, setBuilding] = useState<api.BuildingInfo | null>(null);
  const [units, setUnits] = useState<api.Unit[]>([]);
  const [copied, setCopied] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [editing, setEditing] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>("info");

  // Floor inline editing
  const [editingFloor, setEditingFloor] = useState<string | null>(null);
  const [editFloorLabel, setEditFloorLabel] = useState("");
  const [editFloorType, setEditFloorType] = useState<"سكني" | "تجاري">("سكني");
  const [editFloorCount, setEditFloorCount] = useState(4);
  const [savingFloor, setSavingFloor] = useState(false);

  // Association members (residents with treasurer/board_member roles)
  const [associationMembers, setAssociationMembers] = useState<api.Resident[]>([]);

  // Registration form — building
  const [formName, setFormName] = useState("");
  const [formAddress, setFormAddress] = useState("");
  const [formCity, setFormCity] = useState("");
  const [formFloors, setFormFloors] = useState(10);
  const [formDefaultUnits, setFormDefaultUnits] = useState(4);
  const [formCustomUnits, setFormCustomUnits] = useState(false);
  const [formPerFloor, setFormPerFloor] = useState<number[]>([]);
  // New floor config system
  const [floorConfigs, setFloorConfigs] = useState<api.FloorConfig[]>([]);
  const [showBulkAdd, setShowBulkAdd] = useState(false);
  const [bulkCount, setBulkCount] = useState(8);
  const [bulkUnits, setBulkUnits] = useState(4);
  const [bulkType, setBulkType] = useState<"سكني" | "تجاري">("سكني");
  const [bulkStartNum, setBulkStartNum] = useState(1);
  const [formInitialBalance, setFormInitialBalance] = useState("");
  const [formPreviousDebts, setFormPreviousDebts] = useState("");
  const [formPreviousRevenues, setFormPreviousRevenues] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Registration form — admin
  const [adminName, setAdminName] = useState("");
  const [adminPhone, setAdminPhone] = useState("");
  const [adminEmail, setAdminEmail] = useState("");
  const [adminRole, setAdminRole] = useState("رئيس الاتحاد");
  const [adminUnit, setAdminUnit] = useState("");

  const loadBuilding = useCallback(async () => {
    try {
      const res = await api.getBuilding();
      if (res.exists && res.building) {
        setBuilding(res.building);
        const [u, residents] = await Promise.all([
          api.getUnits(),
          api.getResidents().catch(() => [] as api.Resident[]),
        ]);
        setUnits(u);
        setAssociationMembers(residents.filter(r => r.role === "treasurer" || r.role === "board_member"));
        setPageState("view");
      } else {
        setPageState("register");
      }
    } catch (err) {
      console.error("Error loading building:", err);
      setPageState("register");
    }
  }, []);

  useEffect(() => { loadBuilding(); }, [loadBuilding]);

  const totalUnitsCalc = floorConfigs.length > 0
    ? floorConfigs.reduce((s, fc) => s + fc.unitCount, 0)
    : formCustomUnits
      ? formPerFloor.reduce((s, n) => s + n, 0)
      : formFloors * formDefaultUnits;
  const residentialUnits = floorConfigs.filter(fc => fc.unitType === "سكني").reduce((s, fc) => s + fc.unitCount, 0);
  const commercialUnits = floorConfigs.filter(fc => fc.unitType === "تجاري").reduce((s, fc) => s + fc.unitCount, 0);

  const inviteLink = building ? `https://mollak.app/join/${building.slug}` : "";

  // Floor label mapping (available early for edit helpers)
  const floorLabelMap: Record<string, string> = {};
  units.forEach(u => { if (u.floorLabel) floorLabelMap[u.floor] = u.floorLabel; });

  const showSuccess = (msg: string) => { setSuccessMsg(msg); setTimeout(() => setSuccessMsg(""), 3000); };

  const startEditFloor = (floorNum: string) => {
    const floorUnits = units.filter(u => u.floor === floorNum);
    const currentLabel = floorLabelMap[floorNum] || floorNum;
    const currentType = floorUnits[0]?.unitType || "سكني";
    setEditFloorLabel(currentLabel === floorNum ? `الدور ${floorNum}` : currentLabel);
    setEditFloorType(currentType as "سكني" | "تجاري");
    setEditFloorCount(floorUnits.length);
    setEditingFloor(floorNum);
  };

  const cancelEditFloor = () => {
    setEditingFloor(null);
    setSavingFloor(false);
  };

  const saveEditFloor = async () => {
    if (!editingFloor) return;
    setSavingFloor(true);
    try {
      const res = await api.updateFloorUnits(editingFloor, {
        label: editFloorLabel.trim(),
        unitType: editFloorType,
        unitCount: editFloorCount,
      });
      setUnits(res.units);
      // Refresh building info
      const bRes = await api.getBuilding();
      if (bRes.building) setBuilding(bRes.building);
      setEditingFloor(null);
      const protectedMsg = res.occupiedProtected > 0 ? ` (${res.occupiedProtected} وحدة مشغولة محمية)` : "";
      showSuccess(`تم تعديل ${editFloorLabel}${protectedMsg}`);
    } catch (err: any) {
      console.error("Error updating floor:", err);
      showSuccess(err.message || "حدث خطأ أثناء التعديل");
    } finally {
      setSavingFloor(false);
    }
  };

  const copyLink = () => {
    try {
      const textarea = document.createElement("textarea");
      textarea.value = inviteLink;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
    } catch { /* silently fail */ }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const initPerFloor = (floors: number, defaultVal: number) => {
    setFormPerFloor(Array(floors).fill(defaultVal));
  };

  const updatePerFloor = (index: number, value: number) => {
    setFormPerFloor((prev) => {
      const copy = [...prev];
      copy[index] = Math.max(1, Math.min(20, value));
      return copy;
    });
  };

  // Floor config helpers
  const addFloor = (label: string, unitCount: number, unitType: "سكني" | "تجاري") => {
    setFloorConfigs(prev => [...prev, { label, unitCount, unitType }]);
  };

  const removeFloor = (index: number) => {
    setFloorConfigs(prev => prev.filter((_, i) => i !== index));
  };

  const updateFloorConfig = (index: number, field: keyof api.FloorConfig, value: any) => {
    setFloorConfigs(prev => {
      const copy = [...prev];
      copy[index] = { ...copy[index], [field]: field === "unitCount" ? Math.max(1, Math.min(50, value)) : value };
      return copy;
    });
  };

  const addBulkFloors = () => {
    const newFloors: api.FloorConfig[] = [];
    for (let i = 0; i < bulkCount; i++) {
      newFloors.push({
        label: `الدور ${bulkStartNum + i}`,
        unitCount: bulkUnits,
        unitType: bulkType,
      });
    }
    setFloorConfigs(prev => [...prev, ...newFloors]);
    setShowBulkAdd(false);
    setBulkStartNum(prev => prev + bulkCount);
  };

  const applyPreset = (preset: "simple" | "mezzanine" | "commercial") => {
    switch (preset) {
      case "simple":
        setFloorConfigs([
          { label: "أرضي", unitCount: 4, unitType: "سكني" },
          ...Array.from({ length: 9 }, (_, i) => ({ label: `الدور ${i + 1}`, unitCount: 4, unitType: "سكني" as const })),
        ]);
        setBulkStartNum(10);
        break;
      case "mezzanine":
        setFloorConfigs([
          { label: "أرضي", unitCount: 3, unitType: "تجاري" },
          { label: "ميزانين", unitCount: 2, unitType: "تجاري" },
          ...Array.from({ length: 8 }, (_, i) => ({ label: `الدور ${i + 1}`, unitCount: 4, unitType: "سكني" as const })),
          { label: "روف", unitCount: 2, unitType: "سكني" },
        ]);
        setBulkStartNum(9);
        break;
      case "commercial":
        setFloorConfigs([
          { label: "أرضي", unitCount: 4, unitType: "تجاري" },
          { label: "ميزاني��", unitCount: 4, unitType: "تجاري" },
          ...Array.from({ length: 6 }, (_, i) => ({ label: `الدور ${i + 1}`, unitCount: 4, unitType: "سكني" as const })),
        ]);
        setBulkStartNum(7);
        break;
    }
  };



  const handleRegister = async () => {
    if (!formName.trim() || !adminName.trim()) return;
    setSubmitting(true);
    try {
      let unitsPerFloor: number[] | undefined;
      if (formCustomUnits && formPerFloor.length > 0) {
        unitsPerFloor = [0, ...formPerFloor];
      }
      const res = await api.registerBuilding({
        name: formName.trim(), address: formAddress.trim(), city: formCity.trim(),
        floors: floorConfigs.length > 0 ? floorConfigs.length : formFloors,
        defaultUnitsPerFloor: formDefaultUnits, unitsPerFloor,
        floorConfigs: floorConfigs.length > 0 ? floorConfigs : undefined,
        initialBalance: formInitialBalance ? parseFloat(formInitialBalance) : 0,
        previousDebts: formPreviousDebts ? parseFloat(formPreviousDebts) : 0,
        previousRevenues: formPreviousRevenues ? parseFloat(formPreviousRevenues) : 0,
        admin: {
          name: adminName.trim(), phone: normalizeToEnglishDigits(adminPhone.trim()),
          email: adminEmail.trim(), role: adminRole, unitCode: adminUnit.trim() || undefined,
        },
      });
      setBuilding(res.building);
      const u = await api.getUnits();
      setUnits(u);
      setPageState("view");
      showSuccess(`تم تسجيل "${res.building.name}" بنجاح — ${res.unitsCount} وحدة`);
      window.dispatchEvent(new Event("building-updated"));
    } catch (err) {
      console.error("Error registering building:", err);
      showSuccess("حدث خطأ أثناء تسجيل المبنى");
    } finally { setSubmitting(false); }
  };

  const handleUpdate = async () => {
    if (!formName.trim()) return;
    setSubmitting(true);
    try {
      const res = await api.updateBuilding({
        name: formName.trim(), address: formAddress.trim(), city: formCity.trim(),
        initialBalance: formInitialBalance ? parseFloat(formInitialBalance) : 0,
        previousDebts: formPreviousDebts ? parseFloat(formPreviousDebts) : 0,
        previousRevenues: formPreviousRevenues ? parseFloat(formPreviousRevenues) : 0,
      });
      setBuilding(res.building);
      setEditing(false);
      showSuccess("تم تحديث بيانات المبنى");
      window.dispatchEvent(new Event("building-updated"));
    } catch (err) {
      console.error("Error updating building:", err);
      showSuccess("حدث خطأ أثناء التحديث");
    } finally { setSubmitting(false); }
  };

  const handleUpdateAdmin = async () => {
    if (!adminName.trim()) return;
    setSubmitting(true);
    try {
      const res = await api.updateBuilding({
        admin: {
          name: adminName.trim(), phone: normalizeToEnglishDigits(adminPhone.trim()),
          email: adminEmail.trim(), role: adminRole, unitCode: adminUnit.trim() || undefined,
        },
      });
      setBuilding(res.building);
      setEditingAdmin(false);
      showSuccess("تم تحديث بيانات المسؤول");
      window.dispatchEvent(new Event("building-updated"));
    } catch (err) {
      console.error("Error updating admin:", err);
      showSuccess("حدث خطأ أثناء التحديث");
    } finally { setSubmitting(false); }
  };

  const startEditing = () => {
    if (building) {
      setFormName(building.name);
      setFormAddress(building.address);
      setFormCity(building.city);
      setFormInitialBalance(building.initialBalance ? String(building.initialBalance) : "");
      setFormPreviousDebts(building.previousDebts ? String(building.previousDebts) : "");
      setFormPreviousRevenues(building.previousRevenues ? String(building.previousRevenues) : "");
    }
    setEditing(true);
  };

  const startEditingAdmin = () => {
    if (building?.admin) {
      setAdminName(building.admin.name);
      setAdminPhone(building.admin.phone);
      setAdminEmail(building.admin.email);
      setAdminRole(building.admin.role);
      setAdminUnit(building.admin.unitCode || "");
    }
    setEditingAdmin(true);
  };

  const floorGroups = units.reduce<Record<string, api.Unit[]>>((acc, unit) => {
    const f = unit.floor;
    if (!acc[f]) acc[f] = [];
    acc[f].push(unit);
    return acc;
  }, {});

  const sortedFloors = Object.keys(floorGroups).sort((a, b) => parseInt(a) - parseInt(b));
  const occupiedCount = units.filter((u) => u.occupied).length;
  const emptyCount = units.length - occupiedCount;

  const [expandedFloors, setExpandedFloors] = useState<Set<string>>(new Set());
  const toggleFloor = (floorNum: string) => {
    setExpandedFloors(prev => {
      const next = new Set(prev);
      if (next.has(floorNum)) next.delete(floorNum);
      else next.add(floorNum);
      return next;
    });
  };

  const tabs: { id: Tab; label: string; icon: typeof Building2 }[] = [
    { id: "info", label: "معلومات المبنى", icon: Building2 },
    { id: "association", label: "اتحاد المُلاك", icon: Shield },
    { id: "invite", label: "رابط الدعوة", icon: Link2 },
    { id: "units", label: "الوحدات", icon: Layers },
  ];

  // ===== Loading =====
  if (pageState === "loading") {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin mx-auto mb-3" />
          <p className="text-sm text-[#5f6b7a]">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  // ===== Registration Form =====
  if (pageState === "register") {
    return (
      <div className="max-w-xl mx-auto space-y-6">
        {successMsg && (
          <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-red-500 text-white px-5 py-3 rounded-xl shadow-lg flex items-center gap-2 text-sm">
            <X className="w-4 h-4" />{successMsg}
          </div>
        )}

        <div className="text-center">
          <div className="w-16 h-16 bg-[#0D9488]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Building2 className="w-8 h-8 text-[#0D9488]" />
          </div>
          <h1 className="text-2xl text-[#1a1a2e] mb-1">تسجيل مبنى جديد</h1>
          <p className="text-sm text-[#5f6b7a]">أدخل بيانات المبنى والمسؤول وسيتم إنشاء الوحدات تلقائياً</p>
        </div>

        <div className="flex items-center justify-center gap-2">
          {[
            { num: 1, label: "بيانات المبنى" },
            { num: 2, label: "تصميم الأدوار" },
            { num: 3, label: "المسؤول" },
          ].map((s, i) => (
            <div key={s.num} className="flex items-center gap-2">
              {i > 0 && <div className="w-4 h-px bg-gray-200" />}
              <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition-all ${step === s.num ? "bg-[#0D9488] text-white shadow-md" : step > s.num ? "bg-[#0D9488]/10 text-[#0D9488]" : "bg-gray-100 text-[#5f6b7a]"}`}>
                <span className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center text-[10px]">{s.num}</span>
                <span className="hidden sm:inline">{s.label}</span>
              </div>
            </div>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="bg-white rounded-2xl border border-gray-100 p-6 space-y-5 shadow-sm">
              <div>
                <label className="block text-sm text-[#1a1a2e] mb-2">اسم المبنى <span className="text-red-400">*</span></label>
                <div className="relative">
                  <Building2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" />
                  <input type="text" value={formName} onChange={(e) => setFormName(e.target.value)} placeholder="مثال: برج الصفا" className="w-full pr-10 pl-4 py-3 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm transition-all" />
                </div>
              </div>
              <div>
                <label className="block text-sm text-[#1a1a2e] mb-2">العنوان</label>
                <div className="relative">
                  <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" />
                  <input type="text" value={formAddress} onChange={(e) => setFormAddress(e.target.value)} placeholder="مثال: شارع التسعين، التجمع الخامس" className="w-full pr-10 pl-4 py-3 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm transition-all" />
                </div>
              </div>
              <div>
                <label className="block text-sm text-[#1a1a2e] mb-2">المدينة</label>
                <input type="text" value={formCity} onChange={(e) => setFormCity(e.target.value)} placeholder="مثال: القاهرة الجديدة" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm transition-all" />
              </div>
              <div className="bg-[#F59E0B]/5 border border-[#F59E0B]/10 rounded-xl p-4 space-y-4">
                <div className="flex items-center gap-2 text-sm text-[#1a1a2e]">
                  <Wallet className="w-4 h-4 text-[#F59E0B]" />الوضع المالي قبل مُلاك
                  <span className="text-[10px] text-[#5f6b7a] bg-[#F59E0B]/10 px-2 py-0.5 rounded-full">اختياري</span>
                </div>
                <p className="text-[11px] text-[#5f6b7a] -mt-2">لو الاتحاد عنده رصيد محفوظ أو مديونيات من قبل، سجّلها هنا عشان الحسابات تكون دقيقة</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-[#5f6b7a] mb-1.5"><span className="flex items-center gap-1"><Wallet className="w-3 h-3 text-[#0D9488]" />رصيد حالي (ج.م)</span></label>
                    <input type="number" inputMode="decimal" value={formInitialBalance} onChange={(e) => setFormInitialBalance(e.target.value)} placeholder="0" min="0" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm transition-all text-left" dir="ltr" />
                    <p className="text-[10px] text-[#5f6b7a]/70 mt-1">المبلغ المحفوظ مع أمين الصندوق</p>
                  </div>
                  <div>
                    <label className="block text-xs text-[#5f6b7a] mb-1.5"><span className="flex items-center gap-1"><AlertTriangle className="w-3 h-3 text-[#F59E0B]" />مديونيات سابقة (ج.م)</span></label>
                    <input type="number" inputMode="decimal" value={formPreviousDebts} onChange={(e) => setFormPreviousDebts(e.target.value)} placeholder="0" min="0" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#F59E0B] focus:ring-2 focus:ring-[#F59E0B]/10 outline-none text-sm transition-all text-left" dir="ltr" />
                    <p className="text-[10px] text-[#5f6b7a]/70 mt-1">مبالغ مستحقة على السكان من قبل</p>
                  </div>
                  <div>
                    <label className="block text-xs text-[#5f6b7a] mb-1.5"><span className="flex items-center gap-1"><Wallet className="w-3 h-3 text-[#22c55e]" />إيرادات سابقة (ج.م)</span></label>
                    <input type="number" inputMode="decimal" value={formPreviousRevenues} onChange={(e) => setFormPreviousRevenues(e.target.value)} placeholder="0" min="0" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#22c55e] focus:ring-2 focus:ring-[#22c55e]/10 outline-none text-sm transition-all text-left" dir="ltr" />
                    <p className="text-[10px] text-[#5f6b7a]/70 mt-1">إيرادات تم تحصيلها قبل استخدام مُلاك</p>
                  </div>
                </div>
              </div>
              <button onClick={() => { if (!formName.trim()) return; initPerFloor(formFloors, formDefaultUnits); setStep(2); }} disabled={!formName.trim()} className="w-full py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-all flex items-center justify-center gap-2 shadow-md shadow-[#0D9488]/20 disabled:opacity-50 disabled:cursor-not-allowed">
                التالي<ArrowLeft className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="bg-white rounded-2xl border border-gray-100 p-5 sm:p-6 space-y-5 shadow-sm">
              <div>
                <div className="flex items-center gap-2 text-sm text-[#1a1a2e] mb-1">
                  <div className="w-8 h-8 bg-[#0D9488]/10 rounded-lg flex items-center justify-center"><Layers className="w-4 h-4 text-[#0D9488]" /></div>
                  تصميم الأدوار والوحدات
                </div>
                <p className="text-[11px] text-[#5f6b7a] mr-10">حدد أدوار المبنى ونوع كل دور (سكني/تجاري) وعدد الوحدات فيه</p>
              </div>

              {/* Presets */}
              {floorConfigs.length === 0 && (
                <div className="space-y-3">
                  <div className="text-xs text-[#5f6b7a] flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5 text-[#F59E0B]" />اختر نموذج جاهز أو ابدأ من الصفر</div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    <button onClick={() => applyPreset("simple")} className="border border-gray-200 rounded-xl p-3 text-right hover:border-[#0D9488] hover:bg-[#0D9488]/5 transition-all group">
                      <div className="flex items-center gap-2 mb-1.5">
                        <Building2 className="w-4 h-4 text-[#0D9488] group-hover:scale-110 transition-transform" />
                        <span className="text-sm text-[#1a1a2e]">برج سكني بسيط</span>
                      </div>
                      <p className="text-[10px] text-[#5f6b7a]">أرضي + 9 أدوار سكنية (4 شقق/دور)</p>
                    </button>
                    <button onClick={() => applyPreset("mezzanine")} className="border border-gray-200 rounded-xl p-3 text-right hover:border-[#F59E0B] hover:bg-[#F59E0B]/5 transition-all group">
                      <div className="flex items-center gap-2 mb-1.5">
                        <Store className="w-4 h-4 text-[#F59E0B] group-hover:scale-110 transition-transform" />
                        <span className="text-sm text-[#1a1a2e]">سكني + ميزانين</span>
                      </div>
                      <p className="text-[10px] text-[#5f6b7a]">أرضي تجاري + ميزانين + 8 أدوار + روف</p>
                    </button>
                    <button onClick={() => applyPreset("commercial")} className="border border-gray-200 rounded-xl p-3 text-right hover:border-[#6366f1] hover:bg-[#6366f1]/5 transition-all group">
                      <div className="flex items-center gap-2 mb-1.5">
                        <Layers className="w-4 h-4 text-[#6366f1] group-hover:scale-110 transition-transform" />
                        <span className="text-sm text-[#1a1a2e]">تجاري وسكني</span>
                      </div>
                      <p className="text-[10px] text-[#5f6b7a]">أرضي + ميزانين تجاري + 6 أدوار سكنية</p>
                    </button>
                  </div>
                </div>
              )}

              {/* Floor List */}
              {floorConfigs.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#5f6b7a]">الأدوار ({floorConfigs.length} دور)</span>
                    <button onClick={() => { setFloorConfigs([]); setBulkStartNum(1); }} className="text-[10px] text-red-400 hover:text-red-500 transition-colors">إعادة تعيين</button>
                  </div>
                  <div className="max-h-[320px] overflow-y-auto space-y-2 pr-1 scrollbar-thin">
                    {floorConfigs.map((fc, i) => (
                      <div key={i} className={`rounded-xl border p-3 transition-all ${fc.unitType === "تجاري" ? "border-[#F59E0B]/20 bg-[#F59E0B]/[0.03]" : "border-gray-100 bg-gray-50/50"}`}>
                        <div className="flex items-center gap-2 flex-wrap">
                          {/* Floor label */}
                          <div className="flex-1 min-w-[100px]">
                            <input
                              type="text"
                              value={fc.label}
                              onChange={(e) => updateFloorConfig(i, "label", e.target.value)}
                              className="w-full text-sm text-[#1a1a2e] bg-transparent border-b border-transparent focus:border-[#0D9488] outline-none py-0.5 transition-colors"
                              placeholder="اسم الدور"
                            />
                          </div>
                          {/* Unit type toggle */}
                          <button
                            onClick={() => updateFloorConfig(i, "unitType", fc.unitType === "سكني" ? "تجاري" : "سكني")}
                            className={`text-[10px] px-2.5 py-1 rounded-full border transition-all shrink-0 ${
                              fc.unitType === "تجاري"
                                ? "bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20"
                                : "bg-[#0D9488]/10 text-[#0D9488] border-[#0D9488]/20"
                            }`}
                          >
                            {fc.unitType === "تجاري" ? "🏪 تجاري" : "🏠 سكني"}
                          </button>
                          {/* Unit count */}
                          <div className="flex items-center gap-1.5 shrink-0">
                            <button onClick={() => updateFloorConfig(i, "unitCount", fc.unitCount - 1)} className="w-6 h-6 rounded-md border border-gray-200 flex items-center justify-center text-[#5f6b7a] hover:bg-white text-xs transition-colors"><Minus className="w-3 h-3" /></button>
                            <input
                              type="number"
                              value={fc.unitCount}
                              onChange={(e) => updateFloorConfig(i, "unitCount", parseInt(e.target.value) || 1)}
                              className="w-10 text-center text-sm text-[#1a1a2e] border-b border-gray-300 focus:border-[#0D9488] outline-none bg-transparent"
                            />
                            <button onClick={() => updateFloorConfig(i, "unitCount", fc.unitCount + 1)} className="w-6 h-6 rounded-md border border-gray-200 flex items-center justify-center text-[#5f6b7a] hover:bg-white text-xs transition-colors"><Plus className="w-3 h-3" /></button>
                          </div>
                          {/* Delete */}
                          <button onClick={() => removeFloor(i)} className="w-6 h-6 rounded-md flex items-center justify-center text-red-300 hover:text-red-500 hover:bg-red-50 transition-colors shrink-0">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Quick add buttons */}
                  <div className="flex flex-wrap gap-2">
                    {!floorConfigs.some(fc => fc.label === "أرضي") && (
                      <button onClick={() => { const newConfigs = [{ label: "أرضي", unitCount: 3, unitType: "تجاري" as const }, ...floorConfigs]; setFloorConfigs(newConfigs); }} className="text-[11px] px-3 py-1.5 rounded-lg border border-dashed border-[#F59E0B]/30 text-[#F59E0B] hover:bg-[#F59E0B]/5 transition-colors flex items-center gap-1">
                        <Plus className="w-3 h-3" />أرضي
                      </button>
                    )}
                    {!floorConfigs.some(fc => fc.label === "ميزانين") && (
                      <button onClick={() => {
                        const groundIdx = floorConfigs.findIndex(fc => fc.label === "أرضي");
                        const insertAt = groundIdx >= 0 ? groundIdx + 1 : 0;
                        const copy = [...floorConfigs];
                        copy.splice(insertAt, 0, { label: "ميزانين", unitCount: 2, unitType: "تجاري" });
                        setFloorConfigs(copy);
                      }} className="text-[11px] px-3 py-1.5 rounded-lg border border-dashed border-[#F59E0B]/30 text-[#F59E0B] hover:bg-[#F59E0B]/5 transition-colors flex items-center gap-1">
                        <Plus className="w-3 h-3" />ميزانين
                      </button>
                    )}
                    <button onClick={() => setShowBulkAdd(true)} className="text-[11px] px-3 py-1.5 rounded-lg border border-dashed border-[#0D9488]/30 text-[#0D9488] hover:bg-[#0D9488]/5 transition-colors flex items-center gap-1">
                      <Plus className="w-3 h-3" />أدوار متكررة
                    </button>
                    {!floorConfigs.some(fc => fc.label === "روف") && (
                      <button onClick={() => addFloor("روف", 2, "سكني")} className="text-[11px] px-3 py-1.5 rounded-lg border border-dashed border-[#0D9488]/30 text-[#0D9488] hover:bg-[#0D9488]/5 transition-colors flex items-center gap-1">
                        <Plus className="w-3 h-3" />روف
                      </button>
                    )}
                    <button onClick={() => {
                      const nums = floorConfigs.map(fc => { const m = fc.label.match(/الدور\s*(\d+)/); return m ? parseInt(m[1]) : 0; });
                      const next = Math.max(0, ...nums) + 1;
                      addFloor(`الدور ${next}`, 4, "سكني");
                    }} className="text-[11px] px-3 py-1.5 rounded-lg border border-dashed border-gray-300 text-[#5f6b7a] hover:bg-gray-50 transition-colors flex items-center gap-1">
                      <Plus className="w-3 h-3" />دور جديد
                    </button>
                  </div>

                  {/* Bulk add dialog */}
                  {showBulkAdd && (
                    <div className="bg-[#0D9488]/5 border border-[#0D9488]/15 rounded-xl p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-[#1a1a2e] flex items-center gap-1.5"><Layers className="w-4 h-4 text-[#0D9488]" />إضافة أدوار متكررة</span>
                        <button onClick={() => setShowBulkAdd(false)} className="text-[#5f6b7a] hover:text-[#1a1a2e]"><X className="w-4 h-4" /></button>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] text-[#5f6b7a] mb-1">عدد الأدوار</label>
                          <input type="number" value={bulkCount} onChange={(e) => setBulkCount(Math.max(1, Math.min(50, parseInt(e.target.value) || 1)))} min={1} max={50} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-[#0D9488] outline-none text-sm text-center" />
                        </div>
                        <div>
                          <label className="block text-[11px] text-[#5f6b7a] mb-1">وحدات لكل دور</label>
                          <input type="number" value={bulkUnits} onChange={(e) => setBulkUnits(Math.max(1, Math.min(50, parseInt(e.target.value) || 1)))} min={1} max={50} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-[#0D9488] outline-none text-sm text-center" />
                        </div>
                        <div>
                          <label className="block text-[11px] text-[#5f6b7a] mb-1">ترقيم من</label>
                          <input type="number" value={bulkStartNum} onChange={(e) => setBulkStartNum(Math.max(1, parseInt(e.target.value) || 1))} min={1} className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-[#0D9488] outline-none text-sm text-center" />
                        </div>
                        <div>
                          <label className="block text-[11px] text-[#5f6b7a] mb-1">نوع الوحدات</label>
                          <button onClick={() => setBulkType(prev => prev === "سكني" ? "تجاري" : "سكني")} className={`w-full px-3 py-2 rounded-lg border text-sm transition-all ${bulkType === "تجاري" ? "border-[#F59E0B]/30 bg-[#F59E0B]/10 text-[#F59E0B]" : "border-[#0D9488]/30 bg-[#0D9488]/10 text-[#0D9488]"}`}>
                            {bulkType === "تجاري" ? "🏪 تجاري" : "🏠 سكني"}
                          </button>
                        </div>
                      </div>
                      <p className="text-[10px] text-[#5f6b7a]">سيتم إضافة: الدور {bulkStartNum} إلى الدور {bulkStartNum + bulkCount - 1} ({bulkCount} × {bulkUnits} = {bulkCount * bulkUnits} وحدة)</p>
                      <button onClick={addBulkFloors} className="w-full py-2 rounded-lg bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-colors flex items-center justify-center gap-1.5">
                        <Plus className="w-4 h-4" />إضافة {bulkCount} أدوار
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Summary */}
              {floorConfigs.length > 0 && (
                <div className="bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-xl p-4">
                  <div className="flex items-center justify-between text-sm mb-3"><span className="text-[#5f6b7a]">ملخص المبنى</span><Building2 className="w-4 h-4 text-[#0D9488]" /></div>
                  <div className="grid grid-cols-4 gap-2">
                    <div className="text-center bg-white rounded-lg py-2 border border-gray-100"><div className="text-lg text-[#0D9488]">{floorConfigs.length}</div><div className="text-[10px] text-[#5f6b7a]">دور</div></div>
                    <div className="text-center bg-white rounded-lg py-2 border border-gray-100"><div className="text-lg text-[#0D9488]">{totalUnitsCalc}</div><div className="text-[10px] text-[#5f6b7a]">إجمالي</div></div>
                    <div className="text-center bg-white rounded-lg py-2 border border-gray-100"><div className="text-lg text-[#0D9488]">{residentialUnits}</div><div className="text-[10px] text-[#5f6b7a]">🏠 سكني</div></div>
                    <div className="text-center bg-white rounded-lg py-2 border border-gray-100"><div className="text-lg text-[#F59E0B]">{commercialUnits}</div><div className="text-[10px] text-[#5f6b7a]">🏪 تجاري</div></div>
                  </div>
                  {/* Mini building preview */}
                  <div className="mt-3 flex flex-col-reverse gap-[2px]">
                    {floorConfigs.map((fc, i) => (
                      <div key={i} className={`flex items-center gap-1.5 rounded px-2 py-[3px] text-[9px] ${fc.unitType === "تجاري" ? "bg-[#F59E0B]/10 text-[#F59E0B]" : "bg-[#0D9488]/10 text-[#0D9488]"}`}>
                        <span className="w-14 truncate font-medium">{fc.label}</span>
                        <div className="flex-1 flex gap-[2px]">
                          {Array.from({ length: Math.min(fc.unitCount, 12) }, (_, u) => (
                            <div key={u} className={`h-3 flex-1 rounded-[2px] ${fc.unitType === "تجاري" ? "bg-[#F59E0B]/20" : "bg-[#0D9488]/15"}`} />
                          ))}
                          {fc.unitCount > 12 && <span className="text-[8px] opacity-60">+{fc.unitCount - 12}</span>}
                        </div>
                        <span className="opacity-60">{fc.unitCount}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-3">
                <button onClick={() => setStep(1)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm hover:bg-gray-50 transition-colors">رجوع</button>
                <button onClick={() => setStep(3)} disabled={floorConfigs.length === 0} className="flex-1 py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-all flex items-center justify-center gap-2 shadow-md shadow-[#0D9488]/20 disabled:opacity-50 disabled:cursor-not-allowed">التالي<ArrowLeft className="w-4 h-4" /></button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="bg-white rounded-2xl border border-gray-100 p-6 space-y-5 shadow-sm">
              <div className="flex items-center gap-2 text-sm text-[#1a1a2e]">
                <div className="w-8 h-8 bg-[#0D9488]/10 rounded-lg flex items-center justify-center"><Shield className="w-4 h-4 text-[#0D9488]" /></div>
                بيانات مسؤول المبنى
              </div>
              <div>
                <label className="block text-sm text-[#1a1a2e] mb-2">الاسم الكامل <span className="text-red-400">*</span></label>
                <div className="relative"><User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" /><input type="text" value={adminName} onChange={(e) => setAdminName(e.target.value)} placeholder="مثال: أحمد محمد علي" className="w-full pr-10 pl-4 py-3 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm transition-all" /></div>
              </div>
              <div>
                <label className="block text-sm text-[#1a1a2e] mb-2">رقم الهاتف <span className="text-red-400">*</span></label>
                <div className="relative"><Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" /><input type="tel" value={adminPhone} onChange={(e) => setAdminPhone(normalizeToEnglishDigits(e.target.value))} placeholder="مثال: 01012345678" dir="ltr" className="w-full pr-10 pl-4 py-3 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm transition-all text-left" /></div>
              </div>
              <div>
                <label className="block text-sm text-[#1a1a2e] mb-2">البريد الإلكتروني</label>
                <div className="relative"><Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" /><input type="email" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} placeholder="مثال: ahmed@example.com" dir="ltr" className="w-full pr-10 pl-4 py-3 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm transition-all text-left" /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-[#1a1a2e] mb-2">الدور في الاتحاد</label>
                  <select value={adminRole} onChange={(e) => setAdminRole(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm bg-white transition-all">
                    {roleOptions.map((r) => (<option key={r} value={r}>{r}</option>))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-[#1a1a2e] mb-2">رقم الشقة (اختياري)</label>
                  <input type="text" value={adminUnit} onChange={(e) => setAdminUnit(e.target.value)} placeholder="مثال: 301" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm transition-all" />
                </div>
              </div>
              <div className="bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-xl p-4">
                <div className="text-xs text-[#5f6b7a] mb-2">مل��ص التسجيل</div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-white rounded-lg px-3 py-2 border border-gray-100"><div className="text-[10px] text-[#5f6b7a]">المبنى</div><div className="text-[#1a1a2e]">{formName}</div></div>
                  <div className="bg-white rounded-lg px-3 py-2 border border-gray-100"><div className="text-[10px] text-[#5f6b7a]">الأدوار / الوحدات</div><div className="text-[#1a1a2e]">{floorConfigs.length > 0 ? floorConfigs.length : formFloors} دور — {totalUnitsCalc} وحدة{commercialUnits > 0 ? ` (${commercialUnits} تجاري)` : ""}</div></div>
                  <div className="bg-white rounded-lg px-3 py-2 border border-gray-100"><div className="text-[10px] text-[#5f6b7a]">المسؤول</div><div className="text-[#1a1a2e]">{adminName || "—"}</div></div>
                  <div className="bg-white rounded-lg px-3 py-2 border border-gray-100"><div className="text-[10px] text-[#5f6b7a]">الدور</div><div className="text-[#0D9488]">{adminRole}</div></div>
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setStep(2)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm hover:bg-gray-50 transition-colors">رجوع</button>
                <button onClick={handleRegister} disabled={submitting || !formName.trim() || !adminName.trim() || !adminPhone.trim()} className="flex-1 py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-all flex items-center justify-center gap-2 shadow-md shadow-[#0D9488]/20 disabled:opacity-50">
                  {submitting ? (<><Loader2 className="w-4 h-4 animate-spin" />جاري التسجيل...</>) : (<><CheckCircle2 className="w-4 h-4" />تسجيل المبنى</>)}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  // ===== View Building (Tabbed) =====
  return (
    <div className="space-y-5">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}

      <div>
        <h1 className="text-2xl text-[#1a1a2e]">إدارة المبنى</h1>
        <p className="text-sm text-[#5f6b7a]">
          {building?.name}{building?.address ? ` — ${building.address}` : ""}{building?.city ? `، ${building.city}` : ""}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex overflow-x-auto gap-1 bg-white rounded-2xl border border-gray-100 p-1.5 shadow-sm scrollbar-hide">
        {tabs.map((tab) => (
          <button key={tab.id} onClick={() => { setActiveTab(tab.id); setEditing(false); setEditingAdmin(false); }}
            className={`flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-xs whitespace-nowrap transition-all shrink-0 ${activeTab === tab.id ? "bg-[#0D9488] text-white shadow-md shadow-[#0D9488]/20" : "text-[#5f6b7a] hover:bg-gray-50"}`}>
            <tab.icon className="w-3.5 h-3.5" />{tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        {/* Tab 1: Building Info */}
        {activeTab === "info" && (
          <motion.div key="info" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.15 }}>
            {!editing ? (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-5 py-3 bg-[#0D9488]/5 border-b border-[#0D9488]/10 flex items-center justify-between">
                  <div className="flex items-center gap-2"><Building2 className="w-4 h-4 text-[#0D9488]" /><span className="text-sm text-[#1a1a2e]">بيانات المبنى</span></div>
                  <button onClick={startEditing} className="text-xs text-[#0D9488] hover:underline flex items-center gap-1"><Edit3 className="w-3 h-3" />تعديل</button>
                </div>
                <div className="p-5 space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {[
                      { label: "اسم المبنى", value: building?.name || "—", icon: Building2, color: "#0D9488" },
                      { label: "العنوان", value: building?.address || "—", icon: MapPin, color: "#6366f1" },
                      { label: "المدينة", value: building?.city || "—", icon: MapPin, color: "#8b5cf6" },
                      { label: "عدد الأدوار", value: building?.floors || 0, icon: Layers, color: "#0D9488" },
                      { label: "إجمالي الوحدات", value: building?.totalUnits || units.length, icon: Home, color: "#6366f1" },
                    ].map((item) => (
                      <div key={item.label} className="bg-gray-50 rounded-xl p-3 border border-gray-100">
                        <div className="flex items-center gap-1.5 mb-1"><item.icon className="w-3 h-3" style={{ color: item.color }} /><span className="text-[10px] text-[#5f6b7a]">{item.label}</span></div>
                        <div className="text-sm text-[#1a1a2e]">{item.value}</div>
                      </div>
                    ))}
                  </div>
                  {building?.floorConfigs && building.floorConfigs.length > 0 && (
                    <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
                      <div className="flex items-center gap-2 text-xs text-[#1a1a2e] mb-3"><Layers className="w-3.5 h-3.5 text-[#0D9488]" />تفاصيل الأدوار</div>
                      <div className="flex flex-col-reverse gap-[3px]">
                        {building.floorConfigs.map((fc: any, i: number) => (
                          <div key={i} className={`flex items-center justify-between rounded-lg px-3 py-1.5 text-xs ${fc.unitType === "تجاري" ? "bg-[#F59E0B]/10 text-[#F59E0B]" : "bg-[#0D9488]/10 text-[#0D9488]"}`}>
                            <span>{fc.label}</span>
                            <span className="opacity-70">{fc.unitCount} {fc.unitType === "تجاري" ? "محل" : "شقة"}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="bg-[#F59E0B]/5 border border-[#F59E0B]/10 rounded-xl p-4">
                    <div className="flex items-center gap-2 text-xs text-[#1a1a2e] mb-3"><Wallet className="w-3.5 h-3.5 text-[#F59E0B]" />الوضع المالي الابتدائي</div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div className="bg-white rounded-lg px-4 py-3 border border-gray-100 flex items-center justify-between sm:flex-col sm:text-center gap-2">
                        <div className="text-xs text-[#5f6b7a]">رصيد حالي</div>
                        <div className="text-sm text-[#0D9488] font-semibold whitespace-nowrap">{(building?.initialBalance || 0).toLocaleString("en-US")} ج.م</div>
                      </div>
                      <div className="bg-white rounded-lg px-4 py-3 border border-gray-100 flex items-center justify-between sm:flex-col sm:text-center gap-2">
                        <div className="text-xs text-[#5f6b7a]">مديونيات سابقة</div>
                        <div className={`text-sm font-semibold whitespace-nowrap ${building?.previousDebts ? "text-[#dc2626]" : "text-[#5f6b7a]"}`}>{(building?.previousDebts || 0).toLocaleString("en-US")} ج.م</div>
                      </div>
                      <div className="bg-white rounded-lg px-4 py-3 border border-gray-100 flex items-center justify-between sm:flex-col sm:text-center gap-2">
                        <div className="text-xs text-[#5f6b7a]">إيرادات سابقة</div>
                        <div className={`text-sm font-semibold whitespace-nowrap ${building?.previousRevenues ? "text-[#22c55e]" : "text-[#5f6b7a]"}`}>{(building?.previousRevenues || 0).toLocaleString("en-US")} ج.م</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-[#0D9488]/10 p-5 space-y-4 shadow-sm">
                <h3 className="text-sm text-[#1a1a2e] flex items-center gap-2"><Edit3 className="w-4 h-4 text-[#0D9488]" />تعديل بيانات المبنى</h3>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div><label className="block text-xs text-[#5f6b7a] mb-1">اسم المبنى</label><input type="text" value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm" /></div>
                  <div><label className="block text-xs text-[#5f6b7a] mb-1">العنوان</label><input type="text" value={formAddress} onChange={(e) => setFormAddress(e.target.value)} className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm" /></div>
                  <div><label className="block text-xs text-[#5f6b7a] mb-1">المدينة</label><input type="text" value={formCity} onChange={(e) => setFormCity(e.target.value)} className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm" /></div>
                </div>
                <div className="bg-[#F59E0B]/5 border border-[#F59E0B]/10 rounded-xl p-4">
                  <div className="flex items-center gap-2 text-xs text-[#1a1a2e] mb-3"><Wallet className="w-3.5 h-3.5 text-[#F59E0B]" />الوضع المالي الابتدائي</div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div><label className="block text-[10px] text-[#5f6b7a] mb-1">رصيد حالي (ج.م)</label><input type="number" inputMode="decimal" value={formInitialBalance} onChange={(e) => setFormInitialBalance(e.target.value)} placeholder="0" min="0" dir="ltr" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm text-left" /></div>
                    <div><label className="block text-[10px] text-[#5f6b7a] mb-1">مديونيات سابقة (ج.م)</label><input type="number" inputMode="decimal" value={formPreviousDebts} onChange={(e) => setFormPreviousDebts(e.target.value)} placeholder="0" min="0" dir="ltr" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#F59E0B] focus:ring-2 focus:ring-[#F59E0B]/10 outline-none text-sm text-left" /></div>
                    <div><label className="block text-[10px] text-[#5f6b7a] mb-1">إيرادات سابقة (ج.م)</label><input type="number" inputMode="decimal" value={formPreviousRevenues} onChange={(e) => setFormPreviousRevenues(e.target.value)} placeholder="0" min="0" dir="ltr" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#22c55e] focus:ring-2 focus:ring-[#22c55e]/10 outline-none text-sm text-left" /></div>
                  </div>
                </div>
                <div className="flex gap-2 justify-end">
                  <button onClick={() => setEditing(false)} className="px-4 py-2 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm hover:bg-gray-50 transition-colors">إلغاء</button>
                  <button onClick={handleUpdate} disabled={submitting || !formName.trim()} className="px-5 py-2 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 transition-all flex items-center gap-1.5 disabled:opacity-50">{submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}حفظ</button>
                </div>
              </div>
            )}
          </motion.div>
        )}

        {/* Tab 2: Association */}
        {activeTab === "association" && building?.admin && (
          <motion.div key="assoc" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.15 }} className="space-y-4">
            {/* Admin card (رئيس الاتحاد) */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="px-5 py-3 bg-[#0D9488]/5 border-b border-[#0D9488]/10 flex items-center justify-between">
                <div className="flex items-center gap-2"><Shield className="w-4 h-4 text-[#0D9488]" /><span className="text-sm text-[#1a1a2e]">اتحاد المُلاك</span></div>
                {!editingAdmin && <button onClick={startEditingAdmin} className="text-xs text-[#0D9488] hover:underline flex items-center gap-1"><Edit3 className="w-3 h-3" />تعديل</button>}
              </div>
              {editingAdmin ? (
                <div className="p-5 space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div><label className="block text-xs text-[#5f6b7a] mb-1">الاسم <span className="text-red-400">*</span></label><input type="text" value={adminName} onChange={(e) => setAdminName(e.target.value)} className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm" /></div>
                    <div><label className="block text-xs text-[#5f6b7a] mb-1">رقم الهاتف <span className="text-red-400">*</span></label><input type="tel" value={adminPhone} onChange={(e) => setAdminPhone(normalizeToEnglishDigits(e.target.value))} dir="ltr" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm text-left" /></div>
                    <div><label className="block text-xs text-[#5f6b7a] mb-1">البريد الإلكتروني</label><input type="email" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} dir="ltr" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm text-left" /></div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs text-[#5f6b7a] mb-1">الدور</label><select value={adminRole} onChange={(e) => setAdminRole(e.target.value)} className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] outline-none text-sm bg-white">{roleOptions.map((r) => <option key={r} value={r}>{r}</option>)}</select></div>
                      <div><label className="block text-xs text-[#5f6b7a] mb-1">الشقة</label><input type="text" value={adminUnit} onChange={(e) => setAdminUnit(e.target.value)} placeholder="301" className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] outline-none text-sm" /></div>
                    </div>
                  </div>
                  <div className="flex gap-2 justify-end">
                    <button onClick={() => setEditingAdmin(false)} className="px-4 py-2 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm hover:bg-gray-50">إلغاء</button>
                    <button onClick={handleUpdateAdmin} disabled={submitting || !adminName.trim() || !adminPhone.trim()} className="px-5 py-2 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 flex items-center gap-1.5 disabled:opacity-50">{submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}حفظ</button>
                  </div>
                </div>
              ) : (
                <div className="p-5">
                  {/* Admin (President) */}
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0" style={{ background: 'linear-gradient(135deg, #0D9488, #0d948899)' }}>
                      <Crown className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[#1a1a2e]">{building.admin.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#0D9488]/10 text-[#0D9488]">{building.admin.role}</span>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-[#5f6b7a]">
                        {building.admin.phone && <a href={`tel:${building.admin.phone}`} className="flex items-center gap-1 hover:text-[#0D9488] transition-colors"><Phone className="w-3 h-3" /><span dir="ltr">{building.admin.phone}</span></a>}
                        {building.admin.email && <a href={`mailto:${building.admin.email}`} className="flex items-center gap-1 hover:text-[#0D9488] transition-colors"><Mail className="w-3 h-3" /><span dir="ltr">{building.admin.email}</span></a>}
                        {building.admin.unitCode && <span className="flex items-center gap-1"><Home className="w-3 h-3" />شقة {building.admin.unitCode}</span>}
                      </div>
                    </div>
                  </div>

                  {/* Association Members (treasurer + board_member) */}
                  {associationMembers.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-gray-100 space-y-3">
                      {associationMembers.map((member) => {
                        const roleLabel = member.role === "treasurer" ? "أمين الصندوق" : "عضو اتحاد";
                        const roleColor = member.role === "treasurer" ? "#F59E0B" : "#6366f1";
                        const RoleIcon = member.role === "treasurer" ? KeyRound : Users;
                        return (
                          <div key={member.id} className="flex items-center gap-3">
                            <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${roleColor}15` }}>
                              <RoleIcon className="w-5 h-5" style={{ color: roleColor }} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-0.5">
                                <span className="text-sm text-[#1a1a2e] truncate">{member.title ? `${member.title} ${member.name}` : member.name}</span>
                                <span className="text-[10px] px-2 py-0.5 rounded-full shrink-0" style={{ backgroundColor: `${roleColor}15`, color: roleColor }}>{roleLabel}</span>
                              </div>
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-[#5f6b7a]">
                                {member.phone && <a href={`tel:${member.phone}`} className="flex items-center gap-1 hover:text-[#0D9488] transition-colors"><Phone className="w-2.5 h-2.5" /><span dir="ltr">{member.phone}</span></a>}
                                {member.unitCode && <span className="flex items-center gap-1"><Home className="w-2.5 h-2.5" />شقة {member.unitCode}</span>}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {associationMembers.length === 0 && (
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <p className="text-xs text-[#5f6b7a] text-center py-2">لا يوجد أعضاء اتحاد آخرين بعد. يمكنك تعيين الأدوار من صفحة المُلاك.</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Summary stats */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="bg-white rounded-xl border border-gray-100 px-3 py-2 flex items-center gap-2 shadow-sm">
                <Crown className="w-3.5 h-3.5 text-[#0D9488]" />
                <span className="text-xs text-[#5f6b7a]">رئيس الاتحاد:</span>
                <span className="text-xs text-[#1a1a2e]">1</span>
              </div>
              <div className="bg-white rounded-xl border border-gray-100 px-3 py-2 flex items-center gap-2 shadow-sm">
                <KeyRound className="w-3.5 h-3.5 text-[#F59E0B]" />
                <span className="text-xs text-[#5f6b7a]">أمين صندوق:</span>
                <span className="text-xs text-[#1a1a2e]">{associationMembers.filter(m => m.role === "treasurer").length}</span>
              </div>
              <div className="bg-white rounded-xl border border-gray-100 px-3 py-2 flex items-center gap-2 shadow-sm">
                <Users className="w-3.5 h-3.5 text-[#6366f1]" />
                <span className="text-xs text-[#5f6b7a]">أعضاء:</span>
                <span className="text-xs text-[#1a1a2e]">{associationMembers.filter(m => m.role === "board_member").length}</span>
              </div>
            </div>
          </motion.div>
        )}

        {/* Tab 3: Invite Link */}
        {activeTab === "invite" && (
          <motion.div key="invite" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.15 }}>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="px-5 py-3 bg-[#0D9488]/5 border-b border-[#0D9488]/10">
                <div className="flex items-center gap-2"><Link2 className="w-4 h-4 text-[#0D9488]" /><span className="text-sm text-[#1a1a2e]">رابط دعوة ال��ُلاك</span></div>
              </div>
              <div className="p-5 space-y-4">
                <div className="bg-[#f8fffe] rounded-xl border border-[#0D9488]/10 p-4">
                  <div className="text-xs text-[#5f6b7a] mb-2">رابط الانضمام</div>
                  <div className="text-sm text-[#0D9488] font-mono break-all" dir="ltr">{inviteLink}</div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button onClick={copyLink} className="flex items-center gap-1.5 px-4 py-2.5 bg-white border border-[#0D9488]/20 rounded-xl text-sm text-[#0D9488] hover:bg-[#0D9488]/5 transition-colors">
                    {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}{copied ? "تم النسخ" : "نسخ الرابط"}
                  </button>
                  <button onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(`انضم لـ${building?.name || ""} على مُلاك: ${inviteLink}`)}`, "_blank")} className="flex items-center gap-1.5 px-4 py-2.5 bg-[#25D366] text-white rounded-xl text-sm hover:bg-[#25D366]/90 transition-colors">
                    <Send className="w-4 h-4" />إرسال عبر واتساب
                  </button>
                  {building?.name === "برج الصفا" && (
                   <button onClick={() => building?.slug && navigate(`/join/${building.slug}`)} className="flex items-center gap-1.5 px-4 py-2.5 bg-[#F59E0B] text-white rounded-xl text-sm hover:bg-[#F59E0B]/90 transition-colors shadow-sm">
                     <ExternalLink className="w-4 h-4" />تجربة صفحة الدعوة
                   </button>
                  )}
                </div>
                <p className="text-[11px] text-[#5f6b7a] leading-relaxed">شارك هذا الرابط مع مُلاك الوحدات في البرج للانضمام لمنصة مُلاك. بمجرد تقديم طلب الانضمام ستتمكن من مراجعته وقبوله من قسم "طلبات الانضمام".</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Tab 4: Units */}
        {activeTab === "units" && (
          <motion.div key="units" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.15 }} className="space-y-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="bg-white rounded-xl border border-gray-100 px-3 py-2 flex items-center gap-2 shadow-sm"><Home className="w-3.5 h-3.5 text-[#6366f1]" /><span className="text-xs text-[#5f6b7a]">إجمالي:</span><span className="text-sm text-[#1a1a2e] font-semibold">{units.length}</span></div>
              <div className="bg-white rounded-xl border border-gray-100 px-3 py-2 flex items-center gap-2 shadow-sm"><Users className="w-3.5 h-3.5 text-[#0D9488]" /><span className="text-xs text-[#5f6b7a]">مشغولة:</span><span className="text-sm text-[#0D9488] font-semibold">{occupiedCount}</span></div>
              <div className="bg-white rounded-xl border border-gray-100 px-3 py-2 flex items-center gap-2 shadow-sm"><Home className="w-3.5 h-3.5 text-[#5f6b7a]" /><span className="text-xs text-[#5f6b7a]">فارغة:</span><span className="text-sm text-[#5f6b7a] font-semibold">{emptyCount}</span></div>
            </div>
            {sortedFloors.length > 0 ? sortedFloors.map((floorNum) => {
              const isEditing = editingFloor === floorNum;
              const floorOccupied = floorGroups[floorNum].filter(u => u.occupied).length;
              const floorLabel = floorLabelMap[floorNum] && floorLabelMap[floorNum] !== floorNum ? floorLabelMap[floorNum] : `الدور ${floorNum}`;
              return (
              <div key={floorNum} className={`bg-white rounded-2xl border shadow-sm transition-all ${isEditing ? "border-[#0D9488]/30 ring-2 ring-[#0D9488]/10" : "border-gray-100"}`}>
                {/* Floor header — clickable to expand/collapse */}
                <button
                  onClick={() => !isEditing && toggleFloor(floorNum)}
                  className="w-full flex items-center justify-between p-4 text-right"
                >
                  <h4 className="text-sm text-[#1a1a2e] flex items-center gap-2 flex-wrap">
                    <Building2 className="w-4 h-4 text-[#0D9488]" />{floorLabel}
                    <span className="text-[10px] text-[#5f6b7a] bg-gray-100 px-2 py-0.5 rounded-full">{floorGroups[floorNum].length} وحدة</span>
                    {floorGroups[floorNum][0]?.unitType === "تجاري" && <span className="text-[10px] text-[#F59E0B] bg-[#F59E0B]/10 px-2 py-0.5 rounded-full">تجاري</span>}
                    {floorOccupied > 0 && <span className="text-[10px] text-[#0D9488] bg-[#0D9488]/10 px-2 py-0.5 rounded-full">{floorOccupied} مشغولة</span>}
                  </h4>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {!isEditing && expandedFloors.has(floorNum) && (
                      <span
                        onClick={(e) => { e.stopPropagation(); startEditFloor(floorNum); }}
                        className="flex items-center gap-1 text-[11px] text-[#0D9488] hover:text-[#0D9488]/80 hover:bg-[#0D9488]/5 px-2.5 py-1.5 rounded-lg transition-colors"
                      >
                        <Edit3 className="w-3.5 h-3.5" />تعديل
                      </span>
                    )}
                    <ChevronDown
                      className={`w-4 h-4 text-[#5f6b7a] transition-transform duration-200 ${expandedFloors.has(floorNum) || isEditing ? "rotate-180" : ""}`}
                    />
                  </div>
                </button>

                {/* Collapsible content */}
                {(expandedFloors.has(floorNum) || isEditing) && (
                <div className="px-4 pb-4">
                {/* Inline Edit Panel */}
                {isEditing && (
                  <div className="bg-[#0D9488]/[0.03] border border-[#0D9488]/10 rounded-xl p-4 mb-4 space-y-4">
                    <div className="flex items-center gap-2 text-xs text-[#0D9488]">
                      <Edit3 className="w-3.5 h-3.5" />تعديل {floorLabel}
                    </div>

                    {/* Floor Label */}
                    <div>
                      <label className="block text-[11px] text-[#5f6b7a] mb-1">اسم الدور</label>
                      <input
                        type="text"
                        value={editFloorLabel}
                        onChange={(e) => setEditFloorLabel(e.target.value)}
                        placeholder="مثال: أرضي، ميزانين، الدور 1"
                        className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#0D9488]/10 outline-none text-sm transition-all"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      {/* Unit Type */}
                      <div>
                        <label className="block text-[11px] text-[#5f6b7a] mb-1">نوع الوحدات</label>
                        <button
                          onClick={() => setEditFloorType(prev => prev === "سكني" ? "تجاري" : "سكني")}
                          className={`w-full px-3 py-2.5 rounded-xl border text-sm transition-all ${
                            editFloorType === "تجاري"
                              ? "border-[#F59E0B]/30 bg-[#F59E0B]/10 text-[#F59E0B]"
                              : "border-[#0D9488]/30 bg-[#0D9488]/10 text-[#0D9488]"
                          }`}
                        >
                          {editFloorType === "تجاري" ? "🏪 تجاري" : "🏠 سكني"}
                        </button>
                      </div>

                      {/* Unit Count */}
                      <div>
                        <label className="block text-[11px] text-[#5f6b7a] mb-1">عدد الوحدات</label>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setEditFloorCount(prev => Math.max(floorOccupied || 1, prev - 1))}
                            className="w-10 h-10 rounded-xl border border-gray-200 flex items-center justify-center text-[#5f6b7a] hover:bg-gray-50 active:bg-gray-100 transition-colors shrink-0"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <input
                            type="number"
                            value={editFloorCount}
                            onChange={(e) => setEditFloorCount(Math.max(floorOccupied || 1, Math.min(50, parseInt(e.target.value) || 1)))}
                            className="flex-1 text-center px-2 py-2.5 rounded-xl border border-gray-200 focus:border-[#0D9488] outline-none text-sm min-w-0"
                          />
                          <button
                            onClick={() => setEditFloorCount(prev => Math.min(50, prev + 1))}
                            className="w-10 h-10 rounded-xl border border-gray-200 flex items-center justify-center text-[#5f6b7a] hover:bg-gray-50 active:bg-gray-100 transition-colors shrink-0"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Protected units warning */}
                    {floorOccupied > 0 && editFloorCount < floorGroups[floorNum].length && (
                      <div className="flex items-center gap-2 bg-[#F59E0B]/10 border border-[#F59E0B]/20 rounded-lg px-3 py-2 text-[11px] text-[#F59E0B]">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        {floorOccupied} وحدة مشغولة لن تُحذف — سيتم حذف الوحدات الفارغة فقط
                      </div>
                    )}

                    {/* Change summary */}
                    {(editFloorLabel !== floorLabel || editFloorType !== (floorGroups[floorNum][0]?.unitType || "سكني") || editFloorCount !== floorGroups[floorNum].length) && (
                      <div className="bg-white rounded-lg border border-gray-100 p-3 text-[11px] text-[#5f6b7a] space-y-1">
                        <div className="text-xs text-[#1a1a2e] mb-1">التغييرات:</div>
                        {editFloorLabel !== floorLabel && (
                          <div className="flex items-center gap-1">• الاسم: <span className="line-through text-red-300">{floorLabel}</span> → <span className="text-[#0D9488]">{editFloorLabel}</span></div>
                        )}
                        {editFloorType !== (floorGroups[floorNum][0]?.unitType || "سكني") && (
                          <div className="flex items-center gap-1">• النوع: <span className="line-through text-red-300">{floorGroups[floorNum][0]?.unitType || "سكني"}</span> → <span className="text-[#0D9488]">{editFloorType}</span></div>
                        )}
                        {editFloorCount !== floorGroups[floorNum].length && (
                          <div className="flex items-center gap-1">• العدد: <span className="line-through text-red-300">{floorGroups[floorNum].length}</span> → <span className="text-[#0D9488]">{editFloorCount}</span>
                            {editFloorCount > floorGroups[floorNum].length && <span className="text-[#0D9488]">(+{editFloorCount - floorGroups[floorNum].length})</span>}
                            {editFloorCount < floorGroups[floorNum].length && <span className="text-red-400">(-{floorGroups[floorNum].length - editFloorCount})</span>}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action buttons */}
                    <div className="flex gap-2">
                      <button onClick={cancelEditFloor} disabled={savingFloor} className="flex-1 py-2 rounded-lg border border-gray-200 text-[#5f6b7a] text-xs hover:bg-gray-50 transition-colors disabled:opacity-50">
                        إلغاء
                      </button>
                      <button
                        onClick={saveEditFloor}
                        disabled={savingFloor || (!editFloorLabel.trim())}
                        className="flex-1 py-2 rounded-lg bg-[#0D9488] text-white text-xs hover:bg-[#0D9488]/90 transition-all flex items-center justify-center gap-1.5 shadow-sm disabled:opacity-50"
                      >
                        {savingFloor ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />جاري الحفظ...</> : <><Save className="w-3.5 h-3.5" />حفظ التعديلات</>}
                      </button>
                    </div>
                  </div>
                )}

                {/* Unit cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2.5">
                  {floorGroups[floorNum].map((unit) => (
                    <div key={unit.id} className={`rounded-xl border p-3 text-center transition-all ${unit.occupied ? "border-[#0D9488]/20 bg-[#0D9488]/5" : unit.unitType === "تجاري" ? "border-[#F59E0B]/15 bg-[#F59E0B]/[0.03]" : "border-gray-100 bg-gray-50"}`}>
                      <div className="text-sm text-[#1a1a2e] mb-1">{unit.label}</div>
                      <div className="flex items-center justify-center gap-1 flex-wrap">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full ${unit.occupied ? "bg-[#0D9488]/10 text-[#0D9488]" : "bg-gray-200 text-[#5f6b7a]"}`}>{unit.occupied ? "مشغولة" : "فارغة"}</span>
                        {unit.unitType === "تجاري" && <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-[#F59E0B]/10 text-[#F59E0B]">تجاري</span>}
                      </div>
                      {unit.ownerName && <div className="text-[10px] text-[#5f6b7a] mt-1 truncate">{unit.ownerName}</div>}
                    </div>
                  ))}
                </div>
                </div>
                )}
              </div>
              );
            }) : (
              <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center text-sm text-[#5f6b7a]">
                <Loader2 className="w-6 h-6 text-[#0D9488] animate-spin mx-auto mb-2" />جاري تحميل الوحدات...
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}