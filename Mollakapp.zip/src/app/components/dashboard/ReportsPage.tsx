import { useState, useEffect, useRef } from "react";
import {
  FileText, Building2, Home, Loader2, RefreshCw, Send, Check, AlertTriangle,
  TrendingUp, TrendingDown, Minus, Search, ChevronDown, Download, Printer,
  ArrowUpRight, ArrowDownRight, X, BarChart3, PieChart, Receipt, Banknote,
  Heart, Users, Calendar, Clock,
  ClipboardList, Filter
} from "lucide-react";
import { PieChart as RechartPie, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import * as api from "../../lib/api";

const MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
const COLORS = ["#0D9488", "#F59E0B", "#6366f1", "#ec4899", "#22c55e", "#f97316", "#8b5cf6", "#14b8a6", "#ef4444", "#3b82f6"];

type Tab = "building" | "units" | "ledger";

function fmt(n: number) { return n.toLocaleString("en-US"); }

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    paid: { label: "مدفوعة", cls: "bg-[#0D9488]/10 text-[#0D9488]" },
    pending: { label: "معلقة", cls: "bg-[#F59E0B]/10 text-[#F59E0B]" },
    overdue: { label: "متأخرة", cls: "bg-red-50 text-red-500" },
    awaiting_collection: { label: "بانتظار التحصيل", cls: "bg-purple-50 text-purple-500" },
  };
  const s = map[status] || { label: status, cls: "bg-gray-100 text-gray-500" };
  return <span className={`text-[10px] px-2 py-0.5 rounded-full ${s.cls}`}>{s.label}</span>;
}

export function ReportsPage() {
  const [tab, setTab] = useState<Tab>("building");
  const [report, setReport] = useState<api.FullReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [sending, setSending] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth()); // 0-based
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [unitSearch, setUnitSearch] = useState("");
  const [expandedUnit, setExpandedUnit] = useState<string | null>(null);
  const [showMonthPicker, setShowMonthPicker] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  // Auto-load: on mount, load CURRENT month's report (always fresh)
  useEffect(() => {
    const now = new Date();
    const curMonth = now.getMonth(); // 0-based
    const curYear = now.getFullYear();
    setSelectedMonth(curMonth);
    setSelectedYear(curYear);
    loadReport(curYear, curMonth + 1);
  }, []);

  const loadReport = async (year: number, month: number) => {
    setLoading(true);
    setErrorMsg("");
    try {
      // For current month: always regenerate (data still changing)
      // For past months: use generate (with server-side cache)
      const now = new Date();
      const isCurrentMonth = year === now.getFullYear() && month === now.getMonth() + 1;
      let result;
      if (isCurrentMonth) {
        result = await api.regenerateReport(year, month);
      } else {
        result = await api.generateReport(year, month);
        // If cached report has all zeros, try regenerating fresh
        if (result.cached && result.report?.building?.totalRevenue === 0 && result.report?.building?.totalExpenses === 0 && result.report?.building?.totalInvoices === 0) {
          result = await api.regenerateReport(year, month);
        }
      }
      setReport(result.report);
    } catch (err: any) {
      console.error("Error loading report:", err);
      setErrorMsg(err.message || "حدث خطأ أثناء تحميل التقرير");
    } finally {
      setLoading(false);
    }
  };

  const handleRegenerate = async () => {
    if (!report) return;
    setGenerating(true);
    setErrorMsg("");
    try {
      const result = await api.regenerateReport(report.year, report.month);
      setReport(result.report);
      showSucc("تم تحديث التقرير بنجاح");
    } catch (err: any) {
      setErrorMsg(err.message || "حدث خطأ أثناء تحديث التقرير");
    } finally {
      setGenerating(false);
    }
  };

  const handleSend = async () => {
    if (!report) return;
    setSending(true);
    try {
      const result = await api.sendReportToResidents(report.id);
      setReport(result.report);
      showSucc(result.message);
    } catch (err: any) {
      setErrorMsg(err.message || "حدث خطأ أثناء إرسال التقرير");
    } finally {
      setSending(false);
    }
  };

  const handleMonthSelect = (monthIdx: number) => {
    setSelectedMonth(monthIdx);
    setShowMonthPicker(false);
    loadReport(selectedYear, monthIdx + 1);
  };

  const handlePrint = () => {
    window.print();
  };

  const showSucc = (msg: string) => { setSuccessMsg(msg); setTimeout(() => setSuccessMsg(""), 3000); };

  const b = report?.building;

  // Filter units
  const filteredUnits = (report?.unitReports || []).filter(u =>
    !unitSearch || u.unitCode.includes(unitSearch) || u.residentName.includes(unitSearch)
  );

  // Pie chart data for expenses
  const expPieData = b ? Object.entries(b.expensesByCategory).map(([name, value]) => ({ name, value })) : [];
  const revPieData = b ? Object.entries(b.revenuesByCategory).map(([name, value]) => ({ name, value })) : [];

  // Collection bar data
  const collectionBarData = b ? [
    { name: "مدفوعة", value: b.paidCount, fill: "#0D9488" },
    { name: "معلقة", value: b.pendingCount, fill: "#F59E0B" },
    { name: "متأخرة", value: b.overdueCount, fill: "#ef4444" },
  ] : [];

  return (
    <div className="max-w-6xl mx-auto print:max-w-full" dir="rtl">
      {/* Print styles */}
      <style>{`
        @media print {
          body * { visibility: hidden; }
          .print-area, .print-area * { visibility: visible; }
          .print-area { position: absolute; left: 0; top: 0; width: 100%; padding: 20px; }
          .no-print { display: none !important; }
          .print-break { page-break-before: always; }
        }
      `}</style>

      {/* Toasts */}
      {successMsg && (
        <div className="mb-4 bg-[#0D9488]/10 border border-[#0D9488]/20 text-[#0D9488] px-4 py-3 rounded-2xl text-sm flex items-center gap-2 no-print">
          <Check className="w-4 h-4 shrink-0" />{successMsg}
        </div>
      )}
      {errorMsg && (
        <div className="mb-4 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-2xl text-sm flex items-center gap-2 no-print">
          <AlertTriangle className="w-4 h-4 shrink-0" />{errorMsg}
          <button onClick={() => setErrorMsg("")} className="mr-auto"><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      {/* Header with month selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 no-print">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-[#0D9488]/10 rounded-xl flex items-center justify-center">
            <BarChart3 className="w-5.5 h-5.5 text-[#0D9488]" />
          </div>
          <div>
            <h2 className="text-lg text-[#1a1a2e]">التقارير</h2>
            <p className="text-xs text-[#5f6b7a]">تقرير {MONTHS[selectedMonth]} {selectedYear}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Month Picker */}
          <div className="relative">
            <button
              onClick={() => setShowMonthPicker(!showMonthPicker)}
              className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm text-[#1a1a2e] hover:border-[#0D9488]/30 transition-all"
            >
              <Calendar className="w-4 h-4 text-[#5f6b7a]" />
              {MONTHS[selectedMonth]} {selectedYear}
              <ChevronDown className="w-3.5 h-3.5 text-[#5f6b7a]" />
            </button>

            {showMonthPicker && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setShowMonthPicker(false)} />
                <div className="absolute left-0 sm:right-0 sm:left-auto top-12 bg-white border border-gray-200 rounded-2xl shadow-xl z-20 p-4 w-72">
                  <div className="flex items-center justify-between mb-3">
                    <button onClick={() => setSelectedYear(y => y - 1)} className="text-xs text-[#5f6b7a] hover:text-[#0D9488] px-2 py-1 rounded-lg hover:bg-[#0D9488]/5">
                      &larr; {selectedYear - 1}
                    </button>
                    <span className="text-sm text-[#1a1a2e] font-medium">{selectedYear}</span>
                    <button onClick={() => setSelectedYear(y => y + 1)} className="text-xs text-[#5f6b7a] hover:text-[#0D9488] px-2 py-1 rounded-lg hover:bg-[#0D9488]/5">
                      {selectedYear + 1} &rarr;
                    </button>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {MONTHS.map((m, i) => (
                      <button
                        key={i}
                        onClick={() => handleMonthSelect(i)}
                        className={`py-2 rounded-xl text-xs transition-all ${
                          i === selectedMonth
                            ? "bg-[#0D9488] text-white"
                            : "text-[#5f6b7a] hover:bg-[#0D9488]/5 hover:text-[#0D9488]"
                        }`}
                      >
                        {m}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          {report && (
            <>
              <button onClick={handleRegenerate} disabled={generating} className="flex items-center gap-1.5 px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-xs text-[#5f6b7a] hover:border-[#0D9488]/30 hover:text-[#0D9488] transition-all disabled:opacity-50">
                {generating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                تحديث
              </button>
              <button onClick={handlePrint} className="flex items-center gap-1.5 px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-xs text-[#5f6b7a] hover:border-[#0D9488]/30 hover:text-[#0D9488] transition-all">
                <Printer className="w-3.5 h-3.5" />
                طباعة / PDF
              </button>
              {!report.sentToResidents ? (
                <button onClick={handleSend} disabled={sending} className="flex items-center gap-1.5 px-4 py-2.5 bg-[#0D9488] text-white rounded-xl text-xs hover:bg-[#0D9488]/90 transition-all shadow-sm disabled:opacity-50">
                  {sending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  إرسال للسكان
                </button>
              ) : (
                <span className="flex items-center gap-1.5 px-4 py-2.5 bg-[#0D9488]/10 text-[#0D9488] rounded-xl text-xs">
                  <Check className="w-3.5 h-3.5" />
                  تم الإرسال
                </span>
              )}
            </>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 rounded-xl p-1 mb-5 no-print">
        <button
          onClick={() => setTab("building")}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm transition-all ${
            tab === "building" ? "bg-white text-[#0D9488] shadow-sm" : "text-[#5f6b7a] hover:text-[#0D9488]"
          }`}
        >
          <Building2 className="w-4 h-4" />
          تقرير المبنى
        </button>
        <button
          onClick={() => setTab("units")}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm transition-all ${
            tab === "units" ? "bg-white text-[#0D9488] shadow-sm" : "text-[#5f6b7a] hover:text-[#0D9488]"
          }`}
        >
          <Home className="w-4 h-4" />
          تقارير الوحدات
        </button>
        <button
          onClick={() => setTab("ledger")}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm transition-all ${
            tab === "ledger" ? "bg-white text-[#0D9488] shadow-sm" : "text-[#5f6b7a] hover:text-[#0D9488]"
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          دفتر الأرصدة
        </button>
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-20">
          <div className="text-center">
            <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin mx-auto mb-3" />
            <p className="text-sm text-[#5f6b7a]">جاري إنشاء التقرير...</p>
          </div>
        </div>
      )}

      {/* Content */}
      {!loading && report && (
        <div ref={printRef} className="print-area">
          {/* Print header (hidden on screen) */}
          <div className="hidden print:block mb-6 text-center border-b-2 border-[#0D9488] pb-4">
            <h1 className="text-xl font-bold text-[#1a1a2e]">مُلاك — {b?.name}</h1>
            <p className="text-sm text-[#5f6b7a]">تقرير {report.monthName} {report.year}</p>
            {b?.address && <p className="text-xs text-[#5f6b7a]">{b.address}{b.city ? ` — ${b.city}` : ""}</p>}
          </div>

          {tab === "building" && b && <BuildingTab b={b} expPieData={expPieData} revPieData={revPieData} collectionBarData={collectionBarData} report={report} />}
          {tab === "units" && <UnitsTab units={filteredUnits} unitSearch={unitSearch} setUnitSearch={setUnitSearch} expandedUnit={expandedUnit} setExpandedUnit={setExpandedUnit} report={report} />}
          {tab === "ledger" && b && <LedgerTab b={b} report={report} />}
        </div>
      )}

      {!loading && !report && !errorMsg && (
        <div className="text-center py-20">
          <FileText className="w-12 h-12 text-[#5f6b7a]/30 mx-auto mb-4" />
          <p className="text-sm text-[#5f6b7a] mb-4">لا يوجد تقرير لهذا الشهر بعد</p>
          <button
            onClick={() => loadReport(selectedYear, selectedMonth + 1)}
            className="px-6 py-3 bg-[#0D9488] text-white rounded-xl text-sm hover:bg-[#0D9488]/90 transition-all shadow-sm"
          >
            إنشاء تقرير {MONTHS[selectedMonth]} {selectedYear}
          </button>
        </div>
      )}
    </div>
  );
}

// ── Building Tab ──
function BuildingTab({ b, expPieData, revPieData, collectionBarData, report }: {
  b: api.BuildingReport;
  expPieData: { name: string; value: number }[];
  revPieData: { name: string; value: number }[];
  collectionBarData: { name: string; value: number; fill: string }[];
  report: api.FullReport;
}) {
  return (
    <div className="space-y-5">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <SummaryCard icon={TrendingUp} label="إجمالي الإيرادات" value={fmt(b.totalRevenue)} suffix="ج.م" color="#0D9488" subtitle={`داخلي: ${fmt(b.invoiceRevenue)} · خارجي: ${fmt(b.otherRevenue)}`} />
        <SummaryCard icon={Receipt} label="إجمالي المصروفات" value={fmt(b.totalExpenses)} suffix="ج.م" color="#ef4444" />
        <SummaryCard icon={Banknote} label="صافي الرصيد" value={fmt(b.netBalance)} suffix="ج.م" color={b.netBalance >= 0 ? "#0D9488" : "#ef4444"} />
        <SummaryCard icon={Users} label="نسبة التحصيل" value={`${b.collectionRate}%`} suffix={`${b.paidCount} من ${b.totalInvoices}`} color="#F59E0B" />
      </div>

      {/* Comparison with previous month */}
      {b.comparison.hasPrev && (
        <div className="bg-white rounded-2xl border border-gray-100 p-4">
          <h3 className="text-sm text-[#1a1a2e] mb-3 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-[#0D9488]" />
            مقارنة بالشهر السابق
          </h3>
          <div className="grid grid-cols-3 gap-3">
            <CompareItem label="الإيرادات" diff={b.comparison.revenueDiff} suffix="ج.م" />
            <CompareItem label="المصروفات" diff={b.comparison.expensesDiff} suffix="ج.م" inverted />
            <CompareItem label="التحصيل" diff={b.comparison.collectionRateDiff} suffix="%" />
          </div>
        </div>
      )}

      {/* Revenue breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl border border-gray-100 p-4">
          <h3 className="text-sm text-[#1a1a2e] mb-1 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#0D9488]" />
            تفاصيل الإيرادات الخارجية
          </h3>
          <p className="text-[10px] text-[#5f6b7a] mb-3">إيراد داخلي (فواتير): {fmt(b.invoiceRevenue)} ج.م · إيراد خارجي: {fmt(b.otherRevenue)} ج.م</p>
          {revPieData.length > 0 ? (
            <div className="flex items-center gap-4">
              <div className="w-[120px] h-[120px] shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartPie>
                    <Pie data={revPieData} cx="50%" cy="50%" outerRadius={55} dataKey="value" stroke="none">
                      {revPieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip formatter={(v: number) => `${fmt(v)} ج.م`} />
                  </RechartPie>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 space-y-1.5">
                {revPieData.map((item, i) => (
                  <div key={i} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                      <span className="text-[#5f6b7a]">{item.name}</span>
                    </div>
                    <span className="text-[#1a1a2e]">{fmt(item.value)}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : <p className="text-xs text-[#5f6b7a] text-center py-6">لا توجد إيرادات خارجية</p>}
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 p-4">
          <h3 className="text-sm text-[#1a1a2e] mb-1 flex items-center gap-2">
            <Receipt className="w-4 h-4 text-[#ef4444]" />
            تفاصيل المصروفات
          </h3>
          <p className="text-[10px] text-[#5f6b7a] mb-3">إجمالي: {fmt(b.totalExpenses)} ج.م · {b.expensesList.length} بند</p>
          {expPieData.length > 0 ? (
            <div className="flex items-center gap-4">
              <div className="w-[120px] h-[120px] shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartPie>
                    <Pie data={expPieData} cx="50%" cy="50%" outerRadius={55} dataKey="value" stroke="none">
                      {expPieData.map((_, i) => <Cell key={i} fill={COLORS[(i + 3) % COLORS.length]} />)}
                    </Pie>
                    <Tooltip formatter={(v: number) => `${fmt(v)} ج.م`} />
                  </RechartPie>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 space-y-1.5">
                {expPieData.map((item, i) => (
                  <div key={i} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[(i + 3) % COLORS.length] }} />
                      <span className="text-[#5f6b7a]">{item.name}</span>
                    </div>
                    <span className="text-[#1a1a2e]">{fmt(item.value)}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : <p className="text-xs text-[#5f6b7a] text-center py-6">لا توجد مصروفات</p>}
        </div>
      </div>

      {/* Collection chart */}
      {b.totalInvoices > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-4">
          <h3 className="text-sm text-[#1a1a2e] mb-3 flex items-center gap-2">
            <PieChart className="w-4 h-4 text-[#F59E0B]" />
            حالة التحصيل — {b.totalInvoices} فاتورة
          </h3>
          <div className="h-[160px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={collectionBarData} layout="vertical" barSize={24}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={60} />
                <Tooltip formatter={(v: number) => `${v} فاتورة`} />
                <Bar dataKey="value" radius={[0, 8, 8, 0]}>
                  {collectionBarData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Advances */}
      {b.advancesList.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-4">
          <h3 className="text-sm text-[#1a1a2e] mb-3 flex items-center gap-2">
            <Banknote className="w-4 h-4 text-[#6366f1]" />
            السُلف النشطة ({b.activeAdvancesCount}) — {fmt(b.activeAdvances)} ج.م
          </h3>
          <div className="space-y-2">
            {b.advancesList.map((adv, i) => (
              <div key={i} className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-xl text-xs">
                <div>
                  <span className="text-[#1a1a2e]">{adv.person}</span>
                  <span className="text-[#5f6b7a] mr-2">— {adv.reason}</span>
                </div>
                <div className="text-left">
                  <span className="text-[#1a1a2e]">{fmt(adv.amount)} ج.م</span>
                  <span className={`mr-2 text-[10px] px-2 py-0.5 rounded-full ${adv.status === "overdue" ? "bg-red-50 text-red-500" : "bg-[#F59E0B]/10 text-[#F59E0B]"}`}>
                    {adv.status === "overdue" ? "متأخرة" : "نشطة"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Delinquent units */}
      {b.delinquentUnits.length > 0 && (
        <div className="bg-white rounded-2xl border border-red-100 p-4">
          <h3 className="text-sm text-[#1a1a2e] mb-3 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-500" />
            المتأخرون عن السداد ({b.delinquentUnits.length})
          </h3>
          <div className="space-y-2">
            {b.delinquentUnits.map((unit, i) => (
              <div key={i} className="flex items-center justify-between py-2 px-3 bg-red-50/50 rounded-xl text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center text-red-500 text-[10px] font-bold">{unit.unitCode}</span>
                  <span className="text-[#1a1a2e]">{unit.residentName}</span>
                </div>
                <span className="text-red-500 font-medium">{fmt(unit.amount)} ج.م</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Donations */}
      {b.totalDonations > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-4">
          <div className="flex items-center gap-2">
            <Heart className="w-4 h-4 text-[#ec4899]" />
            <span className="text-sm text-[#1a1a2e]">إجمالي التبرعات:</span>
            <span className="text-sm text-[#0D9488] font-medium">{fmt(b.totalDonations)} ج.م</span>
          </div>
        </div>
      )}

      {/* Generation info */}
      <div className="text-center text-[10px] text-[#5f6b7a] flex items-center justify-center gap-1.5 pb-2">
        <Clock className="w-3 h-3" />
        تم إنشاء التقرير: {new Date(report.generatedAt).toLocaleDateString("ar-u-nu-latn", { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" })}
      </div>
    </div>
  );
}

// ── Units Tab ──
function UnitsTab({ units, unitSearch, setUnitSearch, expandedUnit, setExpandedUnit, report }: {
  units: api.UnitReport[];
  unitSearch: string;
  setUnitSearch: (s: string) => void;
  expandedUnit: string | null;
  setExpandedUnit: (s: string | null) => void;
  report: api.FullReport;
}) {
  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="relative no-print">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" />
        <input
          type="text"
          value={unitSearch}
          onChange={e => setUnitSearch(e.target.value)}
          placeholder="بحث بالشقة أو اسم الساكن..."
          className="w-full pr-10 pl-4 py-3 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 focus:border-[#0D9488]/30"
        />
      </div>

      {/* Summary */}
      <div className="bg-[#0D9488]/5 rounded-2xl p-4 text-center">
        <p className="text-sm text-[#1a1a2e]">
          تقرير {report.monthName} {report.year} — <span className="text-[#0D9488] font-medium">{units.length}</span> وحدة سكنية
        </p>
      </div>

      {/* Units list */}
      {units.length === 0 ? (
        <div className="text-center py-12">
          <Home className="w-10 h-10 text-[#5f6b7a]/20 mx-auto mb-3" />
          <p className="text-sm text-[#5f6b7a]">لا توجد بيانات لهذا الشهر</p>
        </div>
      ) : (
        <div className="space-y-3">
          {units.map(unit => {
            const isExpanded = expandedUnit === unit.unitCode;
            const payRate = unit.totalDue > 0 ? Math.round((unit.totalPaid / unit.totalDue) * 100) : 0;
            const hasIssues = unit.totalOverdue > 0 || unit.totalPending > 0;

            return (
              <div key={unit.unitCode} className={`bg-white rounded-2xl border ${hasIssues ? "border-red-100" : "border-gray-100"} overflow-hidden`}>
                <button
                  onClick={() => setExpandedUnit(isExpanded ? null : unit.unitCode)}
                  className="w-full p-4 flex items-center gap-3 hover:bg-gray-50/50 transition-colors"
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold ${
                    hasIssues ? "bg-red-50 text-red-500" : "bg-[#0D9488]/10 text-[#0D9488]"
                  }`}>
                    {unit.unitCode}
                  </div>
                  <div className="flex-1 text-right">
                    <div className="text-sm text-[#1a1a2e]">{unit.residentName}</div>
                    <div className="text-[10px] text-[#5f6b7a]">
                      الدور {unit.floor} · {unit.invoices.length} فاتورة · سداد {payRate}%
                    </div>
                  </div>
                  <div className="text-left">
                    {unit.totalPaid > 0 && <div className="text-xs text-[#0D9488]">{fmt(unit.totalPaid)} مدفوع</div>}
                    {(unit.totalPending + unit.totalOverdue) > 0 && (
                      <div className="text-xs text-red-500">{fmt(unit.totalPending + unit.totalOverdue)} متبقي</div>
                    )}
                  </div>
                  <ChevronDown className={`w-4 h-4 text-[#5f6b7a] transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                </button>

                {isExpanded && (
                  <div className="px-4 pb-4 border-t border-gray-50">
                    {/* Unit summary cards */}
                    <div className="grid grid-cols-4 gap-2 py-3">
                      <div className="bg-[#f8fffe] rounded-xl p-2.5 text-center">
                        <div className="text-[9px] text-[#5f6b7a]">المطلوب</div>
                        <div className="text-xs text-[#1a1a2e] font-medium">{fmt(unit.totalDue)}</div>
                      </div>
                      <div className="bg-[#f8fffe] rounded-xl p-2.5 text-center">
                        <div className="text-[9px] text-[#5f6b7a]">المدفوع</div>
                        <div className="text-xs text-[#0D9488] font-medium">{fmt(unit.totalPaid)}</div>
                      </div>
                      <div className="bg-[#f8fffe] rounded-xl p-2.5 text-center">
                        <div className="text-[9px] text-[#5f6b7a]">المتبقي</div>
                        <div className={`text-xs font-medium ${(unit.totalPending + unit.totalOverdue) > 0 ? "text-red-500" : "text-[#0D9488]"}`}>
                          {fmt(unit.totalPending + unit.totalOverdue)}
                        </div>
                      </div>
                      <div className="bg-[#f8fffe] rounded-xl p-2.5 text-center">
                        <div className="text-[9px] text-[#5f6b7a]">التبرعات</div>
                        <div className="text-xs text-[#ec4899] font-medium">{fmt(unit.donations)}</div>
                      </div>
                    </div>

                    {/* Payment rate bar */}
                    <div className="mb-3">
                      <div className="flex items-center justify-between text-[10px] text-[#5f6b7a] mb-1">
                        <span>نسبة السداد</span>
                        <span>{payRate}%</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full transition-all ${payRate >= 75 ? "bg-[#0D9488]" : payRate >= 50 ? "bg-[#F59E0B]" : "bg-red-400"}`}
                          style={{ width: `${payRate}%` }} />
                      </div>
                    </div>

                    {/* Invoices table */}
                    <div className="space-y-1.5">
                      {unit.invoices.map((inv, i) => (
                        <div key={i} className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-xl text-xs">
                          <div className="flex-1 min-w-0">
                            <span className="text-[#1a1a2e]">{inv.description}</span>
                            <span className="text-[10px] text-[#5f6b7a] mr-2">
                              {inv.paidDate ? `دُفعت ${new Date(inv.paidDate).toLocaleDateString("ar-u-nu-latn", { month: "short", day: "numeric" })}` : `استحقاق ${new Date(inv.dueDate).toLocaleDateString("ar-u-nu-latn", { month: "short", day: "numeric" })}`}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[#1a1a2e]">{fmt(inv.amount)} ج.م</span>
                            <StatusBadge status={inv.status} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Ledger Tab ──
function LedgerTab({ b, report }: { b: api.BuildingReport; report: api.FullReport }) {
  const [filterType, setFilterType] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  type LedgerEntry = { id: string; date: string; type: string; typeBadge: string; typeColor: string; description: string; category: string; amount: number; direction: "in" | "out"; details?: string };

  const entries: LedgerEntry[] = (() => {
    const rows: LedgerEntry[] = [];
    // Expenses
    for (const [i, exp] of b.expensesList.entries()) {
      rows.push({ id: `exp-${i}`, date: exp.date || "", type: "expense", typeBadge: "مصروف", typeColor: "bg-red-50 text-red-500", description: exp.title, category: exp.category, amount: exp.amount, direction: "out", details: exp.type === "دائم" ? "متكرر" : "" });
    }
    // Other revenues
    for (const [i, rev] of b.revenuesList.entries()) {
      rows.push({ id: `rev-${i}`, date: rev.date || "", type: "revenue", typeBadge: "إيراد خارجي", typeColor: "bg-[#0D9488]/10 text-[#0D9488]", description: rev.title, category: rev.category, amount: rev.amount, direction: "in", details: rev.type === "دائم" ? "متكرر" : "" });
    }
    // Invoice collections from units
    for (const unit of report.unitReports) {
      for (const [j, inv] of unit.invoices.entries()) {
        const statusMap: Record<string, { badge: string; color: string }> = {
          paid: { badge: "إيراد داخلي", color: "bg-[#0D9488]/10 text-[#0D9488]" },
          pending: { badge: "فاتورة معلقة", color: "bg-[#F59E0B]/10 text-[#F59E0B]" },
          overdue: { badge: "فاتورة متأخرة", color: "bg-red-50 text-red-500" },
          awaiting_collection: { badge: "بانتظار التحصيل", color: "bg-purple-50 text-purple-500" },
        };
        const s = statusMap[inv.status] || { badge: inv.status, color: "bg-gray-100 text-gray-500" };
        rows.push({ id: `inv-${unit.unitCode}-${j}`, date: inv.paidDate || inv.dueDate || "", type: inv.status === "paid" ? "collection" : "invoice", typeBadge: s.badge, typeColor: s.color, description: inv.description, category: `شقة ${unit.unitCode}`, amount: inv.amount, direction: inv.status === "paid" ? "in" : "out", details: unit.residentName });
      }
    }
    // Advances
    for (const [i, adv] of b.advancesList.entries()) {
      rows.push({ id: `adv-${i}`, date: adv.dueDate || "", type: "advance", typeBadge: "سُلفة", typeColor: "bg-[#6366f1]/10 text-[#6366f1]", description: adv.reason, category: adv.person, amount: adv.amount, direction: "out", details: adv.status === "overdue" ? "متأخرة" : "نشطة" });
    }
    // Sort by date descending
    rows.sort((a, bb) => { const da = new Date(a.date).getTime() || 0; const db = new Date(bb.date).getTime() || 0; return db - da; });
    return rows;
  })();

  const filterOptions = [
    { value: "all", label: "الكل", count: entries.length },
    { value: "expense", label: "مصروفات", count: entries.filter(e => e.type === "expense").length },
    { value: "revenue", label: "إيرادات خارجية", count: entries.filter(e => e.type === "revenue").length },
    { value: "collection", label: "إيرادات داخلية", count: entries.filter(e => e.type === "collection").length },
    { value: "invoice", label: "فواتير معلقة", count: entries.filter(e => e.type === "invoice").length },
    { value: "advance", label: "سُلف", count: entries.filter(e => e.type === "advance").length },
  ];

  const filtered = entries.filter(e => {
    if (filterType !== "all" && e.type !== filterType) return false;
    if (searchTerm && !e.description.includes(searchTerm) && !e.category.includes(searchTerm) && !(e.details || "").includes(searchTerm)) return false;
    return true;
  });

  const totalIn = filtered.filter(e => e.direction === "in").reduce((s, e) => s + e.amount, 0);
  const totalOut = filtered.filter(e => e.direction === "out").reduce((s, e) => s + e.amount, 0);

  return (
    <div className="space-y-4">
      {/* Summary bar */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white rounded-2xl border border-gray-100 p-3 text-center">
          <div className="text-[10px] text-[#5f6b7a]">إجمالي الوارد</div>
          <div className="text-base font-bold text-[#0D9488]">{fmt(totalIn)}</div>
          <div className="text-[10px] text-[#5f6b7a]">ج.م</div>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 p-3 text-center">
          <div className="text-[10px] text-[#5f6b7a]">إجمالي الصادر</div>
          <div className="text-base font-bold text-red-500">{fmt(totalOut)}</div>
          <div className="text-[10px] text-[#5f6b7a]">ج.م</div>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 p-3 text-center">
          <div className="text-[10px] text-[#5f6b7a]">الصافي</div>
          <div className={`text-base font-bold ${totalIn - totalOut >= 0 ? "text-[#0D9488]" : "text-red-500"}`}>{fmt(totalIn - totalOut)}</div>
          <div className="text-[10px] text-[#5f6b7a]">ج.م</div>
        </div>
      </div>

      {/* Filter chips + search */}
      <div className="no-print space-y-3">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" />
          <input type="text" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="بحث في السجل..." className="w-full pr-10 pl-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 focus:border-[#0D9488]/30" />
        </div>
        <div className="flex gap-2 flex-wrap">
          {filterOptions.filter(f => f.count > 0).map(f => (
            <button key={f.value} onClick={() => setFilterType(f.value)} className={`px-3 py-1.5 rounded-lg text-xs transition-all ${filterType === f.value ? "bg-[#0D9488] text-white" : "bg-white border border-gray-200 text-[#5f6b7a] hover:border-[#0D9488]/30"}`}>
              {f.label} <span className="opacity-70">({f.count.toLocaleString("en-US")})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Table header (desktop) */}
      <div className="hidden sm:flex items-center gap-3 px-4 py-2 bg-gray-50 rounded-xl text-[10px] text-[#5f6b7a] font-medium">
        <div className="w-20">التاريخ</div>
        <div className="w-28">النوع</div>
        <div className="flex-1">البيان</div>
        <div className="w-28">الفئة / الوحدة</div>
        <div className="w-24 text-left">المبلغ</div>
      </div>

      {/* Rows */}
      {filtered.length === 0 ? (
        <div className="text-center py-12">
          <ClipboardList className="w-10 h-10 text-[#5f6b7a]/20 mx-auto mb-3" />
          <p className="text-sm text-[#5f6b7a]">لا توجد حركات في هذا الشهر</p>
        </div>
      ) : (
        <div className="space-y-1.5">
          {filtered.map(entry => (
            <div key={entry.id} className={`flex flex-col sm:flex-row sm:items-center gap-1.5 sm:gap-3 px-4 py-3 bg-white rounded-xl border border-gray-100 hover:border-[#0D9488]/10 transition-colors ${entry.direction === "in" ? "border-r-2 border-r-[#0D9488]" : "border-r-2 border-r-red-300"}`}>
              {/* Date */}
              <div className="text-[10px] text-[#5f6b7a] w-20 shrink-0">
                {entry.date ? new Date(entry.date).toLocaleDateString("ar-u-nu-latn", { month: "short", day: "numeric" }) : "—"}
              </div>
              {/* Type badge */}
              <div className="w-28 shrink-0">
                <span className={`text-[10px] px-2.5 py-1 rounded-full ${entry.typeColor}`}>{entry.typeBadge}</span>
              </div>
              {/* Description */}
              <div className="flex-1 min-w-0">
                <div className="text-xs text-[#1a1a2e] truncate">{entry.description}</div>
                {entry.details && <div className="text-[10px] text-[#5f6b7a] truncate">{entry.details}</div>}
              </div>
              {/* Category */}
              <div className="w-28 shrink-0 text-[10px] text-[#5f6b7a] truncate">{entry.category}</div>
              {/* Amount */}
              <div className={`w-24 text-left text-xs font-medium shrink-0 ${entry.direction === "in" ? "text-[#0D9488]" : "text-red-500"}`}>
                {entry.direction === "in" ? "+" : "-"}{fmt(entry.amount)} <span className="text-[10px] font-normal">ج.م</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Footer total */}
      {filtered.length > 0 && (
        <div className="bg-[#0D9488]/5 rounded-2xl p-3 flex items-center justify-between text-xs">
          <span className="text-[#5f6b7a]">إجمالي {filtered.length.toLocaleString("en-US")} حركة — {report.monthName} {report.year}</span>
          <span className={`font-medium ${totalIn - totalOut >= 0 ? "text-[#0D9488]" : "text-red-500"}`}>صافي: {fmt(totalIn - totalOut)} ج.م</span>
        </div>
      )}
    </div>
  );
}

// ── Helper Components ──
function SummaryCard({ icon: Icon, label, value, suffix, color, subtitle }: {
  icon: typeof TrendingUp;
  label: string;
  value: string;
  suffix: string;
  color: string;
  subtitle?: string;
}) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-4">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${color}15` }}>
          <Icon className="w-4 h-4" style={{ color }} />
        </div>
        <span className="text-[10px] text-[#5f6b7a]">{label}</span>
      </div>
      <div className="text-lg font-bold text-[#1a1a2e]">{value}</div>
      <div className="text-[10px] text-[#5f6b7a]">{suffix}</div>
      {subtitle && <div className="text-[9px] text-[#5f6b7a] mt-0.5">{subtitle}</div>}
    </div>
  );
}

function CompareItem({ label, diff, suffix, inverted }: { label: string; diff: number; suffix: string; inverted?: boolean }) {
  const isPositive = inverted ? diff < 0 : diff > 0;
  const isNeutral = diff === 0;
  return (
    <div className="text-center bg-gray-50 rounded-xl p-3">
      <div className="text-[10px] text-[#5f6b7a] mb-1">{label}</div>
      <div className={`flex items-center justify-center gap-1 text-sm font-medium ${isNeutral ? "text-[#5f6b7a]" : isPositive ? "text-[#0D9488]" : "text-red-500"}`}>
        {isNeutral ? <Minus className="w-3.5 h-3.5" /> : isPositive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
        {diff > 0 ? "+" : ""}{fmt(diff)} {suffix}
      </div>
    </div>
  );
}