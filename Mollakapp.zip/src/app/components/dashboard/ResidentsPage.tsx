import { useState, useEffect, useCallback } from "react";
import { Search, Phone, Home, Link2, CheckCircle2, Building2, Banknote, MessageCircle, ShieldBan, ShieldCheck, X, Loader2, ExternalLink, KeyRound, Shield, Crown, Wallet, UserCheck, ChevronDown, ChevronUp, DoorOpen, DoorClosed, Users, PlusCircle, AlertTriangle, History, CreditCard, MinusCircle, Clock, Layers, ArrowUpDown, Calendar, SortAsc, Pencil, Trash2, FileText, MoreVertical } from "lucide-react";
import { useNavigate } from "react-router";
import * as api from "../../lib/api";

function formatRelativeTime(isoDate: string | null): string {
  if (!isoDate) return "لم يسجّل دخول";
  const now = Date.now();
  const then = new Date(isoDate).getTime();
  const diff = now - then;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "الآن";
  if (mins < 60) return `منذ ${mins} د`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `منذ ${hours} س`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `منذ ${days} يوم`;
  const months = Math.floor(days / 30);
  return `منذ ${months} شهر`;
}

export function ResidentsPage() {
  const navigate = useNavigate();
  const [residents, setResidents] = useState<api.Resident[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<"joined" | "floor" | "name" | "unit">("joined");
  const [sortOpen, setSortOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [copied, setCopied] = useState(false);
  const [togglingBan, setTogglingBan] = useState<string | null>(null);
  const [resetModal, setResetModal] = useState<api.Resident | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [resettingPw, setResettingPw] = useState(false);
  const [roleModal, setRoleModal] = useState<api.Resident | null>(null);
  const [updatingRole, setUpdatingRole] = useState(false);
  const [inviteExpanded, setInviteExpanded] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("mollak-invite-expanded") !== "0";
    }
    return true;
  });

  // Credit modal state
  const [creditModal, setCreditModal] = useState<api.Resident | null>(null);
  const [creditAmount, setCreditAmount] = useState("");
  const [creditNote, setCreditNote] = useState("");
  const [submittingCredit, setSubmittingCredit] = useState(false);

  // Previous debt modal state
  const [debtModal, setDebtModal] = useState<api.Resident | null>(null);
  const [debtAmount, setDebtAmount] = useState("");
  const [debtNote, setDebtNote] = useState("");
  const [submittingDebt, setSubmittingDebt] = useState(false);

  // Credit history modal
  const [historyModal, setHistoryModal] = useState<api.Resident | null>(null);
  const [creditHistory, setCreditHistory] = useState<api.CreditTransaction[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  // Edit modal state
  const [editModal, setEditModal] = useState<api.Resident | null>(null);
  const [editForm, setEditForm] = useState({ name: "", unitCode: "", floor: "", type: "" });
  const [savingEdit, setSavingEdit] = useState(false);

  // Delete confirm
  const [deleteConfirm, setDeleteConfirm] = useState<api.Resident | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Ban confirm
  const [banConfirm, setBanConfirm] = useState<api.Resident | null>(null);

  // Action sheet (bottom sheet) for 3-dots menu
  const [actionSheet, setActionSheet] = useState<api.Resident | null>(null);

  // Building info for invite link
  const [buildingName, setBuildingName] = useState("");
  const [inviteLink, setInviteLink] = useState("");
  const [buildingSlug, setBuildingSlug] = useState("");
  const [totalUnits, setTotalUnits] = useState(0);

  // Load building info
  useEffect(() => {
    (async () => {
      try {
        const res = await api.getBuilding();
        if (res.exists && res.building) {
          setBuildingName(res.building.name);
          setBuildingSlug(res.building.slug);
          setInviteLink(`https://mollak.app/join/${res.building.slug}`);
          setTotalUnits(res.building.totalUnits || 0);
        }
      } catch (err) {
        console.error("Error loading building info:", err);
      }
    })();
  }, []);

  // Load residents
  const loadResidents = useCallback(async () => {
    try {
      const data = await api.getResidents();
      setResidents(data);
    } catch (err) {
      console.error("Error loading residents:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadResidents();
  }, [loadResidents]);

  // Listen for residents-updated event (e.g. after approving a join request)
  useEffect(() => {
    const handleResidentsUpdated = () => loadResidents();
    window.addEventListener("residents-updated", handleResidentsUpdated);
    return () => window.removeEventListener("residents-updated", handleResidentsUpdated);
  }, [loadResidents]);

  const parseNum = (s: string) => { const n = parseInt(s.replace(/\D/g, ""), 10); return isNaN(n) ? 999999 : n; };
  const sortOptions: { key: typeof sortBy; label: string; icon: any }[] = [
    { key: "joined", label: "تاريخ الانضمام", icon: Calendar },
    { key: "name", label: "الأبجدية", icon: SortAsc },
    { key: "floor", label: "الدور", icon: Layers },
    { key: "unit", label: "رقم الشقة", icon: Home },
  ];

  const filtered = residents
    .filter((r) => searchQuery === "" || r.name.includes(searchQuery) || r.unitCode.includes(searchQuery) || r.phone.includes(searchQuery))
    .sort((a, b) => {
      switch (sortBy) {
        case "name": return a.name.localeCompare(b.name, "ar");
        case "floor": return parseNum(a.floor) - parseNum(b.floor) || parseNum(a.unitCode) - parseNum(b.unitCode);
        case "unit": return parseNum(a.unitCode) - parseNum(b.unitCode);
        case "joined": default: return (b.joinedAt || "").localeCompare(a.joinedAt || "");
      }
    });

  const totalResidents = residents.length;
  const bannedCount = residents.filter((r) => r.banned).length;
  const renterCount = residents.filter((r) => r.type === "مستأجر").length;
  const occupiedUnitCodes = new Set(residents.map((r) => r.unitCode));
  const occupiedCount = occupiedUnitCodes.size;

  const toggleInviteExpanded = () => {
    const next = !inviteExpanded;
    setInviteExpanded(next);
    localStorage.setItem("mollak-invite-expanded", next ? "1" : "0");
  };

  const toggleBan = async (id: string) => {
    setTogglingBan(id);
    try {
      await api.toggleResidentBan(id);
      setResidents((prev) => prev.map((r) => r.id === id ? { ...r, banned: !r.banned } : r));
      const resident = residents.find((r) => r.id === id);
      showSuccess(resident?.banned ? `تم رفع الحظر عن ${resident.name}` : `تم حظر ${resident?.name}`);
    } catch (err) {
      console.error("Error toggling ban:", err);
      showSuccess("حدث خطأ");
    } finally {
      setTogglingBan(null);
    }
  };

  const handleResetPassword = async () => {
    if (!resetModal || !newPassword || newPassword.length < 6) return;
    setResettingPw(true);
    try {
      await api.resetUserPassword(resetModal.phone, newPassword);
      showSuccess(`تم إعادة تعيين كلمة مرور ${resetModal.name}`);
      setResetModal(null);
      setNewPassword("");
    } catch (err: any) {
      console.error("Error resetting password:", err);
      showSuccess(err.message || "خطأ في إعادة تعيين كلمة المرور");
    } finally {
      setResettingPw(false);
    }
  };

  const roleLabels: Record<string, { label: string; color: string; icon: any }> = {
    resident: { label: "ساكن", color: "#5f6b7a", icon: UserCheck },
    treasurer: { label: "أمين الصندوق", color: "#F59E0B", icon: Wallet },
    board_member: { label: "عضو اتحاد", color: "#0D9488", icon: Shield },
  };

  const handleRoleChange = async (residentId: string, newRole: string) => {
    setUpdatingRole(true);
    try {
      await api.updateResidentRole(residentId, newRole);
      setResidents((prev) => prev.map((r) => r.id === residentId ? { ...r, role: newRole as any } : r));
      const resident = residents.find((r) => r.id === residentId);
      showSuccess(`تم تغيير صلاحية ${resident?.name} إلى ${roleLabels[newRole]?.label || newRole}`);
      setRoleModal(null);
    } catch (err: any) {
      console.error("Error updating role:", err);
      showSuccess(err.message || "خطأ في تغيير الصلاحية");
    } finally {
      setUpdatingRole(false);
    }
  };

  const openChat = (resident: api.Resident) => {
    navigate(`/dashboard/chat?dm=${encodeURIComponent(resident.phone)}&name=${encodeURIComponent(resident.name)}&unit=${encodeURIComponent(resident.unitCode)}`);
  };

  const handleAddCredit = async () => {
    if (!creditModal || !creditAmount || parseFloat(creditAmount) <= 0) return;
    setSubmittingCredit(true);
    try {
      const res = await api.updateResidentCredit(creditModal.id, parseFloat(creditAmount), creditNote);
      setResidents((prev) => prev.map((r) => r.id === creditModal.id ? { ...r, creditBalance: res.creditBalance } : r));
      showSuccess(`تم إضافة ${parseFloat(creditAmount).toLocaleString("en-US")} ج.م لرصيد ${creditModal.name}`);
      setCreditModal(null);
      setCreditAmount("");
      setCreditNote("");
      loadResidents();
    } catch (err: any) {
      console.error("Error adding credit:", err);
      showSuccess(err.message || "خطأ في إضافة الرصيد");
    } finally {
      setSubmittingCredit(false);
    }
  };

  const handleSetDebt = async () => {
    if (!debtModal || !debtAmount || parseFloat(debtAmount) < 0) return;
    setSubmittingDebt(true);
    try {
      const res = await api.updateResidentPreviousDebt(debtModal.id, parseFloat(debtAmount), debtNote);
      setResidents((prev) => prev.map((r) => r.id === debtModal.id ? { ...r, previousDebt: res.previousDebt } : r));
      showSuccess(`تم تسجيل مديونية ${parseFloat(debtAmount).toLocaleString("en-US")} ج.م على ${debtModal.name}`);
      setDebtModal(null);
      setDebtAmount("");
      setDebtNote("");
    } catch (err: any) {
      console.error("Error setting debt:", err);
      showSuccess(err.message || "خطأ في تسجيل المديونية");
    } finally {
      setSubmittingDebt(false);
    }
  };

  const openCreditHistory = async (resident: api.Resident) => {
    setHistoryModal(resident);
    setLoadingHistory(true);
    try {
      const history = await api.getResidentCreditHistory(resident.id);
      setCreditHistory(history);
    } catch (err) {
      console.error("Error loading credit history:", err);
      setCreditHistory([]);
    } finally {
      setLoadingHistory(false);
    }
  };

  const handleEdit = async () => {
    if (!editModal || !editForm.name) return;
    setSavingEdit(true);
    try {
      await api.editResident(editModal.id, editForm);
      setResidents((prev) => prev.map((r) => r.id === editModal.id ? { ...r, ...editForm } : r));
      showSuccess(`تم تعديل بيانات ${editForm.name}`);
      setEditModal(null);
    } catch (err: any) {
      console.error("Error editing resident:", err);
      showSuccess(err.message || "خطأ في تعديل البيانات");
    } finally {
      setSavingEdit(false);
    }
  };

  const handleDelete = async (resident: api.Resident) => {
    setDeletingId(resident.id);
    try {
      await api.deleteResident(resident.id);
      setResidents((prev) => prev.filter((r) => r.id !== resident.id));
      showSuccess(`تم حذف ${resident.name}`);
      setDeleteConfirm(null);
    } catch (err: any) {
      console.error("Error deleting resident:", err);
      showSuccess(err.message || "خطأ في حذف المالك");
    } finally {
      setDeletingId(null);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin mx-auto mb-3" />
          <p className="text-sm text-[#5f6b7a]">جاري تحميل المُلاك...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl text-[#1a1a2e]">المُلاك</h1>
          <p className="text-sm text-[#5f6b7a]">إدارة مُلاك {buildingName || "المبنى"} والتواصل معهم</p>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Search icon */}
          <button
            onClick={() => { setSearchOpen(true); setTimeout(() => document.getElementById("residents-search-input")?.focus(), 50); }}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              searchQuery ? "bg-[#0D9488] text-white shadow-sm" : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:border-[#0D9488]/30"
            }`}
          >
            <Search className="w-4 h-4" />
          </button>
          {/* Sort icon */}
          <div className="relative">
            <button
              onClick={() => setSortOpen(!sortOpen)}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                sortBy !== "joined"
                  ? "bg-[#0D9488] text-white shadow-sm"
                  : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:border-[#0D9488]/30"
              }`}
            >
              <ArrowUpDown className="w-4 h-4" />
            </button>
            {sortOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setSortOpen(false)} />
                <div className="absolute left-0 top-full mt-1.5 bg-white border border-[#0D9488]/10 rounded-xl shadow-lg z-20 w-48 overflow-hidden">
                  <div className="px-3 py-2 border-b border-gray-100">
                    <span className="text-xs text-[#5f6b7a] font-medium">ترتيب حسب</span>
                  </div>
                  {sortOptions.map((opt) => {
                    const Icon = opt.icon;
                    const isActive = sortBy === opt.key;
                    return (
                      <button
                        key={opt.key}
                        onClick={() => { setSortBy(opt.key); setSortOpen(false); }}
                        className={`w-full flex items-center gap-2.5 px-3 py-2.5 text-sm transition-colors ${
                          isActive ? "bg-[#0D9488]/5 text-[#0D9488]" : "text-[#1a1a2e] hover:bg-gray-50"
                        }`}
                      >
                        <Icon className={`w-4 h-4 ${isActive ? "text-[#0D9488]" : "text-[#5f6b7a]"}`} />
                        <span className="flex-1 text-right">{opt.label}</span>
                        {isActive && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#0D9488]" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </>
            )}
          </div>
          {/* Invite button */}
          {buildingSlug && (
            <button
              onClick={() => navigate(`/join/${buildingSlug}`)}
              className="w-9 h-9 rounded-xl flex items-center justify-center bg-[#F59E0B] text-white hover:bg-[#F59E0B]/90 transition-colors shadow-sm"
              title="تجربة الدعوة"
            >
              <ExternalLink className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Expandable Search Bar */}
      {searchOpen && (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#5f6b7a]" />
            <input
              id="residents-search-input"
              type="text"
              placeholder="ابحث بالاسم أو رقم الوحدة أو الهاتف..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 bg-white border border-[#0D9488]/15 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm"
            />
          </div>
          <button
            onClick={() => { setSearchOpen(false); setSearchQuery(""); }}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#5f6b7a] bg-white border border-gray-100 hover:bg-gray-50 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-white rounded-xl border border-gray-100 px-3 py-2.5 shadow-sm text-center">
          <Users className="w-4 h-4 text-[#0D9488] mx-auto mb-1" />
          <div className="text-base font-semibold text-[#1a1a2e]">{totalResidents}</div>
          <div className="text-xs text-[#5f6b7a]">المُلاك</div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 px-3 py-2.5 shadow-sm text-center">
          <Home className="w-4 h-4 text-[#ec4899] mx-auto mb-1" />
          <div className="text-base font-semibold text-[#1a1a2e]">{renterCount}</div>
          <div className="text-xs text-[#5f6b7a]">مستأجر</div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 px-3 py-2.5 shadow-sm text-center">
          <ShieldBan className="w-4 h-4 text-red-500 mx-auto mb-1" />
          <div className="text-base font-semibold text-[#1a1a2e]">{bannedCount}</div>
          <div className="text-xs text-[#5f6b7a]">محظور</div>
        </div>
      </div>

      {/* Residents List */}
      <div className="space-y-3">
        {filtered.map((resident) => {
          const isOnline = resident.lastLogin && (Date.now() - new Date(resident.lastLogin).getTime()) < 7 * 24 * 60 * 60 * 1000;
          const roleMeta = roleLabels[resident.role] || roleLabels.resident;
          const totalDues = resident.debt + (resident.previousDebt || 0);

          return (
            <div key={resident.id} className={`bg-white rounded-2xl border shadow-sm overflow-hidden ${resident.banned ? "border-red-200/60" : "border-gray-100"}`}>
              <div className="p-4" style={{ backgroundColor: resident.banned ? '#fef2f208' : `${roleMeta.color}04` }}>

                {/* ── Header: Avatar + Name + Time + 3-dots ── */}
                <div className="flex items-start gap-3 mb-3">
                  <div className="relative shrink-0">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold" style={{ backgroundColor: `${roleMeta.color}15`, color: roleMeta.color }}>
                      {resident.name.charAt(0)}
                    </div>
                    <div className={`absolute -bottom-0.5 -left-0.5 w-3 h-3 rounded-full border-2 border-white ${isOnline ? "bg-[#22c55e]" : "bg-gray-300"}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-[#1a1a2e] truncate">{resident.name}</span>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="text-[10px]" style={{ color: isOnline ? '#22c55e' : '#5f6b7a' }}>
                          {formatRelativeTime(resident.lastLogin)}
                        </span>
                        <button
                          onClick={() => setActionSheet(actionSheet?.id === resident.id ? null : resident)}
                          className="w-7 h-7 rounded-lg flex items-center justify-center text-[#5f6b7a] hover:bg-black/5 active:bg-black/10 transition-colors"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                      <span className="text-[10px] px-1.5 py-px rounded-full font-medium" style={{ backgroundColor: `${roleMeta.color}12`, color: roleMeta.color }}>
                        {roleMeta.label}
                      </span>
                      <span className="text-[10px] px-1.5 py-px rounded-full bg-gray-50 text-[#5f6b7a]">{resident.type}</span>
                      {resident.banned && (
                        <span className="text-[10px] px-1.5 py-px rounded-full bg-red-50 text-red-500">محظور</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* ── Info Grid — notification card style ── */}
                <div className="grid grid-cols-4 gap-2 mb-3">
                  <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                    <div className="text-[9px] text-[#5f6b7a]">الشقة</div>
                    <div className="text-xs text-[#1a1a2e] font-medium">{resident.unitCode}</div>
                  </div>
                  <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                    <div className="text-[9px] text-[#5f6b7a]">الدور</div>
                    <div className="text-xs text-[#1a1a2e] font-medium">{resident.floor || "—"}</div>
                  </div>
                  <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                    <div className="text-[9px] text-[#5f6b7a]">الهاتف</div>
                    <div className="text-[10px] text-[#1a1a2e]" dir="ltr">{resident.phone}</div>
                  </div>
                  <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                    <div className="text-[9px] text-[#5f6b7a]">المستحقات</div>
                    <div className="text-xs font-bold" style={{ color: totalDues > 0 ? '#dc2626' : '#22c55e' }}>
                      {totalDues.toLocaleString("en-US")}
                    </div>
                  </div>
                </div>

                {/* ── Credit balance hint ── */}
                {resident.creditBalance > 0 && (
                  <div className="flex items-center gap-1.5 mb-3 px-0.5">
                    <Wallet className="w-3 h-3 text-[#22c55e]" />
                    <span className="text-[10px] text-[#22c55e]">رصيد مقدّم: {resident.creditBalance.toLocaleString("en-US")} ج.م</span>
                  </div>
                )}

                {/* ── Bottom actions — محادثة | حظر | حذف ── */}
                <div className="flex gap-2">
                  <button
                    onClick={() => openChat(resident)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-[#0D9488]/30 text-[#0D9488] text-xs hover:bg-[#0D9488]/5 transition-all"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    محادثة
                  </button>
                  <button
                    onClick={() => setBanConfirm(resident)}
                    disabled={togglingBan === resident.id}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border text-xs transition-all disabled:opacity-50 ${
                      resident.banned
                        ? "border-[#22c55e]/30 text-[#22c55e] hover:bg-[#22c55e]/5"
                        : "border-[#F59E0B]/30 text-[#F59E0B] hover:bg-[#F59E0B]/5"
                    }`}
                  >
                    {togglingBan === resident.id ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : resident.banned ? (
                      <ShieldCheck className="w-3.5 h-3.5" />
                    ) : (
                      <ShieldBan className="w-3.5 h-3.5" />
                    )}
                    {resident.banned ? "رفع الحظر" : "حظر"}
                  </button>
                  <button
                    onClick={() => setDeleteConfirm(resident)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-red-200 text-red-500 text-xs hover:bg-red-50 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    حذف
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Action Sheet (Bottom Sheet) ── */}
      {actionSheet && (
        <>
          <div className="fixed inset-0 bg-black/30 z-40" onClick={() => setActionSheet(null)} />
          <div className="fixed bottom-0 left-0 right-0 z-50 bg-white rounded-t-2xl shadow-2xl" style={{ maxHeight: '70vh' }}>
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-gray-200" />
            </div>
            <div className="flex items-center gap-3 px-5 pb-3 border-b border-gray-100">
              <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold" style={{ backgroundColor: `${(roleLabels[actionSheet.role] || roleLabels.resident).color}12`, color: (roleLabels[actionSheet.role] || roleLabels.resident).color }}>
                {actionSheet.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-[#1a1a2e] truncate">{actionSheet.name}</div>
                <div className="text-[10px] text-[#5f6b7a]">شقة {actionSheet.unitCode} — الدور {actionSheet.floor || "—"}</div>
              </div>
              <button onClick={() => setActionSheet(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-[#5f6b7a] hover:bg-gray-100">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="py-2">
              {[
                { icon: PlusCircle, label: "إضافة رصيد", color: "#22c55e", action: () => { setCreditModal(actionSheet); setCreditAmount(""); setCreditNote(""); setActionSheet(null); } },
                { icon: AlertTriangle, label: "إضافة مديونية", color: "#dc2626", action: () => { setDebtModal(actionSheet); setDebtAmount(String(actionSheet.previousDebt || "")); setDebtNote(""); setActionSheet(null); } },
                { icon: Shield, label: "الصلاحية", color: "#F59E0B", action: () => { setRoleModal(actionSheet); setActionSheet(null); } },
                { icon: Pencil, label: "التعديل", color: "#6366f1", action: () => { setEditModal(actionSheet); setEditForm({ name: actionSheet.name, unitCode: actionSheet.unitCode, floor: actionSheet.floor, type: actionSheet.type }); setActionSheet(null); } },
                { icon: KeyRound, label: "كلمة المرور", color: "#F59E0B", action: () => { setResetModal(actionSheet); setNewPassword(""); setActionSheet(null); } },
              ].map((item, i) => (
                <button
                  key={i}
                  onClick={item.action}
                  className="w-full flex items-center gap-4 px-5 py-3.5 text-sm text-[#1a1a2e] hover:bg-gray-50 active:bg-gray-100 transition-colors"
                >
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${item.color}10` }}>
                    <item.icon className="w-5 h-5" style={{ color: item.color }} />
                  </div>
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
            <div className="h-6" />
          </div>
        </>
      )}

      {filtered.length === 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center text-sm text-[#5f6b7a]">
          {residents.length === 0 ? "لا يوجد مُلاك مسجلين بعد — شارك رابط الدعوة ليتمكن المُلاك من الانضمام" : "لا توجد نتائج مطابقة للبحث"}
        </div>
      )}

      {/* ========= MODALS ========= */}

      {/* Role Change Modal */}
      {roleModal && (
        <ModalOverlay onClose={() => setRoleModal(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <ModalHeader title={`تغيير صلاحية ${roleModal.name}`} onClose={() => setRoleModal(null)} />
            <p className="text-sm text-[#5f6b7a] mb-5">
              اختر الصلاحية الجديدة — عضو الاتحاد وأمين الصندوق يقدرون يشوفوا لوحة التحكم الكاملة
            </p>
            <div className="space-y-3">
              {(["resident", "treasurer", "board_member"] as const).map((roleKey) => {
                const info = roleLabels[roleKey];
                const isCurrentRole = (roleModal.role || "resident") === roleKey;
                const IconComp = info.icon;
                return (
                  <button
                    key={roleKey}
                    onClick={() => !isCurrentRole && handleRoleChange(roleModal.id, roleKey)}
                    disabled={isCurrentRole || updatingRole}
                    className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-right ${
                      isCurrentRole
                        ? "border-[#0D9488] bg-[#0D9488]/5"
                        : "border-gray-100 hover:border-[#0D9488]/30 hover:bg-[#f8fffe]"
                    } disabled:opacity-70`}
                  >
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: isCurrentRole ? '#0D9488' : `${info.color}15`, color: isCurrentRole ? '#fff' : info.color }}>
                      <IconComp className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <div className={`text-sm ${isCurrentRole ? "text-[#0D9488]" : "text-[#1a1a2e]"}`}>
                        {info.label}
                      </div>
                      <div className="text-xs text-[#5f6b7a] mt-0.5">
                        {roleKey === "resident" && "عرض الفواتير والإعلانات فقط"}
                        {roleKey === "treasurer" && "إدارة المصروفات والإيرادات والفواتير"}
                        {roleKey === "board_member" && "صلاحيات كاملة مثل رئيس الاتحاد"}
                      </div>
                    </div>
                    {isCurrentRole && (
                      <span className="text-xs bg-[#0D9488] text-white px-2 py-0.5 rounded-full shrink-0">الحالي</span>
                    )}
                  </button>
                );
              })}
            </div>
            {updatingRole && (
              <div className="flex items-center justify-center gap-2 mt-4 text-sm text-[#0D9488]">
                <Loader2 className="w-4 h-4 animate-spin" /> جاري التحديث...
              </div>
            )}
          </div>
        </ModalOverlay>
      )}

      {/* Reset Password Modal */}
      {resetModal && (
        <ModalOverlay onClose={() => setResetModal(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <ModalHeader title="إعادة تعيين كلمة المرور" onClose={() => setResetModal(null)} />
            <p className="text-sm text-[#5f6b7a] mb-4">أدخل كلمة مرور جديدة للمُلاك {resetModal.name}</p>
            <input
              type="password"
              placeholder="كلمة المرور الجديدة (6 أحرف على الأقل)"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full px-4 py-3 bg-white border border-[#0D9488]/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm"
            />
            <div className="flex items-center justify-end gap-2 mt-4">
              <button onClick={() => setResetModal(null)} className="text-sm text-[#5f6b7a] hover:text-[#0D9488] px-4 py-2.5 rounded-xl">إلغاء</button>
              <button
                onClick={handleResetPassword}
                disabled={resettingPw || newPassword.length < 6}
                className="text-sm bg-[#F59E0B] text-white px-4 py-2.5 rounded-xl hover:bg-[#F59E0B]/90 transition-colors disabled:opacity-50"
              >
                {resettingPw ? "جاري..." : "إعادة تعيين"}
              </button>
            </div>
          </div>
        </ModalOverlay>
      )}

      {/* Credit Balance Modal */}
      {creditModal && (
        <ModalOverlay onClose={() => setCreditModal(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <ModalHeader title="إضافة رصيد مالي" onClose={() => setCreditModal(null)} />
            <div className="bg-[#0D9488]/5 rounded-xl p-3 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#0D9488]/10 flex items-center justify-center text-[#0D9488] text-sm">{creditModal.name.charAt(0)}</div>
                <div>
                  <div className="text-sm text-[#1a1a2e] font-medium">{creditModal.name}</div>
                  <div className="text-xs text-[#5f6b7a]">شقة {creditModal.unitCode}</div>
                </div>
                {creditModal.creditBalance > 0 && (
                  <div className="mr-auto text-left">
                    <div className="text-xs text-[#5f6b7a]">الرصيد الحالي</div>
                    <div className="text-sm font-semibold text-[#22c55e]">{creditModal.creditBalance.toLocaleString("en-US")} ج.م</div>
                  </div>
                )}
              </div>
            </div>
            <p className="text-sm text-[#5f6b7a] mb-4">أدخل المبلغ المدفوع مقدماً — سيتم خصم الفواتير القادمة تلقائياً من هذا الرصيد</p>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-[#5f6b7a] mb-1.5">المبلغ (ج.م)</label>
                <input type="number" inputMode="decimal" value={creditAmount} onChange={(e) => setCreditAmount(e.target.value)} placeholder="مثال: 12000" min="1" dir="ltr" className="w-full px-4 py-3 bg-white border border-[#0D9488]/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#22c55e]/20 focus:border-[#22c55e] text-sm text-left" />
              </div>
              <div>
                <label className="block text-xs text-[#5f6b7a] mb-1.5">ملاحظة (اختياري)</label>
                <input type="text" value={creditNote} onChange={(e) => setCreditNote(e.target.value)} placeholder="مثال: سداد سنة كاملة مقدماً" className="w-full px-4 py-3 bg-white border border-[#0D9488]/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm" />
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 mt-5">
              <button onClick={() => setCreditModal(null)} className="text-sm text-[#5f6b7a] hover:text-[#0D9488] px-4 py-2.5 rounded-xl">إلغاء</button>
              <button
                onClick={handleAddCredit}
                disabled={submittingCredit || !creditAmount || parseFloat(creditAmount) <= 0}
                className="text-sm bg-[#22c55e] text-white px-5 py-2.5 rounded-xl hover:bg-[#22c55e]/90 transition-colors disabled:opacity-50 flex items-center gap-2"
              >
                {submittingCredit ? <Loader2 className="w-4 h-4 animate-spin" /> : <PlusCircle className="w-4 h-4" />}
                {submittingCredit ? "جاري الإضافة..." : "إضافة الرصيد"}
              </button>
            </div>
          </div>
        </ModalOverlay>
      )}

      {/* Previous Debt Modal */}
      {debtModal && (
        <ModalOverlay onClose={() => setDebtModal(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <ModalHeader title="مديونية سابقة" onClose={() => setDebtModal(null)} />
            <div className="bg-[#dc2626]/5 rounded-xl p-3 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#dc2626]/10 flex items-center justify-center text-[#dc2626] text-sm">{debtModal.name.charAt(0)}</div>
                <div>
                  <div className="text-sm text-[#1a1a2e] font-medium">{debtModal.name}</div>
                  <div className="text-xs text-[#5f6b7a]">شقة {debtModal.unitCode}</div>
                </div>
                {debtModal.previousDebt > 0 && (
                  <div className="mr-auto text-left">
                    <div className="text-xs text-[#5f6b7a]">المديونية الحالية</div>
                    <div className="text-sm font-semibold text-[#dc2626]">{debtModal.previousDebt.toLocaleString("en-US")} ج.م</div>
                  </div>
                )}
              </div>
            </div>
            <p className="text-sm text-[#5f6b7a] mb-4">سجّل المديونية المستحقة على هذا المالك من قبل استخدام مُلاك — أدخل 0 لإزالة المديونية</p>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-[#5f6b7a] mb-1.5">مبلغ المديونية (ج.م)</label>
                <input type="number" inputMode="decimal" value={debtAmount} onChange={(e) => setDebtAmount(e.target.value)} placeholder="0" min="0" dir="ltr" className="w-full px-4 py-3 bg-white border border-[#dc2626]/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#dc2626]/20 focus:border-[#dc2626] text-sm text-left" />
              </div>
              <div>
                <label className="block text-xs text-[#5f6b7a] mb-1.5">ملاحظة (اختياري)</label>
                <input type="text" value={debtNote} onChange={(e) => setDebtNote(e.target.value)} placeholder="مثال: متأخرات صيانة 2024" className="w-full px-4 py-3 bg-white border border-[#0D9488]/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm" />
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 mt-5">
              <button onClick={() => setDebtModal(null)} className="text-sm text-[#5f6b7a] hover:text-[#0D9488] px-4 py-2.5 rounded-xl">إلغاء</button>
              <button
                onClick={handleSetDebt}
                disabled={submittingDebt || !debtAmount || parseFloat(debtAmount) < 0}
                className="text-sm bg-[#dc2626] text-white px-5 py-2.5 rounded-xl hover:bg-[#dc2626]/90 transition-colors disabled:opacity-50 flex items-center gap-2"
              >
                {submittingDebt ? <Loader2 className="w-4 h-4 animate-spin" /> : <AlertTriangle className="w-4 h-4" />}
                {submittingDebt ? "جاري الحفظ..." : "حفظ المديونية"}
              </button>
            </div>
          </div>
        </ModalOverlay>
      )}

      {/* Credit History Modal */}
      {historyModal && (
        <ModalOverlay onClose={() => setHistoryModal(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg max-h-[85vh] flex flex-col">
            <ModalHeader title={`سجل الرصيد — ${historyModal.name}`} onClose={() => setHistoryModal(null)} />
            <div className="bg-[#0D9488]/5 rounded-xl p-3 mb-4 flex items-center justify-between">
              <span className="text-sm text-[#5f6b7a]">الرصيد الحالي</span>
              <span className="text-lg font-semibold text-[#22c55e]">{(historyModal.creditBalance || 0).toLocaleString("en-US")} ج.م</span>
            </div>
            {loadingHistory ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 text-[#0D9488] animate-spin" />
              </div>
            ) : creditHistory.length === 0 ? (
              <div className="text-center py-12">
                <History className="w-10 h-10 text-[#0D9488]/15 mx-auto mb-2" />
                <div className="text-sm text-[#5f6b7a]">لا توجد حركات مالية بعد</div>
              </div>
            ) : (
              <div className="overflow-y-auto flex-1 -mx-2 px-2 space-y-2">
                {creditHistory.map((tx) => (
                  <div key={tx.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-xl">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${tx.amount > 0 ? "bg-[#22c55e]/10" : "bg-[#F59E0B]/10"}`}>
                      {tx.amount > 0 ? <PlusCircle className="w-4 h-4 text-[#22c55e]" /> : <MinusCircle className="w-4 h-4 text-[#F59E0B]" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className={`text-sm font-medium ${tx.amount > 0 ? "text-[#22c55e]" : "text-[#F59E0B]"}`}>
                          {tx.amount > 0 ? "+" : ""}{tx.amount.toLocaleString("en-US")} ج.م
                        </span>
                        <span className="text-xs text-[#5f6b7a]">
                          {new Date(tx.createdAt).toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "short", year: "numeric" })}
                        </span>
                      </div>
                      {tx.note && <p className="text-xs text-[#5f6b7a] mt-0.5">{tx.note}</p>}
                      <div className="text-xs text-[#5f6b7a]/60 mt-0.5">الرصيد بعد العملية: {tx.balanceAfter.toLocaleString("en-US")} ج.م</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </ModalOverlay>
      )}

      {/* Edit Resident Modal */}
      {editModal && (
        <ModalOverlay onClose={() => setEditModal(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <ModalHeader title={`تعديل بيانات ${editModal.name}`} onClose={() => setEditModal(null)} />
            <div className="space-y-3 mt-2">
              <div>
                <label className="block text-xs text-[#5f6b7a] mb-1.5">الاسم</label>
                <input type="text" value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} className="w-full px-4 py-3 bg-white border border-[#0D9488]/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-[#5f6b7a] mb-1.5">رقم الشقة</label>
                  <input type="text" value={editForm.unitCode} onChange={(e) => setEditForm({ ...editForm, unitCode: e.target.value })} className="w-full px-4 py-3 bg-white border border-[#0D9488]/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm" />
                </div>
                <div>
                  <label className="block text-xs text-[#5f6b7a] mb-1.5">الدور</label>
                  <input type="text" value={editForm.floor} onChange={(e) => setEditForm({ ...editForm, floor: e.target.value })} className="w-full px-4 py-3 bg-white border border-[#0D9488]/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm" />
                </div>
              </div>
              <div>
                <label className="block text-xs text-[#5f6b7a] mb-1.5">النوع</label>
                <div className="flex gap-2">
                  {["مالك", "مستأجر"].map((t) => (
                    <button key={t} onClick={() => setEditForm({ ...editForm, type: t })} className={`flex-1 py-2.5 rounded-xl text-sm border-2 transition-all ${editForm.type === t ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-100 text-[#5f6b7a]"}`}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 mt-5">
              <button onClick={() => setEditModal(null)} className="text-sm text-[#5f6b7a] hover:text-[#0D9488] px-4 py-2.5 rounded-xl">إلغاء</button>
              <button
                onClick={handleEdit}
                disabled={savingEdit || !editForm.name}
                className="text-sm bg-[#0D9488] text-white px-5 py-2.5 rounded-xl hover:bg-[#0D9488]/90 transition-colors disabled:opacity-50 flex items-center gap-2"
              >
                {savingEdit ? <Loader2 className="w-4 h-4 animate-spin" /> : <Pencil className="w-4 h-4" />}
                {savingEdit ? "جاري الحفظ..." : "حفظ التعديلات"}
              </button>
            </div>
          </div>
        </ModalOverlay>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <ModalOverlay onClose={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm text-center">
            <div className="w-14 h-14 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-7 h-7 text-[#ef4444]" />
            </div>
            <h2 className="text-lg text-[#1a1a2e] mb-2">حذف {deleteConfirm.name}؟</h2>
            <p className="text-sm text-[#5f6b7a] mb-5">
              سيتم حذف هذا المالك نهائياً من المبنى — شقة {deleteConfirm.unitCode}، الدور {deleteConfirm.floor || "—"}
            </p>
            <div className="flex gap-2">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-2.5 rounded-xl text-sm border border-gray-200 text-[#5f6b7a] hover:bg-gray-50 transition-colors">إلغاء</button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                disabled={deletingId === deleteConfirm.id}
                className="flex-1 py-2.5 rounded-xl text-sm bg-[#ef4444] text-white hover:bg-[#ef4444]/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {deletingId === deleteConfirm.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                {deletingId === deleteConfirm.id ? "جاري الحذف..." : "نعم، احذف"}
              </button>
            </div>
          </div>
        </ModalOverlay>
      )}

      {/* Ban Confirmation Modal */}
      {banConfirm && (
        <ModalOverlay onClose={() => setBanConfirm(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm text-center">
            <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: banConfirm.banned ? '#f0fdf4' : '#FFFBEB' }}>
              {banConfirm.banned ? <ShieldCheck className="w-7 h-7 text-[#22c55e]" /> : <ShieldBan className="w-7 h-7 text-[#F59E0B]" />}
            </div>
            <h2 className="text-lg text-[#1a1a2e] mb-2">
              {banConfirm.banned ? `رفع الحظر عن ${banConfirm.name}؟` : `حظر ${banConfirm.name}؟`}
            </h2>
            <p className="text-sm text-[#5f6b7a] mb-5">
              {banConfirm.banned
                ? "سيتمكن هذا المالك من الدخول واستخدام المنصة مرة أخرى"
                : "لن يتمكن هذا المالك من الدخول أو استخدام المنصة حتى يتم رفع الحظر"}
            </p>
            <div className="flex gap-2">
              <button onClick={() => setBanConfirm(null)} className="flex-1 py-2.5 rounded-xl text-sm border border-gray-200 text-[#5f6b7a] hover:bg-gray-50 transition-colors">إلغاء</button>
              <button
                onClick={() => { toggleBan(banConfirm.id); setBanConfirm(null); }}
                disabled={togglingBan === banConfirm.id}
                className="flex-1 py-2.5 rounded-xl text-sm text-white hover:opacity-90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                style={{ backgroundColor: banConfirm.banned ? '#22c55e' : '#F59E0B' }}
              >
                {togglingBan === banConfirm.id ? <Loader2 className="w-4 h-4 animate-spin" /> : (banConfirm.banned ? <ShieldCheck className="w-4 h-4" /> : <ShieldBan className="w-4 h-4" />)}
                {banConfirm.banned ? "نعم، ارفع الحظر" : "نعم، احظر"}
              </button>
            </div>
          </div>
        </ModalOverlay>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════════════
   Sub-components
   ════════════════════════════════════════════════════════════════ */

function ModalOverlay({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed top-0 left-0 w-full h-full bg-black/50 flex items-center justify-center z-50 p-4" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      {children}
    </div>
  );
}

function ModalHeader({ title, onClose }: { title: string; onClose: () => void }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-lg text-[#1a1a2e]">{title}</h2>
      <button onClick={onClose} className="text-[#5f6b7a] hover:text-[#0D9488] p-1">
        <X className="w-5 h-5" />
      </button>
    </div>
  );
}