import { useState, useEffect, useCallback } from "react";
import {
  TrendingUp,
  Receipt,
  Banknote,
  CheckCircle2,
  Loader2,
  FilePlus,
  FileEdit,
  Trash2,
  Activity,
  Building2,
  Heart,
  Vote,
  Search,
  Filter,
  Calendar,
  ArrowRight,
  type LucideIcon,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useNavigate } from "react-router";
import * as api from "../../lib/api";

// Map activity type → icon + fallback color (same as OverviewPage)
const activityIconMap: Record<string, { icon: LucideIcon; fallbackColor: string }> = {
  invoice_created: { icon: FilePlus, fallbackColor: "#0D9488" },
  invoice_paid: { icon: CheckCircle2, fallbackColor: "#0D9488" },
  invoice_updated: { icon: FileEdit, fallbackColor: "#F59E0B" },
  invoice_deleted: { icon: Trash2, fallbackColor: "#ef4444" },
  cash_requested: { icon: Banknote, fallbackColor: "#6366f1" },
  cash_collected: { icon: CheckCircle2, fallbackColor: "#0D9488" },
  building_registered: { icon: Building2, fallbackColor: "#0D9488" },
  building_updated: { icon: Building2, fallbackColor: "#F59E0B" },
  revenue_created: { icon: TrendingUp, fallbackColor: "#0D9488" },
  revenue_updated: { icon: TrendingUp, fallbackColor: "#F59E0B" },
  revenue_deleted: { icon: TrendingUp, fallbackColor: "#ef4444" },
  expense_created: { icon: Receipt, fallbackColor: "#ef4444" },
  expense_updated: { icon: Receipt, fallbackColor: "#F59E0B" },
  expense_deleted: { icon: Receipt, fallbackColor: "#ef4444" },
  donation_created: { icon: Heart, fallbackColor: "#f43f5e" },
  donation_confirmed: { icon: Heart, fallbackColor: "#0D9488" },
  donation_cash_requested: { icon: Heart, fallbackColor: "#F59E0B" },
  donation_cash_confirmed: { icon: Heart, fallbackColor: "#0D9488" },
  donation_cash_cancelled: { icon: Heart, fallbackColor: "#6b7280" },
  poll_created: { icon: Vote, fallbackColor: "#8b5cf6" },
  resident_joined: { icon: Building2, fallbackColor: "#0D9488" },
  resident_approved: { icon: CheckCircle2, fallbackColor: "#0D9488" },
};

// Activity type labels for filter
const activityTypeLabels: Record<string, string> = {
  invoice_created: "إنشاء فاتورة",
  invoice_paid: "دفع فاتورة",
  invoice_updated: "تعديل فاتورة",
  invoice_deleted: "حذف فاتورة",
  cash_requested: "طلب تحصيل",
  cash_collected: "تأكيد تحصيل",
  building_registered: "تسجيل مبنى",
  building_updated: "تحديث مبنى",
  revenue_created: "إيراد جديد",
  revenue_updated: "تعديل إيراد",
  revenue_deleted: "حذف إيراد",
  expense_created: "مصروف جديد",
  donation_created: "تبرع جديد",
  donation_confirmed: "تأكيد تبرع",
  donation_cash_requested: "نية تبرع",
  donation_cash_confirmed: "تحصيل تبرع",
  donation_cash_cancelled: "إلغاء نية تبرع",
  poll_created: "تصويت جديد",
  resident_joined: "طلب انضمام",
  resident_approved: "قبول ساكن",
};

function timeAgo(timestamp: string): string {
  const now = Date.now();
  const then = new Date(timestamp).getTime();
  const diff = Math.max(0, now - then);
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "الآن";
  if (mins < 60) return `منذ ${mins} د`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `منذ ${hours} س`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `منذ ${days} يوم`;
  if (days < 30) return `منذ ${Math.floor(days / 7)} أسبوع`;
  return `منذ ${Math.floor(days / 30)} شهر`;
}

function formatDate(timestamp: string): string {
  const d = new Date(timestamp);
  return d.toLocaleDateString("ar-u-nu-latn", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function ActivityLogPage() {
  const navigate = useNavigate();
  const [activities, setActivities] = useState<api.ActivityEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(false);

  const loadActivities = useCallback(async () => {
    try {
      setLoading(true);
      // Load all activities (large limit)
      const data = await api.getActivityLog(500);
      setActivities(data);
    } catch (err) {
      console.error("Error loading activity log:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadActivities();
  }, [loadActivities]);

  // Get unique activity types from data
  const availableTypes = Array.from(new Set(activities.map((a) => a.type)));

  // Filter activities
  const filteredActivities = activities.filter((act) => {
    // Type filter
    if (selectedType !== "all" && act.type !== selectedType) return false;
    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      return (
        act.title.toLowerCase().includes(q) ||
        act.description.toLowerCase().includes(q) ||
        (act.metadata?.amount && String(act.metadata.amount).includes(q))
      );
    }
    return true;
  });

  // Group activities by date
  const groupedByDate: Record<string, api.ActivityEntry[]> = {};
  filteredActivities.forEach((act) => {
    const dateKey = new Date(act.timestamp).toLocaleDateString("ar-u-nu-latn", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
    if (!groupedByDate[dateKey]) groupedByDate[dateKey] = [];
    groupedByDate[dateKey].push(act);
  });

  const dateGroups = Object.entries(groupedByDate);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate("/dashboard")}
          className="w-10 h-10 rounded-xl bg-white border border-[#0D9488]/10 flex items-center justify-center hover:bg-[#0D9488]/5 transition-colors"
        >
          <ArrowRight className="w-5 h-5 text-[#0D9488]" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl text-[#1a1a2e] font-bold">سجل النشاطات</h1>
          <p className="text-sm text-[#5f6b7a]">
            {loading
              ? "جاري التحميل..."
              : `${filteredActivities.length} نشاط${selectedType !== "all" || searchQuery ? " (بعد الفلتر)" : ""}`}
          </p>
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`p-2.5 rounded-xl border transition-all ${
            showFilters || selectedType !== "all" || searchQuery
              ? "bg-[#0D9488] text-white border-[#0D9488]"
              : "bg-white text-[#5f6b7a] border-[#0D9488]/10 hover:border-[#0D9488]/30"
          }`}
        >
          <Filter className="w-5 h-5" />
        </button>
      </div>

      {/* Filters */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="bg-white rounded-2xl border border-[#0D9488]/10 p-4 space-y-3">
              {/* Search */}
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#5f6b7a]" />
                <input
                  type="text"
                  placeholder="ابحث في النشاطات..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pr-10 pl-4 py-2.5 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                />
              </div>

              {/* Type filter */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-2 block">نوع النشاط</label>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setSelectedType("all")}
                    className={`px-3 py-1.5 rounded-lg text-xs transition-colors ${
                      selectedType === "all"
                        ? "bg-[#0D9488] text-white"
                        : "bg-gray-50 text-[#5f6b7a] hover:bg-gray-100"
                    }`}
                  >
                    الكل
                  </button>
                  {availableTypes.map((type) => (
                    <button
                      key={type}
                      onClick={() => setSelectedType(type === selectedType ? "all" : type)}
                      className={`px-3 py-1.5 rounded-lg text-xs transition-colors ${
                        selectedType === type
                          ? "bg-[#0D9488] text-white"
                          : "bg-gray-50 text-[#5f6b7a] hover:bg-gray-100"
                      }`}
                    >
                      {activityTypeLabels[type] || type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Clear filters */}
              {(selectedType !== "all" || searchQuery) && (
                <button
                  onClick={() => {
                    setSelectedType("all");
                    setSearchQuery("");
                  }}
                  className="text-xs text-red-500 hover:text-red-600"
                >
                  مسح جميع الفلاتر
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Activity List */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-[#0D9488]/10 flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin" />
        </div>
      ) : filteredActivities.length === 0 ? (
        <div className="bg-white rounded-2xl border border-[#0D9488]/10 text-center py-16">
          <Activity className="w-12 h-12 text-[#0D9488]/15 mx-auto mb-3" />
          <div className="text-sm text-[#5f6b7a]">
            {searchQuery || selectedType !== "all"
              ? "لا توجد نشاطات تطابق البحث"
              : "لا يوجد نشاط مسجل بعد"}
          </div>
          {(searchQuery || selectedType !== "all") && (
            <button
              onClick={() => {
                setSearchQuery("");
                setSelectedType("all");
              }}
              className="text-sm text-[#0D9488] hover:underline mt-2"
            >
              مسح الفلاتر
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {dateGroups.map(([dateLabel, acts]) => (
            <div key={dateLabel} className="bg-white rounded-2xl border border-[#0D9488]/10 overflow-hidden">
              {/* Date header */}
              <div className="flex items-center gap-2 px-4 py-2.5 bg-[#f8fffe] border-b border-[#0D9488]/5">
                <Calendar className="w-3.5 h-3.5 text-[#0D9488]" />
                <span className="text-xs font-medium text-[#0D9488]">{dateLabel}</span>
                <span className="text-[10px] text-[#5f6b7a] bg-white px-2 py-0.5 rounded-full">
                  {acts.length} نشاط
                </span>
              </div>

              {/* Activities */}
              <div className="divide-y divide-gray-50">
                {acts.map((act, i) => {
                  const mapped = activityIconMap[act.type] || { icon: Activity, fallbackColor: "#5f6b7a" };
                  const ActIcon = mapped.icon;
                  const color = act.color || mapped.fallbackColor;

                  return (
                    <motion.div
                      key={act.id}
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: Math.min(i * 0.02, 0.3) }}
                      className="flex items-start gap-3 p-4 hover:bg-gray-50/50 transition-colors"
                    >
                      {/* Icon */}
                      <div className="flex flex-col items-center pt-0.5">
                        <div
                          className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                          style={{ backgroundColor: `${color}12` }}
                        >
                          <ActIcon className="w-4 h-4" style={{ color }} />
                        </div>
                        {i < acts.length - 1 && (
                          <div className="w-px h-full min-h-[8px] bg-gray-100 mt-1" />
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm text-[#1a1a2e] font-medium">{act.title}</span>
                          <span
                            className="text-[10px] px-1.5 py-0.5 rounded-md"
                            style={{ backgroundColor: `${color}10`, color }}
                          >
                            {activityTypeLabels[act.type] || act.type}
                          </span>
                        </div>
                        <p className="text-xs text-[#5f6b7a] mt-0.5 leading-relaxed">
                          {act.description}
                        </p>
                        <div className="flex items-center gap-3 mt-1.5">
                          <span className="text-[10px] text-[#5f6b7a]/60">
                            {formatDate(act.timestamp)}
                          </span>
                          <span className="text-[10px] text-[#5f6b7a]/40">
                            ({timeAgo(act.timestamp)})
                          </span>
                        </div>
                      </div>

                      {/* Amount badge */}
                      {act.metadata?.amount && (
                        <div className="shrink-0 text-left">
                          <span
                            className="text-xs px-2.5 py-1 rounded-lg font-medium"
                            style={{ backgroundColor: `${color}10`, color }}
                          >
                            {Number(act.metadata.amount).toLocaleString("en-US")} ج.م
                          </span>
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}