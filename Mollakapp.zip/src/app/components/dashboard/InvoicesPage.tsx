import { useState, useMemo, useEffect, useCallback } from "react";
import { Plus, Search, CheckCircle2, Clock, XCircle, Eye, X, Trash2, FileText, Home, UserX, Check, Users, Tag, ChevronDown, ChevronUp, ChevronLeft, ArrowRight, Pencil, Loader2, Hourglass, ShieldCheck, Repeat, CircleStop, RotateCcw, MoreVertical, Calendar, Banknote, Wallet } from "lucide-react";
import * as api from "../../lib/api";
import { MobileFAB } from "./MobileFAB";

// ===== Arabic Month Names =====
const ARABIC_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
];

function toMonthValue(arabic: string): string {
  const parts = arabic.trim().split(" ");
  if (parts.length < 2) return "";
  const mi = ARABIC_MONTHS.indexOf(parts[0]);
  if (mi === -1) return "";
  return `${parts[1]}-${String(mi + 1).padStart(2, "0")}`;
}

function toArabicMonth(monthVal: string): string {
  if (!monthVal) return "";
  const [y, m] = monthVal.split("-");
  const mi = parseInt(m, 10) - 1;
  if (mi < 0 || mi > 11) return "";
  return `${ARABIC_MONTHS[mi]} ${y}`;
}

// ===== Building Units Data =====
interface Unit {
  id: string;
  label: string;
  unitCode: string;
  floor: string;
  floorLabel: string;
  occupied: boolean;
  resident?: string;
  ownerName: string;
}

// buildingUnits loaded from API

// ===== Data Interfaces =====
interface Invoice {
  id: string;
  resident: string;
  unit: string;
  floor: string;
  amount: number;
  status: "paid" | "pending" | "overdue" | "awaiting_collection";
  method: string;
  occupied: boolean;
  paidDate?: string;
}

interface InvoiceBatch {
  id: string;
  description: string;
  scope: "عام" | "مخصص";
  type?: "دائم" | "مؤقت";
  date: string;
  dueDate: string;
  stoppedAt?: string;
  createdAt?: string;
  invoices: Invoice[];
}

// ===== Initial Data (loaded from API) =====

const statusConfig: Record<string, { label: string; color: string; bg: string; icon: typeof CheckCircle2 }> = {
  paid: { label: "مدفوعة", color: "text-green-600", bg: "bg-green-50", icon: CheckCircle2 },
  pending: { label: "معلقة", color: "text-amber-600", bg: "bg-amber-50", icon: Clock },
  overdue: { label: "متأخرة", color: "text-red-600", bg: "bg-red-50", icon: XCircle },
  awaiting_collection: { label: "بانتظار التحصيل", color: "text-indigo-600", bg: "bg-indigo-50", icon: Hourglass },
};

// ===== Form State =====
interface CreateForm {
  scope: "عام" | "مخصص";
  type: "دائم" | "مؤقت";
  selectedUnitIds: string[];
  description: string;
  amountOccupied: number;
  amountVacant: number;
  sameAmount: boolean;
  dueDate: string;
}

const emptyCreateForm: CreateForm = {
  scope: "عام",
  type: "دائم",
  selectedUnitIds: [],
  description: "اشتراك صيانة",
  amountOccupied: 1250,
  amountVacant: 1250,
  sameAmount: true,
  dueDate: "مارس 2026",
};

// ===== Mini Donut Chart Component =====
function MiniDonut({ paid, total, size = 48 }: { paid: number; total: number; size?: number }) {
  const pct = total === 0 ? 0 : paid / total;
  const r = (size - 6) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ * (1 - pct);
  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#e5e7eb" strokeWidth={5} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#0D9488" strokeWidth={5} strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round" className="transition-all duration-500" />
      </svg>
      <span className="absolute text-[10px] text-[#0D9488]">{Math.round(pct * 100)}%</span>
    </div>
  );
}

// ===== Main Component =====
export function InvoicesPage() {
  const [batches, setBatches] = useState<InvoiceBatch[]>([]);
  const [buildingUnits, setBuildingUnits] = useState<Unit[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [viewInvoice, setViewInvoice] = useState<{ batch: InvoiceBatch; invoice: Invoice } | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [openBatchId, setOpenBatchId] = useState<string | null>(null);
  const [invoiceFilter, setInvoiceFilter] = useState("all");

  const [togglingStop, setTogglingStop] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [actionSheetBatch, setActionSheetBatch] = useState<InvoiceBatch | null>(null);

  // Create form
  const [form, setForm] = useState<CreateForm>(emptyCreateForm);
  const [showPreview, setShowPreview] = useState(false);

  // Edit batch state
  const [editBatchId, setEditBatchId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({ description: "", dueDate: "", amountOccupied: 0, amountVacant: 0, sameAmount: true });

  // ===== Load data from API =====
  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      const [unitsData, batchesData] = await Promise.all([
        api.getUnits(),
        api.getInvoiceBatches(),
      ]);
      setBuildingUnits(unitsData);
      setBatches(batchesData);
    } catch (err) {
      console.error("Error loading invoices data:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  function getFloors() {
    const floors: Record<string, Unit[]> = {};
    buildingUnits.forEach((u) => {
      if (!floors[u.floorLabel]) floors[u.floorLabel] = [];
      floors[u.floorLabel].push(u);
    });
    return Object.entries(floors);
  }

  // ===== Derived stats =====
  const allInvoicesFlat = useMemo(() => batches.flatMap((b) => b.invoices), [batches]);
  const totalPaid = allInvoicesFlat.filter((i) => i.status === "paid").length;
  const totalPending = allInvoicesFlat.filter((i) => i.status === "pending").length;
  const totalOverdue = allInvoicesFlat.filter((i) => i.status === "overdue").length;
  const totalAwaiting = allInvoicesFlat.filter((i) => i.status === "awaiting_collection").length;

  // ===== Search filter on batches =====
  const filteredBatches = batches.filter(
    (b) =>
      searchQuery === "" ||
      b.description.includes(searchQuery) ||
      b.id.includes(searchQuery) ||
      b.invoices.some((inv) => inv.resident.includes(searchQuery))
  );

  // ===== Active batch (detail view) =====
  const activeBatch = batches.find((b) => b.id === openBatchId) || null;

  const filteredBatchInvoices = useMemo(() => {
    if (!activeBatch) return [];
    return activeBatch.invoices.filter((inv) => invoiceFilter === "all" || inv.status === invoiceFilter);
  }, [activeBatch, invoiceFilter]);

  // ===== Targeted units for form =====
  const targetedUnits = useMemo(() => {
    if (form.scope === "عام") return buildingUnits;
    return buildingUnits.filter((u) => form.selectedUnitIds.includes(u.id));
  }, [form.scope, form.selectedUnitIds, buildingUnits]);

  const occupiedCount = targetedUnits.filter((u) => u.occupied).length;
  const vacantCount = targetedUnits.filter((u) => !u.occupied).length;

  const totalAmount = useMemo(() => {
    const occAmt = form.amountOccupied;
    const vacAmt = form.sameAmount ? form.amountOccupied : form.amountVacant;
    return occupiedCount * occAmt + vacantCount * vacAmt;
  }, [form.amountOccupied, form.amountVacant, form.sameAmount, occupiedCount, vacantCount]);

  // ===== Actions =====
  const openCreate = () => {
    setForm(emptyCreateForm);
    setShowPreview(false);
    setShowModal(true);
  };

  const handleCreate = async () => {
    if (!form.description || targetedUnits.length === 0) return;
    setSaving(true);
    try {
      const now = new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });
      const batchNum = batches.length + 1;
      const batchId = `BATCH-${String(batchNum).padStart(3, "0")}-${Date.now()}`;

      const newInvoices: Invoice[] = targetedUnits.map((unit, idx) => {
        const amount = unit.occupied
          ? form.amountOccupied
          : (form.sameAmount ? form.amountOccupied : form.amountVacant);
        return {
          id: `INV-${batchId}-${String(idx + 1).padStart(2, "0")}`,
          resident: unit.occupied ? (unit.resident || unit.ownerName) : unit.ownerName,
          unit: unit.unitCode,
          floor: unit.floorLabel,
          amount,
          status: "pending" as const,
          method: "-",
          occupied: unit.occupied,
        };
      });

      const newBatch: InvoiceBatch = {
        id: batchId,
        description: form.description,
        scope: form.scope,
        type: form.type,
        date: now,
        dueDate: form.dueDate,
        createdAt: new Date().toISOString(),
        invoices: newInvoices,
      };

      await api.createInvoiceBatch(newBatch);
      setBatches((prev) => [newBatch, ...prev]);
      setShowModal(false);
      showSucc(`تم إنشاء فاتورة "${form.description}" تشمل ${newInvoices.length} وحدة`);
    } catch (err) {
      console.error("Error creating invoice batch:", err);
      showSucc("حدث خطأ أثناء إنشاء الفاتورة");
    } finally {
      setSaving(false);
    }
  };

  const markPaid = async (batchId: string, invoiceId: string) => {
    try {
      const batch = batches.find((b) => b.id === batchId);
      const invoice = batch?.invoices.find((inv) => inv.id === invoiceId);
      const wasAwaiting = invoice?.status === "awaiting_collection";
      const method = wasAwaiting ? "كاش عبر الأمن" : "كاش";
      
      await api.markInvoicePaid(batchId, invoiceId, method);
      setBatches((prev) =>
        prev.map((b) =>
          b.id === batchId
            ? { ...b, invoices: b.invoices.map((inv) => inv.id === invoiceId ? { ...inv, status: "paid" as const, method } : inv) }
            : b
        )
      );
      setViewInvoice(null);
      showSucc(wasAwaiting ? "تم تأكيد التحصيل بنجاح ✅" : "تم تسجيل الدفع");
    } catch (err) {
      console.error("Error marking invoice as paid:", err);
      showSucc("حدث خطأ أثناء تسجيل الدفع");
    }
  };

  const deleteBatch = async (batchId: string) => {
    try {
      await api.deleteInvoiceBatch(batchId);
      setBatches((prev) => prev.filter((b) => b.id !== batchId));
      setDeleteConfirm(null);
      if (openBatchId === batchId) setOpenBatchId(null);
      showSucc("تم حذف الفاتورة");
    } catch (err) {
      console.error("Error deleting invoice batch:", err);
      showSucc("حدث خطأ أثناء حذف الفاتورة");
    }
  };

  // ===== Edit batch =====
  const openEditBatch = (batch: InvoiceBatch) => {
    const occupiedAmounts = batch.invoices.filter((i) => i.occupied).map((i) => i.amount);
    const vacantAmounts = batch.invoices.filter((i) => !i.occupied).map((i) => i.amount);
    const occAmt = occupiedAmounts.length > 0 ? occupiedAmounts[0] : 0;
    const vacAmt = vacantAmounts.length > 0 ? vacantAmounts[0] : occAmt;
    setEditForm({
      description: batch.description,
      dueDate: batch.dueDate,
      amountOccupied: occAmt,
      amountVacant: vacAmt,
      sameAmount: occAmt === vacAmt,
    });
    setEditBatchId(batch.id);
  };

  const handleEditSave = async () => {
    if (!editBatchId || !editForm.description) return;
    setSaving(true);
    try {
      const batch = batches.find((b) => b.id === editBatchId);
      if (!batch) return;
      const updatedInvoices = batch.invoices.map((inv) => {
        if (inv.status === "paid") return inv;
        const newAmount = inv.occupied
          ? editForm.amountOccupied
          : (editForm.sameAmount ? editForm.amountOccupied : editForm.amountVacant);
        return { ...inv, amount: newAmount };
      });
      const updatedBatch = { ...batch, description: editForm.description, dueDate: editForm.dueDate, invoices: updatedInvoices };
      await api.updateInvoiceBatch(editBatchId, updatedBatch);
      setBatches((prev) =>
        prev.map((b) => b.id === editBatchId ? updatedBatch : b)
      );
      setEditBatchId(null);
      showSucc("تم تحديث الفاتورة بنجاح");
    } catch (err) {
      console.error("Error updating invoice batch:", err);
      showSucc("حدث خطأ أثناء تحديث الفاتورة");
    } finally {
      setSaving(false);
    }
  };

  const showSucc = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };

  const handleToggleStop = async (batch: InvoiceBatch) => {
    setTogglingStop(batch.id);
    try {
      if (batch.stoppedAt) {
        await api.reactivateInvoiceBatch(batch.id);
        setBatches((prev) => prev.map((b) => b.id === batch.id ? { ...b, stoppedAt: undefined } : b));
        showSucc(`تم إعادة تفعيل "${batch.description}"`);
      } else {
        await api.stopInvoiceBatch(batch.id);
        setBatches((prev) => prev.map((b) => b.id === batch.id ? { ...b, stoppedAt: new Date().toISOString() } : b));
        showSucc(`تم إيقاف "${batch.description}"`);
      }
    } catch (err) {
      console.error("Error toggling invoice batch stop:", err);
      showSucc("حدث خطأ أثناء تغيير حالة الفاتورة");
    } finally {
      setTogglingStop(null);
    }
  };

  // Unit selection helpers
  const toggleUnit = (unitId: string) => {
    setForm((prev) => ({
      ...prev,
      selectedUnitIds: prev.selectedUnitIds.includes(unitId)
        ? prev.selectedUnitIds.filter((id) => id !== unitId)
        : [...prev.selectedUnitIds, unitId],
    }));
  };

  const selectAllFloor = (floorUnits: Unit[]) => {
    const allIds = floorUnits.map((u) => u.id);
    const allSelected = allIds.every((id) => form.selectedUnitIds.includes(id));
    if (allSelected) {
      setForm((prev) => ({ ...prev, selectedUnitIds: prev.selectedUnitIds.filter((id) => !allIds.includes(id)) }));
    } else {
      setForm((prev) => ({ ...prev, selectedUnitIds: [...new Set([...prev.selectedUnitIds, ...allIds])] }));
    }
  };

  const canCreate = form.description && (form.scope === "عام" || form.selectedUnitIds.length > 0) && form.amountOccupied > 0;

  // ===== Helper: batch stats =====
  function batchStats(batch: InvoiceBatch) {
    const total = batch.invoices.length;
    const paid = batch.invoices.filter((i) => i.status === "paid").length;
    const pending = batch.invoices.filter((i) => i.status === "pending").length;
    const overdue = batch.invoices.filter((i) => i.status === "overdue").length;
    const awaiting = batch.invoices.filter((i) => i.status === "awaiting_collection").length;
    const totalAmount = batch.invoices.reduce((sum, i) => sum + i.amount, 0);
    const paidAmount = batch.invoices.filter((i) => i.status === "paid").reduce((sum, i) => sum + i.amount, 0);
    return { total, paid, pending, overdue, awaiting, totalAmount, paidAmount };
  }

  // ===== RENDER =====

  // Loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin mx-auto mb-3" />
          <p className="text-sm text-[#5f6b7a]">جاري تحميل الفواتير...</p>
        </div>
      </div>
    );
  }

  // If a batch is open, show detail view
  if (activeBatch) {
    const stats = batchStats(activeBatch);
    return (
      <div className="space-y-6">
        {successMsg && (
          <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
            <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
          </div>
        )}

        {/* Header with back button */}
        <div className="flex items-center gap-3">
          <button onClick={() => { setOpenBatchId(null); setInvoiceFilter("all"); }} className="w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-[#0D9488]/10 hover:bg-[#0D9488]/5 transition-colors">
            <ArrowRight className="w-5 h-5 text-[#0D9488]" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-lg sm:text-xl text-[#1a1a2e] truncate">{activeBatch.description}</h1>
            <p className="text-xs text-[#5f6b7a]">{activeBatch.date}</p>
          </div>
          {activeBatch.type === "دائم" && (
            activeBatch.stoppedAt ? (
              <button
                onClick={() => handleToggleStop(activeBatch)}
                disabled={togglingStop === activeBatch.id}
                className="h-10 px-3 flex items-center gap-1.5 rounded-xl bg-white border border-[#0D9488]/20 text-[#0D9488] text-xs hover:bg-[#0D9488]/5 transition-colors"
              >
                {togglingStop === activeBatch.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
                تفعيل
              </button>
            ) : (
              <button
                onClick={() => handleToggleStop(activeBatch)}
                disabled={togglingStop === activeBatch.id}
                className="h-10 px-3 flex items-center gap-1.5 rounded-xl bg-white border border-[#F59E0B]/20 text-[#F59E0B] text-xs hover:bg-[#F59E0B]/5 transition-colors"
              >
                {togglingStop === activeBatch.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CircleStop className="w-4 h-4" />}
                إيقاف
              </button>
            )
          )}
          <button onClick={() => openEditBatch(activeBatch)} className="w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-[#0D9488]/10 hover:bg-[#0D9488]/5 transition-colors">
            <Pencil className="w-4 h-4 text-[#0D9488]" />
          </button>
          <button onClick={() => setDeleteConfirm(activeBatch.id)} className="w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-red-100 hover:bg-red-50 transition-colors">
            <Trash2 className="w-4 h-4 text-red-400" />
          </button>
        </div>

        {/* Batch summary card */}
        <div className="bg-white rounded-2xl border border-[#0D9488]/10 p-4 sm:p-5">
          {/* Top: Donut + amounts */}
          <div className="flex items-center gap-4 sm:gap-5">
            <MiniDonut paid={stats.paid} total={stats.total} size={56} />
            <div className="flex-1 min-w-0 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#5f6b7a]">الإجمالي</span>
                <span className="text-lg text-[#0D9488]">{stats.totalAmount.toLocaleString("en-US")} <span className="text-xs">ج.م</span></span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#5f6b7a]">المحصّل</span>
                <span className="text-sm text-green-600">{stats.paidAmount.toLocaleString("en-US")} ج.م</span>
              </div>
              <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-[#0D9488] rounded-full transition-all duration-500" style={{ width: `${stats.total === 0 ? 0 : (stats.paid / stats.total) * 100}%` }} />
              </div>
            </div>
          </div>
          {/* Status counts */}
          <div className="flex items-center gap-2 sm:gap-3 mt-3 text-[10px] sm:text-xs text-[#5f6b7a] flex-wrap">
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500" />{stats.paid} مدفوعة</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-400" />{stats.pending} معلقة</span>
            {stats.awaiting > 0 && <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-indigo-400" />{stats.awaiting} بانتظار</span>}
            {stats.overdue > 0 && <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-400" />{stats.overdue} متأخرة</span>}
          </div>
          {/* Meta info */}
          <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-gray-100 text-[10px] sm:text-xs text-[#5f6b7a]">
            <div className="text-center sm:text-right">
              <span className="text-[#5f6b7a]/60 block">النطاق</span>
              <span className="mt-0.5 block truncate">
                {activeBatch.scope === "عام" ? `عام — ${stats.total}` : `مخصص — ${stats.total}`}
              </span>
            </div>
            <div className="text-center sm:text-right">
              <span className="text-[#5f6b7a]/60 block">النوع</span>
              <span className="mt-0.5 block truncate">
                {activeBatch.type === "دائم" ? (activeBatch.stoppedAt ? "دائمة — متوقفة" : "دائمة — شهرية") : "مؤقتة"}
              </span>
            </div>
            <div className="text-center sm:text-right">
              <span className="text-[#5f6b7a]/60 block">الاستحقاق</span>
              <span className="mt-0.5 block truncate">{activeBatch.dueDate}</span>
            </div>
          </div>
        </div>

        {/* Filter tabs for invoices */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {[
            { key: "all", label: "الكل", count: stats.total },
            { key: "paid", label: "مدفوعة", count: stats.paid },
            { key: "pending", label: "معلقة", count: stats.pending },
            { key: "awaiting_collection", label: "بانتظار التحصيل", count: stats.awaiting },
            { key: "overdue", label: "متأخرة", count: stats.overdue },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setInvoiceFilter(tab.key)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs whitespace-nowrap transition-all ${
                invoiceFilter === tab.key ? "bg-[#0D9488] text-white shadow-sm" : "bg-white text-[#5f6b7a] border border-gray-100 hover:bg-[#0D9488]/5"
              }`}
            >
              {tab.label}
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${invoiceFilter === tab.key ? "bg-white/20" : "bg-[#0D9488]/10 text-[#0D9488]"}`}>{tab.count}</span>
            </button>
          ))}
        </div>

        {/* Individual invoices list */}
        <div className="space-y-2">
          {filteredBatchInvoices.map((invoice) => {
            const status = statusConfig[invoice.status];
            return (
              <div key={invoice.id} className="bg-white rounded-xl border border-gray-100 p-4 hover:shadow-sm transition-all">
                <div className="flex items-center gap-3">
                  {/* Status icon */}
                  <div className={`w-9 h-9 rounded-lg ${status.bg} flex items-center justify-center shrink-0`}>
                    <status.icon className={`w-4 h-4 ${status.color}`} />
                  </div>
                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-[#1a1a2e] truncate">{invoice.resident}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full shrink-0 ${
                        invoice.occupied ? "bg-green-50 text-green-600" : "bg-amber-50 text-amber-600"
                      }`}>
                        {invoice.occupied ? "شاغرة" : "غير شاغرة"}
                      </span>
                    </div>
                    <div className="text-xs text-[#5f6b7a]">شقة {invoice.unit} — الدور {invoice.floor}</div>
                  </div>
                  {/* Amount */}
                  <div className="text-left shrink-0">
                    <div className="text-sm text-[#0D9488]">{invoice.amount.toLocaleString("en-US")} ج.م</div>
                    <div className={`text-[10px] ${status.color}`}>{status.label}</div>
                  </div>
                  {/* Actions */}
                  <div className="flex items-center gap-1 shrink-0">
                    {invoice.status === "awaiting_collection" && (
                      <button onClick={() => markPaid(activeBatch.id, invoice.id)} className="px-2.5 py-1.5 flex items-center gap-1.5 rounded-lg bg-[#0D9488] text-white hover:bg-[#0D9488]/90 transition-colors text-xs shadow-sm" title="تأكيد التحصيل">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        تم التحصيل
                      </button>
                    )}
                    {(invoice.status === "pending" || invoice.status === "overdue") && (
                      <button onClick={() => markPaid(activeBatch.id, invoice.id)} className="w-8 h-8 flex items-center justify-center rounded-lg bg-[#0D9488]/5 hover:bg-[#0D9488]/10 transition-colors" title="تسجيل دفع">
                        <CheckCircle2 className="w-4 h-4 text-[#0D9488]" />
                      </button>
                    )}
                    <button onClick={() => setViewInvoice({ batch: activeBatch, invoice })} className="w-8 h-8 flex items-center justify-center rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors" title="عرض التفاصيل">
                      <Eye className="w-4 h-4 text-[#5f6b7a]" />
                    </button>
                  </div>
                </div>
                {invoice.status === "awaiting_collection" && (
                  <div className="mt-2 mr-12 text-[10px] text-indigo-600 bg-indigo-50 px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 w-fit">
                    <ShieldCheck className="w-3 h-3" />
                    الساكن سلّم المبلغ للأمن — في انتظار تأكيد التحصيل
                  </div>
                )}
                {invoice.status === "paid" && (
                  <div className="mt-2 mr-12 text-[10px] text-green-600 bg-green-50 px-2.5 py-1 rounded-lg inline-block">تم الدفع عبر: {invoice.method}</div>
                )}
              </div>
            );
          })}
        </div>

        {filteredBatchInvoices.length === 0 && (
          <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center text-sm text-[#5f6b7a]">لا توجد فواتير مطابقة للفلتر</div>
        )}

        {/* View Invoice Modal */}
        {viewInvoice && (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setViewInvoice(null)}>
            <div className="bg-white rounded-2xl w-full max-w-md" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
                <h3 className="text-lg text-[#1a1a2e]">تفاصيل الفاتورة</h3>
                <button onClick={() => setViewInvoice(null)} className="text-[#5f6b7a]"><X className="w-5 h-5" /></button>
              </div>
              <div className="p-5">
                <div className="text-center mb-5">
                  <div className="w-14 h-14 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto mb-3">
                    <FileText className="w-7 h-7 text-[#0D9488]" />
                  </div>
                  <div className="text-xs text-[#5f6b7a]">{viewInvoice.invoice.id}</div>
                  <div className="text-3xl text-[#0D9488] mt-2">{viewInvoice.invoice.amount.toLocaleString("en-US")} ج.م</div>
                </div>
                <div className="space-y-3 bg-[#f8fffe] rounded-xl p-4">
                  <div className="flex justify-between text-sm"><span className="text-[#5f6b7a]">الساكن/المالك</span><span className="text-[#1a1a2e]">{viewInvoice.invoice.resident}</span></div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[#5f6b7a]">الشقة</span>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[#1a1a2e]">شقة {viewInvoice.invoice.unit}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                        viewInvoice.invoice.occupied ? "bg-green-50 text-green-600" : "bg-amber-50 text-amber-600"
                      }`}>
                        {viewInvoice.invoice.occupied ? "شاغرة" : "غير شاغرة"}
                      </span>
                    </div>
                  </div>
                  <div className="flex justify-between text-sm"><span className="text-[#5f6b7a]">الفاتورة الأم</span><span className="text-[#1a1a2e]">{viewInvoice.batch.description}</span></div>
                  <div className="flex justify-between text-sm"><span className="text-[#5f6b7a]">النطاق</span><span className="text-[#1a1a2e]">{viewInvoice.batch.scope}</span></div>
                  <div className="flex justify-between text-sm"><span className="text-[#5f6b7a]">النوع</span>
                    <span className="text-[#1a1a2e] flex items-center gap-1">
                      {viewInvoice.batch.type === "دائم" ? <><Repeat className="w-3 h-3 text-[#0D9488]" />دائمة (شهرية)</> : <><Clock className="w-3 h-3" />مؤقتة</>}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm"><span className="text-[#5f6b7a]">تاريخ الإصدار</span><span className="text-[#1a1a2e]">{viewInvoice.batch.date}</span></div>
                  <div className="flex justify-between text-sm"><span className="text-[#5f6b7a]">تاريخ الاستحقاق</span><span className="text-[#1a1a2e]">{viewInvoice.batch.dueDate}</span></div>
                  <div className="flex justify-between text-sm"><span className="text-[#5f6b7a]">الحالة</span>
                    <span className={`${statusConfig[viewInvoice.invoice.status].color}`}>{statusConfig[viewInvoice.invoice.status].label}</span>
                  </div>
                  {(viewInvoice.invoice.status === "paid" || viewInvoice.invoice.status === "awaiting_collection") && (
                    <div className="flex justify-between text-sm"><span className="text-[#5f6b7a]">طريقة الدفع</span><span className="text-[#1a1a2e]">{viewInvoice.invoice.method}</span></div>
                  )}
                  {viewInvoice.invoice.status === "awaiting_collection" && (
                    <div className="bg-indigo-50 border border-indigo-100 rounded-lg p-3 flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-indigo-500 shrink-0" />
                      <span className="text-xs text-indigo-700">الساكن سلّم المبلغ للأمن — في انتظار تأكيد التحصيل</span>
                    </div>
                  )}
                </div>
                <div className="mt-5 flex gap-3">
                  {viewInvoice.invoice.status === "awaiting_collection" && (
                    <button onClick={() => markPaid(viewInvoice.batch.id, viewInvoice.invoice.id)} className="flex-1 py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 flex items-center justify-center gap-2">
                      <ShieldCheck className="w-4 h-4" />تم التحصيل
                    </button>
                  )}
                  {(viewInvoice.invoice.status === "pending" || viewInvoice.invoice.status === "overdue") && (
                    <button onClick={() => markPaid(viewInvoice.batch.id, viewInvoice.invoice.id)} className="flex-1 py-3 rounded-xl bg-[#0D9488] text-white text-sm hover:bg-[#0D9488]/90 flex items-center justify-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />تسجيل دفع
                    </button>
                  )}
                  <button onClick={() => setViewInvoice(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إغلاق</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Edit Batch Modal */}
        {editBatchId && (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setEditBatchId(null)}>
            <div className="bg-white rounded-2xl w-full max-w-md max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-[#0D9488]/10 rounded-lg flex items-center justify-center">
                    <Pencil className="w-4 h-4 text-[#0D9488]" />
                  </div>
                  <h3 className="text-lg text-[#1a1a2e]">تعديل الفاتورة</h3>
                </div>
                <button onClick={() => setEditBatchId(null)} className="text-[#5f6b7a] hover:text-[#1a1a2e]"><X className="w-5 h-5" /></button>
              </div>
              <div className="p-5 space-y-5">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">وصف الفاتورة *</label>
                  <input type="text" value={editForm.description} onChange={(e) => setEditForm({ ...editForm, description: e.target.value })} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
                {batches.find(b => b.id === editBatchId)?.type !== "دائم" && (
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">شهر الاستحقاق</label>
                  <input type="month" value={toMonthValue(editForm.dueDate)} onChange={(e) => setEditForm({ ...editForm, dueDate: toArabicMonth(e.target.value) })} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
                )}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs text-[#5f6b7a]">المبلغ (للفواتير غير المدفوعة)</label>
                    <button onClick={() => setEditForm({ ...editForm, sameAmount: !editForm.sameAmount, amountVacant: editForm.amountOccupied })} className={`flex items-center gap-1.5 text-[10px] px-2 py-1 rounded-lg transition-all ${!editForm.sameAmount ? "bg-[#F59E0B]/10 text-[#F59E0B] border border-[#F59E0B]/20" : "bg-gray-50 text-[#5f6b7a] border border-gray-100"}`}>
                      {!editForm.sameAmount ? <CheckCircle2 className="w-3 h-3" /> : <span className="w-3 h-3 rounded-full border-2 border-gray-300 inline-block" />}
                      مبلغ مختلف
                    </button>
                  </div>
                  {editForm.sameAmount ? (
                    <div>
                      <input type="number" value={editForm.amountOccupied || ""} onChange={(e) => setEditForm({ ...editForm, amountOccupied: Number(e.target.value), amountVacant: Number(e.target.value) })} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                      <span className="text-[10px] text-[#5f6b7a] mt-1 block">ج.م / وحدة</span>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-green-50/50 border border-green-100 rounded-xl p-3">
                        <div className="flex items-center gap-1 mb-1.5"><Home className="w-3 h-3 text-green-500" /><span className="text-[10px] text-green-700">شاغرة</span></div>
                        <input type="number" value={editForm.amountOccupied || ""} onChange={(e) => setEditForm({ ...editForm, amountOccupied: Number(e.target.value) })} className="w-full px-3 py-2 bg-white border border-green-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-200" />
                      </div>
                      <div className="bg-amber-50/50 border border-amber-100 rounded-xl p-3">
                        <div className="flex items-center gap-1 mb-1.5"><UserX className="w-3 h-3 text-amber-500" /><span className="text-[10px] text-amber-700">غير شاغرة</span></div>
                        <input type="number" value={editForm.amountVacant || ""} onChange={(e) => setEditForm({ ...editForm, amountVacant: Number(e.target.value) })} className="w-full px-3 py-2 bg-white border border-amber-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-200" />
                      </div>
                    </div>
                  )}
                </div>
                <div className="bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-xl p-3">
                  <div className="text-xs text-[#5f6b7a] leading-relaxed">تغيير المبلغ سيُطبّق فقط على الفواتير <span className="text-[#1a1a2e]">غير المدفوعة</span>. الفواتير التي تم دفعها بالفعل لن تتأثر.</div>
                </div>
              </div>
              <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
                <button onClick={() => setEditBatchId(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
                <button onClick={handleEditSave} disabled={!editForm.description} className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${editForm.description ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20" : "bg-gray-300 cursor-not-allowed"}`}>
                  <CheckCircle2 className="w-4 h-4" />حفظ التعديلات
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Delete Confirmation */}
        {deleteConfirm && (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
            <div className="bg-white rounded-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
              <div className="text-center mb-5">
                <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3"><Trash2 className="w-7 h-7 text-red-500" /></div>
                <h3 className="text-lg text-[#1a1a2e] mb-1">حذف الفاتورة</h3>
                <p className="text-sm text-[#5f6b7a]">هل أنت متأكد من حذف هذه الفاتورة وجميع الفواتير الفردية بداخلها؟</p>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
                <button onClick={() => deleteBatch(deleteConfirm)} className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm hover:bg-red-600">نعم، احذف</button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ===== MAIN BATCHES LIST VIEW =====
  return (
    <div className="space-y-6">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl text-[#1a1a2e]">الفواتير</h1>
          <p className="text-sm text-[#5f6b7a]">إدارة ومتابعة فواتير السكان</p>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Search icon */}
          <button
            onClick={() => { setSearchOpen(true); setTimeout(() => document.getElementById("invoices-search-input")?.focus(), 50); }}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              searchQuery ? "bg-[#0D9488] text-white shadow-sm" : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:border-[#0D9488]/30"
            }`}
          >
            <Search className="w-4 h-4" />
          </button>
          {/* Add button (desktop) */}
          <button onClick={openCreate} className="hidden sm:flex w-9 h-9 rounded-xl items-center justify-center bg-[#0D9488] text-white hover:bg-[#0D9488]/90 transition-colors shadow-sm" title="إنشاء فاتورة">
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Expandable Search Bar */}
      {searchOpen && (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#5f6b7a]" />
            <input
              id="invoices-search-input"
              type="text"
              placeholder="ابحث باسم الفاتورة أو الساكن..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 bg-white border border-[#0D9488]/15 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm"
            />
          </div>
          <button
            onClick={() => { setSearchOpen(false); setSearchQuery(""); }}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#5f6b7a] bg-white border border-gray-100 hover:bg-gray-50 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-white rounded-xl border border-gray-100 px-3 py-2.5 shadow-sm text-center">
          <CheckCircle2 className="w-4 h-4 text-green-600 mx-auto mb-1" />
          <div className="text-base font-semibold text-[#1a1a2e]">{totalPaid}</div>
          <div className="text-xs text-[#5f6b7a]">مدفوعة</div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 px-3 py-2.5 shadow-sm text-center">
          <Clock className="w-4 h-4 text-amber-500 mx-auto mb-1" />
          <div className="text-base font-semibold text-[#1a1a2e]">{totalPending}</div>
          <div className="text-xs text-[#5f6b7a]">معلقة</div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 px-3 py-2.5 shadow-sm text-center">
          <XCircle className="w-4 h-4 text-red-500 mx-auto mb-1" />
          <div className="text-base font-semibold text-[#1a1a2e]">{totalOverdue + totalAwaiting}</div>
          <div className="text-xs text-[#5f6b7a]">متأخرة/بانتظار</div>
        </div>
      </div>

      {/* Batch cards */}
      <div className="space-y-3">
        {filteredBatches.map((batch) => {
          const stats = batchStats(batch);
          const paidPct = stats.total === 0 ? 0 : Math.round((stats.paid / stats.total) * 100);
          const isStopped = !!batch.stoppedAt;
          const iconColor = isStopped ? "#dc2626" : batch.type === "دائم" ? "#0D9488" : "#6366f1";
          const IconComp = batch.type === "دائم" ? Repeat : FileText;

          return (
            <div
              key={batch.id}
              className={`bg-white rounded-2xl border shadow-sm overflow-hidden ${isStopped ? "border-red-200/60" : "border-gray-100"}`}
            >
              <div className="p-4" style={{ backgroundColor: isStopped ? '#fef2f208' : `${iconColor}04` }}>

                {/* ── Header: Icon circle + Title + Date + 3-dots ── */}
                <div className="flex items-start gap-3 mb-3">
                  <div className="relative shrink-0">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: `${iconColor}15` }}>
                      <IconComp className="w-4.5 h-4.5" style={{ color: iconColor }} />
                    </div>
                    {/* Collection % indicator dot */}
                    <div className={`absolute -bottom-0.5 -left-0.5 w-3 h-3 rounded-full border-2 border-white`} style={{ backgroundColor: paidPct === 100 ? '#22c55e' : paidPct > 50 ? '#0D9488' : '#F59E0B' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-[#1a1a2e] truncate">{batch.description}</span>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="text-[10px] text-[#5f6b7a]">{batch.date}</span>
                        <button
                          onClick={(e) => { e.stopPropagation(); setActionSheetBatch(actionSheetBatch?.id === batch.id ? null : batch); }}
                          className="w-7 h-7 rounded-lg flex items-center justify-center text-[#5f6b7a] hover:bg-black/5 active:bg-black/10 transition-colors"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    {/* Badges row */}
                    <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                      {batch.type === "دائم" && !isStopped && (
                        <span className="text-[10px] px-1.5 py-px rounded-full font-medium" style={{ backgroundColor: '#0D948812', color: '#0D9488' }}>
                          دائمة — شهرية
                        </span>
                      )}
                      {batch.type === "دائم" && isStopped && (
                        <span className="text-[10px] px-1.5 py-px rounded-full font-medium bg-red-50 text-red-500">
                          متوقفة
                        </span>
                      )}
                      {batch.type === "مؤقت" && (
                        <span className="text-[10px] px-1.5 py-px rounded-full bg-gray-50 text-[#5f6b7a]">مؤقتة</span>
                      )}
                      {batch.scope === "مخصص" && (
                        <span className="text-[10px] px-1.5 py-px rounded-full font-medium" style={{ backgroundColor: '#F59E0B12', color: '#F59E0B' }}>
                          مخصص
                        </span>
                      )}
                      {batch.scope === "عام" && (
                        <span className="text-[10px] px-1.5 py-px rounded-full bg-gray-50 text-[#5f6b7a]">عام</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* ── Info Grid — 4 columns ── */}
                <div className="grid grid-cols-4 gap-2 mb-3">
                  <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                    <div className="text-[9px] text-[#5f6b7a]">الوحدات</div>
                    <div className="text-xs text-[#1a1a2e] font-medium">{stats.total}</div>
                  </div>
                  <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                    <div className="text-[9px] text-[#5f6b7a]">الإجمالي</div>
                    <div className="text-xs text-[#0D9488] font-medium">{stats.totalAmount.toLocaleString("en-US")}</div>
                  </div>
                  <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                    <div className="text-[9px] text-[#5f6b7a]">المحصّل</div>
                    <div className="text-xs font-bold" style={{ color: stats.paidAmount > 0 ? '#22c55e' : '#5f6b7a' }}>
                      {stats.paidAmount.toLocaleString("en-US")}
                    </div>
                  </div>
                  <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                    <div className="text-[9px] text-[#5f6b7a]">الاستحقاق</div>
                    <div className="text-[10px] text-[#1a1a2e] font-medium">{batch.dueDate}</div>
                  </div>
                </div>

                {/* ── Progress hint ── */}
                <div className="flex items-center gap-2 mb-3 px-0.5">
                  <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{
                      width: `${paidPct}%`,
                      backgroundColor: paidPct === 100 ? "#10b981" : "#0D9488"
                    }} />
                  </div>
                  <span className="text-[10px] text-[#5f6b7a] shrink-0">{paidPct}% ({stats.paid}/{stats.total})</span>
                </div>

                {/* ── Status badges hint ── */}
                {(stats.pending > 0 || stats.overdue > 0 || stats.awaiting > 0) && (
                  <div className="flex items-center gap-1.5 mb-3 px-0.5 flex-wrap">
                    {stats.pending > 0 && (
                      <span className="text-[10px] text-amber-600 flex items-center gap-0.5">
                        <Clock className="w-3 h-3" />{stats.pending} معلقة
                      </span>
                    )}
                    {stats.awaiting > 0 && (
                      <span className="text-[10px] text-indigo-600 flex items-center gap-0.5">
                        <Hourglass className="w-3 h-3" />{stats.awaiting} بانتظار
                      </span>
                    )}
                    {stats.overdue > 0 && (
                      <span className="text-[10px] text-red-500 flex items-center gap-0.5">
                        <XCircle className="w-3 h-3" />{stats.overdue} متأخرة
                      </span>
                    )}
                  </div>
                )}

                {/* ── Bottom actions ── */}
                <div className="flex gap-2">
                  <button
                    onClick={() => { setOpenBatchId(batch.id); setInvoiceFilter("all"); }}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-[#0D9488]/30 text-[#0D9488] text-xs hover:bg-[#0D9488]/5 transition-all"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    عرض التفاصيل
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); openEditBatch(batch); }}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-[#6366f1]/30 text-[#6366f1] text-xs hover:bg-[#6366f1]/5 transition-all"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    تعديل
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); setDeleteConfirm(batch.id); }}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-red-200 text-red-500 text-xs hover:bg-red-50 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    حذف
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredBatches.length === 0 && (
        <div className="bg-white rounded-2xl border border-[#0D9488]/10 p-10 text-center">
          <FileText className="w-12 h-12 text-[#0D9488]/20 mx-auto mb-3" />
          <div className="text-sm text-[#5f6b7a]">لا توجد فواتير بعد</div>
          <button onClick={openCreate} className="mt-3 text-sm text-[#0D9488] hover:underline">إنشاء فاتورة جديدة</button>
        </div>
      )}

      {/* ── Action Sheet (Bottom Sheet) for batch actions ── */}
      {actionSheetBatch && (
        <>
          <div className="fixed inset-0 bg-black/30 z-40" onClick={() => setActionSheetBatch(null)} />
          <div className="fixed bottom-0 left-0 right-0 z-50 bg-white rounded-t-2xl shadow-2xl" style={{ maxHeight: '70vh' }}>
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-gray-200" />
            </div>
            <div className="flex items-center gap-3 px-5 pb-3 border-b border-gray-100">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: actionSheetBatch.stoppedAt ? '#dc262615' : '#0D948815' }}>
                {actionSheetBatch.type === "دائم" ? (
                  <Repeat className="w-4.5 h-4.5" style={{ color: actionSheetBatch.stoppedAt ? '#dc2626' : '#0D9488' }} />
                ) : (
                  <FileText className="w-4.5 h-4.5" style={{ color: '#6366f1' }} />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-[#1a1a2e] truncate">{actionSheetBatch.description}</div>
                <div className="text-[10px] text-[#5f6b7a]">{actionSheetBatch.date} — {actionSheetBatch.dueDate}</div>
              </div>
              <button onClick={() => setActionSheetBatch(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-[#5f6b7a] hover:bg-gray-100">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="py-2">
              {[
                { icon: Eye, label: "عرض التفاصيل", color: "#0D9488", action: () => { setOpenBatchId(actionSheetBatch.id); setInvoiceFilter("all"); setActionSheetBatch(null); } },
                { icon: Pencil, label: "تعديل الفاتورة", color: "#6366f1", action: () => { openEditBatch(actionSheetBatch); setActionSheetBatch(null); } },
                ...(actionSheetBatch.type === "دائم" ? [
                  actionSheetBatch.stoppedAt
                    ? { icon: RotateCcw, label: "إعادة تفعيل", color: "#0D9488", action: () => { handleToggleStop(actionSheetBatch); setActionSheetBatch(null); } }
                    : { icon: CircleStop, label: "إيقاف الفاتورة الدائمة", color: "#F59E0B", action: () => { handleToggleStop(actionSheetBatch); setActionSheetBatch(null); } }
                ] : []),
                { icon: Trash2, label: "حذف الفاتورة", color: "#dc2626", action: () => { setDeleteConfirm(actionSheetBatch.id); setActionSheetBatch(null); } },
              ].map((item, i) => (
                <button
                  key={i}
                  onClick={item.action}
                  className="w-full flex items-center gap-4 px-5 py-3.5 text-sm text-[#1a1a2e] hover:bg-gray-50 active:bg-gray-100 transition-colors"
                >
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${item.color}10` }}>
                    <item.icon className="w-4.5 h-4.5" style={{ color: item.color }} />
                  </div>
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
            <div className="h-[env(safe-area-inset-bottom)]" />
          </div>
        </>
      )}

      {/* ===== Create Invoice Modal ===== */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl w-full max-w-xl max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">إنشاء فاتورة جديدة</h3>
              <button onClick={() => setShowModal(false)} className="text-[#5f6b7a] hover:text-[#1a1a2e]"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-5">

              {/* Step 1: Scope */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-2 block">نطاق الفاتورة</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setForm({ ...form, scope: "عام", selectedUnitIds: [] })}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-sm transition-all ${
                      form.scope === "عام" ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-200 text-[#5f6b7a] hover:border-gray-300"
                    }`}
                  >
                    <Users className="w-4 h-4" />
                    <span>عام</span>
                    <span className="text-[10px] mr-auto opacity-60">{buildingUnits.length} وحدة</span>
                  </button>
                  <button
                    onClick={() => setForm({ ...form, scope: "مخصص" })}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-sm transition-all ${
                      form.scope === "مخصص" ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-200 text-[#5f6b7a] hover:border-gray-300"
                    }`}
                  >
                    <Tag className="w-4 h-4" />
                    <span>مخصص</span>
                  </button>
                </div>
              </div>

              {/* Step 1.5: Type (دائم / مؤقت) */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-2 block">نوع الفاتورة</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setForm({ ...form, type: "دائم" })}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-sm transition-all ${
                      form.type === "دائم" ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-200 text-[#5f6b7a] hover:border-gray-300"
                    }`}
                  >
                    <Repeat className="w-4 h-4" />
                    <span>دائمة</span>
                    <span className="text-[10px] mr-auto opacity-60">شهرية</span>
                  </button>
                  <button
                    onClick={() => setForm({ ...form, type: "مؤقت" })}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-sm transition-all ${
                      form.type === "مؤقت" ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-200 text-[#5f6b7a] hover:border-gray-300"
                    }`}
                  >
                    <Clock className="w-4 h-4" />
                    <span>مؤقتة</span>
                    <span className="text-[10px] mr-auto opacity-60">مرة واحدة</span>
                  </button>
                </div>
                {form.type === "دائم" && (
                  <div className="bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-xl px-3 py-2 mt-2">
                    <p className="text-[11px] text-[#0D9488]">
                      <Repeat className="w-3 h-3 inline ml-1" />
                      الفاتورة الدائمة تتكرر تلقائياً كل شهر بنفس المبلغ. يمكنك إيقافها لاحقاً.
                    </p>
                  </div>
                )}
                {form.type === "مؤقت" && (
                  <div className="bg-[#F59E0B]/5 border border-[#F59E0B]/10 rounded-xl px-3 py-2 mt-2">
                    <p className="text-[11px] text-[#F59E0B]">
                      <Clock className="w-3 h-3 inline ml-1" />
                      الفاتورة المؤقتة تُدفع مرة واحدة فقط وتختفي من عند الساكن بعد تأكيد الدفع.
                    </p>
                  </div>
                )}
              </div>

              {/* Step 2: Select units (if مخصص) */}
              {form.scope === "مخصص" && (
                <div className="bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <label className="text-xs text-[#1a1a2e]">اختر الوحدات *</label>
                    {form.selectedUnitIds.length > 0 && (
                      <span className="text-[10px] bg-[#0D9488]/10 text-[#0D9488] px-2 py-0.5 rounded-full">
                        {form.selectedUnitIds.length} وحدة محددة
                      </span>
                    )}
                  </div>
                  <div className="border border-[#0D9488]/10 rounded-lg overflow-hidden max-h-[200px] overflow-y-auto bg-white">
                    {getFloors().map(([floor, units]) => {
                      const allSelected = units.every((u) => form.selectedUnitIds.includes(u.id));
                      const someSelected = units.some((u) => form.selectedUnitIds.includes(u.id));
                      return (
                        <div key={floor}>
                          <button
                            onClick={() => selectAllFloor(units)}
                            className="w-full flex items-center justify-between px-3 py-2 bg-[#f8fffe] border-b border-[#0D9488]/5 hover:bg-[#0D9488]/5 transition-colors"
                          >
                            <span className="text-xs text-[#1a1a2e]">الدور {floor}</span>
                            <div className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-all ${
                              allSelected ? "bg-[#0D9488] border-[#0D9488]" : someSelected ? "border-[#0D9488] bg-[#0D9488]/20" : "border-gray-200"
                            }`}>
                              {allSelected && <Check className="w-3 h-3 text-white" />}
                            </div>
                          </button>
                          <div className="divide-y divide-gray-50">
                            {units.map((unit) => {
                              const isSelected = form.selectedUnitIds.includes(unit.id);
                              return (
                                <button
                                  key={unit.id}
                                  onClick={() => toggleUnit(unit.id)}
                                  className={`w-full flex items-center gap-3 px-4 py-2.5 transition-colors ${
                                    isSelected ? "bg-[#0D9488]/5" : "hover:bg-gray-50"
                                  }`}
                                >
                                  <div className={`w-4 h-4 rounded border-2 flex items-center justify-center shrink-0 transition-all ${
                                    isSelected ? "bg-[#0D9488] border-[#0D9488]" : "border-gray-200"
                                  }`}>
                                    {isSelected && <Check className="w-3 h-3 text-white" />}
                                  </div>
                                  <div className="flex-1 text-right">
                                    <div className="text-sm text-[#1a1a2e]">{unit.label}</div>
                                    <div className="text-[10px] text-[#5f6b7a]">{unit.occupied ? unit.resident : unit.ownerName + " (مالك)"}</div>
                                  </div>
                                  <span className={`text-[10px] px-2 py-0.5 rounded-full flex items-center gap-0.5 shrink-0 ${
                                    unit.occupied ? "bg-green-50 text-green-600" : "bg-amber-50 text-amber-600"
                                  }`}>
                                    {unit.occupied ? <><Home className="w-2.5 h-2.5" />شاغرة</> : <><UserX className="w-2.5 h-2.5" />غير شاغرة</>}
                                  </span>
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Step 3: Description */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">وصف الفاتورة *</label>
                <input
                  type="text"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="مثال: اشتراك صيانة — مارس"
                  className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                />
              </div>

              {/* Step 4: Amount with occupancy distinction */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs text-[#5f6b7a]">المبلغ</label>
                  <button
                    onClick={() => setForm({ ...form, sameAmount: !form.sameAmount, amountVacant: form.amountOccupied })}
                    className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-all ${
                      !form.sameAmount
                        ? "bg-[#F59E0B]/10 text-[#F59E0B] border border-[#F59E0B]/20"
                        : "bg-gray-50 text-[#5f6b7a] border border-gray-100 hover:bg-gray-100"
                    }`}
                  >
                    {!form.sameAmount ? <CheckCircle2 className="w-3.5 h-3.5" /> : <span className="w-3.5 h-3.5 rounded-full border-2 border-gray-300 inline-block" />}
                    مبلغ مختلف للوحدة غير الشاغرة
                  </button>
                </div>

                {form.sameAmount ? (
                  <div>
                    <label className="text-[10px] text-[#5f6b7a] mb-1 block">مبلغ موحّد لكل وحدة (ج.م) *</label>
                    <input
                      type="number"
                      value={form.amountOccupied || ""}
                      onChange={(e) => setForm({ ...form, amountOccupied: Number(e.target.value), amountVacant: Number(e.target.value) })}
                      className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                    />
                    <div className="flex gap-2 mt-2">
                      {[1000, 1250, 1500, 1750, 2000].map((v) => (
                        <button key={v} onClick={() => setForm({ ...form, amountOccupied: v, amountVacant: v })} className={`flex-1 py-1.5 rounded-lg text-xs border-2 transition-all ${form.amountOccupied === v ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-100 text-[#5f6b7a]"}`}>
                          {v.toLocaleString("en-US")}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-green-50/50 border border-green-100 rounded-xl p-3">
                      <div className="flex items-center gap-1.5 mb-2">
                        <Home className="w-3.5 h-3.5 text-green-500" />
                        <span className="text-xs text-green-700">وحدة شاغرة</span>
                        <span className="text-[10px] bg-green-100 text-green-600 px-1.5 py-0.5 rounded-full mr-auto">{occupiedCount}</span>
                      </div>
                      <input
                        type="number"
                        value={form.amountOccupied || ""}
                        onChange={(e) => setForm({ ...form, amountOccupied: Number(e.target.value) })}
                        placeholder="0"
                        className="w-full px-3 py-2.5 bg-white border border-green-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-200"
                      />
                      <span className="text-[10px] text-green-600 mt-1 block">ج.م / وحدة</span>
                    </div>
                    <div className="bg-amber-50/50 border border-amber-100 rounded-xl p-3">
                      <div className="flex items-center gap-1.5 mb-2">
                        <UserX className="w-3.5 h-3.5 text-amber-500" />
                        <span className="text-xs text-amber-700">وحدة غير شاغرة</span>
                        <span className="text-[10px] bg-amber-100 text-amber-600 px-1.5 py-0.5 rounded-full mr-auto">{vacantCount}</span>
                      </div>
                      <input
                        type="number"
                        value={form.amountVacant || ""}
                        onChange={(e) => setForm({ ...form, amountVacant: Number(e.target.value) })}
                        placeholder="0"
                        className="w-full px-3 py-2.5 bg-white border border-amber-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-200"
                      />
                      <span className="text-[10px] text-amber-600 mt-1 block">ج.م / وحدة</span>
                    </div>
                  </div>
                )}


              </div>

              {/* Due date — only for مؤقت invoices */}
              {form.type !== "دائم" && (
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">شهر الاستحقاق</label>
                  <input
                    type="month"
                    value={toMonthValue(form.dueDate)}
                    onChange={(e) => setForm({ ...form, dueDate: toArabicMonth(e.target.value) })}
                    className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                  />
                </div>
              )}

              {/* Preview / Summary */}
              {canCreate && (
                <div>
                  <button
                    onClick={() => setShowPreview(!showPreview)}
                    className="w-full flex items-center justify-between px-4 py-3 bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-xl text-sm text-[#0D9488] hover:bg-[#0D9488]/10 transition-colors"
                  >
                    <span>ملخص الفاتورة ({targetedUnits.length} وحدة)</span>
                    {showPreview ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                  {showPreview && (
                    <div className="mt-2 border border-[#0D9488]/10 rounded-xl overflow-hidden">
                      <div className="grid grid-cols-3 gap-px bg-[#0D9488]/5">
                        <div className="bg-white p-3 text-center">
                          <div className="text-[10px] text-[#5f6b7a]">عدد الوحدات</div>
                          <div className="text-sm text-[#0D9488]">{targetedUnits.length}</div>
                        </div>
                        <div className="bg-white p-3 text-center">
                          <div className="text-[10px] text-[#5f6b7a]">شاغرة / غير شاغرة</div>
                          <div className="text-sm text-[#1a1a2e]">
                            <span className="text-green-600">{occupiedCount}</span>
                            {" / "}
                            <span className="text-amber-600">{vacantCount}</span>
                          </div>
                        </div>
                        <div className="bg-white p-3 text-center">
                          <div className="text-[10px] text-[#5f6b7a]">الإجمالي</div>
                          <div className="text-sm text-[#0D9488]">{totalAmount.toLocaleString("en-US")} ج.م</div>
                        </div>
                      </div>
                      <div className="max-h-[160px] overflow-y-auto divide-y divide-gray-50">
                        {targetedUnits.map((unit) => {
                          const amt = unit.occupied
                            ? form.amountOccupied
                            : (form.sameAmount ? form.amountOccupied : form.amountVacant);
                          return (
                            <div key={unit.id} className="flex items-center gap-3 px-4 py-2.5">
                              <span className={`text-[10px] px-1.5 py-0.5 rounded-full flex items-center gap-0.5 shrink-0 ${
                                unit.occupied ? "bg-green-50 text-green-600" : "bg-amber-50 text-amber-600"
                              }`}>
                                {unit.occupied ? <Home className="w-2.5 h-2.5" /> : <UserX className="w-2.5 h-2.5" />}
                              </span>
                              <div className="flex-1 min-w-0">
                                <div className="text-sm text-[#1a1a2e] truncate">{unit.label}</div>
                                <div className="text-[10px] text-[#5f6b7a] truncate">
                                  {unit.occupied ? unit.resident : unit.ownerName + " (مالك)"}
                                </div>
                              </div>
                              <div className="text-sm text-[#0D9488] shrink-0">{amt.toLocaleString("en-US")} ج.م</div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button onClick={() => setShowModal(false)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">
                إلغاء
              </button>
              <button
                onClick={handleCreate}
                disabled={!canCreate || saving}
                className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${
                  canCreate && !saving
                    ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20"
                    : "bg-gray-300 cursor-not-allowed"
                }`}
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
                {saving ? "جاري الحفظ..." : "إنشاء الفاتورة"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-5">
              <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3"><Trash2 className="w-7 h-7 text-red-500" /></div>
              <h3 className="text-lg text-[#1a1a2e] mb-1">حذف الفاتورة</h3>
              <p className="text-sm text-[#5f6b7a]">هل أنت متأكد من حذف هذه الفاتورة وجميع الفواتير الفردية بداخلها؟</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={() => deleteBatch(deleteConfirm)} className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm hover:bg-red-600">نعم، احذف</button>
            </div>
          </div>
        </div>
      )}

      <MobileFAB onClick={openCreate} label="إنشاء فاتورة" />
    </div>
  );
}