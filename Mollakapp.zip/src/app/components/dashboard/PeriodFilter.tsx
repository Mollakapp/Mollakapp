import { useState, useMemo } from "react";
import { ChevronRight, ChevronLeft, Calendar } from "lucide-react";

export type PeriodType = "monthly" | "quarterly" | "yearly";

export interface PeriodFilterValue {
  type: PeriodType;
  year: number;
  month: number; // 0-11
  quarter: number; // 1-4
}

const PERIOD_LABELS: Record<PeriodType, string> = {
  monthly: "شهري",
  quarterly: "ربع سنوي",
  yearly: "سنوي",
};

const MONTH_NAMES_AR = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];

const QUARTER_NAMES_AR = [
  "الربع الأول (يناير — مارس)",
  "الربع الثاني (أبريل — يونيو)",
  "الربع الثالث (يوليو — سبتمبر)",
  "الربع الرابع (أكتوبر — ديسمبر)",
];

function getQuarterFromMonth(month: number): number {
  return Math.floor(month / 3) + 1;
}

function getDisplayLabel(value: PeriodFilterValue): string {
  switch (value.type) {
    case "monthly":
      return `${MONTH_NAMES_AR[value.month]} ${value.year}`;
    case "quarterly":
      return `${QUARTER_NAMES_AR[value.quarter - 1]} — ${value.year}`;
    case "yearly":
      return `سنة ${value.year}`;
  }
}

interface PeriodFilterProps {
  value: PeriodFilterValue;
  onChange: (value: PeriodFilterValue) => void;
}

export function PeriodFilter({ value, onChange }: PeriodFilterProps) {
  const displayLabel = useMemo(() => getDisplayLabel(value), [value]);

  const handleTypeChange = (type: PeriodType) => {
    onChange({
      ...value,
      type,
      quarter: getQuarterFromMonth(value.month),
    });
  };

  const goNext = () => {
    const v = { ...value };
    switch (v.type) {
      case "monthly":
        if (v.month === 11) {
          v.month = 0;
          v.year++;
        } else {
          v.month++;
        }
        v.quarter = getQuarterFromMonth(v.month);
        break;
      case "quarterly":
        if (v.quarter === 4) {
          v.quarter = 1;
          v.year++;
        } else {
          v.quarter++;
        }
        v.month = (v.quarter - 1) * 3;
        break;
      case "yearly":
        v.year++;
        break;
    }
    onChange(v);
  };

  const goPrev = () => {
    const v = { ...value };
    switch (v.type) {
      case "monthly":
        if (v.month === 0) {
          v.month = 11;
          v.year--;
        } else {
          v.month--;
        }
        v.quarter = getQuarterFromMonth(v.month);
        break;
      case "quarterly":
        if (v.quarter === 1) {
          v.quarter = 4;
          v.year--;
        } else {
          v.quarter--;
        }
        v.month = (v.quarter - 1) * 3;
        break;
      case "yearly":
        v.year--;
        break;
    }
    onChange(v);
  };

  return (
    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
      {/* Period Type Buttons */}
      <div className="flex bg-white border border-gray-100 rounded-xl p-1 gap-1">
        {(Object.keys(PERIOD_LABELS) as PeriodType[]).map((type) => (
          <button
            key={type}
            onClick={() => handleTypeChange(type)}
            className={`px-3 py-2 rounded-lg text-sm whitespace-nowrap transition-all ${
              value.type === type
                ? "bg-[#0D9488] text-white shadow-sm"
                : "text-[#5f6b7a] hover:bg-[#0D9488]/5"
            }`}
          >
            {PERIOD_LABELS[type]}
          </button>
        ))}
      </div>

      {/* Date Navigator */}
      <div className="flex items-center gap-1 bg-white border border-gray-100 rounded-xl px-2 py-1">
        <button
          onClick={goPrev}
          className="p-1.5 rounded-lg text-[#5f6b7a] hover:bg-[#0D9488]/5 hover:text-[#0D9488] transition-colors"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
        <div className="flex items-center gap-1.5 px-2 min-w-[140px] justify-center">
          <Calendar className="w-3.5 h-3.5 text-[#0D9488]" />
          <span className="text-sm text-[#1a1a2e] whitespace-nowrap">{displayLabel}</span>
        </div>
        <button
          onClick={goNext}
          className="p-1.5 rounded-lg text-[#5f6b7a] hover:bg-[#0D9488]/5 hover:text-[#0D9488] transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

// ===== Helper: default period value =====
export function getDefaultPeriod(): PeriodFilterValue {
  const now = new Date();
  return {
    type: "monthly",
    year: now.getFullYear(),
    month: now.getMonth(),
    quarter: Math.floor(now.getMonth() / 3) + 1,
  };
}

// ===== Helper: check if an Arabic date string matches the period =====
export function matchesPeriod(dateStr: string, period: PeriodFilterValue): boolean {
  // Extract month name and year from Arabic date like "1 فبراير 2026"
  const yearMatch = dateStr.match(/\d{4}/);
  const year = yearMatch ? parseInt(yearMatch[0]) : null;

  // Find which month
  let monthIndex = -1;
  for (let i = 0; i < MONTH_NAMES_AR.length; i++) {
    if (dateStr.includes(MONTH_NAMES_AR[i])) {
      monthIndex = i;
      break;
    }
  }

  if (year === null || monthIndex === -1) return true; // show if can't parse

  switch (period.type) {
    case "monthly":
      return year === period.year && monthIndex === period.month;
    case "quarterly": {
      const itemQuarter = Math.floor(monthIndex / 3) + 1;
      return year === period.year && itemQuarter === period.quarter;
    }
    case "yearly":
      return year === period.year;
  }
}

// ===== Helper: use period filter hook =====
export function usePeriodFilter() {
  const [period, setPeriod] = useState<PeriodFilterValue>(getDefaultPeriod());
  return { period, setPeriod, matchesPeriod: (dateStr: string) => matchesPeriod(dateStr, period) };
}