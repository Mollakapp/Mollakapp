import { useState, useEffect, useCallback } from "react";
import { Plus, Banknote, CheckCircle2, Clock, AlertCircle, X, Trash2, Pencil, MoreVertical, Loader2, Search, Download } from "lucide-react";
import * as api from "../../lib/api";
import { MobileFAB } from "./MobileFAB";

// ===== Arabic Date Helpers =====
const ARABIC_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
];

function toDateValue(arabic: string): string {
  const parts = arabic.trim().split(" ");
  if (parts.length < 3) return "";
  const day = parseInt(parts[0], 10);
  const mi = ARABIC_MONTHS.indexOf(parts[1]);
  if (isNaN(day) || mi === -1) return "";
  return `${parts[2]}-${String(mi + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function toArabicDate(dateVal: string): string {
  if (!dateVal) return "";
  const [y, m, d] = dateVal.split("-");
  const mi = parseInt(m, 10) - 1;
  if (mi < 0 || mi > 11) return "";
  return `${parseInt(d, 10)} ${ARABIC_MONTHS[mi]} ${y}`;
}

interface AdvanceForm {
  person: string;
  amount: number;
  reason: string;
  date: string;
  dueDate: string;
  approvedBy: string;
}

const emptyForm: AdvanceForm = {
  person: "",
  amount: 0,
  reason: "",
  date: "",
  dueDate: "",
  approvedBy: "رئيس الاتحاد",
};

const statusMap: Record<string, { label: string; color: string; bg: string; icon: typeof Clock }> = {
  active: { label: "نشطة", color: "#0D9488", bg: "#0D9488", icon: Clock },
  returned: { label: "مُرتجعة", color: "#22c55e", bg: "#22c55e", icon: CheckCircle2 },
  overdue: { label: "متأخرة", color: "#dc2626", bg: "#dc2626", icon: AlertCircle },
};

export function AdvancesPage() {
  const [advances, setAdvances] = useState<api.Advance[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<AdvanceForm>(emptyForm);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("الكل");
  const [searchQuery, setSearchQuery] = useState("");

  const fetchAdvances = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getAdvances();
      setAdvances(data);
    } catch (err: any) {
      console.error("Error fetching advances:", err);
      setErrorMsg("خطأ في تحميل السُلف");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAdvances();
  }, [fetchAdvances]);

  const filtered = advances.filter(
    (a) => (filterStatus === "الكل" || a.status === filterStatus) &&
      (searchQuery === "" || a.person.includes(searchQuery) || a.reason.includes(searchQuery))
  );

  const totalActive = advances.filter((a) => a.status === "active").reduce((s, a) => s + a.amount, 0);
  const totalReturned = advances.filter((a) => a.status === "returned").reduce((s, a) => s + a.amount, 0);
  const totalOverdue = advances.filter((a) => a.status === "overdue").reduce((s, a) => s + a.amount, 0);

  const openAdd = () => {
    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
    setForm({ ...emptyForm, date: toArabicDate(todayStr) });
    setEditingId(null);
    setShowModal(true);
  };

  const openEdit = (adv: api.Advance) => {
    setForm({ person: adv.person, amount: adv.amount, reason: adv.reason, date: adv.date, dueDate: adv.dueDate, approvedBy: adv.approvedBy });
    setEditingId(adv.id);
    setShowModal(true);
    setMenuOpen(null);
  };

  const handleSave = async () => {
    if (!form.person || form.amount <= 0) return;
    setSaving(true);
    try {
      if (editingId) {
        await api.updateAdvance(editingId, form);
        showSuccess("تم تحديث السلفة بنجاح");
      } else {
        await api.createAdvance(form);
        showSuccess("تم تسجيل السلفة بنجاح");
      }
      setShowModal(false);
      await fetchAdvances();
    } catch (err: any) {
      console.error("Error saving advance:", err);
      setErrorMsg(err.message || "خطأ في حفظ السلفة");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteAdvance(id);
      setDeleteConfirm(null);
      setMenuOpen(null);
      showSuccess("تم حذف السلفة");
      await fetchAdvances();
    } catch (err: any) {
      console.error("Error deleting advance:", err);
      setErrorMsg(err.message || "خطأ في حذف السلفة");
    }
  };

  const toggleReturn = async (id: string) => {
    const adv = advances.find((a) => a.id === id);
    if (!adv) return;
    const newStatus = adv.status === "returned" ? "active" : "returned";
    try {
      await api.updateAdvance(id, { status: newStatus });
      setMenuOpen(null);
      showSuccess(newStatus === "returned" ? "تم تسجيل الإرجاع" : "تم إلغاء الإرجاع");
      await fetchAdvances();
    } catch (err: any) {
      console.error("Error toggling return:", err);
      setErrorMsg(err.message || "خطأ في تحديث الحالة");
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };

  const canSave = form.person && form.amount > 0;

  const statCards = [
    { label: "سُلف نشطة", value: totalActive, color: "#0D9488", icon: Clock },
    { label: "تم الإرجاع", value: totalReturned, color: "#22c55e", icon: CheckCircle2 },
    { label: "متأخرة", value: totalOverdue, color: "#dc2626", icon: AlertCircle },
  ];

  return (
    <div className="space-y-6">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}
      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm cursor-pointer" onClick={() => setErrorMsg("")}>
          <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl text-[#1a1a2e]">السُلف</h1>
          <p className="text-sm text-[#5f6b7a]">تسجيل ومتابعة السُلف المصروفة والمُرتجعة</p>
        </div>
        <div className="flex items-center gap-2">
          {advances.length > 0 && (
            <button
              onClick={() => {
                const statusLabels: Record<string, string> = { active: "نشطة", returned: "مُرتجعة", overdue: "متأخرة" };
                const csv = "\uFEFF" + "الشخص,المبلغ,السبب,الحالة,تاريخ الصرف,تاريخ الإرجاع,بواسطة\n" +
                  filtered.map(a => `"${a.person}",${a.amount},"${a.reason}","${statusLabels[a.status] || a.status}","${a.date}","${a.dueDate}","${a.approvedBy}"`).join("\n");
                const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url; a.download = "سُلف.csv"; a.click();
                URL.revokeObjectURL(url);
              }}
              className="p-3 rounded-xl border border-gray-200 text-[#5f6b7a] hover:bg-gray-50 transition-all"
              title="تصدير CSV"
            >
              <Download className="w-5 h-5" />
            </button>
          )}
          <button onClick={openAdd} className="hidden sm:inline-flex items-center gap-2 bg-[#0D9488] text-white px-5 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20">
            <Plus className="w-5 h-5" />
            تسجيل سلفة
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2 sm:gap-4">
        {statCards.map((s) => (
          <div key={s.label} className="bg-white rounded-xl sm:rounded-2xl border border-gray-100 p-3 sm:p-4 shadow-sm text-center">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center mx-auto mb-2" style={{ backgroundColor: `${s.color}15` }}>
              <s.icon className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: s.color }} />
            </div>
            <div className="text-lg sm:text-xl text-[#1a1a2e] leading-tight">{s.value.toLocaleString("en-US")}</div>
            <div className="text-[10px] sm:text-xs text-[#5f6b7a] mt-0.5">ج.م</div>
            <div className="text-[10px] sm:text-xs text-[#5f6b7a] mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
          <input type="text" placeholder="ابحث بالاسم أو السبب..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pr-11 pl-4 py-3 bg-white border border-[#0D9488]/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm" />
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
          {["الكل", "active", "returned", "overdue"].map((f) => (
            <button key={f} onClick={() => setFilterStatus(f)} className={`px-3 py-2 rounded-xl text-xs whitespace-nowrap transition-all ${filterStatus === f ? "bg-[#0D9488] text-white shadow-md" : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:bg-[#0D9488]/5"}`}>
              {f === "الكل" ? "الكل" : statusMap[f]?.label}
            </button>
          ))}
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin" />
        </div>
      )}

      {/* Advances List */}
      {!loading && (
        <div className="space-y-3">
          {filtered.map((adv) => {
            const st = statusMap[adv.status];
            const StIcon = st.icon;
            return (
              <div key={adv.id} className="bg-white rounded-2xl border border-gray-100 p-4 sm:p-5 shadow-sm hover:shadow-md transition-all">
                <div className="flex items-start gap-3 sm:gap-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${st.color}15` }}>
                    <Banknote className="w-5 h-5" style={{ color: st.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="text-sm text-[#1a1a2e]">{adv.person}</h3>
                      <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full" style={{ backgroundColor: `${st.color}15`, color: st.color }}>
                        <StIcon className="w-3 h-3" />{st.label}
                      </span>
                    </div>
                    <p className="text-sm text-[#0D9488] mb-1">{adv.amount.toLocaleString("en-US")} ج.م</p>
                    <p className="text-xs text-[#5f6b7a] mb-2">{adv.reason}</p>
                    <div className="flex items-center gap-4 text-xs text-[#5f6b7a] flex-wrap">
                      <span>📅 {adv.date}</span>
                      {adv.dueDate && <span>⏰ الإرجاع: {adv.dueDate}</span>}
                      <span>بواسطة: {adv.approvedBy}</span>
                    </div>
                  </div>
                  <div className="relative shrink-0">
                    <button onClick={() => setMenuOpen(menuOpen === adv.id ? null : adv.id)} className="text-[#5f6b7a] hover:text-[#0D9488] p-1 rounded-lg hover:bg-[#0D9488]/5">
                      <MoreVertical className="w-4 h-4" />
                    </button>
                    {menuOpen === adv.id && (
                      <div className="absolute left-0 top-full mt-1 bg-white border border-[#0D9488]/10 rounded-xl shadow-lg z-20 w-40 overflow-hidden">
                        <button onClick={() => toggleReturn(adv.id)} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-[#1a1a2e] hover:bg-[#0D9488]/5 transition-colors">
                          <CheckCircle2 className="w-4 h-4 text-[#22c55e]" />
                          {adv.status === "returned" ? "إلغاء الإرجاع" : "تم الإرجاع"}
                        </button>
                        <button onClick={() => openEdit(adv)} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-[#1a1a2e] hover:bg-[#0D9488]/5 transition-colors">
                          <Pencil className="w-4 h-4 text-[#0D9488]" /> تعديل
                        </button>
                        <button onClick={() => { setDeleteConfirm(adv.id); setMenuOpen(null); }} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 transition-colors">
                          <Trash2 className="w-4 h-4" /> حذف
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && !loading && (
            <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center text-sm text-[#5f6b7a]">لا توجد سُلف مسجلة</div>
          )}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">{editingId ? "تعديل السلفة" : "تسجيل سلفة جديدة"}</h3>
              <button onClick={() => setShowModal(false)} className="text-[#5f6b7a]"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">اسم الشخص *</label>
                <input type="text" value={form.person} onChange={(e) => setForm({ ...form, person: e.target.value })} placeholder="مثال: أحمد محمد" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">المبلغ (ج.م) *</label>
                <input type="number" value={form.amount || ""} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} placeholder="0" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">السبب</label>
                <input type="text" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} placeholder="سبب السلفة" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">تاريخ الصرف</label>
                  <input type="date" value={toDateValue(form.date)} onChange={(e) => setForm({ ...form, date: toArabicDate(e.target.value) })} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">تاريخ الإرجاع المتوقع</label>
                  <input type="date" value={toDateValue(form.dueDate)} onChange={(e) => setForm({ ...form, dueDate: toArabicDate(e.target.value) })} placeholder="مثال: 1 أبريل 2026" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button onClick={() => setShowModal(false)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={handleSave} disabled={!canSave || saving} className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${canSave && !saving ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20" : "bg-gray-300 cursor-not-allowed"}`}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                {editingId ? "حفظ التعديلات" : "تسجيل السلفة"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-5">
              <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3"><Trash2 className="w-7 h-7 text-red-500" /></div>
              <h3 className="text-lg text-[#1a1a2e] mb-1">تأكيد الحذف</h3>
              <p className="text-sm text-[#5f6b7a]">هل أنت متأكد من حذف هذه السلفة؟</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm hover:bg-red-600">نعم، احذف</button>
            </div>
          </div>
        </div>
      )}
      <MobileFAB onClick={openAdd} label="تسجيل سلفة" />
    </div>
  );
}