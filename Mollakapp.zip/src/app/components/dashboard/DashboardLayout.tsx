import { useState, useEffect, useCallback } from "react";
import { Outlet, useNavigate, useLocation, Navigate } from "react-router";
import {
  Building2,
  LayoutDashboard,
  Receipt,
  TrendingUp,
  FileText,
  MessageCircle,
  Megaphone,
  Phone,
  CalendarHeart,
  Heart,
  Vote,
  Shield,
  UserCheck,
  Settings,
  LogOut,
  Menu,
  X,
  Bell,
  ChevronLeft,
  Users,
  Banknote,
  Check,
  Home,
  ShieldCheck,
  Loader2,
  AlertTriangle,
  Edit3,
  ArrowLeftRight,
  ClipboardList,
  CreditCard,
} from "lucide-react";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";

const menuItems = [
  { id: "overview", label: "الرئيسية", icon: Home, path: "/dashboard" },
  { id: "residents", label: "المُلاك", icon: Users, path: "/dashboard/residents" },
  { id: "invoices", label: "الفواتير", icon: FileText, path: "/dashboard/invoices" },
  { id: "revenue", label: "الإيرادات", icon: TrendingUp, path: "/dashboard/revenue" },
  { id: "expenses", label: "المصروفات", icon: Receipt, path: "/dashboard/expenses" },
  { id: "advances", label: "السُلف", icon: Banknote, path: "/dashboard/advances" },
  { id: "announcements", label: "الإعلانات", icon: Megaphone, path: "/dashboard/announcements" },
  { id: "directory", label: "الأرقام", icon: Phone, path: "/dashboard/directory" },
  { id: "events", label: "المناسبات", icon: CalendarHeart, path: "/dashboard/events" },
  { id: "donations", label: "التبرعات", icon: Heart, path: "/dashboard/donations" },
  { id: "voting", label: "التصويت", icon: Vote, path: "/dashboard/voting" },
  { id: "subscription", label: "الاشتراك", icon: CreditCard, path: "/dashboard/subscription" },
];

function timeAgo(dateStr: string): string {
  try {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "الآن";
    if (mins < 60) return `منذ ${mins} دقيقة`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `منذ ${hrs} ساعة`;
    const days = Math.floor(hrs / 24);
    return `منذ ${days} يوم`;
  } catch {
    return "";
  }
}

export function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isLargeScreen, setIsLargeScreen] = useState(() =>
    typeof window !== "undefined" ? window.matchMedia("(min-width: 1024px)").matches : false
  );
  const [notifOpen, setNotifOpen] = useState(false);
  const [joinRequests, setJoinRequests] = useState<api.JoinRequest[]>([]);
  const [cashCollections, setCashCollections] = useState<api.CashCollection[]>([]);
  const [donationCashRequests, setDonationCashRequests] = useState<api.DonationCashRequest[]>([]);
  const [serviceRequests, setServiceRequests] = useState<api.ServiceRequest[]>([]);
  const [confirmingId, setConfirmingId] = useState<string | null>(null);
  const [respondingId, setRespondingId] = useState<string | null>(null);
  const [srRespondingId, setSrRespondingId] = useState<string | null>(null);
  const [srNoteId, setSrNoteId] = useState<string | null>(null);
  const [srNote, setSrNote] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [buildingName, setBuildingName] = useState("مُلاك");
  const [buildingSubtitle, setBuildingSubtitle] = useState("");
  const [adminName, setAdminName] = useState("");
  const [adminRole, setAdminRole] = useState("رئيس الاتحاد");
  const [adminInitials, setAdminInitials] = useState("");
  const [showProfilePrompt, setShowProfilePrompt] = useState(false);
  const [unreadChatCount, setUnreadChatCount] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();
  const { session, profile, loading, logout } = useAuth();

  // Track screen size for sidebar behavior
  useEffect(() => {
    const mql = window.matchMedia("(min-width: 1024px)");
    const handler = (e: MediaQueryListEvent) => setIsLargeScreen(e.matches);
    mql.addEventListener("change", handler);
    setIsLargeScreen(mql.matches);
    return () => mql.removeEventListener("change", handler);
  }, []);

  // Load notifications (cash collections + join requests)
  const loadNotifications = useCallback(async () => {
    try {
      const [cashResult, joinsResult, donationResult, srResult] = await Promise.allSettled([
        api.getCashCollections(),
        api.getJoinRequests(),
        api.getDonationCashRequests(),
        api.getServiceRequests(),
      ]);
      if (cashResult.status === "fulfilled") {
        setCashCollections(cashResult.value);
      } else {
        console.error("Error loading cash collections:", cashResult.reason);
      }
      if (joinsResult.status === "fulfilled") {
        setJoinRequests(joinsResult.value);
      } else {
        console.error("Error loading join requests:", joinsResult.reason);
      }
      if (donationResult.status === "fulfilled") {
        setDonationCashRequests(donationResult.value);
      } else {
        console.error("Error loading donation cash requests:", donationResult.reason);
      }
      if (srResult.status === "fulfilled") {
        setServiceRequests(srResult.value);
      } else {
        console.error("Error loading service requests:", srResult.reason);
      }
    } catch (err) {
      console.error("Error loading notifications:", err);
    }
  }, []);

  // Load building info — merge auth profile with API data
  const loadBuildingInfo = useCallback(async () => {
    try {
      // Use auth profile data first for admin info
      if (profile) {
        setAdminName(profile.name || "");
        const roleLabelMap: Record<string, string> = {
          "admin": "رئيس الاتحاد",
          "treasurer": "أمين الصندوق",
          "board_member": "عضو اتحاد",
          "resident": "ساكن",
        };
        setAdminRole(profile.adminRole || roleLabelMap[profile.role || ""] || "رئيس الاتحاد");
        const initials = (profile.name || "")
          .split(" ")
          .map((w: string) => w[0])
          .slice(0, 2)
          .join("");
        setAdminInitials(initials);
      }

      const res = await api.getBuilding();
      if (res.exists && res.building) {
        setBuildingName(res.building.name);
        setBuildingSubtitle(`${res.building.floors} دور - ${res.building.totalUnits} شقة`);
        // Check if profile is incomplete (no building page setup)
        if (profile && (!res.building.address && !res.building.city)) {
          setShowProfilePrompt(true);
        }
        // Fallback: if no auth profile, use building admin info
        if (!profile && res.building.admin) {
          setAdminName(res.building.admin.name);
          setAdminRole(res.building.admin.role);
          const initials = res.building.admin.name
            .split(" ")
            .map((w: string) => w[0])
            .slice(0, 2)
            .join("");
          setAdminInitials(initials);
        }
      }
    } catch (err) {
      console.error("Error loading building info:", err);
    }
  }, [profile]);

  useEffect(() => {
    if (loading || !session) return;
    // Warm up the edge function first, then load data
    api.warmUp().then(() => {
      loadNotifications();
      loadBuildingInfo();
    });
    const interval = setInterval(loadNotifications, 30000);
    // Listen for building registration/update events from child pages
    const handleBuildingUpdated = () => loadBuildingInfo();
    window.addEventListener("building-updated", handleBuildingUpdated);
    return () => {
      clearInterval(interval);
      window.removeEventListener("building-updated", handleBuildingUpdated);
    };
  }, [loadNotifications, loadBuildingInfo, loading, session]);

  // Check for unread chat messages
  const loadUnreadChat = useCallback(async () => {
    if (!profile?.phone) return;
    try {
      const conversations = await api.getDMList(profile.phone);
      const totalUnread = conversations.reduce((sum: number, c: api.DMConversation) => sum + (c.unread || 0), 0);
      setUnreadChatCount(totalUnread);
    } catch (err) {
      console.error("Error loading DM unread count:", err);
    }
  }, [profile?.phone]);

  useEffect(() => {
    if (loading || !session || !profile?.phone) return;
    loadUnreadChat();
    const chatInterval = setInterval(loadUnreadChat, 30000);
    return () => clearInterval(chatInterval);
  }, [loadUnreadChat, loading, session, profile?.phone]);

  // Mark chat as seen when navigating to chat
  useEffect(() => {
    if (location.pathname.startsWith("/dashboard/chat")) {
      setUnreadChatCount(0);
    }
  }, [location.pathname]);

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-[#f8fffe] flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <Loader2 className="w-10 h-10 text-[#0D9488] animate-spin mx-auto mb-4" />
          <p className="text-sm text-[#5f6b7a]">جاري التحقق من الحساب...</p>
        </div>
      </div>
    );
  }

  // Auth guard — redirect to login if no session
  if (!session) {
    return <Navigate to="/login" replace />;
  }

  // Profile guard — if session exists but profile failed to load, redirect to login
  if (!profile) {
    return <Navigate to="/login" replace />;
  }

  // Role guard — ONLY admin, treasurer, board_member can access the dashboard
  const allowedRoles = ["admin", "treasurer", "board_member"];
  if (!allowedRoles.includes(profile.role || "")) {
    return <Navigate to="/resident" replace />;
  }

  const handleConfirmCollection = async (col: api.CashCollection) => {
    setConfirmingId(col.id);
    try {
      await api.confirmCashCollection(col.batchId, col.invoiceId);
      setCashCollections((prev) => prev.filter((c) => c.id !== col.id));
      showSucc(`تم تأكيد تحصيل ${col.amount.toLocaleString("en-US")} ج.م من ${col.residentName}`);
    } catch (err) {
      console.error("Error confirming collection:", err);
      showSucc("حدث خطأ أثناء تأكيد التحصيل");
    } finally {
      setConfirmingId(null);
    }
  };

  const handleConfirmDonationCash = async (req: api.DonationCashRequest) => {
    setConfirmingId(req.id);
    try {
      await api.confirmDonationCash(req.campaignId, req.id);
      setDonationCashRequests((prev) => prev.filter((r) => r.id !== req.id));
      showSucc(`تم تحصيل تبرع ${req.residentName} بمبلغ ${req.amount.toLocaleString("en-US")} ج.م`);
    } catch (err) {
      console.error("Error confirming donation cash:", err);
      showSucc("حدث خطأ أثناء تحصيل التبرع");
    } finally {
      setConfirmingId(null);
    }
  };

  const handleApprove = async (id: string) => {
    setRespondingId(id);
    try {
      await api.respondToJoinRequest(id, "approve");
      const req = joinRequests.find((r) => r.id === id);
      setJoinRequests((prev) => prev.filter((r) => r.id !== id));
      showSucc(`تم قبول ${req?.name} — شقة ${req?.unitCode}`);
      // Notify ResidentsPage to refresh
      window.dispatchEvent(new Event("residents-updated"));
    } catch (err) {
      console.error("Error approving join request:", err);
      showSucc("حدث خطأ أثناء قبول الطلب");
    } finally {
      setRespondingId(null);
    }
  };

  const handleReject = async (id: string) => {
    setRespondingId(id);
    try {
      await api.respondToJoinRequest(id, "reject");
      const req = joinRequests.find((r) => r.id === id);
      setJoinRequests((prev) => prev.filter((r) => r.id !== id));
      showSucc(`تم رفض طلب ${req?.name}`);
    } catch (err) {
      console.error("Error rejecting join request:", err);
      showSucc("حدث خطأ أثناء رفض الطلب");
    } finally {
      setRespondingId(null);
    }
  };

  const handleSrAction = async (id: string, status: "approved" | "rejected" | "closed") => {
    setSrRespondingId(id);
    try {
      const note = srNoteId === id ? srNote.trim() : "";
      await api.updateServiceRequest(id, {
        status,
        ...(status === "closed"
          ? { closingNote: note || undefined, closedBy: adminName }
          : { adminNote: note || undefined, respondedBy: adminName }),
      });
      setServiceRequests((prev) => prev.map((r) => r.id === id ? { ...r, status } : r));
      const req = serviceRequests.find((r) => r.id === id);
      const labels: Record<string, string> = { approved: "قبول", rejected: "رفض", closed: "إغلاق" };
      showSucc(`تم ${labels[status]} طلب "${req?.title}" من ${req?.requesterName}`);
      setSrNoteId(null);
      setSrNote("");
    } catch (err) {
      console.error(`Error updating service request:`, err);
      showSucc("حدث خطأ أثناء تحديث الطلب");
    } finally {
      setSrRespondingId(null);
    }
  };

  const isActive = (path: string) => {
    if (path === "/dashboard") return location.pathname === "/dashboard";
    return location.pathname.startsWith(path);
  };

  const pendingJoinCount = joinRequests.filter((r) => r.status === "pending").length;
  const pendingCashCount = cashCollections.filter((c) => c.status === "pending").length;
  const pendingDonationCount = donationCashRequests.filter((d) => d.status === "pending").length;
  const pendingSrCount = serviceRequests.filter((sr) => sr.status === "pending").length;
  const pendingCount = pendingJoinCount + pendingCashCount + pendingDonationCount + pendingSrCount;

  const showSucc = (msg: string) => { setSuccessMsg(msg); setTimeout(() => setSuccessMsg(""), 2500); };

  return (
    <div className="min-h-screen bg-[#f8fffe] flex">
      {/* Success Toast */}
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-[60] max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />{successMsg}
        </div>
      )}

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Notification overlay */}
      {notifOpen && (
        <div
          className="fixed inset-0 z-20"
          onClick={() => setNotifOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className="w-[280px] sm:w-72 bg-[#ffffff] border-l border-[#0D9488]/10 z-50 transition-transform duration-300"
        style={{
          position: isLargeScreen ? 'static' : 'fixed',
          top: 0,
          right: 0,
          bottom: 0,
          transform: isLargeScreen ? 'translateX(0)' : sidebarOpen ? 'translateX(0)' : 'translateX(100%)',
          zIndex: isLargeScreen ? 'auto' : 50,
        }}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-[#0D9488] rounded-xl flex items-center justify-center">
                <Building2 className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="text-sm text-[#1a1a2e]">{buildingName}</span>
                {buildingSubtitle && (
                  <span className="text-[10px] text-[#5f6b7a] block -mt-0.5">{buildingSubtitle}</span>
                )}
              </div>
              <button
                onClick={() => {
                  navigate("/dashboard/building");
                  setSidebarOpen(false);
                }}
                className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${isActive("/dashboard/building")
                  ? "bg-[#0D9488] text-white"
                  : "text-[#5f6b7a] hover:bg-[#0D9488]/10 hover:text-[#0D9488]"
                  }`}
                title="إدارة المبنى"
              >
                <Settings className="w-4 h-4" />
              </button>
            </div>
            <button
              className="lg:hidden text-[#5f6b7a]"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-1">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  navigate(item.path);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 sm:px-4 py-3 rounded-xl text-sm transition-all ${isActive(item.path)
                  ? "bg-[#0D9488] text-white shadow-md shadow-[#0D9488]/20"
                  : "text-[#5f6b7a] hover:bg-[#0D9488]/5 hover:text-[#0D9488]"
                  }`}
              >
                <item.icon className="w-5 h-5 shrink-0" />
                <span className="flex-1 text-right">{item.label}</span>
              </button>
            ))}
          </nav>

          {/* User */}
          <div className="p-3 border-t border-[#0D9488]/10">
            <div className="flex items-center gap-2">
              {/* Avatar */}
              <div
                className="w-9 h-9 bg-[#0D9488]/10 rounded-full flex items-center justify-center overflow-hidden shrink-0 cursor-pointer"
                onClick={() => { navigate("/dashboard/settings"); setSidebarOpen(false); }}
              >
                {profile?.avatarBase64 ? (
                  <img src={profile.avatarBase64} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-xs text-[#0D9488]">{adminInitials}</span>
                )}
              </div>
              {/* Name + Role */}
              <div className="flex-1 min-w-0 cursor-pointer" onClick={() => { navigate("/dashboard/settings"); setSidebarOpen(false); }}>
                <div className="text-sm text-[#1a1a2e] truncate leading-tight">{adminName}</div>
                <div className="text-[11px] text-[#5f6b7a] truncate leading-tight">{adminRole}</div>
              </div>
              {/* Switch to Resident Portal */}
              <button
                onClick={() => { navigate("/resident"); setSidebarOpen(false); }}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-[#F59E0B] hover:bg-[#F59E0B]/10 transition-colors shrink-0"
                title="التبديل لحساب الساكن"
              >
                <ArrowLeftRight className="w-4 h-4" />
              </button>
              {/* Logout */}
              <button
                onClick={async () => { await logout(); navigate("/login"); }}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-[#5f6b7a] hover:text-red-500 hover:bg-red-50 transition-colors shrink-0"
                title="تسجيل الخروج"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-h-screen min-w-0 overflow-x-hidden">
        {/* Top bar */}
        <header className="sticky top-0 z-30 border-b border-[#0D9488]/10" style={{ backgroundColor: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}>
          <div className="flex items-center justify-between px-4 sm:px-6 h-16">
            <div className="flex items-center gap-3">
              <button
                className="lg:hidden text-[#5f6b7a]"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="w-6 h-6" />
              </button>
              <h2 className="text-[#1a1a2e]">
                {location.pathname === "/dashboard/building"
                  ? "إدارة المبنى"
                  : location.pathname === "/dashboard/settings"
                    ? "الملف الشخصي"
                    : location.pathname === "/dashboard/subscription"
                      ? "الاشتراك"
                      : location.pathname.startsWith("/dashboard/chat")
                        ? "المحادثات"
                        : location.pathname === "/dashboard"
                          ? buildingName
                          : menuItems.find((item) => isActive(item.path))?.label || "لوحة التحكم"}
              </h2>
            </div>
            <div className="flex items-center gap-3">
              {/* Chat Icon */}
              <button
                onClick={() => navigate("/dashboard/chat")}
                className={`relative p-2 rounded-xl transition-colors ${
                  isActive("/dashboard/chat")
                    ? "text-[#0D9488] bg-[#0D9488]/10"
                    : "text-[#5f6b7a] hover:text-[#0D9488] hover:bg-[#0D9488]/5"
                }`}
                title="المحادثات"
              >
                <MessageCircle className="w-5 h-5" />
                {unreadChatCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] bg-[#F59E0B] text-white text-[10px] rounded-full flex items-center justify-center px-1">
                    {unreadChatCount}
                  </span>
                )}
              </button>

              {/* Notifications Bell */}
              <div className="relative">
                <button
                  onClick={() => setNotifOpen(!notifOpen)}
                  className="relative p-2 text-[#5f6b7a] hover:text-[#0D9488] hover:bg-[#0D9488]/5 rounded-xl transition-colors"
                >
                  <Bell className="w-5 h-5" />
                  {pendingCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] bg-[#F59E0B] text-white text-[10px] rounded-full flex items-center justify-center px-1">
                      {pendingCount}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown */}
                {notifOpen && (
                  <div className="absolute left-0 sm:left-auto sm:right-0 top-12 w-[340px] sm:w-[380px] bg-white rounded-2xl border border-[#0D9488]/10 shadow-xl z-50 overflow-hidden">
                    <div className="px-4 py-3 border-b border-[#0D9488]/10 flex items-center justify-between">
                      <h3 className="text-sm text-[#1a1a2e]">الإشعارات</h3>
                      {pendingCount > 0 && (
                        <span className="text-[10px] bg-[#F59E0B]/10 text-[#F59E0B] px-2 py-0.5 rounded-full">
                          {pendingCount} جديد
                        </span>
                      )}
                    </div>

                    <div className="max-h-[70vh] overflow-y-auto">
                      {pendingJoinCount === 0 && pendingCashCount === 0 && pendingDonationCount === 0 && pendingSrCount === 0 && joinRequests.length === 0 && serviceRequests.length === 0 ? (
                        <div className="p-6 text-center text-sm text-[#5f6b7a]">لا توجد إشعارات</div>
                      ) : (
                        <div className="divide-y divide-gray-50">
                          {/* Cash Collection Notifications */}
                          {cashCollections.filter((c) => c.status === "pending").map((col) => (
                            <div key={col.id} className="p-4 bg-[#6366f1]/[0.03]">
                              <div className="flex items-start gap-3 mb-3">
                                <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 bg-[#6366f1]/10">
                                  <ShieldCheck className="w-5 h-5 text-[#6366f1]" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm text-[#1a1a2e]">{col.residentName}</span>
                                    <span className="text-[10px] text-[#5f6b7a]">{col.date}</span>
                                  </div>
                                  <p className="text-xs text-[#5f6b7a] mt-0.5">
                                    سلّم مبلغ <span className="text-[#0D9488] font-semibold">{col.amount.toLocaleString("en-US")} ج.م</span> للأمن
                                  </p>
                                </div>
                              </div>
                              <div className="grid grid-cols-3 gap-2 mb-3">
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">الشقة</div>
                                  <div className="text-xs text-[#1a1a2e]">{col.unitCode}</div>
                                </div>
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">المبلغ</div>
                                  <div className="text-xs text-[#0D9488]">{col.amount.toLocaleString("en-US")}</div>
                                </div>
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">الفاتورة</div>
                                  <div className="text-[10px] text-[#1a1a2e] truncate">{col.batchDescription}</div>
                                </div>
                              </div>
                              <button
                                onClick={() => handleConfirmCollection(col)}
                                disabled={confirmingId === col.id}
                                className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-lg bg-[#0D9488] text-white text-xs hover:bg-[#0D9488]/90 transition-all shadow-sm disabled:opacity-60"
                              >
                                {confirmingId === col.id ? (
                                  <><Loader2 className="w-3.5 h-3.5 animate-spin" />جاري التأكيد...</>
                                ) : (
                                  <><Check className="w-3.5 h-3.5" />تم التحصيل</>
                                )}
                              </button>
                            </div>
                          ))}

                          {/* Join Request Notifications */}
                          {joinRequests.filter((r) => r.status === "pending").map((req) => (
                            <div key={req.id} className="p-4 bg-[#F59E0B]/[0.03]">
                              <div className="flex items-start gap-3 mb-3">
                                <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 bg-[#F59E0B]/10">
                                  <Users className="w-5 h-5 text-[#F59E0B]" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm text-[#1a1a2e]">{req.name}</span>
                                    <span className="text-[10px] text-[#5f6b7a]">{timeAgo(req.createdAt)}</span>
                                  </div>
                                  <p className="text-xs text-[#5f6b7a] mt-0.5">
                                    طلب انضمام كـ{req.type}
                                  </p>
                                </div>
                              </div>

                              <div className="grid grid-cols-3 gap-2 mb-3">
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">الشقة</div>
                                  <div className="text-xs text-[#1a1a2e]">{req.unitCode}</div>
                                </div>
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">الدور</div>
                                  <div className="text-xs text-[#1a1a2e]">{req.floor}</div>
                                </div>
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">الهاتف</div>
                                  <div className="text-[10px] text-[#1a1a2e]" dir="ltr">{req.phone}</div>
                                </div>
                              </div>

                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleApprove(req.id)}
                                  disabled={respondingId === req.id}
                                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#0D9488] text-white text-xs hover:bg-[#0D9488]/90 transition-all shadow-sm disabled:opacity-60"
                                >
                                  {respondingId === req.id ? (
                                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                  ) : (
                                    <Check className="w-3.5 h-3.5" />
                                  )}
                                  قبول
                                </button>
                                <button
                                  onClick={() => handleReject(req.id)}
                                  disabled={respondingId === req.id}
                                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-red-200 text-red-500 text-xs hover:bg-red-50 transition-all disabled:opacity-60"
                                >
                                  <X className="w-3.5 h-3.5" />رفض
                                </button>
                              </div>
                            </div>
                          ))}

                          {/* Donation Cash Requests */}
                          {donationCashRequests.filter((r) => r.status === "pending").map((req) => (
                            <div key={req.id} className="p-4 bg-[#F59E0B]/[0.03]">
                              <div className="flex items-start gap-3 mb-3">
                                <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 bg-[#F59E0B]/10">
                                  <Heart className="w-5 h-5 text-[#F59E0B]" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm text-[#1a1a2e]">{req.residentName}</span>
                                    <span className="text-[10px] text-[#5f6b7a]">{timeAgo(req.date)}</span>
                                  </div>
                                  <p className="text-xs text-[#5f6b7a] mt-0.5">
                                    بانتظار تحصيل <span className="text-[#0D9488] font-semibold">{req.amount.toLocaleString("en-US")} ج.م</span>
                                  </p>
                                </div>
                              </div>

                              <div className="grid grid-cols-3 gap-2 mb-3">
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">الشقة</div>
                                  <div className="text-xs text-[#1a1a2e]">{req.unitCode}</div>
                                </div>
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">المبلغ</div>
                                  <div className="text-xs text-[#0D9488]">{req.amount.toLocaleString("en-US")}</div>
                                </div>
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">الحملة</div>
                                  <div className="text-[10px] text-[#1a1a2e] truncate">{req.campaignTitle}</div>
                                </div>
                              </div>

                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleConfirmDonationCash(req)}
                                  disabled={confirmingId === req.id}
                                  className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg bg-[#0D9488] text-white text-xs hover:bg-[#0D9488]/90 transition-all shadow-sm disabled:opacity-60"
                                >
                                  {confirmingId === req.id ? (
                                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                  ) : (
                                    <Check className="w-3.5 h-3.5" />
                                  )}
                                  تم التحصيل
                                </button>
                              </div>
                            </div>
                          ))}

                          {/* Service Requests — Pending */}
                          {serviceRequests.filter((sr) => sr.status === "pending").map((sr) => (
                            <div key={sr.id} className="p-4 bg-[#F59E0B]/[0.03]">
                              <div className="flex items-start gap-3 mb-3">
                                <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 bg-[#F59E0B]/10">
                                  <ClipboardList className="w-5 h-5 text-[#F59E0B]" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm text-[#1a1a2e]">{sr.requesterName}</span>
                                    <span className="text-[10px] text-[#5f6b7a]">{timeAgo(sr.createdAt)}</span>
                                  </div>
                                  <p className="text-xs text-[#5f6b7a] mt-0.5">
                                    طلب خدمة: <span className="text-[#1a1a2e]">{sr.title}</span>
                                  </p>
                                </div>
                              </div>

                              <div className="grid grid-cols-3 gap-2 mb-3">
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">الشقة</div>
                                  <div className="text-xs text-[#1a1a2e]">{sr.unitCode || "—"}</div>
                                </div>
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">التصنيف</div>
                                  <div className="text-xs text-[#0D9488]">{sr.category}</div>
                                </div>
                                <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                                  <div className="text-[9px] text-[#5f6b7a]">التفاصيل</div>
                                  <div className="text-[10px] text-[#1a1a2e] truncate">{sr.description || "—"}</div>
                                </div>
                              </div>

                              {/* Inline note */}
                              {srNoteId === sr.id && (
                                <div className="mb-3">
                                  <input
                                    type="text"
                                    value={srNote}
                                    onChange={(e) => setSrNote(e.target.value)}
                                    placeholder="ملاحظة للساكن (اختياري)..."
                                    className="w-full px-3 py-2 border border-gray-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-[#0D9488]/30 bg-white"
                                  />
                                </div>
                              )}

                              <div className="flex gap-2">
                                {srNoteId !== sr.id ? (
                                  <>
                                    <button
                                      onClick={() => handleSrAction(sr.id, "approved")}
                                      disabled={srRespondingId === sr.id}
                                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#0D9488] text-white text-xs hover:bg-[#0D9488]/90 transition-all shadow-sm disabled:opacity-60"
                                    >
                                      {srRespondingId === sr.id ? (
                                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                      ) : (
                                        <Check className="w-3.5 h-3.5" />
                                      )}
                                      قبول
                                    </button>
                                    <button
                                      onClick={() => handleSrAction(sr.id, "rejected")}
                                      disabled={srRespondingId === sr.id}
                                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-red-200 text-red-500 text-xs hover:bg-red-50 transition-all disabled:opacity-60"
                                    >
                                      <X className="w-3.5 h-3.5" />رفض
                                    </button>
                                    <button
                                      onClick={() => { setSrNoteId(sr.id); setSrNote(""); }}
                                      className="px-2 py-2 rounded-lg border border-gray-200 text-[#5f6b7a] text-xs hover:bg-gray-50 transition-all"
                                      title="إضافة ملاحظة"
                                    >
                                      <Edit3 className="w-3.5 h-3.5" />
                                    </button>
                                  </>
                                ) : (
                                  <>
                                    <button
                                      onClick={() => handleSrAction(sr.id, "approved")}
                                      disabled={srRespondingId === sr.id}
                                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#0D9488] text-white text-xs hover:bg-[#0D9488]/90 transition-all shadow-sm disabled:opacity-60"
                                    >
                                      {srRespondingId === sr.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                                      قبول مع ملاحظة
                                    </button>
                                    <button
                                      onClick={() => handleSrAction(sr.id, "rejected")}
                                      disabled={srRespondingId === sr.id}
                                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-red-200 text-red-500 text-xs hover:bg-red-50 transition-all disabled:opacity-60"
                                    >
                                      <X className="w-3.5 h-3.5" />رفض
                                    </button>
                                    <button
                                      onClick={() => { setSrNoteId(null); setSrNote(""); }}
                                      className="px-2 py-2 rounded-lg border border-gray-200 text-[#5f6b7a] text-xs hover:bg-gray-50"
                                    >
                                      <X className="w-3 h-3" />
                                    </button>
                                  </>
                                )}
                              </div>
                            </div>
                          ))}

                          {/* Service Requests — Approved (waiting to be closed) */}
                          {serviceRequests.filter((sr) => sr.status === "approved").map((sr) => (
                            <div key={sr.id} className="p-4">
                              <div className="flex items-start gap-3 mb-2">
                                <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 bg-[#22c55e]/10">
                                  <ClipboardList className="w-5 h-5 text-[#22c55e]" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm text-[#1a1a2e]">{sr.requesterName}</span>
                                    <span className="text-[10px] text-[#5f6b7a]">{timeAgo(sr.updatedAt)}</span>
                                  </div>
                                  <p className="text-xs text-[#5f6b7a] mt-0.5">{sr.title} — شقة {sr.unitCode || "—"}</p>
                                </div>
                              </div>
                              <div className="flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#22c55e]/10 text-[#22c55e] text-xs mb-2">
                                <Check className="w-3.5 h-3.5" />تم القبول
                              </div>
                              <button
                                onClick={() => handleSrAction(sr.id, "closed")}
                                disabled={srRespondingId === sr.id}
                                className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#6b7280] text-white text-xs hover:bg-[#6b7280]/90 transition-all shadow-sm disabled:opacity-60"
                              >
                                {srRespondingId === sr.id ? (
                                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                ) : (
                                  <Check className="w-3.5 h-3.5" />
                                )}
                                إغلاق الطلب
                              </button>
                            </div>
                          ))}

                          {/* Recently handled join requests (show last 5) */}
                          {joinRequests.filter((r) => r.status !== "pending").slice(0, 5).map((req) => (
                            <div key={req.id} className="p-4">
                              <div className="flex items-start gap-3 mb-2">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                                  req.status === "approved" ? "bg-[#0D9488]/10" : "bg-red-50"
                                }`}>
                                  <Users className={`w-5 h-5 ${
                                    req.status === "approved" ? "text-[#0D9488]" : "text-red-400"
                                  }`} />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm text-[#1a1a2e]">{req.name}</span>
                                    <span className="text-[10px] text-[#5f6b7a]">{timeAgo(req.updatedAt)}</span>
                                  </div>
                                  <p className="text-xs text-[#5f6b7a] mt-0.5">شقة {req.unitCode} — {req.type}</p>
                                </div>
                              </div>
                              <div className={`flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs ${
                                req.status === "approved"
                                  ? "bg-[#0D9488]/10 text-[#0D9488]"
                                  : "bg-red-50 text-red-500"
                              }`}>
                                {req.status === "approved" ? (
                                  <><Check className="w-3.5 h-3.5" />تم القبول</>
                                ) : (
                                  <><X className="w-3.5 h-3.5" />تم الرفض</>
                                )}
                              </div>
                            </div>
                          ))}

                          {/* Recently handled service requests */}
                          {serviceRequests.filter((sr) => sr.status === "rejected" || sr.status === "closed").slice(0, 5).map((sr) => (
                            <div key={sr.id} className="p-4">
                              <div className="flex items-start gap-3 mb-2">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                                  sr.status === "closed" ? "bg-[#6b7280]/10" : "bg-red-50"
                                }`}>
                                  <ClipboardList className={`w-5 h-5 ${
                                    sr.status === "closed" ? "text-[#6b7280]" : "text-red-400"
                                  }`} />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm text-[#1a1a2e]">{sr.requesterName}</span>
                                    <span className="text-[10px] text-[#5f6b7a]">{timeAgo(sr.updatedAt)}</span>
                                  </div>
                                  <p className="text-xs text-[#5f6b7a] mt-0.5">{sr.title}</p>
                                </div>
                              </div>
                              <div className={`flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs ${
                                sr.status === "closed"
                                  ? "bg-[#6b7280]/10 text-[#6b7280]"
                                  : "bg-red-50 text-red-500"
                              }`}>
                                {sr.status === "closed" ? (
                                  <><Check className="w-3.5 h-3.5" />تم الإغلاق</>
                                ) : (
                                  <><X className="w-3.5 h-3.5" />تم الرفض</>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 sm:p-6">
          {/* Complete Profile Prompt */}
          {showProfilePrompt && (
            <div className="mb-4 bg-[#F59E0B]/5 border border-[#F59E0B]/20 rounded-2xl p-4 flex items-start gap-3">
              <div className="w-10 h-10 bg-[#F59E0B]/10 rounded-xl flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-[#F59E0B]" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm text-[#1a1a2e] mb-1">أكمل ملفك الشخصي</h3>
                <p className="text-xs text-[#5f6b7a] mb-2">أضف عنوان المبنى والمدينة وباقي البيانات لتجربة أفضل</p>
                <button
                  onClick={() => { navigate("/dashboard/building"); setShowProfilePrompt(false); }}
                  className="text-xs bg-[#F59E0B] text-white px-4 py-2 rounded-xl hover:bg-[#F59E0B]/90 transition-all"
                >
                  إكمال البيانات
                </button>
              </div>
              <button onClick={() => setShowProfilePrompt(false)} className="text-[#5f6b7a] hover:text-[#1a1a2e]">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
          <Outlet />
        </main>
      </div>
    </div>
  );
}