import { useState, useEffect, useCallback } from "react";
import { Plus, Search, TrendingUp, Repeat, Clock, MoreVertical, X, Pencil, Trash2, CheckCircle2, Loader2, Download, CircleStop, RotateCcw, AlertCircle } from "lucide-react";
import * as api from "../../lib/api";
import { MobileFAB } from "./MobileFAB";

const categories = ["الكل", "إيجار محلات", "كراج", "إعلانات", "أخرى"];
const categoryOptions = ["إيجار محلات", "كراج", "إعلانات", "أخرى"];

interface RevenueForm {
  title: string;
  amount: number;
  category: string;
  type: "دائم" | "مؤقت";
  date: string;
}

const emptyForm: RevenueForm = {
  title: "", amount: 0, category: "إيجار محلات", type: "دائم", date: "",
};

export function RevenuePage() {
  const [revenues, setRevenues] = useState<api.Revenue[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeCategory, setActiveCategory] = useState("الكل");
  const [searchQuery, setSearchQuery] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<RevenueForm>(emptyForm);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [togglingStop, setTogglingStop] = useState<string | null>(null);

  const loadRevenues = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getRevenues();
      setRevenues(data);
    } catch (err) {
      console.error("Error loading revenues:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadRevenues();
  }, [loadRevenues]);

  const filtered = revenues.filter(
    (r) =>
      (activeCategory === "الكل" || r.category === activeCategory) &&
      (searchQuery === "" || r.title.includes(searchQuery))
  );

  const total = filtered.reduce((sum, r) => sum + r.amount, 0);

  const openAdd = () => {
    setForm({ ...emptyForm, date: new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" }) });
    setEditingId(null);
    setShowModal(true);
  };

  const openEdit = (revenue: api.Revenue) => {
    setForm({
      title: revenue.title,
      amount: revenue.amount,
      category: revenue.category,
      type: revenue.type,
      date: revenue.date,
    });
    setEditingId(revenue.id);
    setShowModal(true);
    setMenuOpen(null);
  };

  const handleSave = async () => {
    if (!form.title || !form.amount) return;
    try {
      setSaving(true);
      if (editingId) {
        await api.updateRevenue(editingId, form);
        showSuccess("تم تحديث الإيراد بنجاح");
      } else {
        await api.createRevenue(form);
        showSuccess("تم إضافة الإيراد بنجاح");
      }
      setShowModal(false);
      await loadRevenues();
    } catch (err: any) {
      console.error("Error saving revenue:", err);
      setErrorMsg(err.message || "خطأ في حفظ الإيراد");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      setSaving(true);
      await api.deleteRevenue(id);
      setDeleteConfirm(null);
      showSuccess("تم حذف الإيراد");
      await loadRevenues();
    } catch (err: any) {
      console.error("Error deleting revenue:", err);
      setErrorMsg(err.message || "خطأ في حذف الإيراد");
    } finally {
      setSaving(false);
    }
  };

  const handleToggleStop = async (revenue: api.Revenue) => {
    setTogglingStop(revenue.id);
    setMenuOpen(null);
    try {
      if (revenue.stoppedAt) {
        await api.reactivateRevenue(revenue.id);
        showSuccess(`تم إعادة تفعيل "${revenue.title}"`);
      } else {
        await api.stopRevenue(revenue.id);
        showSuccess(`تم إيقاف "${revenue.title}"`);
      }
      await loadRevenues();
    } catch (err: any) {
      console.error("Error toggling revenue stop:", err);
      setErrorMsg(err.message || "خطأ في تغيير حالة الإيراد");
    } finally {
      setTogglingStop(null);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };

  return (
    <div className="space-y-6">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
          {successMsg}
        </div>
      )}
      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm cursor-pointer" onClick={() => setErrorMsg("")}>
          <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl text-[#1a1a2e]">الإيرادات الخارجية</h1>
          <p className="text-sm text-[#5f6b7a]">إيرادات من خارج السكان — إيجار محلات، كراج، إعلانات وغيرها</p>
        </div>
        <div className="flex items-center gap-2">
          {revenues.length > 0 && (
            <button
              onClick={() => {
                const csv = "\uFEFF" + "البند,المبلغ,التصنيف,النوع,الحالة,التاريخ\n" +
                  filtered.map(r => `"${r.title}",${r.amount},"${r.category}","${r.type}","${r.type === "دائم" ? (r.stoppedAt ? "متوقف" : "نشط") : "—"}","${r.date}"`).join("\n");
                const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url; a.download = "إيرادات.csv"; a.click();
                URL.revokeObjectURL(url);
              }}
              className="p-3 rounded-xl border border-gray-200 text-[#5f6b7a] hover:bg-gray-50 transition-all"
              title="تصدير CSV"
            >
              <Download className="w-5 h-5" />
            </button>
          )}
          <button onClick={openAdd} className="hidden sm:inline-flex items-center gap-2 bg-[#0D9488] text-white px-5 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20">
            <Plus className="w-5 h-5" />
            إضافة إيراد
          </button>
        </div>
      </div>

      {/* Total Banner */}
      {!loading && revenues.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#5f6b7a]">إجمالي الإيرادات {activeCategory !== "الكل" ? `(${activeCategory})` : ""}</span>
            <span className="text-lg text-[#1a1a2e]">{total.toLocaleString("en-US")} ج.م</span>
          </div>
        </div>
      )}

      {/* Search + Category Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#5f6b7a]" />
          <input
            type="text"
            placeholder="ابحث عن إيراد..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pr-11 pl-4 py-3 bg-white border border-[#0D9488]/10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm"
          />
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-2 rounded-xl text-xs whitespace-nowrap transition-all ${
                activeCategory === cat
                  ? "bg-[#0D9488] text-white shadow-md"
                  : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:bg-[#0D9488]/5"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Revenues List */}
      <div className="bg-white rounded-2xl border border-[#0D9488]/10 divide-y divide-[#0D9488]/5">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-6 h-6 text-[#0D9488] animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-10 text-center text-sm text-[#5f6b7a]">
            {revenues.length === 0 ? "لا توجد إيرادات مسجلة بعد — ابدأ بإضافة إيراد جديد" : "لا توجد إيرادات مطابقة للبحث"}
          </div>
        ) : (
          <>
            {filtered.map((revenue) => (
              <div key={revenue.id} className={`p-4 sm:p-5 hover:bg-[#0D9488]/3 transition-colors ${revenue.stoppedAt ? "opacity-60" : ""}`}>
                <div className="flex items-center gap-3 sm:gap-4">
                  {/* Icon */}
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${revenue.stoppedAt ? "bg-gray-100" : "bg-[#0D9488]/10"}`}>
                    {revenue.stoppedAt ? (
                      <CircleStop className="w-5 h-5 text-gray-400" />
                    ) : (
                      <TrendingUp className="w-5 h-5 text-[#0D9488]" />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-[#1a1a2e]">{revenue.title}</div>
                    <div className="flex items-center gap-2 sm:gap-3 mt-1 flex-wrap">
                      <span className="text-xs bg-[#0D9488]/10 text-[#0D9488] px-2 py-0.5 rounded">{revenue.category}</span>
                      <span className="flex items-center gap-1 text-[10px] text-[#5f6b7a]">
                        {revenue.type === "دائم" ? <Repeat className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                        {revenue.type}
                      </span>
                      {revenue.type === "دائم" && !revenue.stoppedAt && (
                        <span className="text-[10px] text-[#0D9488] font-medium">نشط — شهري</span>
                      )}
                      {revenue.type === "دائم" && revenue.stoppedAt && (
                        <span className="text-[10px] text-red-500 flex items-center gap-0.5 font-medium">
                          <CircleStop className="w-2.5 h-2.5" />
                          متوقف
                        </span>
                      )}
                      <span className="text-[10px] text-[#5f6b7a]">{revenue.date}</span>
                    </div>
                  </div>

                  {/* Amount + Actions */}
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-sm text-[#0D9488]">{revenue.amount.toLocaleString("en-US")} ج.م</div>
                    <div className="relative">
                      <button
                        onClick={() => setMenuOpen(menuOpen === revenue.id ? null : revenue.id)}
                        className="text-[#5f6b7a] hover:text-[#0D9488] p-1 rounded-lg hover:bg-[#0D9488]/5"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </button>
                      {menuOpen === revenue.id && (
                        <div className="absolute left-0 top-full mt-1 bg-white border border-[#0D9488]/10 rounded-xl shadow-lg z-20 w-40 overflow-hidden">
                          <button onClick={() => openEdit(revenue)} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-[#1a1a2e] hover:bg-[#0D9488]/5">
                            <Pencil className="w-4 h-4 text-[#0D9488]" /> تعديل
                          </button>
                          {revenue.type === "دائم" && (
                            revenue.stoppedAt ? (
                              <button
                                onClick={() => handleToggleStop(revenue)}
                                disabled={togglingStop === revenue.id}
                                className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-[#0D9488] hover:bg-[#0D9488]/5"
                              >
                                {togglingStop === revenue.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />} إعادة تفعيل
                              </button>
                            ) : (
                              <button
                                onClick={() => handleToggleStop(revenue)}
                                disabled={togglingStop === revenue.id}
                                className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-[#F59E0B] hover:bg-[#F59E0B]/5"
                              >
                                {togglingStop === revenue.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CircleStop className="w-4 h-4" />} إيقاف
                              </button>
                            )
                          )}
                          <button onClick={() => { setDeleteConfirm(revenue.id); setMenuOpen(null); }} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-red-500 hover:bg-red-50">
                            <Trash2 className="w-4 h-4" /> حذف
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">{editingId ? "تعديل إيراد" : "إضافة إيراد جديد"}</h3>
              <button onClick={() => setShowModal(false)} className="text-[#5f6b7a] hover:text-[#1a1a2e]"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4">
              {/* اسم البند */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">اسم البند *</label>
                <input
                  type="text"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="مثال: إيجار محل تجاري"
                  className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                />
              </div>

              {/* المبلغ + التصنيف */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">المبلغ (ج.م) *</label>
                  <input
                    type="number"
                    value={form.amount || ""}
                    onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })}
                    placeholder="0"
                    className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">التصنيف</label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                  >
                    {categoryOptions.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              {/* النوع + التاريخ */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">النوع</label>
                  <div className="flex gap-2">
                    {(["دائم", "مؤقت"] as const).map((t) => (
                      <button
                        key={t}
                        onClick={() => setForm({ ...form, type: t })}
                        className={`flex-1 py-2.5 rounded-xl text-sm border-2 transition-all ${
                          form.type === t ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-100 text-[#5f6b7a]"
                        }`}
                      >
                        {t === "دائم" ? "🔄 دائم" : "⏱️ مؤقت"}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">التاريخ</label>
                  <input
                    type="text"
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    placeholder="1 مارس 2026"
                    className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                  />
                </div>
              </div>

              {/* Info box for recurring type */}
              {form.type === "دائم" && (
                <div className="bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-xl px-3 py-2">
                  <p className="text-[11px] text-[#0D9488]">
                    <Repeat className="w-3 h-3 inline ml-1" />
                    الإيراد الدائم يتكرر تلقائياً كل شهر من تاريخ إنشائه. يمكنك إيقافه لاحقاً من القائمة.
                  </p>
                </div>
              )}
              {form.type === "مؤقت" && (
                <div className="bg-[#F59E0B]/5 border border-[#F59E0B]/10 rounded-xl px-3 py-2">
                  <p className="text-[11px] text-[#F59E0B]">
                    <Clock className="w-3 h-3 inline ml-1" />
                    الإيراد المؤقت يُحسب مرة واحدة فقط في الشهر الذي تم تسجيله فيه.
                  </p>
                </div>
              )}
            </div>
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button onClick={() => setShowModal(false)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button
                onClick={handleSave}
                disabled={!form.title || !form.amount || saving}
                className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${
                  form.title && form.amount && !saving ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20" : "bg-gray-300 cursor-not-allowed"
                }`}
              >
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                {editingId ? "حفظ التعديلات" : "إضافة الإيراد"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-5">
              <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3">
                <Trash2 className="w-7 h-7 text-red-500" />
              </div>
              <h3 className="text-lg text-[#1a1a2e] mb-1">تأكيد الحذف</h3>
              <p className="text-sm text-[#5f6b7a]">هل أنت متأكد من حذف هذا الإيراد؟</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                disabled={saving}
                className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm hover:bg-red-600 flex items-center justify-center gap-2"
              >
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                نعم، احذف
              </button>
            </div>
          </div>
        </div>
      )}

      <MobileFAB onClick={openAdd} label="إضافة إيراد" />
    </div>
  );
}