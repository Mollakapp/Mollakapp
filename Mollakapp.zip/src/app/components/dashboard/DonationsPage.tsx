import { useState, useEffect, useCallback, useRef } from "react";
import {
  Plus,
  Heart,
  Users,
  Clock,
  CheckCircle2,
  X,
  Trash2,
  Loader2,
  HandCoins,
  ChevronLeft,
  ChevronRight,
  Calendar,
  Eye,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";
import * as api from "../../lib/api";
import { MobileFAB } from "./MobileFAB";

// ===== Inline Calendar Picker =====
const AR_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];
const AR_DAYS = ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"];

function CalendarPicker({
  value,
  onChange,
  onClose,
}: {
  value: string;
  onChange: (iso: string) => void;
  onClose: () => void;
}) {
  const today = new Date();
  const initial = value ? new Date(value) : today;
  const [year, setYear] = useState(initial.getFullYear());
  const [month, setMonth] = useState(initial.getMonth());
  const selected = value ? new Date(value) : null;
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [onClose]);

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const prevMonth = () => {
    if (month === 0) { setMonth(11); setYear(year - 1); }
    else setMonth(month - 1);
  };
  const nextMonth = () => {
    if (month === 11) { setMonth(0); setYear(year + 1); }
    else setMonth(month + 1);
  };

  const pick = (day: number) => {
    const d = new Date(year, month, day);
    onChange(d.toISOString().split("T")[0]);
    onClose();
  };

  const isSelected = (day: number) =>
    selected &&
    selected.getFullYear() === year &&
    selected.getMonth() === month &&
    selected.getDate() === day;

  const isToday = (day: number) =>
    today.getFullYear() === year &&
    today.getMonth() === month &&
    today.getDate() === day;

  const isPast = (day: number) => {
    const d = new Date(year, month, day);
    d.setHours(0, 0, 0, 0);
    const t = new Date();
    t.setHours(0, 0, 0, 0);
    return d < t;
  };

  return (
    <div
      ref={ref}
      className="absolute top-full mt-1 right-0 z-50 bg-white rounded-xl border border-[#0D9488]/10 shadow-xl p-3 w-[280px]"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <button onClick={nextMonth} className="p-1 hover:bg-gray-100 rounded-lg">
          <ChevronRight className="w-4 h-4 text-[#5f6b7a]" />
        </button>
        <span className="text-sm text-[#1a1a2e]">
          {AR_MONTHS[month]} {year}
        </span>
        <button onClick={prevMonth} className="p-1 hover:bg-gray-100 rounded-lg">
          <ChevronLeft className="w-4 h-4 text-[#5f6b7a]" />
        </button>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-7 gap-0.5 mb-1">
        {AR_DAYS.map((d) => (
          <div key={d} className="text-center text-[10px] text-[#5f6b7a] py-1">{d}</div>
        ))}
      </div>

      {/* Days */}
      <div className="grid grid-cols-7 gap-0.5">
        {cells.map((day, i) => (
          <button
            key={i}
            disabled={day === null || isPast(day)}
            onClick={() => day && pick(day)}
            className={`h-8 rounded-lg text-xs transition-all ${
              day === null
                ? ""
                : isSelected(day)
                ? "bg-[#0D9488] text-white font-semibold"
                : isToday(day)
                ? "bg-[#0D9488]/10 text-[#0D9488] font-semibold"
                : isPast(day)
                ? "text-gray-300 cursor-not-allowed"
                : "text-[#1a1a2e] hover:bg-[#0D9488]/5"
            }`}
          >
            {day || ""}
          </button>
        ))}
      </div>
    </div>
  );
}

function formatDate(iso: string): string {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });
  } catch {
    return iso;
  }
}

export function DonationsPage() {
  const [campaigns, setCampaigns] = useState<api.DonationCampaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [showDonateModal, setShowDonateModal] = useState<string | null>(null);
  const [showDonorsModal, setShowDonorsModal] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [form, setForm] = useState({ title: "", description: "", target: 0, deadline: "" });
  const [donateForm, setDonateForm] = useState({ name: "", amount: 0 });
  const [showCalendar, setShowCalendar] = useState(false);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  const totalCollected = campaigns.reduce((s, c) => s + c.collected, 0);
  const totalDonors = campaigns.reduce((s, c) => s + c.donors.length, 0);
  const activeCampaigns = campaigns.filter((c) => c.status === "active").length;

  const loadCampaigns = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getDonations();
      setCampaigns(data);
    } catch (err) {
      console.error("Error loading donations:", err);
      showError("فشل تحميل حملات التبرع");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadCampaigns();
  }, [loadCampaigns]);

  const openAdd = () => {
    setForm({ title: "", description: "", target: 0, deadline: "" });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.title || form.target <= 0) return;
    setSaving(true);
    try {
      const res = await api.createDonation(form);
      setCampaigns((prev) => [res.campaign, ...prev]);
      setShowModal(false);
      showSuccess("تم إنشاء حملة التبرع بنجاح");
    } catch (err: any) {
      console.error("Error creating donation:", err);
      showError(err.message || "فشل إنشاء الحملة");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await api.deleteDonation(id);
      setCampaigns((prev) => prev.filter((c) => c.id !== id));
      setDeleteConfirm(null);
      showSuccess("تم حذف الحملة");
    } catch (err: any) {
      console.error("Error deleting donation:", err);
      showError(err.message || "فشل حذف الحملة");
    } finally {
      setDeletingId(null);
    }
  };

  const handleDonate = async () => {
    if (!showDonateModal || !donateForm.name || donateForm.amount <= 0) return;
    setSaving(true);
    try {
      const res = await api.addDonation(showDonateModal, donateForm);
      setCampaigns((prev) =>
        prev.map((c) => (c.id === showDonateModal ? res.campaign : c))
      );
      setShowDonateModal(null);
      setDonateForm({ name: "", amount: 0 });
      showSuccess("تم تسجيل التبرع بنجاح");
    } catch (err: any) {
      console.error("Error adding donation:", err);
      showError(err.message || "فشل تسجيل التبرع");
    } finally {
      setSaving(false);
    }
  };

  const handleToggleStatus = async (id: string) => {
    setTogglingId(id);
    try {
      const res = await api.toggleDonationStatus(id);
      setCampaigns((prev) =>
        prev.map((c) => (c.id === id ? res.campaign : c))
      );
      showSuccess(res.campaign.status === "active" ? "تم إعادة تفعيل الحملة" : "تم إغلاق الحملة");
    } catch (err: any) {
      console.error("Error toggling status:", err);
      showError(err.message || "فشل تحديث حالة الحملة");
    } finally {
      setTogglingId(null);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };
  const showError = (msg: string) => {
    setErrorMsg(msg);
    setTimeout(() => setErrorMsg(""), 3000);
  };

  const statCards = [
    { label: "إجمالي التبرعات", value: `${totalCollected.toLocaleString("en-US")} ج.م`, color: "#0D9488", icon: Heart },
    { label: "عدد المتبرعين", value: totalDonors, color: "#6366f1", icon: Users },
    { label: "حملات نشطة", value: activeCampaigns, color: "#F59E0B", icon: Clock },
  ];

  const donorsCampaign = showDonorsModal
    ? campaigns.find((c) => c.id === showDonorsModal)
    : null;

  return (
    <div className="space-y-6">
      {/* Success Toast */}
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}
      {/* Error Toast */}
      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <X className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl text-[#1a1a2e]">التبرعات</h1>
          <p className="text-sm text-[#5f6b7a]">إنشاء ومتابعة حملات التبرع</p>
        </div>
        <button
          onClick={openAdd}
          className="hidden sm:inline-flex items-center gap-2 bg-[#0D9488] text-white px-5 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20"
        >
          <Plus className="w-5 h-5" />حملة تبرع جديدة
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        {statCards.map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-100 px-2 py-2.5 sm:px-4 sm:py-3 shadow-sm text-center">
            <s.icon className="w-4 h-4 mx-auto mb-1" style={{ color: s.color }} />
            <div className="text-base font-semibold text-[#1a1a2e] truncate">{s.value}</div>
            <div className="text-[10px] sm:text-xs text-[#5f6b7a] truncate">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Loading */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin mx-auto mb-3" />
          <p className="text-sm text-[#5f6b7a]">جاري تحميل الحملات...</p>
        </div>
      ) : (
        /* Campaigns List */
        <div className="space-y-4">
          {campaigns.map((campaign) => {
            const pct = campaign.target > 0 ? Math.min(100, Math.round((campaign.collected / campaign.target) * 100)) : 0;
            return (
              <div
                key={campaign.id}
                className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-all"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className="text-[#1a1a2e]">{campaign.title}</h3>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full ${
                          campaign.status === "active"
                            ? "bg-[#0D9488]/10 text-[#0D9488]"
                            : "bg-gray-100 text-[#5f6b7a]"
                        }`}
                      >
                        {campaign.status === "active" ? "نشطة" : "مكتملة"}
                      </span>
                    </div>
                    {campaign.description && (
                      <p className="text-sm text-[#5f6b7a]">{campaign.description}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-1 shrink-0 mr-2">
                    {/* Toggle status */}
                    <button
                      onClick={() => handleToggleStatus(campaign.id)}
                      disabled={togglingId === campaign.id}
                      className={`p-2 rounded-lg transition-colors ${
                        campaign.status === "active"
                          ? "text-[#0D9488] hover:bg-[#0D9488]/10"
                          : "text-[#5f6b7a] hover:bg-gray-100"
                      }`}
                      title={campaign.status === "active" ? "إغلاق الحملة" : "إعادة تفعيل"}
                    >
                      {togglingId === campaign.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : campaign.status === "active" ? (
                        <ToggleRight className="w-4 h-4" />
                      ) : (
                        <ToggleLeft className="w-4 h-4" />
                      )}
                    </button>
                    {/* Delete */}
                    <button
                      onClick={() => setDeleteConfirm(campaign.id)}
                      className="p-2 text-[#5f6b7a] hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Progress */}
                <div className="mb-3">
                  <div className="flex justify-between text-xs text-[#5f6b7a] mb-1.5">
                    <span>{campaign.collected.toLocaleString("en-US")} ج.م</span>
                    <span>{campaign.target.toLocaleString("en-US")} ج.م</span>
                  </div>
                  <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        pct >= 100 ? "bg-[#F59E0B]" : "bg-[#0D9488]"
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="text-left text-[10px] text-[#5f6b7a] mt-1">{pct}%</div>
                </div>

                {/* Info row */}
                <div className="flex items-center gap-4 text-xs text-[#5f6b7a] flex-wrap mb-3">
                  <span className="flex items-center gap-1">
                    <Users className="w-3 h-3" />{campaign.donors.length} متبرع
                  </span>
                  {campaign.deadline && (
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />{formatDate(campaign.deadline)}
                    </span>
                  )}
                  <span>بواسطة: {campaign.createdBy}</span>
                </div>

                {/* Action buttons */}
                <div className="flex gap-2">
                  {campaign.status === "active" && (
                    <button
                      onClick={() => {
                        setDonateForm({ name: "", amount: 0 });
                        setShowDonateModal(campaign.id);
                      }}
                      className="flex items-center gap-1.5 px-4 py-2 bg-[#0D9488] text-white text-xs rounded-lg hover:bg-[#0D9488]/90 transition-all shadow-sm"
                    >
                      <HandCoins className="w-3.5 h-3.5" />تسجيل تبرع
                    </button>
                  )}
                  {campaign.donors.length > 0 && (
                    <button
                      onClick={() => setShowDonorsModal(campaign.id)}
                      className="flex items-center gap-1.5 px-4 py-2 border border-[#0D9488]/20 text-[#0D9488] text-xs rounded-lg hover:bg-[#0D9488]/5 transition-all"
                    >
                      <Eye className="w-3.5 h-3.5" />المتبرعين ({campaign.donors.length})
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          {campaigns.length === 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center">
              <Heart className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="text-sm text-[#5f6b7a]">لا توجد حملات تبرع</p>
              <p className="text-xs text-[#5f6b7a]/60 mt-1">أنشئ حملة جديدة لبدء جمع التبرعات</p>
            </div>
          )}
        </div>
      )}

      {/* ===== Add Campaign Modal ===== */}
      {showModal && (
        <div
          className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4"
          onClick={() => setShowModal(false)}
        >
          <div className="bg-white rounded-2xl w-full max-w-md" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">حملة تبرع جديدة</h3>
              <button onClick={() => setShowModal(false)} className="text-[#5f6b7a]">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">عنوان الحملة *</label>
                <input
                  type="text"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="مثال: تبرع لعملية جراحية لحارس البرج"
                  className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                />
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">الوصف</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 resize-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">المبلغ المستهدف (ج.م) *</label>
                  <input
                    type="number"
                    value={form.target || ""}
                    onChange={(e) => setForm({ ...form, target: Number(e.target.value) })}
                    className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                  />
                </div>
                <div className="relative">
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">الموعد النهائي</label>
                  <button
                    type="button"
                    onClick={() => setShowCalendar(!showCalendar)}
                    className="w-full flex items-center justify-between px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-right"
                  >
                    <span className={form.deadline ? "text-[#1a1a2e]" : "text-[#5f6b7a]/50"}>
                      {form.deadline ? formatDate(form.deadline) : "اختر تاريخ"}
                    </span>
                    <Calendar className="w-4 h-4 text-[#5f6b7a] shrink-0" />
                  </button>
                  {showCalendar && (
                    <CalendarPicker
                      value={form.deadline}
                      onChange={(iso) => setForm({ ...form, deadline: iso })}
                      onClose={() => setShowCalendar(false)}
                    />
                  )}
                </div>
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button
                onClick={() => setShowModal(false)}
                className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm"
              >
                إلغاء
              </button>
              <button
                onClick={handleSave}
                disabled={!form.title || form.target <= 0 || saving}
                className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${
                  form.title && form.target > 0 && !saving
                    ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20"
                    : "bg-gray-300 cursor-not-allowed"
                }`}
              >
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                إنشاء الحملة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Donate Modal ===== */}
      {showDonateModal && (
        <div
          className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4"
          onClick={() => setShowDonateModal(null)}
        >
          <div className="bg-white rounded-2xl w-full max-w-sm" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">تسجيل تبرع</h3>
              <button onClick={() => setShowDonateModal(null)} className="text-[#5f6b7a]">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">اسم المتبرع *</label>
                <input
                  type="text"
                  value={donateForm.name}
                  onChange={(e) => setDonateForm({ ...donateForm, name: e.target.value })}
                  placeholder="اسم المتبرع"
                  className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                />
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">المبلغ (ج.م) *</label>
                <input
                  type="number"
                  value={donateForm.amount || ""}
                  onChange={(e) => setDonateForm({ ...donateForm, amount: Number(e.target.value) })}
                  className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                />
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button
                onClick={() => setShowDonateModal(null)}
                className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm"
              >
                إلغاء
              </button>
              <button
                onClick={handleDonate}
                disabled={!donateForm.name || donateForm.amount <= 0 || saving}
                className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${
                  donateForm.name && donateForm.amount > 0 && !saving
                    ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20"
                    : "bg-gray-300 cursor-not-allowed"
                }`}
              >
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                تسجيل التبرع
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Donors List Modal ===== */}
      {showDonorsModal && donorsCampaign && (
        <div
          className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4"
          onClick={() => setShowDonorsModal(null)}
        >
          <div
            className="bg-white rounded-2xl w-full max-w-md max-h-[80vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10 shrink-0">
              <h3 className="text-lg text-[#1a1a2e]">
                متبرعو "{donorsCampaign.title}"
              </h3>
              <button onClick={() => setShowDonorsModal(null)} className="text-[#5f6b7a]">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="overflow-y-auto flex-1 p-5">
              {donorsCampaign.donors.length === 0 ? (
                <p className="text-sm text-[#5f6b7a] text-center py-6">لا يوجد متبرعين بعد</p>
              ) : (
                <div className="space-y-3">
                  {donorsCampaign.donors.map((d, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between p-3 bg-[#f8fffe] rounded-xl border border-[#0D9488]/5"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 bg-[#0D9488]/10 rounded-full flex items-center justify-center">
                          <Heart className="w-4 h-4 text-[#0D9488]" />
                        </div>
                        <div>
                          <div className="text-sm text-[#1a1a2e]">{d.name}</div>
                          <div className="text-[10px] text-[#5f6b7a]">
                            {d.date ? formatDate(d.date.split("T")[0]) : ""}
                          </div>
                        </div>
                      </div>
                      <span className="text-sm text-[#0D9488] font-semibold">
                        {d.amount.toLocaleString("en-US")} ج.م
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="p-4 border-t border-[#0D9488]/10 shrink-0 flex items-center justify-between">
              <span className="text-xs text-[#5f6b7a]">
                الإجمالي: {donorsCampaign.collected.toLocaleString("en-US")} ج.م
              </span>
              <span className="text-xs text-[#5f6b7a]">
                {donorsCampaign.donors.length} متبرع
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ===== Delete Confirmation ===== */}
      {deleteConfirm && (
        <div
          className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4"
          onClick={() => setDeleteConfirm(null)}
        >
          <div className="bg-white rounded-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-5">
              <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3">
                <Trash2 className="w-7 h-7 text-red-500" />
              </div>
              <h3 className="text-lg text-[#1a1a2e] mb-1">حذف الحملة</h3>
              <p className="text-sm text-[#5f6b7a]">هل أنت متأكد من حذف هذه الحملة؟</p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm"
              >
                إلغاء
              </button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                disabled={deletingId === deleteConfirm}
                className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm hover:bg-red-600 flex items-center justify-center gap-2"
              >
                {deletingId === deleteConfirm && <Loader2 className="w-4 h-4 animate-spin" />}
                نعم، احذف
              </button>
            </div>
          </div>
        </div>
      )}
      <MobileFAB onClick={openAdd} label="حملة تبرع جديدة" />
    </div>
  );
}