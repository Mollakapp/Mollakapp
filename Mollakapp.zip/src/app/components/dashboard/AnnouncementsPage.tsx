import { useState, useEffect, useCallback } from "react";
import { Plus, Megaphone, AlertTriangle, Info, Wrench, Zap, Clock, X, Trash2, Pencil, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import * as api from "../../lib/api";
import { MobileFAB } from "./MobileFAB";

const iconMap: Record<string, typeof Wrench> = { "صيانة": Wrench, "طوارئ": Zap, "عام": Info, "مالي": Megaphone };
const colorMap: Record<string, string> = { "صيانة": "#F59E0B", "طوارئ": "#dc2626", "عام": "#0D9488", "مالي": "#6366f1" };

const emptyForm = { title: "", description: "", category: "عام", date: "", timeFrom: "", timeTo: "", urgent: false, author: "رئيس الاتحاد" };

const categoriesList = ["الكل", "صيانة", "طوارئ", "عام", "مالي"];
const categoryOptions = ["صيانة", "طوارئ", "عام", "مالي"];

// ===== Arabic Date Helpers =====
const ARABIC_MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
];

function toArabicDate(dateVal: string): string {
  if (!dateVal) return "";
  const [y, m, d] = dateVal.split("-");
  const mi = parseInt(m, 10) - 1;
  if (mi < 0 || mi > 11) return "";
  return `${parseInt(d, 10)} ${ARABIC_MONTHS[mi]} ${y}`;
}

function toDateValue(arabic: string): string {
  const parts = arabic.trim().split(" ");
  if (parts.length < 3) return "";
  const day = parseInt(parts[0], 10);
  const mi = ARABIC_MONTHS.indexOf(parts[1]);
  if (isNaN(day) || mi === -1) return "";
  return `${parts[2]}-${String(mi + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

export function AnnouncementsPage() {
  const [announcements, setAnnouncements] = useState<api.Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeCategory, setActiveCategory] = useState("الكل");
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const fetchAnnouncements = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getAnnouncements();
      setAnnouncements(data);
    } catch (err: any) {
      console.error("Error fetching announcements:", err);
      setErrorMsg("خطأ في تحميل الإعلانات");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAnnouncements();
  }, [fetchAnnouncements]);

  const filtered = announcements.filter(
    (a) => activeCategory === "الكل" || a.category === activeCategory
  );

  const openAdd = () => {
    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
    setForm({ ...emptyForm, date: toArabicDate(todayStr) });
    setEditingId(null);
    setShowModal(true);
  };

  const openEdit = (ann: api.Announcement) => {
    setForm({ title: ann.title, description: ann.description, category: ann.category, date: ann.date, timeFrom: ann.timeFrom, timeTo: ann.timeTo, urgent: ann.urgent, author: ann.author });
    setEditingId(ann.id);
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.title || !form.description) return;
    setSaving(true);
    try {
      if (editingId) {
        await api.updateAnnouncement(editingId, form);
        showSucc("تم تحديث الإعلان بنجاح");
      } else {
        await api.createAnnouncement(form);
        showSucc("تم نشر الإعلان بنجاح");
      }
      setShowModal(false);
      await fetchAnnouncements();
    } catch (err: any) {
      console.error("Error saving announcement:", err);
      setErrorMsg(err.message || "خطأ في حفظ الإعلان");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteAnnouncement(id);
      setDeleteConfirm(null);
      showSucc("تم حذف الإعلان");
      await fetchAnnouncements();
    } catch (err: any) {
      console.error("Error deleting announcement:", err);
      setErrorMsg(err.message || "خطأ في حذف الإعلان");
    }
  };

  const showSucc = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };

  return (
    <div className="space-y-6">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}
      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm cursor-pointer" onClick={() => setErrorMsg("")}>
          <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl text-[#1a1a2e]">الإعلانات والتنبيهات</h1>
          <p className="text-sm text-[#5f6b7a]">أعلن عن صيانة أو تنبيه مهم لكل السكان</p>
        </div>
        <button onClick={openAdd} className="hidden sm:inline-flex items-center gap-2 bg-[#0D9488] text-white px-5 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all shadow-md shadow-[#0D9488]/20">
          <Plus className="w-5 h-5" />
          إعلان جديد
        </button>
      </div>

      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
        {categoriesList.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-2 rounded-xl text-xs whitespace-nowrap transition-all ${
              activeCategory === cat ? "bg-[#0D9488] text-white shadow-md" : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:bg-[#0D9488]/5"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin" />
        </div>
      )}

      {!loading && (
        <div className="space-y-4">
          {filtered.map((announcement) => {
            const Icon = iconMap[announcement.category] || Megaphone;
            const color = colorMap[announcement.category] || "#0D9488";
            return (
              <div
                key={announcement.id}
                className={`bg-white rounded-2xl border p-4 sm:p-6 hover:shadow-md transition-all ${
                  announcement.urgent ? "border-[#F59E0B]/30 shadow-sm shadow-[#F59E0B]/5" : "border-[#0D9488]/10"
                }`}
              >
                <div className="flex items-start gap-3 sm:gap-4">
                  <div className="w-10 sm:w-12 h-10 sm:h-12 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${color}15` }}>
                    <Icon className="w-5 sm:w-6 h-5 sm:h-6" style={{ color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-2">
                      <h3 className="text-[#1a1a2e]">{announcement.title}</h3>
                      {announcement.urgent && (
                        <span className="flex items-center gap-1 text-xs bg-[#F59E0B]/10 text-[#F59E0B] px-2 py-0.5 rounded-full">
                          <AlertTriangle className="w-3 h-3" />عاجل
                        </span>
                      )}
                      <span className="text-xs px-2 py-0.5 rounded-full" style={{ backgroundColor: `${color}15`, color }}>{announcement.category}</span>
                    </div>
                    <p className="text-sm text-[#5f6b7a] leading-relaxed mb-3">{announcement.description}</p>
                    <div className="flex items-center gap-4 flex-wrap text-xs text-[#5f6b7a]">
                      <span>📅 {announcement.date}</span>
                      {announcement.timeFrom && (
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{announcement.timeFrom} — {announcement.timeTo}</span>
                      )}
                      <span>بواسطة: {announcement.author}</span>
                    </div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <button onClick={() => openEdit(announcement)} className="p-2 text-[#5f6b7a] hover:text-[#0D9488] hover:bg-[#0D9488]/5 rounded-lg transition-colors">
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button onClick={() => setDeleteConfirm(announcement.id)} className="p-2 text-[#5f6b7a] hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div className="bg-white rounded-2xl border border-[#0D9488]/10 p-10 text-center text-sm text-[#5f6b7a]">لا توجد إعلانات في هذا التصنيف</div>
          )}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">{editingId ? "تعديل الإعلان" : "إعلان جديد"}</h3>
              <button onClick={() => setShowModal(false)} className="text-[#5f6b7a]"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">عنوان الإعلان *</label>
                <input type="text" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="مثال: صيانة المصعد" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
              </div>
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">التفاصيل *</label>
                <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} placeholder="اكتب تفاصيل الإعلان..." className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 resize-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">التصنيف</label>
                  <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20">
                    {categoryOptions.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">التاريخ</label>
                  <input type="date" value={toDateValue(form.date)} onChange={(e) => setForm({ ...form, date: toArabicDate(e.target.value) })} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">من الساعة</label>
                  <input type="time" value={form.timeFrom} onChange={(e) => setForm({ ...form, timeFrom: e.target.value })} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">إلى الساعة</label>
                  <input type="time" value={form.timeTo} onChange={(e) => setForm({ ...form, timeTo: e.target.value })} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-[#F59E0B]/5 rounded-xl">
                <button
                  onClick={() => setForm({ ...form, urgent: !form.urgent })}
                  className={`w-12 h-7 rounded-full transition-all relative ${form.urgent ? "bg-[#F59E0B]" : "bg-gray-200"}`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full absolute top-1 transition-all shadow-sm ${form.urgent ? "left-1" : "left-6"}`} />
                </button>
                <div>
                  <div className="text-sm text-[#1a1a2e]">إعلان عاجل</div>
                  <div className="text-xs text-[#5f6b7a]">سيظهر بتنبيه مميز لكل السكان</div>
                </div>
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button onClick={() => setShowModal(false)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={handleSave} disabled={!form.title || !form.description || saving} className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${form.title && form.description && !saving ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20" : "bg-gray-300 cursor-not-allowed"}`}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                {editingId ? "حفظ التعديلات" : "نشر الإعلان"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-5">
              <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3"><Trash2 className="w-7 h-7 text-red-500" /></div>
              <h3 className="text-lg text-[#1a1a2e] mb-1">حذف الإعلان</h3>
              <p className="text-sm text-[#5f6b7a]">هل أنت متأكد من حذف هذا الإعلان؟</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm hover:bg-red-600">نعم، احذف</button>
            </div>
          </div>
        </div>
      )}
      <MobileFAB onClick={openAdd} label="إعلان جديد" />
    </div>
  );
}