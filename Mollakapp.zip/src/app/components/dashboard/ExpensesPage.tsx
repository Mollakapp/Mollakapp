import { useState, useEffect, useCallback } from "react";
import { Plus, Search, MoreVertical, Clock, Repeat, X, Pencil, Trash2, CheckCircle2, CalendarX, ImagePlus, XCircle, Loader2, AlertCircle, CircleStop, RotateCcw } from "lucide-react";
import * as api from "../../lib/api";
import { MobileFAB } from "./MobileFAB";

const categories = ["الكل", "رواتب", "صيانة", "نظافة", "كهرباء", "أخرى"];
const categoryOptions = ["رواتب", "صيانة", "نظافة", "كهرباء", "أخرى"];

interface ExpenseForm {
  title: string;
  unitPrice: number;
  quantity: number;
  category: string;
  type: "دائم" | "مؤقت";
  date: string;
  endDate: string;
  image?: string;
}

const emptyForm: ExpenseForm = {
  title: "",
  unitPrice: 0,
  quantity: 1,
  category: "صيانة",
  type: "مؤقت",
  date: "",
  endDate: "",
};

export function ExpensesPage() {
  const [expenses, setExpenses] = useState<api.Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeCategory, setActiveCategory] = useState("الكل");
  const [searchQuery, setSearchQuery] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<ExpenseForm>(emptyForm);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [togglingStop, setTogglingStop] = useState<string | null>(null);
  const [mobileActionSheet, setMobileActionSheet] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);

  const fetchExpenses = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getExpenses();
      setExpenses(data);
    } catch (err: any) {
      console.error("Error fetching expenses:", err);
      setErrorMsg("خطأ في تحميل المصروفات");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchExpenses();
  }, [fetchExpenses]);

  const filtered = expenses.filter(
    (e) =>
      (activeCategory === "الكل" || e.category === activeCategory) &&
      (searchQuery === "" || e.title.includes(searchQuery))
  );

  const total = filtered.reduce((sum, e) => sum + e.amount, 0);
  const formTotal = form.unitPrice * form.quantity;

  const openAdd = () => {
    setForm({ ...emptyForm, date: new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" }) });
    setEditingId(null);
    setShowModal(true);
  };

  const openEdit = (expense: api.Expense) => {
    setForm({
      title: expense.title,
      unitPrice: expense.unitPrice,
      quantity: expense.quantity,
      category: expense.category,
      type: expense.type,
      date: expense.date,
      endDate: expense.endDate || "",
      image: expense.image,
    });
    setEditingId(expense.id);
    setShowModal(true);
    setMenuOpen(null);
  };

  const handleSave = async () => {
    if (!form.title || formTotal <= 0) return;
    setSaving(true);
    try {
      const expenseData = {
        title: form.title,
        unitPrice: form.unitPrice,
        quantity: form.quantity,
        category: form.category,
        type: form.type,
        date: form.date,
        endDate: form.type === "مؤقت" && form.endDate ? form.endDate : undefined,
        image: form.image,
      };
      if (editingId) {
        await api.updateExpense(editingId, expenseData);
        showSuccess("تم تحديث المصروف بنجاح");
      } else {
        await api.createExpense(expenseData);
        showSuccess("تم إضافة المصروف بنجاح");
      }
      setShowModal(false);
      await fetchExpenses();
    } catch (err: any) {
      console.error("Error saving expense:", err);
      setErrorMsg(err.message || "خطأ في حفظ المصروف");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteExpense(id);
      setDeleteConfirm(null);
      setMenuOpen(null);
      showSuccess("تم حذف المصروف");
      await fetchExpenses();
    } catch (err: any) {
      console.error("Error deleting expense:", err);
      setErrorMsg(err.message || "خطأ في حذف المصروف");
    }
  };

  const handleToggleStop = async (expense: api.Expense) => {
    setTogglingStop(expense.id);
    setMenuOpen(null);
    try {
      if (expense.stoppedAt) {
        await api.reactivateExpense(expense.id);
        showSuccess(`تم إعادة تفعيل "${expense.title}"`);
      } else {
        await api.stopExpense(expense.id);
        showSuccess(`تم إيقاف "${expense.title}"`);
      }
      await fetchExpenses();
    } catch (err: any) {
      console.error("Error toggling expense stop:", err);
      setErrorMsg(err.message || "خطأ في تغيير حالة المصروف");
    } finally {
      setTogglingStop(null);
    }
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };

  const canSave = form.title && formTotal > 0;

  return (
    <div className="space-y-6">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm animate-[fadeIn_0.3s]">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
          {successMsg}
        </div>
      )}
      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm cursor-pointer" onClick={() => setErrorMsg("")}>
          <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl text-[#1a1a2e]">المصروفات</h1>
          <p className="text-sm text-[#5f6b7a]">تسجيل ومتابعة ما يتم إنفاقه من اتحاد الملاك</p>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Search icon */}
          <button
            onClick={() => { setSearchOpen(true); setTimeout(() => document.getElementById("expenses-search-input")?.focus(), 50); }}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              searchQuery ? "bg-[#0D9488] text-white shadow-sm" : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:border-[#0D9488]/30"
            }`}
          >
            <Search className="w-4 h-4" />
          </button>
          {/* Add button (desktop) */}
          <button onClick={openAdd} className="hidden sm:flex w-9 h-9 rounded-xl items-center justify-center bg-[#0D9488] text-white hover:bg-[#0D9488]/90 transition-colors shadow-sm" title="إضافة مصروف">
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Expandable Search Bar */}
      {searchOpen && (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#5f6b7a]" />
            <input
              id="expenses-search-input"
              type="text"
              placeholder="ابحث عن مصروف..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 bg-white border border-[#0D9488]/15 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm"
            />
          </div>
          <button
            onClick={() => { setSearchOpen(false); setSearchQuery(""); }}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#5f6b7a] bg-white border border-gray-100 hover:bg-gray-50 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Total Banner */}
      {!loading && expenses.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#5f6b7a]">إجمالي المصروفات {activeCategory !== "الكل" ? `(${activeCategory})` : ""}</span>
            <span className="text-lg text-[#1a1a2e]">{total.toLocaleString("en-US")} ج.م</span>
          </div>
        </div>
      )}

      {/* Category Filters */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
        {categories.map((cat) => (
          <button key={cat} onClick={() => setActiveCategory(cat)} className={`px-3 py-2 rounded-xl text-xs whitespace-nowrap transition-all ${activeCategory === cat ? "bg-[#0D9488] text-white shadow-md" : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:bg-[#0D9488]/5"}`}>
            {cat}
          </button>
        ))}
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin" />
        </div>
      )}

      {/* Expenses List */}
      {!loading && (
        <div className="bg-white rounded-2xl border border-[#0D9488]/10 overflow-hidden">
          {/* Desktop Table */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#0D9488]/10">
                  <th className="text-right text-xs text-[#5f6b7a] p-4">البند</th>
                  <th className="text-right text-xs text-[#5f6b7a] p-4">التصنيف</th>
                  <th className="text-right text-xs text-[#5f6b7a] p-4">النوع</th>
                  <th className="text-right text-xs text-[#5f6b7a] p-4">المبلغ</th>
                  <th className="text-right text-xs text-[#5f6b7a] p-4">التاريخ</th>
                  <th className="p-4"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#0D9488]/5">
                {filtered.map((expense) => (
                  <tr key={expense.id} className="hover:bg-[#0D9488]/3 transition-colors">
                    <td className="p-4">
                      <div className="text-sm text-[#1a1a2e]">{expense.title}</div>
                      {expense.quantity > 1 && (
                        <div className="text-[10px] text-[#0D9488] mt-0.5">
                          {expense.unitPrice.toLocaleString("en-US")} × {expense.quantity}
                        </div>
                      )}
                    </td>
                    <td className="p-4">
                      <span className="text-xs bg-[#0D9488]/10 text-[#0D9488] px-2 py-1 rounded-lg">{expense.category}</span>
                    </td>
                    <td className="p-4">
                      <span className="flex items-center gap-1 text-xs text-[#5f6b7a]">
                        {expense.type === "دائم" ? <Repeat className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                        {expense.type}
                      </span>
                      {expense.type === "دائم" && expense.stoppedAt && (
                        <div className="flex items-center gap-1 text-[10px] text-red-500 mt-0.5">
                          <CircleStop className="w-2.5 h-2.5" />
                          متوقف
                        </div>
                      )}
                      {expense.type === "دائم" && !expense.stoppedAt && (
                        <div className="flex items-center gap-1 text-[10px] text-[#0D9488] mt-0.5">
                          نشط — يتكرر شهرياً
                        </div>
                      )}
                      {expense.type === "مؤقت" && expense.endDate && (
                        <div className="flex items-center gap-1 text-[10px] text-[#F59E0B] mt-0.5">
                          <CalendarX className="w-2.5 h-2.5" />
                          ينتهي: {expense.endDate}
                        </div>
                      )}
                    </td>
                    <td className="p-4 text-sm text-[#1a1a2e]">{expense.amount.toLocaleString("en-US")} ج.م</td>
                    <td className="p-4 text-xs text-[#5f6b7a]">{expense.date}</td>
                    <td className="p-4 relative">
                      <button onClick={() => setMenuOpen(menuOpen === expense.id ? null : expense.id)} className="text-[#5f6b7a] hover:text-[#0D9488] p-1 rounded-lg hover:bg-[#0D9488]/5">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                      {menuOpen === expense.id && (
                        <div className="absolute left-0 top-full mt-1 bg-white border border-[#0D9488]/10 rounded-xl shadow-lg z-20 w-36 overflow-hidden">
                          <button onClick={() => openEdit(expense)} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-[#1a1a2e] hover:bg-[#0D9488]/5 transition-colors">
                            <Pencil className="w-4 h-4 text-[#0D9488]" /> تعديل
                          </button>
                          {expense.type === "دائم" && (
                            expense.stoppedAt ? (
                              <button onClick={() => handleToggleStop(expense)} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-[#0D9488] hover:bg-[#0D9488]/5 transition-colors">
                                <RotateCcw className="w-4 h-4" /> إعادة تفعيل
                              </button>
                            ) : (
                              <button onClick={() => handleToggleStop(expense)} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-[#F59E0B] hover:bg-[#F59E0B]/5 transition-colors">
                                <CircleStop className="w-4 h-4" /> إيقاف
                              </button>
                            )
                          )}
                          <button onClick={() => { setDeleteConfirm(expense.id); setMenuOpen(null); }} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 transition-colors">
                            <Trash2 className="w-4 h-4" /> حذف
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="sm:hidden divide-y divide-[#0D9488]/5">
            {filtered.map((expense) => (
              <div
                key={expense.id}
                className={`p-4 transition-colors ${expense.stoppedAt ? "opacity-60" : ""}`}
              >
                {/* Row 1: Title + Amount + 3-dot */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-[#1a1a2e] truncate">{expense.title}</div>
                    {expense.quantity > 1 && (
                      <div className="text-[10px] text-[#5f6b7a] mt-0.5">
                        {expense.unitPrice.toLocaleString("en-US")} × {expense.quantity}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className="text-sm font-semibold text-[#0D9488]">{expense.amount.toLocaleString("en-US")} ج.م</span>
                    <button
                      onClick={(e) => { e.stopPropagation(); setMobileActionSheet(expense.id); }}
                      className="p-1.5 -ml-1 rounded-lg text-[#5f6b7a] hover:bg-gray-100 active:bg-gray-200 transition-colors"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Row 2: Tags */}
                <div className="flex items-center gap-1.5 flex-wrap mt-2.5">
                  <span className="text-[10px] bg-[#0D9488]/10 text-[#0D9488] px-2 py-0.5 rounded-md">{expense.category}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-md flex items-center gap-0.5 ${
                    expense.type === "دائم"
                      ? expense.stoppedAt ? "bg-red-50 text-red-500" : "bg-emerald-50 text-emerald-600"
                      : "bg-gray-50 text-[#5f6b7a]"
                  }`}>
                    {expense.type === "دائم" ? (
                      expense.stoppedAt ? <><CircleStop className="w-2.5 h-2.5" />متوقف</> : <><Repeat className="w-2.5 h-2.5" />شهري</>
                    ) : (
                      <><Clock className="w-2.5 h-2.5" />مؤقت</>
                    )}
                  </span>
                  {expense.type === "مؤقت" && expense.endDate && (
                    <span className="text-[10px] bg-amber-50 text-[#F59E0B] px-2 py-0.5 rounded-md flex items-center gap-0.5">
                      <CalendarX className="w-2.5 h-2.5" />
                      {expense.endDate}
                    </span>
                  )}
                  {expense.date && expense.type !== "دائم" && (
                    <span className="text-[10px] text-[#5f6b7a] mr-auto">{expense.date}</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {filtered.length === 0 && !loading && (
            <div className="p-10 text-center text-sm text-[#5f6b7a]">لا توجد مصروفات مطابقة للبحث</div>
          )}
        </div>
      )}

      {/* ===== Add/Edit Modal ===== */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">{editingId ? "تعديل مصروف" : "إضافة مصروف جديد"}</h3>
              <button onClick={() => setShowModal(false)} className="text-[#5f6b7a] hover:text-[#1a1a2e]">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-5">

              {/* اسم البند */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">اسم البند *</label>
                <input
                  type="text"
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="مثال: راتب أمن البرج"
                  className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                />
              </div>

              {/* سعر الوحدة × العدد = المبلغ */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">المبلغ *</label>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-[10px] text-[#5f6b7a] mb-1 block">سعر الوحدة (ج.م)</label>
                    <input
                      type="number"
                      inputMode="decimal"
                      value={form.unitPrice || ""}
                      onChange={(e) => setForm({ ...form, unitPrice: Number(e.target.value) })}
                      placeholder="0"
                      dir="ltr"
                      className="w-full px-3 py-2.5 bg-[#f8fffe] border border-[#0D9488]/10 rounded-lg text-sm text-center focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#5f6b7a] mb-1 block">العدد</label>
                    <input
                      type="number"
                      inputMode="numeric"
                      min={1}
                      value={form.quantity || ""}
                      onChange={(e) => setForm({ ...form, quantity: Math.max(1, Number(e.target.value)) })}
                      dir="ltr"
                      className="w-full px-3 py-2.5 bg-[#f8fffe] border border-[#0D9488]/10 rounded-lg text-sm text-center focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#5f6b7a] mb-1 block">الإجمالي</label>
                    <div className="px-3 py-2.5 bg-[#0D9488]/5 border border-[#0D9488]/20 rounded-lg text-sm text-[#0D9488] text-center font-medium">
                      {formTotal > 0 ? formTotal.toLocaleString("en-US") : "—"}
                    </div>
                  </div>
                </div>
                {form.quantity > 1 && formTotal > 0 && (
                  <div className="text-[10px] text-[#0D9488] mt-1.5 bg-[#0D9488]/5 rounded-lg px-3 py-1.5 text-center">
                    {form.title || "البند"} × {form.quantity} = {formTotal.toLocaleString("en-US")} ج.م
                  </div>
                )}
              </div>

              {/* التصنيف + النوع */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">التصنيف</label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full px-3 py-2.5 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                  >
                    {categoryOptions.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">النوع</label>
                  <div className="flex gap-1.5">
                    {(["دائم", "مؤقت"] as const).map((t) => (
                      <button
                        key={t}
                        onClick={() => setForm({ ...form, type: t })}
                        className={`flex-1 py-2.5 rounded-xl text-xs border-2 transition-all ${
                          form.type === t ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-100 text-[#5f6b7a]"
                        }`}
                      >
                        {t === "دائم" ? "🔄 دائم" : "⏱️ مؤقت"}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              {form.type === "دائم" && (
                <div className="bg-[#0D9488]/5 border border-[#0D9488]/10 rounded-xl px-3 py-2">
                  <p className="text-[11px] text-[#0D9488]">
                    <Repeat className="w-3 h-3 inline ml-1" />
                    المصروف الدائم يتكرر تلقائياً كل شهر من تاريخ إنشائه. يمكنك إيقافه لاحقاً من القائمة.
                  </p>
                </div>
              )}

              {/* التاريخ — فقط للبنود المؤقتة */}
              {form.type !== "دائم" && (
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">التاريخ</label>
                  <input
                    type="text"
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    placeholder="مثال: 1 مارس 2026"
                    className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
                  />
                </div>
              )}

              {/* صورة المصروف */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">إرفاق صورة (اختياري)</label>
                {form.image ? (
                  <div className="relative w-full rounded-xl border border-[#0D9488]/10 overflow-hidden bg-[#f8fffe]">
                    <img src={form.image} alt="مرفق المصروف" className="w-full max-h-32 object-contain" />
                    <button
                      onClick={() => setForm({ ...form, image: undefined })}
                      className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm text-red-500 rounded-lg p-1.5 shadow-sm hover:bg-red-50 transition-colors"
                    >
                      <XCircle className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      const input = document.createElement("input");
                      input.type = "file";
                      input.accept = "image/*";
                      input.onchange = (e) => {
                        const file = (e.target as HTMLInputElement).files?.[0];
                        if (file) {
                          if (file.size > 512000) {
                            setErrorMsg("حجم الصورة كبير جداً — الحد الأقصى 500KB");
                            return;
                          }
                          const reader = new FileReader();
                          reader.onload = (ev) => setForm({ ...form, image: ev.target?.result as string });
                          reader.readAsDataURL(file);
                        }
                      };
                      input.click();
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 border border-dashed border-gray-200 rounded-xl text-[#5f6b7a] hover:border-[#0D9488]/30 hover:bg-[#0D9488]/3 transition-all cursor-pointer"
                  >
                    <div className="w-8 h-8 bg-[#0D9488]/10 rounded-lg flex items-center justify-center shrink-0">
                      <ImagePlus className="w-4 h-4 text-[#0D9488]" />
                    </div>
                    <div className="text-right">
                      <span className="text-xs block">إرفاق صورة الفاتورة</span>
                      <span className="text-[10px] text-[#5f6b7a]/60">الحد الأقصى 500KB</span>
                    </div>
                  </button>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button onClick={() => setShowModal(false)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">
                إلغاء
              </button>
              <button
                onClick={handleSave}
                disabled={!canSave || saving}
                className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${
                  canSave && !saving
                    ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20"
                    : "bg-gray-300 cursor-not-allowed"
                }`}
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                {editingId ? "حفظ التعديلات" : "إضافة المصروف"}
                {formTotal > 0 && !saving && <span className="mr-1 text-xs opacity-80">({formTotal.toLocaleString("en-US")} ج.م)</span>}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-5">
              <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3">
                <Trash2 className="w-7 h-7 text-red-500" />
              </div>
              <h3 className="text-lg text-[#1a1a2e] mb-1">تأكيد الحذف</h3>
              <p className="text-sm text-[#5f6b7a]">هل أنت متأكد من حذف هذا المصروف؟ لا يمكن التراجع عن هذا الإجراء.</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm hover:bg-red-600">نعم، احذف</button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Action Sheet */}
      {mobileActionSheet && (() => {
        const expense = expenses.find((e) => e.id === mobileActionSheet);
        if (!expense) return null;
        return (
          <div className="fixed inset-0 bg-black/40 z-50 flex items-end justify-center sm:hidden" onClick={() => setMobileActionSheet(null)}>
            <div className="bg-white rounded-t-2xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
              <div className="flex justify-center pt-3 pb-1">
                <div className="w-10 h-1 bg-gray-300 rounded-full" />
              </div>
              <div className="px-5 py-3 border-b border-gray-100">
                <div className="text-sm font-medium text-[#1a1a2e] truncate">{expense.title}</div>
                <div className="text-xs text-[#5f6b7a] mt-0.5">{expense.amount.toLocaleString("en-US")} ج.م — {expense.category}</div>
              </div>
              <div className="p-3 space-y-1">
                <button
                  onClick={() => { setMobileActionSheet(null); openEdit(expense); }}
                  className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm text-[#1a1a2e] hover:bg-[#0D9488]/5 active:bg-[#0D9488]/10 transition-colors"
                >
                  <Pencil className="w-5 h-5 text-[#0D9488]" /> تعديل المصروف
                </button>
                {expense.type === "دائم" && (
                  expense.stoppedAt ? (
                    <button
                      onClick={() => { setMobileActionSheet(null); handleToggleStop(expense); }}
                      className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm text-[#0D9488] hover:bg-[#0D9488]/5 active:bg-[#0D9488]/10 transition-colors"
                    >
                      <RotateCcw className="w-5 h-5" /> إعادة تفعيل
                    </button>
                  ) : (
                    <button
                      onClick={() => { setMobileActionSheet(null); handleToggleStop(expense); }}
                      className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm text-[#F59E0B] hover:bg-[#F59E0B]/5 active:bg-[#F59E0B]/10 transition-colors"
                    >
                      <CircleStop className="w-5 h-5" /> إيقاف المصروف
                    </button>
                  )
                )}
                <button
                  onClick={() => { setMobileActionSheet(null); setDeleteConfirm(expense.id); }}
                  className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm text-red-500 hover:bg-red-50 active:bg-red-100 transition-colors"
                >
                  <Trash2 className="w-5 h-5" /> حذف المصروف
                </button>
              </div>
              <div className="p-3 pt-0">
                <button
                  onClick={() => setMobileActionSheet(null)}
                  className="w-full py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        );
      })()}
      <MobileFAB onClick={openAdd} label="إضافة مصروف" />
    </div>
  );
}