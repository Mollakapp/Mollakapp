import { useState, useEffect, useCallback } from "react";
import { Plus, Search, Phone, MapPin, X, Trash2, Pencil, CheckCircle2, AlertCircle, Loader2, Wrench, Zap, Droplets, PaintBucket, Wind, Sparkles, HelpCircle, MoreVertical } from "lucide-react";
import { normalizeToEnglishDigits } from "../../lib/phoneUtils";
import * as api from "../../lib/api";
import { MobileFAB } from "./MobileFAB";

const specialties = ["الكل", "سباكة", "كهرباء", "نجارة", "دهانات", "تكييف", "نظافة", "أخرى"];
const specOptions = ["سباكة", "كهرباء", "نجارة", "دهانات", "تكييف", "نظافة", "أخرى"];

const iconMap: Record<string, typeof Wrench> = {
  "سباكة": Droplets,
  "كهرباء": Zap,
  "نجارة": Wrench,
  "دهانات": PaintBucket,
  "تكييف": Wind,
  "نظافة": Sparkles,
  "أخرى": HelpCircle,
};

const colorMap: Record<string, string> = {
  "سباكة": "#3b82f6",
  "كهرباء": "#F59E0B",
  "نجارة": "#8b5cf6",
  "دهانات": "#ec4899",
  "تكييف": "#0D9488",
  "نظافة": "#10b981",
  "أخرى": "#6b7280",
};

const emptyForm = {
  name: "",
  specialty: "سباكة",
  phone: "",
  area: "",
};

export function DirectoryPage() {
  const [contacts, setContacts] = useState<api.DirectoryContact[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeSpecialty, setActiveSpecialty] = useState("الكل");
  const [searchQuery, setSearchQuery] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [actionSheet, setActionSheet] = useState<api.DirectoryContact | null>(null);

  const fetchContacts = useCallback(async () => {
    try {
      setLoading(true);
      const data = await api.getDirectory();
      setContacts(data);
    } catch (err: any) {
      console.error("Error fetching directory:", err);
      setErrorMsg("خطأ في تحميل الأرقام");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchContacts();
  }, [fetchContacts]);

  const filtered = contacts.filter(
    (c) =>
      (activeSpecialty === "الكل" || c.specialty === activeSpecialty) &&
      (searchQuery === "" || c.name.includes(searchQuery) || c.specialty.includes(searchQuery) || c.phone.includes(searchQuery))
  );

  const openAdd = () => { setForm(emptyForm); setEditingId(null); setShowModal(true); };
  const openEdit = (c: api.DirectoryContact) => {
    setForm({ name: c.name, specialty: c.specialty, phone: c.phone, area: c.area });
    setEditingId(c.id); setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.name || !form.phone) return;
    setSaving(true);
    try {
      if (editingId) {
        await api.updateDirectoryContact(editingId, form);
        showSucc("تم تحديث جهة الاتصال");
      } else {
        await api.createDirectoryContact(form);
        showSucc("تم إضافة جهة الاتصال");
      }
      setShowModal(false);
      await fetchContacts();
    } catch (err: any) {
      console.error("Error saving contact:", err);
      setErrorMsg(err.message || "خطأ في حفظ جهة الاتصال");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteDirectoryContact(id);
      setDeleteConfirm(null);
      showSucc("تم حذف جهة الاتصال");
      await fetchContacts();
    } catch (err: any) {
      console.error("Error deleting contact:", err);
      setErrorMsg(err.message || "خطأ في حذف جهة الاتصال");
    }
  };

  const showSucc = (msg: string) => { setSuccessMsg(msg); setTimeout(() => setSuccessMsg(""), 2500); };

  return (
    <div className="space-y-6">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm"><CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}</div>
      )}
      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm cursor-pointer" onClick={() => setErrorMsg("")}>
          <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl text-[#1a1a2e]">الأرقام</h1>
          <p className="text-sm text-[#5f6b7a]">أرقام الحرفيين ومقدمي الخدمات — {filtered.length.toLocaleString("en-US")} جهة</p>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => { setSearchOpen(true); setTimeout(() => document.getElementById("directory-search-input")?.focus(), 50); }}
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
              searchQuery ? "bg-[#0D9488] text-white shadow-sm" : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:border-[#0D9488]/30"
            }`}
          >
            <Search className="w-4 h-4" />
          </button>
          <button onClick={openAdd} className="hidden sm:flex w-9 h-9 rounded-xl items-center justify-center bg-[#0D9488] text-white hover:bg-[#0D9488]/90 transition-colors shadow-sm" title="إضافة جهة اتصال">
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Expandable Search Bar */}
      {searchOpen && (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#5f6b7a]" />
            <input
              id="directory-search-input"
              type="text"
              placeholder="ابحث عن حرفي أو تخصص..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 bg-white border border-[#0D9488]/15 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-sm"
            />
          </div>
          <button
            onClick={() => { setSearchOpen(false); setSearchQuery(""); }}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#5f6b7a] bg-white border border-gray-100 hover:bg-gray-50 transition-colors shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Category Filters */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide" style={{ WebkitOverflowScrolling: "touch" }}>
        {specialties.map((spec) => (
          <button key={spec} onClick={() => setActiveSpecialty(spec)} className={`px-3 py-2 rounded-xl text-xs whitespace-nowrap transition-all shrink-0 ${activeSpecialty === spec ? "bg-[#0D9488] text-white shadow-md" : "bg-white text-[#5f6b7a] border border-[#0D9488]/10 hover:bg-[#0D9488]/5"}`}>
            {spec}
            {spec !== "الكل" && (
              <span className={`mr-1 text-[10px] ${activeSpecialty === spec ? "text-white/70" : "text-[#5f6b7a]/50"}`}>
                ({contacts.filter((c) => c.specialty === spec).length.toLocaleString("en-US")})
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin" />
        </div>
      )}

      {/* Contacts List */}
      {!loading && (
        <div className="space-y-3">
          {filtered.map((contact) => {
            const Icon = iconMap[contact.specialty] || HelpCircle;
            const color = colorMap[contact.specialty] || "#6b7280";

            return (
              <div
                key={contact.id}
                className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm"
              >
                <div className="p-4" style={{ backgroundColor: `${color}04` }}>

                  {/* ── Header: Icon + Name + Specialty badge + 3-dots ── */}
                  <div className="flex items-start gap-3 mb-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
                      style={{ backgroundColor: `${color}15` }}
                    >
                      <Icon className="w-5 h-5" style={{ color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-[#1a1a2e] truncate">{contact.name}</span>
                        <button
                          onClick={() => setActionSheet(actionSheet?.id === contact.id ? null : contact)}
                          className="w-7 h-7 rounded-lg flex items-center justify-center text-[#5f6b7a] hover:bg-black/5 active:bg-black/10 transition-colors shrink-0"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </div>
                      <span
                        className="text-[10px] px-1.5 py-px rounded-full inline-block mt-1 font-medium"
                        style={{
                          backgroundColor: `${color}12`,
                          color: color,
                        }}
                      >
                        {contact.specialty}
                      </span>
                    </div>
                  </div>

                  {/* ── Info Grid ── */}
                  <div className={`grid ${contact.area ? "grid-cols-2" : "grid-cols-1"} gap-2 mb-3`}>
                    <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                      <div className="text-[9px] text-[#5f6b7a]">الهاتف</div>
                      <div className="text-xs text-[#1a1a2e] font-medium" dir="ltr">{contact.phone}</div>
                    </div>
                    {contact.area && (
                      <div className="bg-white rounded-lg px-2.5 py-1.5 border border-gray-100 text-center">
                        <div className="text-[9px] text-[#5f6b7a]">المنطقة</div>
                        <div className="text-xs text-[#1a1a2e] font-medium">{contact.area}</div>
                      </div>
                    )}
                  </div>

                  {/* ── Bottom actions: اتصال | تعديل | حذف ── */}
                  <div className="flex gap-2">
                    <a
                      href={`tel:${contact.phone.replace(/-/g, "")}`}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#0D9488] text-white text-xs hover:bg-[#0D9488]/90 transition-all shadow-sm"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      اتصال
                    </a>
                    <button
                      onClick={() => openEdit(contact)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-[#6366f1]/30 text-[#6366f1] text-xs hover:bg-[#6366f1]/5 transition-all"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                      تعديل
                    </button>
                    <button
                      onClick={() => setDeleteConfirm(contact.id)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-red-200 text-red-500 text-xs hover:bg-red-50 transition-all"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      حذف
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && !loading && (
            <div className="text-center py-16">
              <div className="w-16 h-16 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-[#0D9488]" />
              </div>
              <p className="text-sm text-[#5f6b7a]">لا توجد جهات اتصال</p>
            </div>
          )}
        </div>
      )}

      {/* ── Action Sheet (Bottom Sheet) ── */}
      {actionSheet && (
        <>
          <div className="fixed inset-0 bg-black/30 z-40" onClick={() => setActionSheet(null)} />
          <div className="fixed bottom-0 left-0 right-0 z-50 bg-white rounded-t-2xl shadow-2xl" style={{ maxHeight: '60vh' }}>
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-gray-200" />
            </div>
            <div className="flex items-center gap-3 px-5 pb-3 border-b border-gray-100">
              {(() => {
                const Icon = iconMap[actionSheet.specialty] || HelpCircle;
                const color = colorMap[actionSheet.specialty] || "#6b7280";
                return (
                  <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0" style={{ backgroundColor: `${color}15` }}>
                    <Icon className="w-5 h-5" style={{ color }} />
                  </div>
                );
              })()}
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-[#1a1a2e] truncate">{actionSheet.name}</div>
                <div className="text-[10px] text-[#5f6b7a]">{actionSheet.specialty}{actionSheet.area ? ` — ${actionSheet.area}` : ""}</div>
              </div>
              <button onClick={() => setActionSheet(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-[#5f6b7a] hover:bg-gray-100">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="py-2">
              {[
                { icon: Phone, label: "اتصال", color: "#0D9488", action: () => { window.location.href = `tel:${actionSheet.phone.replace(/-/g, "")}`; setActionSheet(null); } },
                { icon: Pencil, label: "تعديل", color: "#6366f1", action: () => { openEdit(actionSheet); setActionSheet(null); } },
                { icon: Trash2, label: "حذف", color: "#dc2626", action: () => { setDeleteConfirm(actionSheet.id); setActionSheet(null); } },
              ].map((item, i) => (
                <button
                  key={i}
                  onClick={item.action}
                  className="w-full flex items-center gap-4 px-5 py-3.5 text-sm text-[#1a1a2e] hover:bg-gray-50 active:bg-gray-100 transition-colors"
                >
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${item.color}12` }}>
                    <item.icon className="w-4 h-4" style={{ color: item.color }} />
                  </div>
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
            <div className="h-safe-area-inset-bottom pb-4" />
          </div>
        </>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
              <h3 className="text-lg text-[#1a1a2e]">{editingId ? "تعديل جهة اتصال" : "إضافة جهة اتصال"}</h3>
              <button onClick={() => setShowModal(false)} className="text-[#5f6b7a]"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">الاسم *</label>
                  <input type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">التخصص</label>
                  <select value={form.specialty} onChange={(e) => setForm({ ...form, specialty: e.target.value })} className="w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20">
                    {specOptions.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">رقم الهاتف *</label>
                  <input type="tel" dir="ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: normalizeToEnglishDigits(e.target.value) })} className="w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 text-right" />
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">المنطقة</label>
                  <input type="text" value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} className="w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button onClick={() => setShowModal(false)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={handleSave} disabled={!form.name || !form.phone || saving} className={`flex-1 py-3 rounded-xl text-white text-sm flex items-center justify-center gap-2 transition-all ${form.name && form.phone && !saving ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20" : "bg-gray-300 cursor-not-allowed"}`}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                {editingId ? "حفظ" : "إضافة"}
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-center mb-5">
              <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3"><Trash2 className="w-7 h-7 text-red-500" /></div>
              <h3 className="text-lg text-[#1a1a2e] mb-1">حذف جهة الاتصال</h3>
              <p className="text-sm text-[#5f6b7a]">هل أنت متأكد؟</p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 py-3 rounded-xl bg-red-500 text-white text-sm">نعم، احذف</button>
            </div>
          </div>
        </div>
      )}

      <MobileFAB onClick={openAdd} label="إضافة جهة اتصال" />
    </div>
  );
}
