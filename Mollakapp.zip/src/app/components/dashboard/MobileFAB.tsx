import { Plus } from "lucide-react";

interface MobileFABProps {
  onClick: () => void;
  label: string;
}

/**
 * Floating Action Button — only visible on mobile (hidden on sm+).
 * Fixed at bottom-left corner for RTL layouts.
 */
export function MobileFAB({ onClick, label }: MobileFABProps) {
  return (
    <button
      onClick={onClick}
      className="sm:hidden fixed bottom-6 left-6 z-40 w-14 h-14 rounded-full bg-[#0D9488] text-white flex items-center justify-center active:scale-95 transition-transform"
      style={{ boxShadow: '0 6px 20px rgba(13, 148, 136, 0.4)' }}
      title={label}
      aria-label={label}
    >
      <Plus className="w-6 h-6" />
    </button>
  );
}
