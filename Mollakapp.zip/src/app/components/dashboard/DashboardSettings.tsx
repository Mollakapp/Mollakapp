import { useState, useEffect } from "react";
import {
  User, Edit3, X, CheckCircle2, AlertCircle, Camera, Loader2,
  Phone, Shield, Calendar, FileText, Heart, IdCard,
  Home, Building2,
} from "lucide-react";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";
import { normalizeToEnglishDigits } from "../../lib/phoneUtils";

// Compress image to base64
function compressImage(file: File, maxSize = 200): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let w = img.width, h = img.height;
        if (w > maxSize || h > maxSize) {
          if (w > h) { h = (h / w) * maxSize; w = maxSize; }
          else { w = (w / h) * maxSize; h = maxSize; }
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.7));
      };
      img.onerror = reject;
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function DashboardSettings() {
  const { profile, refreshProfile, session } = useAuth();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const [formName, setFormName] = useState("");
  const [formGender, setFormGender] = useState("");
  const [formBirthDate, setFormBirthDate] = useState("");
  const [formBio, setFormBio] = useState("");
  const [formEmergencyContact, setFormEmergencyContact] = useState("");
  const [formEmergencyPhone, setFormEmergencyPhone] = useState("");
  const [formNationalId, setFormNationalId] = useState("");
  const [formAvatar, setFormAvatar] = useState<string | null>(null);
  const [formUnitCode, setFormUnitCode] = useState("");
  const [formFloor, setFormFloor] = useState("");
  const [formType, setFormType] = useState("");
  const [units, setUnits] = useState<api.Unit[]>([]);
  const [loadingUnits, setLoadingUnits] = useState(false);

  useEffect(() => {
    if (profile && !editing) {
      setFormName(profile.name || "");
      setFormGender(profile.gender || "");
      setFormBirthDate(profile.birthDate || "");
      setFormBio(profile.bio || "");
      setFormEmergencyContact(profile.emergencyContact || "");
      setFormEmergencyPhone(profile.emergencyPhone || "");
      setFormNationalId(profile.nationalId || "");
      setFormAvatar(profile.avatarBase64 || null);
      setFormUnitCode(profile.unitCode || "");
      setFormFloor(profile.floor || "");
      setFormType(profile.type === "مالك" || profile.type === "مستأجر" ? profile.type : "مالك");
    }
  }, [profile, editing]);

  // Load units for the unit picker
  useEffect(() => {
    const loadUnits = async () => {
      setLoadingUnits(true);
      try {
        const data = await api.getUnits();
        setUnits(data);
      } catch (err) {
        console.error("Error loading units:", err);
      } finally {
        setLoadingUnits(false);
      }
    };
    loadUnits();
  }, []);

  const handleOpenEdit = () => {
    if (profile) {
      setFormName(profile.name || "");
      setFormGender(profile.gender || "");
      setFormBirthDate(profile.birthDate || "");
      setFormBio(profile.bio || "");
      setFormEmergencyContact(profile.emergencyContact || "");
      setFormEmergencyPhone(profile.emergencyPhone || "");
      setFormNationalId(profile.nationalId || "");
      setFormAvatar(profile.avatarBase64 || null);
      setFormUnitCode(profile.unitCode || "");
      setFormFloor(profile.floor || "");
      setFormType(profile.type === "مالك" || profile.type === "مستأجر" ? profile.type : "مالك");
    }
    setEditing(true);
  };

  const handleSave = async () => {
    if (!profile) return;
    setSaving(true);
    try {
      await api.updateProfile({
        token: session?.access_token || "", // will use session
        name: formName || undefined,
        gender: formGender || undefined,
        birthDate: formBirthDate || undefined,
        bio: formBio || undefined,
        emergencyContact: formEmergencyContact || undefined,
        emergencyPhone: formEmergencyPhone ? normalizeToEnglishDigits(formEmergencyPhone) : undefined,
        nationalId: formNationalId ? normalizeToEnglishDigits(formNationalId) : undefined,
        avatarBase64: formAvatar,
        unitCode: formUnitCode || undefined,
        floor: formFloor || undefined,
        type: formType || undefined,
      });
      await refreshProfile();
      setEditing(false);
      showSuccess("تم تحديث الملف الشخصي بنجاح");
    } catch (err: any) {
      console.error("Error updating profile:", err);
      setErrorMsg(err.message || "خطأ في تحديث الملف الشخصي");
    } finally {
      setSaving(false);
    }
  };

  const handleAvatarUpload = async () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      try {
        const compressed = await compressImage(file);
        setFormAvatar(compressed);
      } catch {
        setErrorMsg("خطأ في معالجة الصورة");
      }
    };
    input.click();
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(""), 2500);
  };

  const initials = profile?.name?.slice(0, 2) || "—";
  const roleLabel = profile?.adminRole || profile?.role || "عضو اتحاد";

  const needsUnit = !profile?.unitCode;

  const infoItems = [
    { icon: Phone, label: "رقم الجوال", value: profile?.phone, dir: "ltr" as const },
    { icon: Shield, label: "الصلاحية", value: roleLabel },
    { icon: Home, label: "الشقة", value: profile?.unitCode ? `شقة ${profile.unitCode} — الدور ${profile.floor}` : undefined },
    { icon: Building2, label: "نوع السكن", value: profile?.type === "مالك" || profile?.type === "مستأجر" ? profile.type : undefined },
    { icon: IdCard, label: "الرقم القومي", value: profile?.nationalId, dir: "ltr" as const },
    { icon: Calendar, label: "تاريخ الميلاد", value: profile?.birthDate },
    { icon: User, label: "النوع", value: profile?.gender },
    { icon: Heart, label: "جهة اتصال الطوارئ", value: profile?.emergencyContact ? `${profile.emergencyContact}${profile.emergencyPhone ? ` — ${profile.emergencyPhone}` : ""}` : undefined },
    { icon: FileText, label: "نبذة", value: profile?.bio },
  ];

  return (
    <div className="space-y-6">
      {successMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-[#0D9488] text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
          <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{successMsg}
        </div>
      )}
      {errorMsg && (
        <div className="fixed top-4 sm:top-20 left-1/2 -translate-x-1/2 z-50 max-w-[90vw] sm:max-w-md bg-red-500 text-white px-3 py-2 sm:px-5 sm:py-3 rounded-xl shadow-lg flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm cursor-pointer" onClick={() => setErrorMsg("")}>
          <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />{errorMsg}
        </div>
      )}

      <div>
        <h1 className="text-2xl text-[#1a1a2e]">الملف الشخصي</h1>
        <p className="text-sm text-[#5f6b7a]">عرض وتعديل بيانات حسابك</p>
      </div>

      {/* Missing Unit Banner */}
      {needsUnit && (
        <div className="bg-[#F59E0B]/10 border border-[#F59E0B]/30 rounded-2xl p-4 flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#F59E0B]/20 flex items-center justify-center shrink-0 mt-0.5">
            <Home className="w-5 h-5 text-[#F59E0B]" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm text-[#1a1a2e] font-semibold mb-1">لم يتم تحديد شقتك بعد</h3>
            <p className="text-xs text-[#5f6b7a] leading-relaxed">
              لعرض الفواتير والبيانات المرتبطة بحسابك كساكن، يجب تحديد الشقة التي تسكن فيها.
            </p>
            <button
              onClick={handleOpenEdit}
              className="mt-2.5 flex items-center gap-1.5 px-4 py-2 bg-[#F59E0B] text-white text-xs rounded-xl hover:bg-[#F59E0B]/90 transition-colors shadow-sm"
            >
              <Edit3 className="w-3.5 h-3.5" />
              تحديد الشقة الآن
            </button>
          </div>
        </div>
      )}

      {/* Profile Card */}
      <div className="bg-white rounded-2xl border border-[#0D9488]/10 overflow-hidden shadow-sm">
        {/* Banner */}
        <div className="h-28 bg-gradient-to-l from-[#0D9488] to-[#0D9488]/80 relative">
          <div className="absolute -bottom-10 right-6">
            <div className="w-20 h-20 rounded-2xl border-4 border-white bg-[#0D9488]/10 overflow-hidden shadow-md flex items-center justify-center">
              {profile?.avatarBase64 ? (
                <img src={profile.avatarBase64} alt="" className="w-full h-full object-cover" />
              ) : (
                <span className="text-2xl text-[#0D9488] font-bold">{initials}</span>
              )}
            </div>
          </div>
        </div>
        <div className="pt-12 px-5 pb-5">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-lg text-[#1a1a2e] font-semibold">{profile?.name || "—"}</h2>
              <p className="text-xs text-[#5f6b7a] mt-0.5">{roleLabel} — {profile?.buildingName || "—"}</p>
              {profile?.bio && (
                <p className="text-xs text-[#5f6b7a] mt-2 leading-relaxed italic">"{profile.bio}"</p>
              )}
            </div>
            <button
              onClick={handleOpenEdit}
              className="flex items-center gap-1.5 px-3 py-2 bg-[#0D9488] text-white text-[11px] rounded-xl hover:bg-[#0D9488]/90 transition-colors shadow-sm"
            >
              <Edit3 className="w-3.5 h-3.5" />
              تعديل
            </button>
          </div>
        </div>
      </div>

      {/* Info Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {infoItems.map((item) => {
          if (!item.value) return null;
          const Icon = item.icon;
          return (
            <div key={item.label} className="bg-white rounded-xl border border-gray-100 p-4 flex items-start gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#0D9488]/10 flex items-center justify-center shrink-0">
                <Icon className="w-4 h-4 text-[#0D9488]" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-[10px] text-[#5f6b7a] mb-0.5">{item.label}</div>
                <div
                  className="text-sm text-[#1a1a2e] truncate"
                  dir={item.dir || "rtl"}
                  style={item.dir === "ltr" ? { textAlign: "right" } : undefined}
                >
                  {item.value}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit Modal */}
      {editing && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center" onClick={() => setEditing(false)}>
          <div
            className="bg-white rounded-t-3xl sm:rounded-2xl w-full sm:max-w-md max-h-[92vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sm:hidden flex justify-center pt-3">
              <div className="w-10 h-1 bg-gray-300 rounded-full" />
            </div>
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#0D9488]/10">
              <h3 className="text-base text-[#1a1a2e] font-semibold">تعديل الملف الشخصي</h3>
              <button onClick={() => setEditing(false)} className="p-2 hover:bg-gray-100 rounded-lg">
                <X className="w-4 h-4 text-[#5f6b7a]" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Avatar */}
              <div className="flex justify-center">
                <button onClick={handleAvatarUpload} className="relative group">
                  <div className="w-20 h-20 rounded-2xl bg-[#0D9488]/10 overflow-hidden border-2 border-[#0D9488]/20 flex items-center justify-center">
                    {formAvatar ? (
                      <img src={formAvatar} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-2xl text-[#0D9488] font-bold">{initials}</span>
                    )}
                  </div>
                  <div className="absolute inset-0 bg-black/30 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Camera className="w-5 h-5 text-white" />
                  </div>
                </button>
              </div>

              {/* Name */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">الاسم</label>
                <input type="text" value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
              </div>

              {/* Gender */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">النوع</label>
                <div className="flex gap-2">
                  {["ذكر", "أنثى"].map((g) => (
                    <button key={g} onClick={() => setFormGender(g)} className={`flex-1 py-2.5 rounded-xl text-sm border-2 transition-all ${formGender === g ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-100 text-[#5f6b7a]"}`}>
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              {/* Birth Date */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">تاريخ الميلاد</label>
                <input type="date" value={formBirthDate} onChange={(e) => setFormBirthDate(e.target.value)} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
              </div>

              {/* Bio */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">نبذة</label>
                <textarea value={formBio} onChange={(e) => setFormBio(e.target.value)} rows={2} placeholder="نبذة مختصرة عنك..." className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20 resize-none" />
              </div>

              {/* National ID */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">الرقم القومي</label>
                <input type="text" value={formNationalId} onChange={(e) => setFormNationalId(normalizeToEnglishDigits(e.target.value))} placeholder="الرقم القومي (14 رقم)" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" dir="ltr" style={{ textAlign: "right" }} />
              </div>

              {/* Emergency */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">جهة اتصال طوارئ</label>
                  <input type="text" value={formEmergencyContact} onChange={(e) => setFormEmergencyContact(e.target.value)} placeholder="الاسم" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">رقم الطوارئ</label>
                  <input type="tel" value={formEmergencyPhone} onChange={(e) => setFormEmergencyPhone(normalizeToEnglishDigits(e.target.value))} placeholder="01xxxxxxxxx" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" dir="ltr" style={{ textAlign: "right" }} />
                </div>
              </div>

              {/* Unit */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">شقة</label>
                  <select value={formUnitCode} onChange={(e) => {
                    const selectedUnit = units.find((u) => u.unitCode === e.target.value);
                    setFormUnitCode(e.target.value);
                    if (selectedUnit) setFormFloor(selectedUnit.floor);
                  }} className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20">
                    <option value="">اختر شقة</option>
                    {loadingUnits ? (
                      <option value="">جارٍ التحميل...</option>
                    ) : (
                      units.map((unit) => (
                        <option key={unit.unitCode} value={unit.unitCode}>
                          {unit.unitCode} — الدور {unit.floor}{unit.occupied ? ` (مشغولة — ${unit.ownerName || ""})` : ""}
                        </option>
                      ))
                    )}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-[#5f6b7a] mb-1.5 block">دور</label>
                  <input type="text" value={formFloor} onChange={(e) => setFormFloor(e.target.value)} placeholder="مثال: 5" className="w-full px-4 py-3 bg-[#f8fffe] border border-[#0D9488]/10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20" />
                </div>
              </div>

              {/* Type */}
              <div>
                <label className="text-xs text-[#5f6b7a] mb-1.5 block">نوع السكن</label>
                <div className="flex gap-2">
                  {["مالك", "مستأجر"].map((t) => (
                    <button key={t} onClick={() => setFormType(t)} className={`flex-1 py-2.5 rounded-xl text-sm border-2 transition-all ${formType === t ? "border-[#0D9488] bg-[#0D9488]/5 text-[#0D9488]" : "border-gray-100 text-[#5f6b7a]"}`}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="flex gap-3 p-5 border-t border-[#0D9488]/10">
              <button onClick={() => setEditing(false)} className="flex-1 py-3 rounded-xl border border-gray-200 text-[#5f6b7a] text-sm">إلغاء</button>
              <button onClick={handleSave} disabled={saving} className={`flex-1 py-3 rounded-xl text-white text-sm transition-all flex items-center justify-center gap-2 ${!saving ? "bg-[#0D9488] hover:bg-[#0D9488]/90 shadow-md shadow-[#0D9488]/20" : "bg-gray-300 cursor-not-allowed"}`}>
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                حفظ التعديلات
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}