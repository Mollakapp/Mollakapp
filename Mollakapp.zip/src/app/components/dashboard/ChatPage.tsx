import { useState, useRef, useEffect, useCallback } from "react";
import { Send, Shield, Loader2, ArrowRight, MessageCircle, User, Home } from "lucide-react";
import { useSearchParams } from "react-router";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";

export function ChatPage() {
  const { profile } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const dmPhone = searchParams.get("dm") || "";
  const dmName = searchParams.get("name") || "";
  const dmUnit = searchParams.get("unit") || "";

  // DM state
  const [dmMessages, setDmMessages] = useState<api.ChatMsg[]>([]);
  const [dmLoading, setDmLoading] = useState(false);
  const [dmSending, setDmSending] = useState(false);
  const [dmNewMessage, setDmNewMessage] = useState("");
  const dmMessagesEndRef = useRef<HTMLDivElement>(null);

  // DM conversations list
  const [dmList, setDmList] = useState<api.DMConversation[]>([]);
  const [dmListLoading, setDmListLoading] = useState(false);

  const myPhone = profile?.phone || "";
  const myName = profile?.name || "الإدارة";
  const myRole = profile?.adminRole || profile?.role || "إدارة";

  // Load DM messages
  const loadDmMessages = useCallback(async () => {
    if (!dmPhone || !myPhone) return;
    try {
      const data = await api.getDMMessages(dmPhone, myPhone);
      setDmMessages(data);
    } catch (err) {
      console.error("Error loading DM:", err);
    } finally {
      setDmLoading(false);
    }
  }, [dmPhone, myPhone]);

  useEffect(() => {
    if (dmPhone) {
      setDmLoading(true);
      loadDmMessages();
      const interval = setInterval(loadDmMessages, 4000);
      return () => clearInterval(interval);
    }
  }, [dmPhone, loadDmMessages]);

  useEffect(() => {
    dmMessagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [dmMessages]);

  // Load DM conversations list
  const loadDmList = useCallback(async () => {
    if (!myPhone) return;
    setDmListLoading(true);
    try {
      const data = await api.getDMList(myPhone);
      setDmList(data);
    } catch (err) {
      console.error("Error loading DM list:", err);
    } finally {
      setDmListLoading(false);
    }
  }, [myPhone]);

  useEffect(() => {
    if (!dmPhone) {
      loadDmList();
    }
  }, [dmPhone, loadDmList]);

  // Send DM
  const handleSendDm = async () => {
    if (!dmNewMessage.trim() || dmSending || !dmPhone) return;
    setDmSending(true);
    try {
      await api.sendDMMessage(dmPhone, {
        sender: myName,
        senderRole: myRole,
        senderPhone: myPhone,
        text: dmNewMessage.trim(),
      });
      setDmNewMessage("");
      await loadDmMessages();
    } catch (err) {
      console.error("Error sending DM:", err);
    } finally {
      setDmSending(false);
    }
  };

  const openDm = (phone: string, name: string, unitCode: string) => {
    setSearchParams({ dm: phone, name, unit: unitCode });
  };

  const closeDm = () => {
    setSearchParams({});
    setDmMessages([]);
    loadDmList();
  };

  const isMine = (msg: api.ChatMsg) => msg.senderPhone === myPhone;
  const isAdmin = (role: string) =>
    role === "admin" || role === "إدارة" || role === "رئيس الاتحاد" || role === "أمين الصندوق" || role === "أمين صندوق" || role === "عضو اتحاد" || role === "عضو";

  const formatTime = (ts: string) => {
    try {
      return new Date(ts).toLocaleTimeString("ar-u-nu-latn", { hour: "2-digit", minute: "2-digit" });
    } catch {
      return "";
    }
  };

  const renderBubble = (msg: api.ChatMsg, mine: boolean) => (
    <div key={msg.id} className={`flex ${mine ? "justify-start" : "justify-end"}`}>
      <div
        className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm ${
          mine
            ? "bg-[#0D9488] text-white rounded-br-md"
            : isAdmin(msg.senderRole)
            ? "bg-[#0D9488]/10 text-[#1a1a2e] rounded-bl-md"
            : "bg-white border border-gray-100 text-[#1a1a2e] rounded-bl-md"
        }`}
      >
        {!mine && (
          <div className="text-[10px] text-[#0D9488] mb-1 flex items-center gap-1">
            {isAdmin(msg.senderRole) && <Shield className="w-2.5 h-2.5" />}
            {msg.sender}
            {msg.senderRole && msg.senderRole !== "ساكن" && msg.senderRole !== "مالك" && msg.senderRole !== "مستأجر" && (
              <span className="text-[#5f6b7a]">· {msg.senderRole}</span>
            )}
          </div>
        )}
        <p>{msg.text}</p>
        <div className={`text-[10px] mt-1 ${mine ? "text-white/70" : "text-[#5f6b7a]"}`}>
          {formatTime(msg.timestamp)}
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-100 bg-gray-50/50">
        {dmPhone ? (
          <>
            <button onClick={closeDm} className="text-[#5f6b7a] hover:text-[#0D9488] p-1 rounded-lg hover:bg-[#0D9488]/5">
              <ArrowRight className="w-5 h-5" />
            </button>
            <div className="w-9 h-9 rounded-full bg-[#0D9488]/10 flex items-center justify-center text-[#0D9488] text-sm font-semibold">
              {dmName.charAt(0) || <User className="w-4 h-4" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-[#1a1a2e] truncate">{dmName || dmPhone}</div>
              {dmUnit && (
                <div className="flex items-center gap-1 text-[10px] text-[#5f6b7a]">
                  <Home className="w-2.5 h-2.5" />شقة {dmUnit}
                </div>
              )}
            </div>
          </>
        ) : (
          <>
            <div className="w-9 h-9 rounded-full bg-[#0D9488]/10 flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-[#0D9488]" />
            </div>
            <div>
              <div className="text-sm font-medium text-[#1a1a2e]">رسائل خاصة</div>
              <div className="text-[10px] text-[#5f6b7a]">تواصل مع السكان مباشرة</div>
            </div>
          </>
        )}
      </div>

      {/* Conversations List */}
      {!dmPhone && (
        <div className="flex-1 overflow-y-auto">
          {dmListLoading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin" />
            </div>
          ) : dmList.length === 0 ? (
            <div className="flex items-center justify-center h-full text-sm text-[#5f6b7a]">
              <div className="text-center px-4">
                <div className="w-16 h-16 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <MessageCircle className="w-8 h-8 text-[#0D9488]" />
                </div>
                <p className="mb-1">لا توجد محادثات خاصة بعد</p>
                <p className="text-xs text-[#5f6b7a]/60">اضغط على زر "محادثة" في كارت أي ساكن لبدء محادثة خاصة</p>
              </div>
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {dmList.map((conv) => (
                <button
                  key={conv.phone}
                  onClick={() => openDm(conv.phone, conv.name, conv.unitCode)}
                  className="w-full flex items-center gap-3 p-4 hover:bg-[#0D9488]/5 transition-colors text-right"
                >
                  <div className="w-10 h-10 rounded-full bg-[#0D9488]/10 flex items-center justify-center text-[#0D9488] text-sm font-semibold shrink-0">
                    {conv.name.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-[#1a1a2e] truncate">{conv.name}</span>
                      {conv.unitCode && (
                        <span className="text-[10px] text-[#0D9488] bg-[#0D9488]/10 px-1.5 py-0.5 rounded-full shrink-0">شقة {conv.unitCode}</span>
                      )}
                    </div>
                    <p className="text-xs text-[#5f6b7a] truncate mt-0.5">{conv.lastMessage}</p>
                  </div>
                  <div className="text-[10px] text-[#5f6b7a] shrink-0">
                    {formatTime(conv.lastTimestamp)}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* DM CONVERSATION */}
      {dmPhone && (
        <>
          {/* DM Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50/50">
            {dmLoading ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin" />
              </div>
            ) : dmMessages.length === 0 ? (
              <div className="flex items-center justify-center h-full text-sm text-[#5f6b7a]">
                <div className="text-center">
                  <div className="w-14 h-14 bg-[#0D9488]/10 rounded-full flex items-center justify-center mx-auto mb-3">
                    <MessageCircle className="w-7 h-7 text-[#0D9488]" />
                  </div>
                  <p>ابدأ محادثة خاصة مع {dmName || "هذا الساكن"}</p>
                </div>
              </div>
            ) : (
              dmMessages.map((msg) => renderBubble(msg, isMine(msg)))
            )}
            <div ref={dmMessagesEndRef} />
          </div>

          {/* DM Input */}
          <div className="p-4 border-t border-gray-100 flex gap-2">
            <input
              type="text"
              value={dmNewMessage}
              onChange={(e) => setDmNewMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendDm()}
              placeholder={`رسالة إلى ${dmName || "الساكن"}...`}
              className="flex-1 px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#0D9488]/20"
            />
            <button
              onClick={handleSendDm}
              disabled={!dmNewMessage.trim() || dmSending}
              className={`px-4 py-3 rounded-xl transition-all ${
                dmNewMessage.trim() && !dmSending ? "bg-[#0D9488] text-white shadow-md" : "bg-gray-100 text-[#5f6b7a]"
              }`}
            >
              {dmSending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
