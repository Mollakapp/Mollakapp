import { useState, useEffect, useCallback, useRef } from "react";
import {
  TrendingUp,
  Receipt,
  Banknote,
  AlertCircle,
  FileText,
  CheckCircle2,
  Megaphone,
  Loader2,
  Users,
  FilePlus,
  FileEdit,
  Trash2,
  Activity,
  Heart,
  Vote,
  Building2,
  Home,
  ArrowLeft,
  HandCoins,
  type LucideIcon,
} from "lucide-react";
import { motion } from "motion/react";
import { useNavigate } from "react-router";
import { getDefaultPeriod } from "./PeriodFilter";
import type { PeriodFilterValue } from "./PeriodFilter";
import * as api from "../../lib/api";
import { useAuth } from "../../lib/auth";
import { getFirstName } from "../../lib/titles";

// Map activity type → icon + fallback color
const activityIconMap: Record<string, { icon: LucideIcon; fallbackColor: string }> = {
  invoice_created: { icon: FilePlus, fallbackColor: "#0D9488" },
  invoice_paid: { icon: CheckCircle2, fallbackColor: "#0D9488" },
  invoice_updated: { icon: FileEdit, fallbackColor: "#F59E0B" },
  invoice_deleted: { icon: Trash2, fallbackColor: "#ef4444" },
  cash_requested: { icon: Banknote, fallbackColor: "#6366f1" },
  cash_collected: { icon: CheckCircle2, fallbackColor: "#0D9488" },
  building_registered: { icon: Building2, fallbackColor: "#0D9488" },
  building_updated: { icon: Building2, fallbackColor: "#F59E0B" },
  revenue_created: { icon: TrendingUp, fallbackColor: "#0D9488" },
  revenue_updated: { icon: TrendingUp, fallbackColor: "#F59E0B" },
  revenue_deleted: { icon: TrendingUp, fallbackColor: "#ef4444" },
};

function timeAgo(timestamp: string): string {
  const now = Date.now();
  const then = new Date(timestamp).getTime();
  const diff = Math.max(0, now - then);
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "الآن";
  if (mins < 60) return `منذ ${mins} د`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `منذ ${hours} س`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `منذ ${days} يوم`;
  if (days < 30) return `منذ ${Math.floor(days / 7)} أسبوع`;
  return `منذ ${Math.floor(days / 30)} شهر`;
}

function formatNumber(n: number): string {
  return n.toLocaleString("en-US");
}

const quickActions = [
  { label: "إضافة فاتورة", icon: FileText, color: "#0D9488", path: "/dashboard/invoices" },
  { label: "إرسال إعلان", icon: Megaphone, color: "#F59E0B", path: "/dashboard/announcements" },
  { label: "تسجيل سلفة", icon: Banknote, color: "#6366f1", path: "/dashboard/advances" },
  { label: "دعوة مالك", icon: Users, color: "#ec4899", path: "/dashboard/residents" },
  { label: "تسجيل مصروف", icon: Receipt, color: "#ef4444", path: "/dashboard/expenses" },
  { label: "تسجيل تبرع", icon: Heart, color: "#f43f5e", path: "/dashboard/donations" },
  { label: "إنشاء تصويت", icon: Vote, color: "#8b5cf6", path: "/dashboard/voting" },
];

export function OverviewPage() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [activities, setActivities] = useState<api.ActivityEntry[]>([]);
  const [loadingActivities, setLoadingActivities] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [buildingName, setBuildingName] = useState("");
  const [adminName, setAdminName] = useState("");

  // Stats from API
  const [overviewStats, setOverviewStats] = useState<api.OverviewStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(true);

  // Current month period (no user-selectable filter)
  const currentPeriod: PeriodFilterValue = getDefaultPeriod();

  // Load building info
  useEffect(() => {
    (async () => {
      try {
        const res = await api.getBuilding();
        if (res.exists && res.building) {
          setBuildingName(res.building.name);
        }
      } catch (err) {
        console.error("Error loading building info:", err);
      }
    })();
  }, []);

  // Derive first name from auth profile (skips title prefix)
  useEffect(() => {
    if (profile?.name) {
      setAdminName(getFirstName(profile.name, ""));
    }
  }, [profile]);

  // Load overview stats (current month)
  useEffect(() => {
    (async () => {
      try {
        setLoadingStats(true);
        const stats = await api.getOverviewStats(currentPeriod);
        setOverviewStats(stats);
      } catch (err) {
        console.error("Error loading overview stats:", err);
      } finally {
        setLoadingStats(false);
      }
    })();
  }, []);

  const loadActivities = useCallback(async () => {
    try {
      setLoadingActivities(true);
      const data = await api.getActivityLog(5);
      setActivities(data);
    } catch (err) {
      console.error("Error loading activity log:", err);
    } finally {
      setLoadingActivities(false);
    }
  }, []);

  useEffect(() => {
    loadActivities();
  }, [loadActivities]);

  // Auto-process recurring invoices on dashboard load (idempotent — once per month)
  useEffect(() => {
    (async () => {
      try {
        const result = await api.processRecurringInvoices();
        if (result.created > 0) {
          console.log(`Auto-created ${result.created} recurring invoices for ${result.monthKey}`);
          // Reload stats and activities to reflect new invoices
          const stats = await api.getOverviewStats(currentPeriod);
          setOverviewStats(stats);
          loadActivities();
        }
      } catch (err) {
        console.error("Error processing recurring invoices:", err);
      }
    })();
  }, []); // once on mount

  const s = overviewStats || {
    revenue: 0, internalRevenue: 0, externalRevenue: 0,
    expenses: 0, balance: 0,
    initialBalance: 0, previousDebts: 0, previousRevenues: 0,
    activeAdvancesTotal: 0, activeAdvancesCount: 0, returnedAdvancesTotal: 0,
    pendingCount: 0, pendingAmount: 0,
    totalInvoices: 0, paidCount: 0, overdueCount: 0,
    awaitingCount: 0, residentsCount: 0, occupiedUnits: 0, totalUnits: 0,
  };

  // Simple balance = revenue - expenses
  const simpleBalance = s.revenue - s.expenses;

  // Build revenue subtitle with breakdown
  const revenueParts: string[] = [];
  if (s.internalRevenue > 0) revenueParts.push(`داخلي: ${formatNumber(s.internalRevenue)}`);
  if (s.externalRevenue > 0) revenueParts.push(`خارجي: ${formatNumber(s.externalRevenue)}`);
  const revenueSub = revenueParts.length > 0
    ? revenueParts.join(" + ")
    : (s.paidCount > 0 ? `${s.paidCount} فاتورة مدفوعة` : "لا إيرادات بعد");

  const stats = [
    {
      label: "إجمالي الإيرادات",
      value: `${formatNumber(s.revenue)} ج.م`,
      sub: revenueSub,
      icon: TrendingUp,
      color: "#0D9488",
      valueColor: "",
    },
    {
      label: "إجمالي المصروفات",
      value: `${formatNumber(s.expenses)} ج.م`,
      sub: s.expenses > 0 ? `${Math.round((s.expenses / (s.revenue || 1)) * 100)}% من الإيرادات` : "لا مصروفات بعد",
      icon: Receipt,
      color: "#0D9488",
      valueColor: "",
    },
    {
      label: "الرصيد الحالي",
      value: `${formatNumber(simpleBalance)} ج.م`,
      sub: simpleBalance >= 0 ? "رصيد إيجابي — الإيرادات أكبر من المصروفات" : "رصيد سالب — المصروفات أكبر من الإيرادات",
      icon: Banknote,
      color: "#0D9488",
      valueColor: simpleBalance < 0 ? "#dc2626" : "#0D9488",
    },
    {
      label: "مديونيات سابقة",
      value: s.previousDebts > 0 ? `${formatNumber(s.previousDebts)} ج.م` : "٠ ج.م",
      sub: s.previousDebts > 0 ? "مستحقات من قبل مُلاك" : "الاتحاد بدأ بدون مديونيات",
      icon: AlertCircle,
      color: "#0D9488",
      valueColor: s.previousDebts > 0 ? "#dc2626" : "",
    },
  ];

  // Mini info cards
  const infoCards = [
    { label: "إجمالي الشقق", value: s.totalUnits, icon: Building2, color: "#0D9488" },
    { label: "شقق مشغولة", value: s.occupiedUnits, icon: Home, color: "#0D9488" },
    { label: "السكان", value: s.residentsCount, icon: Users, color: "#0D9488" },
    { label: "فواتير غير مدفوعة", value: s.pendingCount, icon: FileText, color: "#0D9488" },
  ];

  return (
    <div className="space-y-5">
      {/* Welcome Banner */}
      <div
        className="rounded-2xl p-5 sm:p-6 lg:p-8"
        style={{ background: 'linear-gradient(to left, #0D9488, #0a7a70)' }}
      >
        <div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl mb-2" style={{ color: '#ffffff' }}>{adminName ? `أهلاً ${adminName}!` : "أهلاً بك!"} 👋</h1>
          <p className="text-sm sm:text-base" style={{ color: 'rgba(255,255,255,0.8)' }}>
            إليك ملخص ما يحدث في {buildingName || "المبنى"} اليوم
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-2 sm:gap-3">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.06 }}
            className="bg-white rounded-xl p-2.5 sm:p-3 border border-gray-100 shadow-sm relative overflow-hidden"
          >
            {loadingStats && (
              <div className="absolute inset-0 bg-white/60 flex items-center justify-center z-10">
                <Loader2 className="w-3.5 h-3.5 text-[#0D9488] animate-spin" />
              </div>
            )}
            <div className="flex items-center gap-2 mb-1.5">
              <div
                className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center shrink-0"
                style={{ backgroundColor: `${stat.color}12` }}
              >
                <stat.icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" style={{ color: stat.color }} />
              </div>
              <div className="text-[10px] sm:text-xs text-[#5f6b7a] leading-tight truncate">{stat.label}</div>
            </div>
            <div className="text-sm sm:text-base font-semibold text-[#1a1a2e] truncate" style={stat.valueColor ? { color: stat.valueColor } : undefined}>{stat.value}</div>
          </motion.div>
        ))}
      </div>

      {/* Mini Info Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
        {infoCards.map((card) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-xl p-3 border border-gray-100 text-center relative overflow-hidden"
          >
            {loadingStats && (
              <div className="absolute inset-0 bg-white/60 flex items-center justify-center z-10">
                <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: card.color }} />
              </div>
            )}
            <card.icon className="w-4 h-4 mx-auto mb-1.5" style={{ color: card.color }} />
            <div className="text-base sm:text-lg font-semibold text-[#1a1a2e]">{card.value}</div>
            <div className="text-[9px] sm:text-[10px] text-[#5f6b7a] leading-tight">{card.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions — Horizontal scrollable strip */}
      <div className="relative">
        <div
          ref={scrollRef}
          className="flex gap-2.5 overflow-x-auto scrollbar-hide pb-1 -mx-1 px-1"
          style={{ scrollBehavior: "smooth", WebkitOverflowScrolling: "touch" }}
        >
          {quickActions.map((action) => (
            <button
              key={action.label}
              onClick={() => navigate(action.path)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-gray-100 bg-white hover:shadow-md transition-all hover:-translate-y-0.5 shrink-0"
            >
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: `${action.color}12` }}
              >
                <action.icon className="w-3.5 h-3.5" style={{ color: action.color }} />
              </div>
              <span className="text-xs text-[#5f6b7a] whitespace-nowrap">{action.label}</span>
            </button>
          ))}
        </div>
        {/* Fade edges to hint scrollability */}
        <div className="absolute left-0 top-0 bottom-1 w-6 pointer-events-none" style={{ background: 'linear-gradient(to right, #f8fffe, transparent)' }} />
      </div>

      {/* Activity Log */}
      <div className="bg-white rounded-2xl border border-[#0D9488]/10">
        <div className="flex items-center justify-between p-5 border-b border-[#0D9488]/10">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#0D9488]" />
            <h3 className="text-[#1a1a2e]">سجل النشاط</h3>
          </div>
          {!loadingActivities && activities.length > 0 && (
            <span className="text-[10px] text-[#5f6b7a] bg-gray-50 px-2 py-1 rounded-full">
              آخر {activities.length} نشاط
            </span>
          )}
        </div>

        {loadingActivities ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 text-[#0D9488] animate-spin" />
          </div>
        ) : activities.length === 0 ? (
          <div className="text-center py-12">
            <Activity className="w-10 h-10 text-[#0D9488]/15 mx-auto mb-2" />
            <div className="text-sm text-[#5f6b7a]">لا يوجد نشاط مسجل بعد</div>
            <div className="text-xs text-[#5f6b7a]/60 mt-1">ابدأ بإنشاء فاتورة أو إرسال إعلان</div>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {activities.map((act, i) => {
              const mapped = activityIconMap[act.type] || { icon: Activity, fallbackColor: "#5f6b7a" };
              const ActIcon = mapped.icon;
              const color = act.color || mapped.fallbackColor;

              return (
                <motion.div
                  key={act.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="flex items-start gap-3 p-4 hover:bg-gray-50/50 transition-colors"
                >
                  {/* Timeline dot */}
                  <div className="flex flex-col items-center pt-0.5">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                      style={{ backgroundColor: `${color}12` }}
                    >
                      <ActIcon className="w-4 h-4" style={{ color }} />
                    </div>
                    {i < activities.length - 1 && (
                      <div className="w-px h-full min-h-[8px] bg-gray-100 mt-1" />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm text-[#1a1a2e] font-medium">{act.title}</span>
                      <span className="text-[10px] text-[#5f6b7a]/70">{timeAgo(act.timestamp)}</span>
                    </div>
                    <p className="text-xs text-[#5f6b7a] mt-0.5 leading-relaxed truncate">
                      {act.description}
                    </p>
                  </div>

                  {/* Amount badge if exists */}
                  {act.metadata?.amount && (
                    <div className="shrink-0 text-left">
                      <span
                        className="text-xs px-2 py-1 rounded-lg font-medium"
                        style={{ backgroundColor: `${color}10`, color }}
                      >
                        {Number(act.metadata.amount).toLocaleString("en-US")} ج.م
                      </span>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}

        {/* "المزيد" button */}
        {!loadingActivities && activities.length >= 5 && (
          <div className="border-t border-[#0D9488]/10 p-3">
            <button
              onClick={() => navigate("/dashboard/activity-log")}
              className="w-full flex items-center justify-center gap-2 py-2.5 text-sm text-[#0D9488] hover:bg-[#0D9488]/5 rounded-xl transition-colors font-medium"
            >
              عرض جميع النشاطات
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}