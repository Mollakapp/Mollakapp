import { useState, useEffect } from "react";
import {
  CreditCard,
  Crown,
  Check,
  Clock,
  AlertTriangle,
  Loader2,
  Shield,
  Sparkles,
  CalendarDays,
  Zap,
  Gift,
  ChevronDown,
  ChevronUp,
  History,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import * as api from "../../lib/api";

const PLAN_DETAILS: Record<string, {
  key: string;
  name: string;
  monthlyPrice: number;
  totalPrice: number;
  discount: number;
  period: string;
  icon: typeof CreditCard;
  color: string;
  popular?: boolean;
  features: string[];
}> = {
  monthly: {
    key: "monthly",
    name: "الباقة الشهرية",
    monthlyPrice: 299,
    totalPrice: 299,
    discount: 0,
    period: "شهر",
    icon: CreditCard,
    color: "#5f6b7a",
    features: [
      "جميع مميزات النظام",
      "إدارة المُلاك والشقق",
      "الفواتير والمصروفات",
      "الإعلانات والتصويت",
      "المحادثات والرسائل",
      "التقارير المالية",
    ],
  },
  semi_annual: {
    key: "semi_annual",
    name: "باقة 6 أشهر",
    monthlyPrice: Math.round((299 * 6 * 0.85) / 6),
    totalPrice: Math.round(299 * 6 * 0.85),
    discount: 15,
    period: "6 أشهر",
    icon: Shield,
    color: "#0D9488",
    popular: true,
    features: [
      "جميع مميزات الباقة الشهرية",
      "توفير 15% من السعر",
      "أولوية الدعم الفني",
      "تنبيهات متقدمة",
    ],
  },
  annual: {
    key: "annual",
    name: "الباقة السنوية",
    monthlyPrice: Math.round((299 * 12 * 0.80) / 12),
    totalPrice: Math.round(299 * 12 * 0.80),
    discount: 20,
    period: "سنة",
    icon: Crown,
    color: "#F59E0B",
    features: [
      "جميع مميزات الباقة الشهرية",
      "أقصى توفير — 20%",
      "أولوية الدعم الفني",
      "تنبيهات متقدمة",
      "تقارير شاملة",
    ],
  },
};

const planLabels: Record<string, string> = {
  trial: "فترة تجريبية",
  monthly: "شهري",
  semi_annual: "6 أشهر",
  annual: "سنوي",
};

export function SubscriptionPage() {
  const [sub, setSub] = useState<api.Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [activating, setActivating] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const [confirmPlan, setConfirmPlan] = useState<string | null>(null);

  useEffect(() => {
    loadSubscription();
  }, []);

  const loadSubscription = async () => {
    try {
      setLoading(true);
      const data = await api.getSubscription();
      setSub(data);
    } catch (err) {
      console.error("Error loading subscription:", err);
      setErrorMsg("حدث خطأ أثناء تحميل بيانات الاشتراك");
    } finally {
      setLoading(false);
    }
  };

  const handleActivate = async (plan: string) => {
    setActivating(plan);
    setErrorMsg("");
    try {
      const result = await api.activateSubscription(plan);
      setSub(result.subscription);
      setSuccessMsg(result.message);
      setConfirmPlan(null);
      setTimeout(() => setSuccessMsg(""), 3000);
    } catch (err: any) {
      console.error("Error activating subscription:", err);
      setErrorMsg(err.message || "حدث خطأ أثناء تفعيل الاشتراك");
    } finally {
      setActivating(null);
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleDateString("ar-u-nu-latn", {
        year: "numeric",
        month: "long",
        day: "numeric",
      });
    } catch {
      return dateStr;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20" dir="rtl">
        <Loader2 className="w-8 h-8 text-[#0D9488] animate-spin" />
      </div>
    );
  }

  const isTrial = sub?.plan === "trial";
  const isActive = sub?.status === "active";
  const isExpired = sub?.status === "expired";
  const daysLeft = sub?.remainingDays || 0;
  const urgentDays = isTrial ? daysLeft <= 14 : daysLeft <= 7;

  return (
    <div className="max-w-5xl mx-auto" dir="rtl">
      {/* Success/Error Messages */}
      <AnimatePresence>
        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mb-4 bg-[#0D9488]/10 border border-[#0D9488]/20 text-[#0D9488] px-4 py-3 rounded-2xl text-sm flex items-center gap-2"
          >
            <Check className="w-4 h-4 shrink-0" />{successMsg}
          </motion.div>
        )}
        {errorMsg && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mb-4 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-2xl text-sm flex items-center gap-2"
          >
            <AlertTriangle className="w-4 h-4 shrink-0" />{errorMsg}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Current Status Card */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`rounded-3xl p-5 sm:p-6 mb-6 border ${
          isExpired
            ? "bg-red-50/50 border-red-200"
            : isTrial
            ? "bg-gradient-to-bl from-[#F59E0B]/5 to-[#0D9488]/5 border-[#F59E0B]/20"
            : "bg-gradient-to-bl from-[#0D9488]/5 to-[#0D9488]/10 border-[#0D9488]/20"
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${
            isExpired
              ? "bg-red-100"
              : isTrial
              ? "bg-[#F59E0B]/10"
              : "bg-[#0D9488]/10"
          }`}>
            {isExpired ? (
              <AlertTriangle className="w-7 h-7 text-red-500" />
            ) : isTrial ? (
              <Gift className="w-7 h-7 text-[#F59E0B]" />
            ) : (
              <Crown className="w-7 h-7 text-[#0D9488]" />
            )}
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-lg text-[#1a1a2e]">
                {isExpired
                  ? "انتهى الاشتراك"
                  : isTrial
                  ? "الفترة التجريبية"
                  : `باقة ${planLabels[sub?.plan || ""]}`}
              </h2>
              <span className={`text-[10px] px-2.5 py-0.5 rounded-full ${
                isExpired
                  ? "bg-red-100 text-red-600"
                  : isActive
                  ? "bg-[#0D9488]/10 text-[#0D9488]"
                  : "bg-gray-100 text-gray-500"
              }`}>
                {isExpired ? "منتهي" : isActive ? "نشط" : sub?.status}
              </span>
            </div>

            {isActive && (
              <p className="text-sm text-[#5f6b7a]">
                {isTrial ? "استمتع بجميع المميزات مجاناً" : `المبلغ: ${(sub?.amount || 0).toLocaleString("en-US")} ج.م`}
                {" · "}
                ينتهي في {formatDate(sub?.endDate || "")}
              </p>
            )}

            {isExpired && (
              <p className="text-sm text-red-500">
                انتهى اشتراكك. اختر باقة أدناه لتجديد الاشتراك والاستمرار في استخدام النظام.
              </p>
            )}
          </div>

          {/* Days remaining badge */}
          {isActive && (
            <div className={`text-center px-5 py-3 rounded-2xl ${
              urgentDays
                ? "bg-red-50 border border-red-200"
                : "bg-white border border-gray-100"
            }`}>
              <div className={`text-2xl font-bold ${urgentDays ? "text-red-500" : "text-[#0D9488]"}`}>
                {daysLeft.toLocaleString("en-US")}
              </div>
              <div className={`text-[10px] ${urgentDays ? "text-red-400" : "text-[#5f6b7a]"}`}>
                يوم متبقي
              </div>
            </div>
          )}
        </div>

        {/* Progress bar for trial */}
        {isTrial && isActive && (
          <div className="mt-4">
            <div className="flex items-center justify-between text-[10px] text-[#5f6b7a] mb-1.5">
              <span>بداية التجربة</span>
              <span>{daysLeft} يوم من 90</span>
              <span>نهاية التجربة</span>
            </div>
            <div className="h-2 bg-white rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.max(2, ((90 - daysLeft) / 90) * 100)}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className={`h-full rounded-full ${
                  urgentDays
                    ? "bg-gradient-to-l from-red-400 to-red-500"
                    : "bg-gradient-to-l from-[#0D9488] to-[#F59E0B]"
                }`}
              />
            </div>
          </div>
        )}
      </motion.div>

      {/* Section Title */}
      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 bg-[#0D9488]/10 rounded-xl flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-[#0D9488]" />
        </div>
        <div>
          <h3 className="text-[#1a1a2e]">اختر باقتك</h3>
          <p className="text-xs text-[#5f6b7a]">
            {isTrial
              ? "فعّل اشتراكك قبل انتهاء الفترة التجريبية"
              : isExpired
              ? "جدّد اشتراكك للاستمرار"
              : "غيّر أو جدّد باقتك"}
          </p>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {Object.values(PLAN_DETAILS).map((plan, idx) => {
          const isCurrentPlan = sub?.plan === plan.key && isActive;
          const Icon = plan.icon;

          return (
            <motion.div
              key={plan.key}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className={`relative rounded-3xl border-2 transition-all overflow-hidden ${
                plan.popular
                  ? "border-[#0D9488] shadow-lg shadow-[#0D9488]/10"
                  : isCurrentPlan
                  ? "border-[#F59E0B] shadow-md"
                  : "border-gray-100 hover:border-[#0D9488]/30 hover:shadow-md"
              }`}
            >
              {/* Popular badge */}
              {plan.popular && (
                <div className="bg-[#0D9488] text-white text-[10px] text-center py-1.5 font-medium">
                  <Zap className="w-3 h-3 inline-block ml-1 -mt-0.5" />
                  الأكثر طلباً
                </div>
              )}

              {/* Current plan badge */}
              {isCurrentPlan && (
                <div className="bg-[#F59E0B] text-white text-[10px] text-center py-1.5 font-medium">
                  <Check className="w-3 h-3 inline-block ml-1 -mt-0.5" />
                  باقتك الحالية
                </div>
              )}

              <div className="p-5">
                {/* Plan header */}
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center"
                    style={{ backgroundColor: `${plan.color}15` }}
                  >
                    <Icon className="w-5.5 h-5.5" style={{ color: plan.color }} />
                  </div>
                  <div>
                    <h4 className="text-sm text-[#1a1a2e]">{plan.name}</h4>
                    <span className="text-[10px] text-[#5f6b7a]">{plan.period}</span>
                  </div>
                </div>

                {/* Price */}
                <div className="mb-4">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-bold text-[#1a1a2e]">
                      {plan.monthlyPrice.toLocaleString("en-US")}
                    </span>
                    <span className="text-sm text-[#5f6b7a]">ج.م / شهر</span>
                  </div>
                  {plan.discount > 0 && (
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="text-xs text-[#5f6b7a] line-through">
                        {(299).toLocaleString("en-US")} ج.م
                      </span>
                      <span className="text-[10px] bg-[#0D9488]/10 text-[#0D9488] px-2 py-0.5 rounded-full font-medium">
                        وفّر {plan.discount}%
                      </span>
                    </div>
                  )}
                  {plan.key !== "monthly" && (
                    <div className="text-xs text-[#5f6b7a] mt-1">
                      الإجمالي: {plan.totalPrice.toLocaleString("en-US")} ج.م
                    </div>
                  )}
                </div>

                {/* Features */}
                <ul className="space-y-2.5 mb-5">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-[#5f6b7a]">
                      <Check className="w-3.5 h-3.5 text-[#0D9488] shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* Action button */}
                {isCurrentPlan ? (
                  <button
                    disabled
                    className="w-full py-3 rounded-xl text-sm bg-gray-100 text-gray-400 cursor-not-allowed"
                  >
                    <Check className="w-4 h-4 inline-block ml-1" />
                    مفعّلة
                  </button>
                ) : confirmPlan === plan.key ? (
                  <div className="space-y-2">
                    <p className="text-xs text-center text-[#1a1a2e] bg-[#F59E0B]/5 rounded-xl py-2 px-3">
                      تأكيد تفعيل {plan.name} بمبلغ{" "}
                      <span className="font-bold text-[#0D9488]">
                        {plan.totalPrice.toLocaleString("en-US")} ج.م
                      </span>؟
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleActivate(plan.key)}
                        disabled={!!activating}
                        className="flex-1 py-2.5 rounded-xl text-sm bg-[#0D9488] text-white hover:bg-[#0D9488]/90 transition-all shadow-sm disabled:opacity-60 flex items-center justify-center gap-1.5"
                      >
                        {activating === plan.key ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Check className="w-4 h-4" />
                        )}
                        تأكيد
                      </button>
                      <button
                        onClick={() => setConfirmPlan(null)}
                        disabled={!!activating}
                        className="flex-1 py-2.5 rounded-xl text-sm border border-gray-200 text-[#5f6b7a] hover:bg-gray-50 transition-all"
                      >
                        إلغاء
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmPlan(plan.key)}
                    className={`w-full py-3 rounded-xl text-sm transition-all shadow-sm ${
                      plan.popular
                        ? "bg-[#0D9488] text-white hover:bg-[#0D9488]/90 shadow-[#0D9488]/20"
                        : plan.key === "annual"
                        ? "bg-[#F59E0B] text-white hover:bg-[#F59E0B]/90 shadow-[#F59E0B]/20"
                        : "bg-[#1a1a2e] text-white hover:bg-[#1a1a2e]/90"
                    }`}
                  >
                    <CreditCard className="w-4 h-4 inline-block ml-1" />
                    {isExpired ? "تفعيل الآن" : isTrial ? "الاشتراك الآن" : "تغيير الباقة"}
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Subscription Timeline / Info */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-3xl border border-gray-100 p-5 mb-4"
      >
        <div className="flex items-center gap-3 mb-4">
          <CalendarDays className="w-5 h-5 text-[#0D9488]" />
          <h3 className="text-sm text-[#1a1a2e]">تفاصيل الاشتراك</h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-[#f8fffe] rounded-xl p-3 text-center">
            <div className="text-[10px] text-[#5f6b7a] mb-1">الباقة</div>
            <div className="text-sm text-[#1a1a2e]">{planLabels[sub?.plan || ""] || "—"}</div>
          </div>
          <div className="bg-[#f8fffe] rounded-xl p-3 text-center">
            <div className="text-[10px] text-[#5f6b7a] mb-1">الحالة</div>
            <div className={`text-sm ${isActive ? "text-[#0D9488]" : "text-red-500"}`}>
              {isActive ? "نشط" : "منتهي"}
            </div>
          </div>
          <div className="bg-[#f8fffe] rounded-xl p-3 text-center">
            <div className="text-[10px] text-[#5f6b7a] mb-1">بداية الاشتراك</div>
            <div className="text-xs text-[#1a1a2e]">{formatDate(sub?.startDate || "")}</div>
          </div>
          <div className="bg-[#f8fffe] rounded-xl p-3 text-center">
            <div className="text-[10px] text-[#5f6b7a] mb-1">تاريخ الانتهاء</div>
            <div className={`text-xs ${urgentDays ? "text-red-500 font-medium" : "text-[#1a1a2e]"}`}>
              {formatDate(sub?.endDate || "")}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Subscription History */}
      {sub?.history && sub.history.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-3xl border border-gray-100 overflow-hidden"
        >
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="w-full flex items-center justify-between p-5 hover:bg-gray-50/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <History className="w-5 h-5 text-[#5f6b7a]" />
              <span className="text-sm text-[#1a1a2e]">
                سجل الاشتراكات ({sub.history.length})
              </span>
            </div>
            {showHistory ? (
              <ChevronUp className="w-4 h-4 text-[#5f6b7a]" />
            ) : (
              <ChevronDown className="w-4 h-4 text-[#5f6b7a]" />
            )}
          </button>

          <AnimatePresence>
            {showHistory && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="border-t border-gray-100 overflow-hidden"
              >
                <div className="divide-y divide-gray-50">
                  {sub.history.map((entry, idx) => (
                    <div key={idx} className="px-5 py-3 flex items-center justify-between">
                      <div>
                        <span className="text-sm text-[#1a1a2e]">
                          {planLabels[entry.plan] || entry.plan}
                        </span>
                        <span className="text-xs text-[#5f6b7a] mr-2">
                          {formatDate(entry.startDate)} → {formatDate(entry.endDate)}
                        </span>
                      </div>
                      <span className="text-sm text-[#0D9488]">
                        {entry.amount.toLocaleString("en-US")} ج.م
                      </span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}

      {/* Info note */}
      <div className="mt-6 text-center text-xs text-[#5f6b7a] pb-4">
        <Clock className="w-3.5 h-3.5 inline-block ml-1" />
        الاشتراك يتجدد تلقائياً عند التفعيل. يمكنك تغيير الباقة في أي وقت.
      </div>
    </div>
  );
}
