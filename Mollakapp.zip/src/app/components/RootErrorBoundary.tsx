import { useRouteError, useNavigate } from "react-router";
import { AlertCircle, Home } from "lucide-react";

export function RootErrorBoundary() {
  const error = useRouteError() as any;
  const navigate = useNavigate();

  const status = error?.status || 500;
  const isNotFound = status === 404;

  return (
    <div
      className="min-h-screen bg-gradient-to-bl from-[#0D9488]/5 via-[#f8fffe] to-[#F59E0B]/5 flex items-center justify-center p-4"
      dir="rtl"
    >
      <div className="text-center max-w-md">
        <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <AlertCircle className="w-8 h-8 text-red-400" />
        </div>
        <h1 className="text-5xl font-bold text-[#1a1a2e] mb-2">{status}</h1>
        <h2 className="text-xl text-[#1a1a2e] mb-2">
          {isNotFound ? "الصفحة غير موجودة" : "حدث خطأ"}
        </h2>
        <p className="text-sm text-[#5f6b7a] mb-6">
          {isNotFound
            ? "الصفحة اللي بتدور عليها مش موجودة أو تم نقلها."
            : "حدث خطأ غير متوقع. حاول مرة تانية."}
        </p>
        <button
          onClick={() => navigate("/")}
          className="inline-flex items-center gap-2 bg-[#0D9488] text-white px-6 py-3 rounded-xl hover:bg-[#0D9488]/90 transition-all text-sm"
        >
          <Home className="w-4 h-4" />
          الصفحة الرئيسية
        </button>
      </div>
    </div>
  );
}
