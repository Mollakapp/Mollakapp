import { createBrowserRouter } from "react-router";
import { lazy } from "react";

// Only eagerly load root layout and landing (first paint)
import { RootErrorBoundary } from "./components/RootErrorBoundary";
import { RootLayout } from "./components/RootLayout";
import { LandingPage } from "./components/landing/LandingPage";

// Auth pages — lazy
const LoginPage = lazy(() => import("./components/auth/LoginPage").then(m => ({ default: m.LoginPage })));
const RegisterPage = lazy(() => import("./components/auth/RegisterPage").then(m => ({ default: m.RegisterPage })));
const JoinBuildingPage = lazy(() => import("./components/auth/JoinBuildingPage").then(m => ({ default: m.JoinBuildingPage })));
const ForgotPasswordPage = lazy(() => import("./components/auth/ForgotPasswordPage").then(m => ({ default: m.ForgotPasswordPage })));

// Union Dashboard — lazy
const DashboardLayout = lazy(() => import("./components/dashboard/DashboardLayout").then(m => ({ default: m.DashboardLayout })));
const OverviewPage = lazy(() => import("./components/dashboard/OverviewPage").then(m => ({ default: m.OverviewPage })));
const ExpensesPage = lazy(() => import("./components/dashboard/ExpensesPage").then(m => ({ default: m.ExpensesPage })));
const RevenuePage = lazy(() => import("./components/dashboard/RevenuePage").then(m => ({ default: m.RevenuePage })));
const InvoicesPage = lazy(() => import("./components/dashboard/InvoicesPage").then(m => ({ default: m.InvoicesPage })));
const AdvancesPage = lazy(() => import("./components/dashboard/AdvancesPage").then(m => ({ default: m.AdvancesPage })));
const BuildingPage = lazy(() => import("./components/dashboard/BuildingPage").then(m => ({ default: m.BuildingPage })));
const ResidentsPage = lazy(() => import("./components/dashboard/ResidentsPage").then(m => ({ default: m.ResidentsPage })));
const ChatPage = lazy(() => import("./components/dashboard/ChatPage").then(m => ({ default: m.ChatPage })));
const AnnouncementsPage = lazy(() => import("./components/dashboard/AnnouncementsPage").then(m => ({ default: m.AnnouncementsPage })));
const DirectoryPage = lazy(() => import("./components/dashboard/DirectoryPage").then(m => ({ default: m.DirectoryPage })));
const EventsPage = lazy(() => import("./components/dashboard/EventsPage").then(m => ({ default: m.EventsPage })));
const DonationsPage = lazy(() => import("./components/dashboard/DonationsPage").then(m => ({ default: m.DonationsPage })));
const VotingPage = lazy(() => import("./components/dashboard/VotingPage").then(m => ({ default: m.VotingPage })));
const ActivityLogPage = lazy(() => import("./components/dashboard/ActivityLogPage").then(m => ({ default: m.ActivityLogPage })));
const DashboardSettings = lazy(() => import("./components/dashboard/DashboardSettings").then(m => ({ default: m.DashboardSettings })));
const SubscriptionPage = lazy(() => import("./components/dashboard/SubscriptionPage").then(m => ({ default: m.SubscriptionPage })));

// Resident Dashboard — lazy
const ResidentLayout = lazy(() => import("./components/resident/ResidentLayout").then(m => ({ default: m.ResidentLayout })));
const ResidentOverview = lazy(() => import("./components/resident/ResidentOverview").then(m => ({ default: m.ResidentOverview })));
const ResidentInvoices = lazy(() => import("./components/resident/ResidentInvoices").then(m => ({ default: m.ResidentInvoices })));
const ResidentDirectory = lazy(() => import("./components/resident/ResidentDirectory").then(m => ({ default: m.ResidentDirectory })));
const ResidentEvents = lazy(() => import("./components/resident/ResidentEvents").then(m => ({ default: m.ResidentEvents })));
const ResidentDonations = lazy(() => import("./components/resident/ResidentDonations").then(m => ({ default: m.ResidentDonations })));
const ResidentVoting = lazy(() => import("./components/resident/ResidentVoting").then(m => ({ default: m.ResidentVoting })));
const ResidentChat = lazy(() => import("./components/resident/ResidentChat").then(m => ({ default: m.ResidentChat })));
const ResidentSettings = lazy(() => import("./components/resident/ResidentSettings").then(m => ({ default: m.ResidentSettings })));
const ResidentServiceRequests = lazy(() => import("./components/resident/ResidentServiceRequests").then(m => ({ default: m.ResidentServiceRequests })));
const ResidentResidents = lazy(() => import("./components/resident/ResidentResidents").then(m => ({ default: m.ResidentResidents })));

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    ErrorBoundary: RootErrorBoundary,
    children: [
      { index: true, Component: LandingPage },
      { path: "login", Component: LoginPage },
      { path: "register", Component: RegisterPage },
      { path: "forgot-password", Component: ForgotPasswordPage },
      { path: "join/:buildingSlug", Component: JoinBuildingPage },
      // Union Members Dashboard
      {
        path: "dashboard",
        Component: DashboardLayout,
        children: [
          { index: true, Component: OverviewPage },
          { path: "expenses", Component: ExpensesPage },
          { path: "revenue", Component: RevenuePage },
          { path: "invoices", Component: InvoicesPage },
          { path: "advances", Component: AdvancesPage },
          { path: "building", Component: BuildingPage },
          { path: "residents", Component: ResidentsPage },
          { path: "chat", Component: ChatPage },
          { path: "announcements", Component: AnnouncementsPage },
          { path: "directory", Component: DirectoryPage },
          { path: "events", Component: EventsPage },
          { path: "donations", Component: DonationsPage },
          { path: "voting", Component: VotingPage },
          { path: "activity-log", Component: ActivityLogPage },
          { path: "settings", Component: DashboardSettings },
          { path: "subscription", Component: SubscriptionPage },
        ],
      },
      // Resident Dashboard
      {
        path: "resident",
        Component: ResidentLayout,
        children: [
          { index: true, Component: ResidentOverview },
          { path: "invoices", Component: ResidentInvoices },
          { path: "directory", Component: ResidentDirectory },
          { path: "events", Component: ResidentEvents },
          { path: "donations", Component: ResidentDonations },
          { path: "voting", Component: ResidentVoting },
          { path: "chat", Component: ResidentChat },
          { path: "residents", Component: ResidentResidents },
          { path: "settings", Component: ResidentSettings },
          { path: "service-requests", Component: ResidentServiceRequests },
        ],
      },
      // Catch-all 404
      { path: "*", Component: LandingPage },
    ],
  },
]);