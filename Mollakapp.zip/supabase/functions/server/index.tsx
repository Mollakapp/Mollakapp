import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { createClient } from "npm:@supabase/supabase-js@2";
import { AsyncLocalStorage } from "node:async_hooks";

const app = new Hono();

// ── In-Memory Cache Layer ──
// Reduces DB reads for frequently-accessed, rarely-changed data.
// TTL-based: data is cached for a set duration, then re-fetched.
const memCache = new Map<string, { value: any; expiresAt: number }>();
const CACHE_TTL_MS = 30_000; // 30 seconds default

function cacheGet(key: string): any | undefined {
  const entry = memCache.get(key);
  if (!entry) return undefined;
  if (Date.now() > entry.expiresAt) {
    memCache.delete(key);
    return undefined;
  }
  return entry.value;
}

function cacheSet(key: string, value: any, ttl = CACHE_TTL_MS): void {
  memCache.set(key, { value, expiresAt: Date.now() + ttl });
  // Prevent unbounded growth — evict oldest if > 500 keys
  if (memCache.size > 500) {
    const firstKey = memCache.keys().next().value;
    if (firstKey) memCache.delete(firstKey);
  }
}

function cacheInvalidate(key: string): void {
  memCache.delete(key);
}

function cacheInvalidatePrefix(prefix: string): void {
  for (const k of memCache.keys()) {
    if (k.startsWith(prefix)) memCache.delete(k);
  }
}

// Cached KV get — checks memory first, then DB
async function cachedGet(key: string, ttl = CACHE_TTL_MS): Promise<any> {
  const cached = cacheGet(key);
  if (cached !== undefined) return cached;
  const value = await kv.get(key);
  if (value !== null && value !== undefined) {
    cacheSet(key, value, ttl);
  }
  return value;
}

// ── Per-request context storage ──
// Stores the Hono context `c` so getActiveBuildingId() can read
// the X-Building-Id header without needing `c` passed as a parameter.
const requestContextStorage = new AsyncLocalStorage<any>();

// Must be registered FIRST — wraps every middleware & route handler
app.use('*', async (c, next) => {
  await requestContextStorage.run(c, next);
});

// Supabase admin client (for creating auth users)
const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

// Supabase anon client (for verifying tokens)
const supabaseAnon = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization", "X-User-Token", "X-Building-Id"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-86a3da15/health", (c) => {
  return c.json({ status: "ok" });
});

// ===================================================================
// Building-scoped KV keys helper
// ===================================================================
// All data is scoped per building. Key format: "{buildingId}:{dataType}"
// "building:active" stores the currently active building ID.

async function getActiveBuildingId(): Promise<string | null> {
  // Priority 1: X-Building-Id header from the current request (per-user, per-building)
  const c = requestContextStorage.getStore();
  if (c) {
    const headerBuildingId = c.req.header('X-Building-Id');
    if (headerBuildingId) return headerBuildingId;
  }
  // Priority 2: Global fallback (used during registration & unauthenticated flows)
  const id = await kv.get("building:active");
  return id || null;
}

function bKey(buildingId: string, dataType: string): string {
  return `${buildingId}:${dataType}`;
}

// ===================================================================
// Activity Log — Building-scoped
// ===================================================================

interface ActivityEntry {
  id: string;
  type: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

async function logActivity(buildingId: string, entry: Omit<ActivityEntry, "id" | "timestamp">) {
  try {
    const key = bKey(buildingId, "activity_log");
    const existing = await kv.get(key);
    const log: ActivityEntry[] = Array.isArray(existing) ? existing : [];
    log.unshift({
      ...entry,
      id: `act-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: new Date().toISOString(),
    });
    // Keep only last 200 entries
    if (log.length > 200) log.length = 200;
    await kv.set(key, log);
  } catch (err: any) {
    console.log("Error logging activity:", err.message);
  }
}

app.get("/make-server-86a3da15/activity-log", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) {
      return c.json([]);
    }
    const limit = parseInt(c.req.query("limit") || "20");
    const log = await kv.get(bKey(buildingId, "activity_log"));
    const entries: ActivityEntry[] = Array.isArray(log) ? log : [];
    return c.json(entries.slice(0, limit));
  } catch (err: any) {
    console.log("Error fetching activity log:", err.message);
    return c.json({ error: `Error fetching activity log: ${err.message}` }, 500);
  }
});

// ===================================================================
// Building Registration & Management
// ===================================================================

interface BuildingInfo {
  id: string;
  name: string;
  address: string;
  city: string;
  floors: number;
  unitsPerFloor: number[];
  floorConfigs?: FloorConfig[];
  totalUnits: number;
  slug: string;
  admin: {
    name: string;
    phone: string;
    email: string;
    role: string;
    unitCode?: string;
  };
  initialBalance: number;
  previousDebts: number;
  previousRevenues: number;
  createdAt: string;
  updatedAt: string;
}

interface FloorConfig {
  label: string;
  unitCount: number;
  unitType: "سكني" | "تجاري";
}

function generateUnitsFromConfig(buildingId: string, floors: number, unitsPerFloor: number[], floorConfigs?: FloorConfig[]) {
  const units: any[] = [];

  if (floorConfigs && floorConfigs.length > 0) {
    // New system: use floorConfigs for labels, types, and counts
    floorConfigs.forEach((fc, idx) => {
      const floorNum = idx + 1;
      for (let u = 1; u <= fc.unitCount; u++) {
        const code = `${floorNum * 100 + u}`;
        const typeLabel = fc.unitType === "تجاري" ? "محل" : "شقة";
        units.push({
          id: `unit-${code}`,
          label: `${typeLabel} ${code}`,
          unitCode: code,
          floor: `${floorNum}`,
          floorLabel: fc.label,
          unitType: fc.unitType,
          occupied: false,
          resident: undefined,
          ownerName: `مالك ${code}`,
        });
      }
    });
  } else {
    // Legacy system: use unitsPerFloor array
    for (let floor = 1; floor <= floors; floor++) {
      const count = unitsPerFloor[floor] || 4;
      for (let u = 1; u <= count; u++) {
        const code = `${floor * 100 + u}`;
        units.push({
          id: `unit-${code}`,
          label: `شقة ${code}`,
          unitCode: code,
          floor: `${floor}`,
          floorLabel: `${floor}`,
          occupied: false,
          resident: undefined,
          ownerName: `مالك ${code}`,
        });
      }
    }
  }
  return units;
}

function generateSlug(name: string) {
  return name
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\u0600-\u06FFa-zA-Z0-9\-]/g, "")
    .toLowerCase() + "-" + Date.now().toString(36);
}

// Register a new building
app.post("/make-server-86a3da15/building", async (c) => {
  try {
    const body = await c.req.json();
    const { name, address, city, floors, unitsPerFloor, floorConfigs, admin, initialBalance, previousDebts, previousRevenues } = body;

    console.log("Building registration: received body fields:", JSON.stringify({ name: !!name, floors, defaultUnitsPerFloor: body.defaultUnitsPerFloor, bodyKeys: Object.keys(body) }));

    if (!name || !floors || floors < 1) {
      const missing: string[] = [];
      if (!name) missing.push("اسم البرج");
      if (!floors && floors !== 0) missing.push("عدد الأدوار (غير موجود)");
      else if (floors < 1) missing.push(`عدد الأدوار (القيمة: ${floors}، يجب أن يكون 1 أو أكثر)`);
      return c.json({ error: `بيانات ناقصة: ${missing.join("، ")}` }, 400);
    }

    // ===== Check if admin phone is already registered =====
    if (admin?.phone && admin?.password) {
      const normalizedAdminPhone = admin.phone.replace(/\s/g, "");
      const adminFakeEmail = `${normalizedAdminPhone}@mollak.app`;
      
      // Check KV mapping first (fast)
      const existingKvUser = await kv.get(`auth:email:${adminFakeEmail}`);
      if (existingKvUser) {
        return c.json({ 
          error: `رقم الجوال ${normalizedAdminPhone} مسجّل بالفعل في مبنى آخر — استخدم رقم مختلف أو سجّل دخول بحسابك الحالي` 
        }, 409);
      }
      
      // Also check Supabase Auth directly (in case KV is out of sync)
      try {
        const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
        const existingAuthUser = existingUsers?.users?.find((u: any) => u.email === adminFakeEmail);
        if (existingAuthUser) {
          return c.json({ 
            error: `رقم الجوال ${normalizedAdminPhone} مسجّل بالفعل — استخدم رقم مختلف أو سجّل دخول بحسابك الحالي` 
          }, 409);
        }
      } catch (lookupErr: any) {
        console.log("Building reg: Error checking existing admin user:", lookupErr.message);
        // Continue anyway — createUser will fail if duplicate
      }
    }

    // Build unitsPerFloor array (legacy) + floorConfigs (new)
    let parsedFloorConfigs: FloorConfig[] | undefined;
    let perFloor: number[] = [0];

    if (Array.isArray(floorConfigs) && floorConfigs.length > 0) {
      parsedFloorConfigs = floorConfigs;
      // Also build legacy perFloor for backward compat
      perFloor = [0, ...floorConfigs.map((fc: FloorConfig) => fc.unitCount)];
    } else if (Array.isArray(unitsPerFloor) && unitsPerFloor.length > 0) {
      perFloor = unitsPerFloor;
    } else {
      for (let i = 1; i <= floors; i++) {
        perFloor.push(body.defaultUnitsPerFloor || 4);
      }
    }

    const totalUnits = parsedFloorConfigs
      ? parsedFloorConfigs.reduce((s: number, fc: FloorConfig) => s + fc.unitCount, 0)
      : perFloor.slice(1).reduce((sum: number, n: number) => sum + n, 0);
    const slug = generateSlug(name);
    const now = new Date().toISOString();

    const buildingId = `bld-${Date.now()}`;

    // Strip password from admin before saving to building info
    const adminInfo = {
      name: admin?.name || "",
      phone: admin?.phone || "",
      email: admin?.email || "",
      role: admin?.role || "رئيس الاتحاد",
      unitCode: admin?.unitCode || "",
    };

    const actualFloors = parsedFloorConfigs ? parsedFloorConfigs.length : floors;

    const building: BuildingInfo = {
      id: buildingId,
      name,
      address: address || "",
      city: city || "",
      floors: actualFloors,
      unitsPerFloor: perFloor,
      floorConfigs: parsedFloorConfigs,
      totalUnits,
      slug,
      admin: adminInfo,
      initialBalance: Number(initialBalance) || 0,
      previousDebts: Number(previousDebts) || 0,
      previousRevenues: Number(previousRevenues) || 0,
      createdAt: now,
      updatedAt: now,
    };

    // Set this as the active building
    await kv.set("building:active", buildingId);

    // Save building info under its own namespace
    await kv.set(bKey(buildingId, "info"), building);
    cacheInvalidate(bKey(buildingId, "info"));

    // Generate and save units under building namespace
    const units = generateUnitsFromConfig(buildingId, actualFloors, perFloor, parsedFloorConfigs);
    await kv.set(bKey(buildingId, "units"), units);

    // Initialize empty data for this building
    await kv.set(bKey(buildingId, "invoice_batches"), []);
    await kv.set(bKey(buildingId, "cash_collections"), []);
    await kv.set(bKey(buildingId, "activity_log"), []);
    await kv.set(bKey(buildingId, "join_requests"), []);
    await kv.set(bKey(buildingId, "advances"), []);
    await kv.set(bKey(buildingId, "expenses"), []);
    await kv.set(bKey(buildingId, "revenues"), []);
    await kv.set(bKey(buildingId, "events"), []);
    await kv.set(bKey(buildingId, "donations"), []);
    await kv.set(bKey(buildingId, "donation_cash_requests"), []);
    await kv.set(bKey(buildingId, "polls"), []);
    await kv.set(bKey(buildingId, "chat_messages"), []);

    // Initialize subscription — 3-month free trial
    const trialEnd = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString();
    await kv.set(bKey(buildingId, "subscription"), {
      plan: "trial",
      status: "active",
      startDate: now,
      endDate: trialEnd,
      trialStartDate: now,
      trialEndDate: trialEnd,
      amount: 0,
      history: [],
    });

    // Track this building in the global buildings list
    const buildingsList = await kv.get("buildings_list") || [];
    buildingsList.push({ id: buildingId, name, slug, createdAt: now });
    await kv.set("buildings_list", buildingsList);

    // ===== Create Supabase Auth user for the admin =====
    let adminAuthError = "";
    if (admin?.phone && admin?.password) {
      const normalizedPhone = admin.phone.replace(/\s/g, "");
      const fakeEmail = `${normalizedPhone}@mollak.app`;

      try {
        const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
          email: fakeEmail,
          password: admin.password,
          user_metadata: {
            name: admin.name || "",
            phone: normalizedPhone,
            buildingId,
            buildingName: name,
            role: "admin",
            adminRole: admin.role || "رئيس الاتحاد",
          },
          // Automatically confirm the user's email since an email server hasn't been configured.
          email_confirm: true,
        });

        if (authError) {
          console.log(`Building reg: Error creating admin auth user: ${authError.message}`);
          adminAuthError = authError.message;
        } else if (authData?.user) {
          console.log(`Building reg: Admin auth user created: ${authData.user.id} for ${fakeEmail}`);
          // Save admin profile in KV
          const adminProfile = {
            id: authData.user.id,
            userId: authData.user.id,
            email: fakeEmail,
            name: admin.name || "",
            phone: normalizedPhone,
            buildingId,
            buildingName: name,
            unitCode: "",
            floor: "",
            type: "admin",
            role: "admin",
            adminRole: admin.role || "رئيس الاتحاد",
          };
          await kv.set(`auth:${authData.user.id}`, adminProfile);
          await kv.set(`auth:email:${fakeEmail}`, authData.user.id);
          console.log(`Building reg: Admin KV profile saved for ${authData.user.id}`);
        }
      } catch (authErr: any) {
        console.log(`Building reg: Exception creating admin auth: ${authErr.message}`);
        adminAuthError = authErr.message;
      }
    } else {
      console.log("Building reg: No admin phone/password provided, skipping auth user creation");
    }

    await logActivity(buildingId, {
      type: "building_registered",
      title: "تسجيل مبنى جديد",
      description: `تم تسجيل "${name}" — ${floors} دور، ${totalUnits} وحدة`,
      icon: "Building2",
      color: "#0D9488",
      metadata: { buildingId, slug },
    });

    return c.json({
      message: "Building registered successfully",
      building,
      unitsCount: units.length,
      adminAuthError: adminAuthError || undefined,
    });
  } catch (err: any) {
    console.log("Error registering building:", err.message);
    return c.json({ error: `Error registering building: ${err.message}` }, 500);
  }
});

// Get building info
app.get("/make-server-86a3da15/building", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) {
      return c.json({ exists: false });
    }
    const building = await cachedGet(bKey(buildingId, "info"), 60_000); // 1 min cache
    if (!building) {
      return c.json({ exists: false });
    }
    return c.json({ exists: true, building });
  } catch (err: any) {
    console.log("Error fetching building info:", err.message);
    return c.json({ error: `Error fetching building info: ${err.message}` }, 500);
  }
});

// Update building info
app.put("/make-server-86a3da15/building", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) {
      return c.json({ error: "No active building" }, 404);
    }

    const body = await c.req.json();
    const existing = await kv.get(bKey(buildingId, "info"));
    if (!existing) {
      return c.json({ error: "No building registered yet" }, 404);
    }

    const { name, address, city, floors, unitsPerFloor, floorConfigs, defaultUnitsPerFloor, admin, initialBalance, previousDebts, previousRevenues } = body;

    // If floors/units changed, regenerate units
    let perFloor = existing.unitsPerFloor;
    let updatedFloorConfigs: FloorConfig[] | undefined = existing.floorConfigs;
    let needRegenerate = false;

    if (Array.isArray(floorConfigs) && floorConfigs.length > 0) {
      // New floorConfigs provided
      updatedFloorConfigs = floorConfigs;
      perFloor = [0, ...floorConfigs.map((fc: FloorConfig) => fc.unitCount)];
      needRegenerate = true;
    } else if (floors && floors !== existing.floors) {
      needRegenerate = true;
      updatedFloorConfigs = undefined;
      perFloor = [0];
      if (Array.isArray(unitsPerFloor) && unitsPerFloor.length > 0) {
        perFloor = unitsPerFloor;
      } else {
        for (let i = 1; i <= floors; i++) {
          perFloor.push(defaultUnitsPerFloor || 4);
        }
      }
    } else if (Array.isArray(unitsPerFloor)) {
      perFloor = unitsPerFloor;
      updatedFloorConfigs = undefined;
      needRegenerate = true;
    }

    const actualFloors = updatedFloorConfigs ? updatedFloorConfigs.length : (floors || existing.floors);
    const totalUnits = updatedFloorConfigs
      ? updatedFloorConfigs.reduce((s: number, fc: FloorConfig) => s + fc.unitCount, 0)
      : perFloor.slice(1).reduce((sum: number, n: number) => sum + n, 0);

    const updated: BuildingInfo = {
      ...existing,
      name: name || existing.name,
      address: address !== undefined ? address : existing.address,
      city: city !== undefined ? city : existing.city,
      floors: actualFloors,
      unitsPerFloor: perFloor,
      floorConfigs: updatedFloorConfigs,
      totalUnits,
      admin: admin || existing.admin,
      initialBalance: initialBalance !== undefined ? Number(initialBalance) : (existing.initialBalance || 0),
      previousDebts: previousDebts !== undefined ? Number(previousDebts) : (existing.previousDebts || 0),
      previousRevenues: previousRevenues !== undefined ? Number(previousRevenues) : (existing.previousRevenues || 0),
      updatedAt: new Date().toISOString(),
    };

    await kv.set(bKey(buildingId, "info"), updated);
    cacheInvalidate(bKey(buildingId, "info"));

    if (needRegenerate) {
      const units = generateUnitsFromConfig(updated.id, actualFloors, perFloor, updatedFloorConfigs);
      await kv.set(bKey(buildingId, "units"), units);
    }

    await logActivity(buildingId, {
      type: "building_updated",
      title: "تعديل بيانات المبنى",
      description: `تم تعديل بيانات "${updated.name}"`,
      icon: "Building2",
      color: "#F59E0B",
      metadata: { buildingId: updated.id },
    });

    return c.json({ message: "Building updated successfully", building: updated });
  } catch (err: any) {
    console.log("Error updating building:", err.message);
    return c.json({ error: `Error updating building: ${err.message}` }, 500);
  }
});

// Legacy seed endpoint (backward compat)
app.post("/make-server-86a3da15/building/seed", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) {
      return c.json({ error: "No active building. Register a building first." }, 400);
    }

    const existing = await kv.get(bKey(buildingId, "units"));
    if (existing && Array.isArray(existing) && existing.length > 0) {
      return c.json({ message: "Building already seeded", count: existing.length });
    }

    const buildingInfo = await kv.get(bKey(buildingId, "info"));
    if (buildingInfo) {
      const units = generateUnitsFromConfig(buildingInfo.id, buildingInfo.floors, buildingInfo.unitsPerFloor);
      await kv.set(bKey(buildingId, "units"), units);
      return c.json({ message: "Building seeded from config", count: units.length });
    }

    return c.json({ error: "No building config found" }, 404);
  } catch (err: any) {
    console.log("Error seeding building:", err.message);
    return c.json({ error: `Error seeding building: ${err.message}` }, 500);
  }
});

// Get building units
app.get("/make-server-86a3da15/building/units", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) {
      return c.json([]);
    }

    let units = await kv.get(bKey(buildingId, "units"));
    if (!units || !Array.isArray(units) || units.length === 0) {
      const buildingInfo = await kv.get(bKey(buildingId, "info"));
      if (buildingInfo) {
        units = generateUnitsFromConfig(buildingInfo.id, buildingInfo.floors, buildingInfo.unitsPerFloor, buildingInfo.floorConfigs);
        await kv.set(bKey(buildingId, "units"), units);
      } else {
        return c.json([]);
      }
    }
    return c.json(units);
  } catch (err: any) {
    console.log("Error fetching building units:", err.message);
    return c.json({ error: `Error fetching building units: ${err.message}` }, 500);
  }
});

// Update units for a specific floor
app.put("/make-server-86a3da15/building/units/floor/:floorNum", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 404);

    const floorNum = c.req.param("floorNum"); // e.g. "1", "2", etc.
    const body = await c.req.json();
    const { label, unitType, unitCount } = body;

    const unitsKey = bKey(buildingId, "units");
    const allUnits: any[] = await kv.get(unitsKey) || [];

    // Get units on this floor
    const floorUnits = allUnits.filter((u: any) => u.floor === floorNum);
    const otherUnits = allUnits.filter((u: any) => u.floor !== floorNum);
    const occupiedUnits = floorUnits.filter((u: any) => u.occupied);
    const unoccupiedUnits = floorUnits.filter((u: any) => !u.occupied);

    if (floorUnits.length === 0) {
      return c.json({ error: `لا توجد وحدات في الدور ${floorNum}` }, 404);
    }

    const currentType = floorUnits[0]?.unitType || "سكني";
    const newType = unitType || currentType;
    const newLabel = label !== undefined ? label : (floorUnits[0]?.floorLabel || floorNum);
    const targetCount = unitCount !== undefined ? Math.max(occupiedUnits.length, unitCount) : floorUnits.length;

    // Build updated units for this floor
    let updatedFloorUnits: any[] = [];

    // Keep all occupied units first (these can't be removed)
    for (const u of occupiedUnits) {
      const typeLabel = newType === "تجاري" ? "محل" : "شقة";
      updatedFloorUnits.push({
        ...u,
        label: `${typeLabel} ${u.unitCode}`,
        floorLabel: newLabel,
        unitType: newType,
      });
    }

    // Keep unoccupied units up to the target count
    const remainingSlots = targetCount - occupiedUnits.length;
    const keptUnoccupied = unoccupiedUnits.slice(0, remainingSlots);
    for (const u of keptUnoccupied) {
      const typeLabel = newType === "تجاري" ? "محل" : "شقة";
      updatedFloorUnits.push({
        ...u,
        label: `${typeLabel} ${u.unitCode}`,
        floorLabel: newLabel,
        unitType: newType,
      });
    }

    // If we need more units, create new ones
    const floorIdx = parseInt(floorNum);
    if (updatedFloorUnits.length < targetCount) {
      // Find the highest unit number on this floor
      const existingCodes = floorUnits.map((u: any) => parseInt(u.unitCode));
      let maxCode = Math.max(...existingCodes, floorIdx * 100);

      for (let i = updatedFloorUnits.length; i < targetCount; i++) {
        maxCode++;
        const code = `${maxCode}`;
        const typeLabel = newType === "تجاري" ? "محل" : "شقة";
        updatedFloorUnits.push({
          id: `unit-${code}`,
          label: `${typeLabel} ${code}`,
          unitCode: code,
          floor: floorNum,
          floorLabel: newLabel,
          unitType: newType,
          occupied: false,
          resident: undefined,
          ownerName: `مالك ${code}`,
        });
      }
    }

    // Sort by unit code
    updatedFloorUnits.sort((a: any, b: any) => parseInt(a.unitCode) - parseInt(b.unitCode));

    // Merge back
    const newAllUnits = [...otherUnits, ...updatedFloorUnits].sort(
      (a: any, b: any) => parseInt(a.floor) - parseInt(b.floor) || parseInt(a.unitCode) - parseInt(b.unitCode)
    );
    await kv.set(unitsKey, newAllUnits);

    // Also update building info (floorConfigs + totalUnits)
    const buildingInfo = await kv.get(bKey(buildingId, "info"));
    if (buildingInfo) {
      const floorConfigIdx = parseInt(floorNum) - 1;
      if (buildingInfo.floorConfigs && buildingInfo.floorConfigs[floorConfigIdx]) {
        buildingInfo.floorConfigs[floorConfigIdx] = {
          label: newLabel,
          unitCount: targetCount,
          unitType: newType,
        };
      }
      // Recalculate totals
      const floorCounts: Record<string, number> = {};
      for (const u of newAllUnits) {
        floorCounts[u.floor] = (floorCounts[u.floor] || 0) + 1;
      }
      buildingInfo.totalUnits = newAllUnits.length;
      buildingInfo.unitsPerFloor = [0, ...Object.keys(floorCounts).sort((a, b) => parseInt(a) - parseInt(b)).map(k => floorCounts[k])];
      buildingInfo.updatedAt = new Date().toISOString();
      await kv.set(bKey(buildingId, "info"), buildingInfo);
      cacheInvalidate(bKey(buildingId, "info"));
    }

    const removedCount = floorUnits.length - updatedFloorUnits.length;
    const addedCount = Math.max(0, targetCount - floorUnits.length);

    await logActivity(buildingId, {
      type: "floor_updated",
      title: "تعديل وحدات دور",
      description: `��م تعديل ${newLabel}: ${updatedFloorUnits.length} وحدة${removedCount > 0 ? ` (حُذفت ${removedCount})` : ""}${addedCount > 0 ? ` (أُضيفت ${addedCount})` : ""}`,
      icon: "Layers",
      color: "#0D9488",
      metadata: { floorNum, label: newLabel, unitCount: targetCount, unitType: newType },
    });

    return c.json({
      message: `تم تعديل ${newLabel} بنجاح`,
      units: newAllUnits,
      floorUnits: updatedFloorUnits,
      occupiedProtected: occupiedUnits.length,
    });
  } catch (err: any) {
    console.log("Error updating floor units:", err.message);
    return c.json({ error: `Error updating floor units: ${err.message}` }, 500);
  }
});

// ===================================================================
// Invoice Batches — CRUD (Building-scoped)
// ===================================================================

app.get("/make-server-86a3da15/invoices", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const batches = await kv.get(bKey(buildingId, "invoice_batches"));
    return c.json(batches || []);
  } catch (err: any) {
    console.log("Error fetching invoices:", err.message);
    return c.json({ error: `Error fetching invoices: ${err.message}` }, 500);
  }
});

app.post("/make-server-86a3da15/invoices", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const batch = await c.req.json();
    if (!batch || !batch.id || !batch.description) {
      return c.json({ error: "Missing required fields: id, description" }, 400);
    }
    const key = bKey(buildingId, "invoice_batches");
    const existing = await kv.get(key);
    const batches = Array.isArray(existing) ? existing : [];
    batches.unshift(batch);
    await kv.set(key, batches);
    await logActivity(buildingId, {
      type: "invoice_created",
      title: "إنشاء فاتورة جديدة",
      description: `تم إنشاء فاتورة "${batch.description}" — ${batch.invoices?.length || 0} وحدة`,
      icon: "FilePlus",
      color: "#0D9488",
      metadata: { batchId: batch.id, count: batch.invoices?.length || 0 },
    });

    // Auto-pay invoices from resident credit balances
    if (batch.invoices && batch.invoices.length > 0) {
      const jKey = bKey(buildingId, "join_requests");
      const joinRequests = await kv.get(jKey) || [];
      let batchModified = false;
      let totalAutoPaid = 0;
      const now = new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });
      const txKey = bKey(buildingId, "credit_transactions");
      const txs = await kv.get(txKey) || [];

      for (let i = 0; i < batch.invoices.length; i++) {
        const inv = batch.invoices[i];
        if (inv.status !== "pending") continue;
        // Find resident by unit code
        const resIdx = joinRequests.findIndex((r: any) => r.status === "approved" && r.unitCode === inv.unit && (r.creditBalance || 0) >= inv.amount);
        if (resIdx === -1) continue;

        const resident = joinRequests[resIdx];
        // Auto-pay
        batch.invoices[i] = { ...inv, status: "paid", method: "رصيد مالي (دفع تلقائي)", paidDate: now };
        joinRequests[resIdx] = { ...resident, creditBalance: (resident.creditBalance || 0) - inv.amount };
        batchModified = true;
        totalAutoPaid++;

        txs.unshift({
          id: crypto.randomUUID(),
          residentId: resident.id,
          residentName: resident.name,
          unitCode: resident.unitCode,
          amount: -inv.amount,
          balanceAfter: joinRequests[resIdx].creditBalance,
          note: `دفع تلقائي — ${batch.description}`,
          createdAt: new Date().toISOString(),
        });
      }

      if (batchModified) {
        // Update batches with auto-paid invoices
        const freshBatches = await kv.get(key) || [];
        const bIdx = freshBatches.findIndex((b: any) => b.id === batch.id);
        if (bIdx !== -1) {
          freshBatches[bIdx] = batch;
          await kv.set(key, freshBatches);
        }
        await kv.set(jKey, joinRequests);
        await kv.set(txKey, txs);
        await logActivity(buildingId, {
          type: "credit_auto_pay",
          title: "دفع تلقائي من أرصدة المُ��اك",
          description: `تم سداد ${totalAutoPaid} فاتورة تلقائياً من أرصدة المُلاك عند إنشاء "${batch.description}"`,
          icon: "CheckCircle",
          color: "#0D9488",
          metadata: { batchId: batch.id, autoPaidCount: totalAutoPaid },
        });
      }
    }

    // Notify all residents about the new invoice
    await pushNotificationToAll(buildingId, {
      type: "invoice",
      title: "فاتورة جديدة",
      body: `تم إصدار فاتورة "${batch.description}" — ${batch.invoices?.length || 0} وحدة`,
      icon: "FileText",
      color: "#0D9488",
      metadata: { batchId: batch.id },
    });

    return c.json({ message: "Invoice batch created successfully" });
  } catch (err: any) {
    console.log("Error creating invoice batch:", err.message);
    return c.json({ error: `Error creating invoice batch: ${err.message}` }, 500);
  }
});

app.put("/make-server-86a3da15/invoices/:batchId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const batchId = c.req.param("batchId");
    const updatedBatch = await c.req.json();
    const key = bKey(buildingId, "invoice_batches");
    const existing = await kv.get(key);
    const batches = Array.isArray(existing) ? existing : [];
    const idx = batches.findIndex((b: any) => b.id === batchId);
    if (idx === -1) {
      return c.json({ error: `Invoice batch not found: ${batchId}` }, 404);
    }
    batches[idx] = { ...batches[idx], ...updatedBatch };
    await kv.set(key, batches);
    await logActivity(buildingId, {
      type: "invoice_updated",
      title: "تعديل فاتورة",
      description: `تم تعديل فاتورة "${updatedBatch.description || batches[idx].description}"`,
      icon: "FileEdit",
      color: "#F59E0B",
      metadata: { batchId },
    });
    return c.json({ message: "Invoice batch updated successfully" });
  } catch (err: any) {
    console.log("Error updating invoice batch:", err.message);
    return c.json({ error: `Error updating invoice batch: ${err.message}` }, 500);
  }
});

app.delete("/make-server-86a3da15/invoices/:batchId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const batchId = c.req.param("batchId");
    const key = bKey(buildingId, "invoice_batches");
    const existing = await kv.get(key);
    const batches = Array.isArray(existing) ? existing : [];
    const deletedBatch = batches.find((b: any) => b.id === batchId);
    const filtered = batches.filter((b: any) => b.id !== batchId);
    if (filtered.length === batches.length) {
      return c.json({ error: `Invoice batch not found: ${batchId}` }, 404);
    }
    await kv.set(key, filtered);
    await logActivity(buildingId, {
      type: "invoice_deleted",
      title: "حذف فاتورة",
      description: `تم حذف فاتورة: ${deletedBatch?.description || batchId}`,
      icon: "trash",
      color: "#ef4444",
      metadata: { batchId },
    });
    return c.json({ message: "Invoice batch deleted successfully" });
  } catch (err: any) {
    console.log("Error deleting invoice batch:", err.message);
    return c.json({ error: `Error deleting invoice batch: ${err.message}` }, 500);
  }
});

// ===================================================================
// Invoice Batch — Stop / Reactivate recurring batches
// ===================================================================

app.put("/make-server-86a3da15/invoices/:batchId/stop", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const batchId = c.req.param("batchId");
    const key = bKey(buildingId, "invoice_batches");
    const existing = await kv.get(key);
    const batches = Array.isArray(existing) ? existing : [];
    const idx = batches.findIndex((b: any) => b.id === batchId);
    if (idx === -1) return c.json({ error: `Invoice batch not found: ${batchId}` }, 404);
    if (batches[idx].type !== "دائم") return c.json({ error: "Only recurring invoice batches can be stopped" }, 400);

    batches[idx].stoppedAt = new Date().toISOString();
    await kv.set(key, batches);

    await logActivity(buildingId, {
      type: "invoice_stopped",
      title: "إيقاف فاتورة دائمة",
      description: `تم إيقاف "${batches[idx].description}"`,
      icon: "CircleStop",
      color: "#ef4444",
      metadata: { batchId },
    });

    return c.json({ message: "Recurring invoice batch stopped", batch: batches[idx] });
  } catch (err: any) {
    console.log("Error stopping invoice batch:", err.message);
    return c.json({ error: `Error stopping invoice batch: ${err.message}` }, 500);
  }
});

app.put("/make-server-86a3da15/invoices/:batchId/reactivate", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const batchId = c.req.param("batchId");
    const key = bKey(buildingId, "invoice_batches");
    const existing = await kv.get(key);
    const batches = Array.isArray(existing) ? existing : [];
    const idx = batches.findIndex((b: any) => b.id === batchId);
    if (idx === -1) return c.json({ error: `Invoice batch not found: ${batchId}` }, 404);

    delete batches[idx].stoppedAt;
    await kv.set(key, batches);

    await logActivity(buildingId, {
      type: "invoice_reactivated",
      title: "إعادة تفعيل فاتورة دائمة",
      description: `تم إعادة تفعيل "${batches[idx].description}"`,
      icon: "RotateCcw",
      color: "#0D9488",
      metadata: { batchId },
    });

    return c.json({ message: "Recurring invoice batch reactivated", batch: batches[idx] });
  } catch (err: any) {
    console.log("Error reactivating invoice batch:", err.message);
    return c.json({ error: `Error reactivating invoice batch: ${err.message}` }, 500);
  }
});

// ===================================================================
// Auto-Create Recurring Invoices for Current Month
// ===================================================================

app.post("/make-server-86a3da15/invoices/process-recurring", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth(); // 0-based
    const monthKey = `${year}-${String(month + 1).padStart(2, "0")}`;
    const processedKey = bKey(buildingId, `recurring_processed:${monthKey}`);

    // Check if already processed this month
    const alreadyProcessed = await kv.get(processedKey);
    if (alreadyProcessed) {
      return c.json({ message: "Already processed for this month", monthKey, created: 0 });
    }

    const batchesKey = bKey(buildingId, "invoice_batches");
    const batches = await kv.get(batchesKey) || [];

    // Find active recurring batches (type === "دائم" && no stoppedAt)
    const recurringBatches = batches.filter((b: any) => b.type === "دائم" && !b.stoppedAt);
    if (recurringBatches.length === 0) {
      await kv.set(processedKey, { processedAt: now.toISOString(), created: 0 });
      return c.json({ message: "No active recurring invoices", monthKey, created: 0 });
    }

    // Get current units for occupied status
    const units = await kv.get(bKey(buildingId, "units")) || [];
    const unitMap: Record<string, any> = {};
    for (const u of units) unitMap[u.code] = u;

    // Get join requests for resident names and credit balances
    const jKey = bKey(buildingId, "join_requests");
    const joinRequests = await kv.get(jKey) || [];

    const monthName = MONTH_NAMES_AR[month];
    const firstOfMonth = `${year}-${String(month + 1).padStart(2, "0")}-01`;
    const lastDay = new Date(year, month + 1, 0).getDate();
    const lastOfMonth = `${year}-${String(month + 1).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;

    const newBatches: any[] = [];
    let totalCreated = 0;
    let totalInvoices = 0;

    // Credit auto-pay tracking
    const txKey = bKey(buildingId, "credit_transactions");
    const txs = await kv.get(txKey) || [];
    let joinRequestsModified = false;
    let totalAutoPaid = 0;

    for (const recurring of recurringBatches) {
      const newId = crypto.randomUUID();
      const desc = `${recurring.description} — ${monthName} ${year}`;

      // Create fresh invoices for each unit from the original batch
      const newInvoices: any[] = [];
      for (const origInv of (recurring.invoices || [])) {
        const unit = unitMap[origInv.unit];
        const isOccupied = unit ? !!unit.occupied : origInv.occupied;
        const resident = joinRequests.find((r: any) => r.status === "approved" && r.unitCode === origInv.unit);
        const residentName = resident?.name || origInv.resident || "—";

        newInvoices.push({
          id: crypto.randomUUID(),
          resident: residentName,
          unit: origInv.unit,
          floor: origInv.floor || (unit?.floor || ""),
          amount: Number(origInv.amount) || 0,
          status: "pending",
          method: "",
          occupied: isOccupied,
          ownerName: origInv.ownerName || residentName,
        });
      }

      const newBatch = {
        id: newId,
        description: desc,
        scope: recurring.scope || "عام",
        type: "مؤقت",
        date: firstOfMonth,
        dueDate: lastOfMonth,
        createdAt: now.toISOString(),
        sourceRecurringId: recurring.id,
        autoGenerated: true,
        invoices: newInvoices,
      };

      // Auto-pay from credit balances
      for (let i = 0; i < newBatch.invoices.length; i++) {
        const inv = newBatch.invoices[i];
        if (inv.status !== "pending") continue;
        const resIdx = joinRequests.findIndex((r: any) => r.status === "approved" && r.unitCode === inv.unit && (r.creditBalance || 0) >= inv.amount);
        if (resIdx === -1) continue;

        const res = joinRequests[resIdx];
        const paidDateStr = now.toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });
        newBatch.invoices[i] = { ...inv, status: "paid", method: "رصيد مالي (دفع تلقائي)", paidDate: paidDateStr };
        joinRequests[resIdx] = { ...res, creditBalance: (res.creditBalance || 0) - inv.amount };
        joinRequestsModified = true;
        totalAutoPaid++;

        txs.unshift({
          id: crypto.randomUUID(),
          residentId: res.id,
          residentName: res.name,
          unitCode: res.unitCode,
          amount: -inv.amount,
          balanceAfter: joinRequests[resIdx].creditBalance,
          note: `دفع تلقائي — ${desc}`,
          createdAt: now.toISOString(),
        });
      }

      newBatches.push(newBatch);
      totalCreated++;
      totalInvoices += newInvoices.length;
    }

    // Prepend new batches to existing ones
    const updatedBatches = [...newBatches, ...batches];
    await kv.set(batchesKey, updatedBatches);

    if (joinRequestsModified) {
      await kv.set(jKey, joinRequests);
      await kv.set(txKey, txs);
    }

    await kv.set(processedKey, { processedAt: now.toISOString(), created: totalCreated, invoices: totalInvoices, autoPaid: totalAutoPaid });

    await logActivity(buildingId, {
      type: "invoice_created",
      title: "إنشاء فواتير دائمة تلقائياً",
      description: `تم إنشاء ${totalCreated} فاتورة دائمة لشهر ${monthName} ${year} — ${totalInvoices} وحدة${totalAutoPaid > 0 ? ` (${totalAutoPaid} مدفوعة تلقائياً)` : ""}`,
      icon: "FilePlus",
      color: "#0D9488",
      metadata: { monthKey, totalCreated, totalInvoices, totalAutoPaid },
    });

    await pushNotificationToAll(buildingId, {
      type: "invoice",
      title: `فواتير ${monthName} ${year}`,
      body: `تم إصدار ${totalCreated} فاتورة دائمة لشهر ${monthName} — ${totalInvoices} وحدة`,
      icon: "FileText",
      color: "#0D9488",
      metadata: { monthKey },
    });

    return c.json({ message: `Created ${totalCreated} recurring invoices for ${monthKey}`, monthKey, created: totalCreated, invoices: totalInvoices, autoPaid: totalAutoPaid });
  } catch (err: any) {
    console.log("Error processing recurring invoices:", err.message);
    return c.json({ error: `Error processing recurring invoices: ${err.message}` }, 500);
  }
});

// ===================================================================
// Invoice Payment — Mark as paid by treasurer (Building-scoped)
// ===================================================================

app.put("/make-server-86a3da15/invoices/:batchId/pay/:invoiceId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const batchId = c.req.param("batchId");
    const invoiceId = c.req.param("invoiceId");
    const { method } = await c.req.json();

    const invoiceKey = bKey(buildingId, "invoice_batches");
    const existing = await kv.get(invoiceKey);
    const batches = Array.isArray(existing) ? existing : [];
    const batchIdx = batches.findIndex((b: any) => b.id === batchId);
    if (batchIdx === -1) {
      return c.json({ error: `Invoice batch not found: ${batchId}` }, 404);
    }

    const invoiceIdx = batches[batchIdx].invoices.findIndex((inv: any) => inv.id === invoiceId);
    if (invoiceIdx === -1) {
      return c.json({ error: `Invoice not found: ${invoiceId} in batch ${batchId}` }, 404);
    }

    const now = new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });
    batches[batchIdx].invoices[invoiceIdx] = {
      ...batches[batchIdx].invoices[invoiceIdx],
      status: "paid",
      method: method || "كاش",
      paidDate: now,
    };

    // Remove from cash_collections if applicable
    const collKey = bKey(buildingId, "cash_collections");
    const collections = await kv.get(collKey) || [];
    const updatedCollections = collections.filter(
      (col: any) => !(col.batchId === batchId && col.invoiceId === invoiceId)
    );

    await kv.set(invoiceKey, batches);
    await kv.set(collKey, updatedCollections);
    await logActivity(buildingId, {
      type: "invoice_paid",
      title: "تم تحصيل فاتورة",
      description: `${batches[batchIdx].invoices[invoiceIdx].resident} (شقة ${batches[batchIdx].invoices[invoiceIdx].unit}) — ${batches[batchIdx].description} — ${batches[batchIdx].invoices[invoiceIdx].amount} ج.م`,
      icon: "CheckCircle",
      color: "#0D9488",
      metadata: { batchId, invoiceId, unit: batches[batchIdx].invoices[invoiceIdx].unit, amount: batches[batchIdx].invoices[invoiceIdx].amount },
    });
    // Notify the resident that their invoice was confirmed
    const paidInv = batches[batchIdx].invoices[invoiceIdx];
    try {
      const joinRequests = await kv.get(bKey(buildingId, "join_requests")) || [];
      const residentReq = (Array.isArray(joinRequests) ? joinRequests : []).find(
        (r: any) => r.status === "approved" && r.unitCode === paidInv.unit
      );
      if (residentReq?.phone) {
        await pushNotification(buildingId, residentReq.phone, {
          type: "invoice_paid",
          title: "تم تأكيد سداد فاتورتك",
          body: `تم تأكيد سداد فاتورة "${batches[batchIdx].description}" بمبلغ ${paidInv.amount.toLocaleString("en-US")} ج.م`,
          icon: "CheckCircle",
          color: "#22c55e",
          metadata: { batchId, invoiceId },
        });
      }
    } catch (notifErr: any) {
      console.log("Error sending invoice notification:", notifErr.message);
    }
    return c.json({ message: "Invoice marked as paid" });
  } catch (err: any) {
    console.log("Error marking invoice as paid:", err.message);
    return c.json({ error: `Error marking invoice as paid: ${err.message}` }, 500);
  }
});

// ===================================================================
// Cash Payment Flow — Resident → Security → Treasurer (Building-scoped)
// ===================================================================

app.post("/make-server-86a3da15/resident/pay-cash", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const { batchId, invoiceId, residentName, unitCode, amount } = await c.req.json();
    if (!batchId || !invoiceId) {
      return c.json({ error: "Missing required fields: batchId, invoiceId" }, 400);
    }

    const invoiceKey = bKey(buildingId, "invoice_batches");
    const existing = await kv.get(invoiceKey);
    const batches = Array.isArray(existing) ? existing : [];
    const batchIdx = batches.findIndex((b: any) => b.id === batchId);
    if (batchIdx === -1) {
      return c.json({ error: `Invoice batch not found: ${batchId}` }, 404);
    }

    const invoiceIdx = batches[batchIdx].invoices.findIndex((inv: any) => inv.id === invoiceId);
    if (invoiceIdx === -1) {
      return c.json({ error: `Invoice not found: ${invoiceId}` }, 404);
    }

    const now = new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" });

    batches[batchIdx].invoices[invoiceIdx] = {
      ...batches[batchIdx].invoices[invoiceIdx],
      status: "awaiting_collection",
      method: "كاش عبر الأمن",
    };

    const collKey = bKey(buildingId, "cash_collections");
    const collections = await kv.get(collKey) || [];
    collections.unshift({
      id: `col-${Date.now()}`,
      batchId,
      invoiceId,
      batchDescription: batches[batchIdx].description,
      residentName: residentName || batches[batchIdx].invoices[invoiceIdx].resident,
      unitCode: unitCode || batches[batchIdx].invoices[invoiceIdx].unit,
      amount: amount || batches[batchIdx].invoices[invoiceIdx].amount,
      date: now,
      status: "pending",
    });

    await kv.set(invoiceKey, batches);
    await kv.set(collKey, collections);
    await logActivity(buildingId, {
      type: "cash_requested",
      title: "طلب دفع كاش",
      description: `${residentName || batches[batchIdx].invoices[invoiceIdx].resident} (شقة ${unitCode || batches[batchIdx].invoices[invoiceIdx].unit}) سلّم المبلغ للأمن — ${batches[batchIdx].description}`,
      icon: "Banknote",
      color: "#6366f1",
      metadata: { batchId, invoiceId, unit: unitCode || batches[batchIdx].invoices[invoiceIdx].unit },
    });

    return c.json({ message: "Cash payment request submitted — treasurer notified" });
  } catch (err: any) {
    console.log("Error requesting cash payment:", err.message);
    return c.json({ error: `Error requesting cash payment: ${err.message}` }, 500);
  }
});

// Get pending cash collections (for treasurer dashboard)
app.get("/make-server-86a3da15/invoices/cash-collections", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const collections = await kv.get(bKey(buildingId, "cash_collections")) || [];
    return c.json(collections);
  } catch (err: any) {
    console.log("Error fetching cash collections:", err.message);
    return c.json({ error: `Error fetching cash collections: ${err.message}` }, 500);
  }
});

// ===================================================================
// Resident Invoices — filter by unit code (Building-scoped)
// ===================================================================

app.get("/make-server-86a3da15/resident/invoices", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);

    const unitCode = c.req.query("unit");
    if (!unitCode) {
      return c.json({ error: "Missing required query parameter: unit" }, 400);
    }

    const existing = await kv.get(bKey(buildingId, "invoice_batches"));
    const batches = Array.isArray(existing) ? existing : [];

    const result: any[] = [];
    for (const batch of batches) {
      for (const inv of batch.invoices) {
        if (inv.unit === unitCode) {
          // Hide paid one-time (مؤقت) invoices from resident view
          if (batch.type === "مؤقت" && inv.status === "paid") continue;
          result.push({
            id: inv.id,
            batchId: batch.id,
            description: batch.description,
            amount: inv.amount,
            status: inv.status,
            dueDate: batch.dueDate,
            paidDate: inv.paidDate || (inv.status === "paid" ? batch.date : undefined),
            category: batch.scope === "عام" ? "صيانة عامة" : "مخصص",
            method: inv.method,
            type: batch.type || "مؤقت",
          });
        }
      }
    }

    return c.json(result);
  } catch (err: any) {
    console.log("Error fetching resident invoices:", err.message);
    return c.json({ error: `Error fetching resident invoices: ${err.message}` }, 500);
  }
});

// ===================================================================
// Overview Stats — Computed from invoice data (Building-scoped)
// ===================================================================

app.get("/make-server-86a3da15/overview-stats", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) {
      return c.json({
        revenue: 0, expenses: 0, balance: 0,
        initialBalance: 0, previousDebts: 0, previousRevenues: 0,
        activeAdvancesTotal: 0, activeAdvancesCount: 0, returnedAdvancesTotal: 0,
        pendingCount: 0, pendingAmount: 0,
        totalInvoices: 0, paidCount: 0, overdueCount: 0,
        awaitingCount: 0, residentsCount: 0, occupiedUnits: 0, totalUnits: 0,
        recurringExpensesTotal: 0, recurringExpensesCount: 0,
        recurringRevenueTotal: 0, recurringRevenueCount: 0,
      });
    }

    const periodType = c.req.query("period") || "monthly"; // monthly | quarterly | yearly
    const year = parseInt(c.req.query("year") || `${new Date().getFullYear()}`);
    const month = parseInt(c.req.query("month") || `${new Date().getMonth() + 1}`);
    const quarter = parseInt(c.req.query("quarter") || `${Math.ceil((new Date().getMonth() + 1) / 3)}`);

    // Helper: check if a date string falls within the selected period
    function isInPeriod(dateStr: string): boolean {
      if (!dateStr) return false;
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return false;
      const dYear = d.getFullYear();
      const dMonth = d.getMonth() + 1;
      if (periodType === "yearly") return dYear === year;
      if (periodType === "quarterly") {
        const dQuarter = Math.ceil(dMonth / 3);
        return dYear === year && dQuarter === quarter;
      }
      // monthly
      return dYear === year && dMonth === month;
    }

    // Helper: get the start/end dates of the selected period
    function getPeriodStart(): Date {
      if (periodType === "yearly") return new Date(year, 0, 1);
      if (periodType === "quarterly") return new Date(year, (quarter - 1) * 3, 1);
      return new Date(year, month - 1, 1);
    }
    function getPeriodEnd(): Date {
      if (periodType === "yearly") return new Date(year, 11, 31, 23, 59, 59);
      if (periodType === "quarterly") return new Date(year, quarter * 3, 0, 23, 59, 59);
      return new Date(year, month, 0, 23, 59, 59);
    }

    // Helper: check if a recurring (دائم) expense is active during the selected period
    function isRecurringInPeriod(exp: any): boolean {
      let startDate: Date | null = null;
      if (exp.createdAt) { const d = new Date(exp.createdAt); if (!isNaN(d.getTime())) startDate = d; }
      if (!startDate && exp.date) { const d = new Date(exp.date); if (!isNaN(d.getTime())) startDate = d; }
      if (!startDate) return false;
      const periodStart = getPeriodStart();
      const periodEnd = getPeriodEnd();
      // Must have been created on or before this period ends
      if (startDate > periodEnd) return false;
      // If stopped, check if it was stopped before this period started
      const stoppedStr = exp.stoppedAt || exp.endDate;
      if (stoppedStr) {
        const stoppedDate = new Date(stoppedStr);
        if (!isNaN(stoppedDate.getTime()) && stoppedDate < periodStart) return false;
      }
      return true;
    }

    // Load invoices (use cache for better performance)
    const batches = await cachedGet(bKey(buildingId, "invoice_batches"), 20_000) || [];

    let revenue = 0;
    let internalRevenue = 0;
    let pendingAmount = 0;
    let pendingCount = 0;
    let paidCount = 0;
    let overdueCount = 0;
    let awaitingCount = 0;
    let totalInvoices = 0;

    for (const batch of batches) {
      // Check if this batch falls in the selected period
      const isRecurring = batch.type === "دائم";
      let batchInPeriod = false;
      if (isRecurring) {
        batchInPeriod = isRecurringInPeriod(batch);
      } else {
        batchInPeriod = isInPeriod(batch.date) || isInPeriod(batch.dueDate);
      }
      if (!batchInPeriod) continue;

      for (const inv of (batch.invoices || [])) {
        totalInvoices++;
        const amount = Number(inv.amount) || 0;

        if (inv.status === "paid") {
          paidCount++;
          revenue += amount;
          internalRevenue += amount;
        } else if (inv.status === "overdue") {
          overdueCount++;
          pendingAmount += amount;
          pendingCount++;
        } else if (inv.status === "awaiting_collection") {
          awaitingCount++;
          pendingAmount += amount;
          pendingCount++;
        } else {
          // pending
          pendingCount++;
          pendingAmount += amount;
        }
      }
    }

    // Load expenses — handle recurring (دائم) vs one-time (مؤقت) expenses
    const expensesData = await cachedGet(bKey(buildingId, "expenses"), 20_000) || [];
    let expenses = 0;
    let recurringExpensesTotal = 0;
    let recurringExpensesCount = 0;
    for (const exp of expensesData) {
      const amount = Number(exp.amount) || 0;
      if (exp.type === "دائم") {
        // Recurring: count if the expense was active during this period
        if (isRecurringInPeriod(exp)) {
          expenses += amount;
          recurringExpensesTotal += amount;
          recurringExpensesCount++;
        }
      } else {
        // One-time (مؤقت): only count if created in this period
        if (isInPeriod(exp.createdAt) || isInPeriod(exp.date)) {
          expenses += amount;
        }
      }
    }

    // Load revenues — handle recurring (دائم) vs one-time (مؤقت) revenues
    const revenuesData = await cachedGet(bKey(buildingId, "revenues"), 20_000) || [];
    let otherRevenue = 0;
    let recurringRevenueTotal = 0;
    let recurringRevenueCount = 0;
    for (const rev of revenuesData) {
      const amount = Number(rev.amount) || 0;
      if (rev.type === "دائم") {
        if (isRecurringInPeriod(rev)) {
          otherRevenue += amount;
          recurringRevenueTotal += amount;
          recurringRevenueCount++;
        }
      } else {
        if (isInPeriod(rev.createdAt) || isInPeriod(rev.date)) {
          otherRevenue += amount;
        }
      }
    }
    revenue += otherRevenue;
    const externalRevenue = otherRevenue;

    // Load advances (active + overdue reduce available cash)
    const advancesData = await cachedGet(bKey(buildingId, "advances"), 20_000) || [];
    let activeAdvancesTotal = 0;
    let returnedAdvancesTotal = 0;
    let activeAdvancesCount = 0;
    for (const adv of advancesData) {
      const amt = Number(adv.amount) || 0;
      if (adv.status === "active" || adv.status === "overdue") {
        activeAdvancesTotal += amt;
        activeAdvancesCount++;
      } else if (adv.status === "returned") {
        returnedAdvancesTotal += amt;
      }
    }

    // Load building info for initialBalance and previousDebts
    const buildingInfo = await cachedGet(bKey(buildingId, "info"), 60_000);
    const initialBalance = Number(buildingInfo?.initialBalance) || 0;
    const previousDebts = Number(buildingInfo?.previousDebts) || 0;
    const previousRevenues = Number(buildingInfo?.previousRevenues) || 0;
    // Balance = initial + previousRevenues + revenue - expenses - outstanding advances
    const balance = initialBalance + previousRevenues + revenue - expenses - activeAdvancesTotal;

    // Units and residents stats
    const units = await cachedGet(bKey(buildingId, "units"), 30_000) || [];
    const totalUnits = units.length;
    const occupiedUnits = units.filter((u: any) => u.occupied).length;

    const joinRequests = await cachedGet(bKey(buildingId, "join_requests"), 15_000) || [];
    const residentsCount = joinRequests.filter((r: any) => r.status === "approved").length;

    return c.json({
      revenue,
      internalRevenue,
      externalRevenue,
      expenses,
      balance,
      initialBalance,
      previousDebts,
      previousRevenues,
      activeAdvancesTotal,
      activeAdvancesCount,
      returnedAdvancesTotal,
      pendingCount,
      pendingAmount,
      totalInvoices,
      paidCount,
      overdueCount,
      awaitingCount,
      residentsCount,
      occupiedUnits,
      totalUnits,
      recurringExpensesTotal,
      recurringExpensesCount,
      recurringRevenueTotal,
      recurringRevenueCount,
    });
  } catch (err: any) {
    console.log("Error computing overview stats:", err.message);
    return c.json({ error: `Error computing overview stats: ${err.message}` }, 500);
  }
});

// ===================================================================
// List all buildings (for switching/management)
// ===================================================================

app.get("/make-server-86a3da15/buildings", async (c) => {
  try {
    const list = await kv.get("buildings_list") || [];
    const activeId = await getActiveBuildingId();
    return c.json({ buildings: list, activeId });
  } catch (err: any) {
    console.log("Error fetching buildings list:", err.message);
    return c.json({ error: `Error fetching buildings list: ${err.message}` }, 500);
  }
});

// Switch active building
app.put("/make-server-86a3da15/buildings/switch", async (c) => {
  try {
    const { buildingId } = await c.req.json();
    if (!buildingId) {
      return c.json({ error: "Missing buildingId" }, 400);
    }
    const info = await kv.get(bKey(buildingId, "info"));
    if (!info) {
      return c.json({ error: `Building not found: ${buildingId}` }, 404);
    }
    await kv.set("building:active", buildingId);
    return c.json({ message: "Switched active building", building: info });
  } catch (err: any) {
    console.log("Error switching building:", err.message);
    return c.json({ error: `Error switching building: ${err.message}` }, 500);
  }
});

// Delete a building and all its data
app.delete("/make-server-86a3da15/buildings/:buildingId", async (c) => {
  try {
    const buildingId = c.req.param("buildingId");

    // Remove all building-scoped data
    await kv.del(bKey(buildingId, "info"));
    await kv.del(bKey(buildingId, "units"));
    await kv.del(bKey(buildingId, "invoice_batches"));
    await kv.del(bKey(buildingId, "cash_collections"));
    await kv.del(bKey(buildingId, "activity_log"));
    await kv.del(bKey(buildingId, "join_requests"));
    await kv.del(bKey(buildingId, "advances"));
    await kv.del(bKey(buildingId, "expenses"));
    await kv.del(bKey(buildingId, "revenues"));
    await kv.del(bKey(buildingId, "announcements"));
    await kv.del(bKey(buildingId, "directory"));
    await kv.del(bKey(buildingId, "events"));
    await kv.del(bKey(buildingId, "donations"));
    await kv.del(bKey(buildingId, "donation_cash_requests"));
    await kv.del(bKey(buildingId, "polls"));
    await kv.del(bKey(buildingId, "chat_messages"));

    // Remove from buildings list
    const list = await kv.get("buildings_list") || [];
    const updated = list.filter((b: any) => b.id !== buildingId);
    await kv.set("buildings_list", updated);

    // If this was the active building, clear active
    const activeId = await getActiveBuildingId();
    if (activeId === buildingId) {
      if (updated.length > 0) {
        await kv.set("building:active", updated[0].id);
      } else {
        await kv.del("building:active");
      }
    }

    return c.json({ message: "Building deleted successfully" });
  } catch (err: any) {
    console.log("Error deleting building:", err.message);
    return c.json({ error: `Error deleting building: ${err.message}` }, 500);
  }
});

// ===================================================================
// Join Requests — Owner registration flow (Building-scoped)
// ===================================================================

// Public: Get building info by slug (for join page)
app.get("/make-server-86a3da15/building/by-slug/:slug", async (c) => {
  try {
    const slug = c.req.param("slug");
    const list = await kv.get("buildings_list") || [];
    const entry = list.find((b: any) => b.slug === slug);
    if (!entry) {
      return c.json({ found: false, error: "Building not found for this invitation link" }, 404);
    }
    const building = await kv.get(bKey(entry.id, "info"));
    if (!building) {
      return c.json({ found: false, error: "Building data not found" }, 404);
    }
    // Get units for floor/unit selection
    const units = await kv.get(bKey(entry.id, "units")) || [];
    // Count approved residents
    const joinRequests = await kv.get(bKey(entry.id, "join_requests")) || [];
    const approvedCount = joinRequests.filter((r: any) => r.status === "approved").length;

    return c.json({
      found: true,
      building: {
        id: building.id,
        name: building.name,
        address: building.address,
        city: building.city,
        floors: building.floors,
        totalUnits: building.totalUnits,
        admin: {
          name: building.admin?.name || "",
          role: building.admin?.role || "رئيس الاتحاد",
        },
        approvedCount,
      },
      units: units.map((u: any) => ({
        id: u.id,
        unitCode: u.unitCode,
        floor: u.floor,
        floorLabel: u.floorLabel || u.floor,
        label: u.label,
        unitType: u.unitType,
        occupied: u.occupied,
      })),
    });
  } catch (err: any) {
    console.log("Error fetching building by slug:", err.message);
    return c.json({ error: `Error fetching building by slug: ${err.message}` }, 500);
  }
});

// Public: Submit a join request
app.post("/make-server-86a3da15/join-requests", async (c) => {
  try {
    const body = await c.req.json();
    const { buildingId, title, name, phone, password, unitCode, floor, type } = body;

    if (!buildingId || !name || !phone || !unitCode || !floor) {
      return c.json({ error: "Missing required fields: buildingId, name, phone, unitCode, floor" }, 400);
    }

    if (!password) {
      return c.json({ error: "Missing required field: password — مطلوب كلمة مرور لإنشاء حسابك" }, 400);
    }

    if (password.length < 6) {
      return c.json({ error: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" }, 400);
    }

    const buildingInfo = await kv.get(bKey(buildingId, "info"));
    if (!buildingInfo) {
      return c.json({ error: "Building not found" }, 404);
    }

    // Check if phone already has a pending/approved request for this building
    const key = bKey(buildingId, "join_requests");
    const existing = await kv.get(key) || [];
    const duplicate = existing.find((r: any) =>
      r.phone === phone && (r.status === "pending" || r.status === "approved")
    );
    if (duplicate) {
      const msg = duplicate.status === "approved"
        ? "هذا الرقم مسجل بالفعل في المبنى"
        : "يوجد طلب انضمام معلق لهذا الرقم بالفعل";
      return c.json({ error: msg }, 409);
    }

    // Check if phone is already registered in ANY other building (global check)
    const normalizedPhone = phone.replace(/\s/g, "");
    const globalPhoneEntry = await kv.get(`platform:phone:${normalizedPhone}`);
    if (globalPhoneEntry && globalPhoneEntry.buildingId && globalPhoneEntry.buildingId !== buildingId) {
      return c.json({ error: `رقم الجوال مسجل بالفعل في برج "${globalPhoneEntry.buildingName || "آخر"}". لا يمكن التسجيل في أكثر من برج بنفس الرقم.` }, 409);
    }

    // Check if unit is already taken by an approved request
    const unitTaken = existing.find((r: any) =>
      r.unitCode === unitCode && r.status === "approved"
    );
    if (unitTaken) {
      return c.json({ error: "هذه الوحدة مسجلة بالفعل لساكن آخر" }, 409);
    }

    // Derive a fake email from the phone number for Supabase Auth
    const fakeEmail = `${phone.replace(/\s/g, "")}@mollak.app`;

    const now = new Date().toISOString();
    const request = {
      id: `jr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      buildingId,
      title: title || "",
      name,
      phone,
      fakeEmail,
      // Store password temporarily (server-side only) — will be used to create auth user on approval
      _tempPassword: password,
      unitCode,
      floor,
      type: type || "مالك",
      status: "pending",
      createdAt: now,
      updatedAt: now,
    };

    existing.unshift(request);
    await kv.set(key, existing);

    await logActivity(buildingId, {
      type: "join_request",
      title: "طلب انضمام جديد",
      description: `${name} — شقة ${unitCode} (الدور ${floor}) — ${type || "مالك"}`,
      icon: "UserPlus",
      color: "#F59E0B",
      metadata: { requestId: request.id, phone, unitCode },
    });

    return c.json({ message: "Join request submitted successfully", request: { ...request, _tempPassword: undefined } });
  } catch (err: any) {
    console.log("Error submitting join request:", err.message);
    return c.json({ error: `Error submitting join request: ${err.message}` }, 500);
  }
});

// Dashboard: Get all join requests for active building
app.get("/make-server-86a3da15/join-requests", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const requests = await kv.get(bKey(buildingId, "join_requests")) || [];
    return c.json(requests);
  } catch (err: any) {
    console.log("Error fetching join requests:", err.message);
    return c.json({ error: `Error fetching join requests: ${err.message}` }, 500);
  }
});

// Dashboard: Approve or reject a join request
app.put("/make-server-86a3da15/join-requests/:requestId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const requestId = c.req.param("requestId");
    const { action } = await c.req.json(); // "approve" | "reject"

    if (!action || !["approve", "reject"].includes(action)) {
      return c.json({ error: "Invalid action. Must be 'approve' or 'reject'" }, 400);
    }

    const key = bKey(buildingId, "join_requests");
    const requests = await kv.get(key) || [];
    const idx = requests.findIndex((r: any) => r.id === requestId);
    if (idx === -1) {
      return c.json({ error: `Join request not found: ${requestId}` }, 404);
    }

    const req = requests[idx];
    const newStatus = action === "approve" ? "approved" : "rejected";
    requests[idx] = { ...req, status: newStatus, updatedAt: new Date().toISOString() };
    await kv.set(key, requests);

    // If approved, update the unit to occupied
    if (action === "approve") {
      const unitsKey = bKey(buildingId, "units");
      const units = await kv.get(unitsKey) || [];
      const unitIdx = units.findIndex((u: any) => u.unitCode === req.unitCode);
      if (unitIdx !== -1) {
        units[unitIdx] = {
          ...units[unitIdx],
          occupied: true,
          resident: req.name,
          ownerName: req.name,
          phone: req.phone,
          residentType: req.type,
        };
        await kv.set(unitsKey, units);
      }

      // Fetch building info (needed for auth profile and notification)
      const buildingInfo = await kv.get(bKey(buildingId, "info"));

      // === Create Supabase Auth user for the approved resident ===
      if (req.fakeEmail && req._tempPassword) {
        try {
          const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
            email: req.fakeEmail,
            password: req._tempPassword,
            user_metadata: {
              name: req.name,
              phone: req.phone,
              buildingId: buildingId,
              buildingName: buildingInfo?.name || "",
              unitCode: req.unitCode,
              floor: req.floor,
              type: req.type,
              role: "resident",
            },
            // Automatically confirm the user's email since an email server hasn't been configured.
            email_confirm: true,
          });

          if (authError) {
            // If user already exists in Supabase, ensure KV profile exists
            if (authError.message?.includes("already been registered") || authError.message?.includes("already exists")) {
              console.log(`Approval: auth user already exists for ${req.fakeEmail}, ensuring KV profile...`);
              try {
                const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
                const existingUser = existingUsers?.users?.find((u: any) => u.email === req.fakeEmail);
                if (existingUser) {
                  const existingProfile = await kv.get(`auth:${existingUser.id}`);
                  if (!existingProfile) {
                    console.log(`Approval: KV profile missing for ${existingUser.id}, creating...`);
                    await kv.set(`auth:${existingUser.id}`, {
                      id: existingUser.id,
                      userId: existingUser.id,
                      email: req.fakeEmail,
                      name: req.name,
                      phone: req.phone,
                      buildingId: buildingId,
                      buildingName: buildingInfo?.name || "",
                      unitCode: req.unitCode,
                      floor: req.floor,
                      type: req.type,
                      joinRequestId: req.id,
                    });
                    await kv.set(`auth:email:${req.fakeEmail}`, existingUser.id);
                  } else if (!existingProfile.id) {
                    existingProfile.id = existingUser.id;
                    await kv.set(`auth:${existingUser.id}`, existingProfile);
                  }
                  requests[idx].authUserId = existingUser.id;
                  requests[idx]._tempPassword = undefined;
                  await kv.set(key, requests);
                }
              } catch (lookupErr: any) {
                console.log("Approval: Error looking up existing user:", lookupErr.message);
              }
            } else {
              console.log("Error creating auth user during join approval:", authError.message);
            }
            // Don't fail the whole approval — just log
          } else if (authData?.user) {
            console.log(`Auth user created for ${req.fakeEmail}: ${authData.user.id}`);
            // Save auth user mapping: auth:{userId} → resident info
            await kv.set(`auth:${authData.user.id}`, {
              id: authData.user.id,
              userId: authData.user.id,
              email: req.fakeEmail,
              name: req.name,
              phone: req.phone,
              buildingId: buildingId,
              buildingName: buildingInfo?.name || "",
              unitCode: req.unitCode,
              floor: req.floor,
              type: req.type,
              joinRequestId: req.id,
            });
            // Also save email → userId mapping for quick lookup
            await kv.set(`auth:email:${req.fakeEmail}`, authData.user.id);
            // Update the join request to remove temp password and store auth user id
            requests[idx].authUserId = authData.user.id;
            requests[idx]._tempPassword = undefined;
            await kv.set(key, requests);
          }
        } catch (authErr: any) {
          console.log("Exception creating auth user during join approval:", authErr.message);
        }
      }

      // Register phone globally so it can't be used in another building
      const approvedPhone = (req.phone || "").replace(/\s/g, "");
      if (approvedPhone) {
        const buildingInfoForReg = buildingInfo || await kv.get(bKey(buildingId, "info"));
        await kv.set(`platform:phone:${approvedPhone}`, {
          buildingId,
          buildingName: buildingInfoForReg?.name || "",
          residentName: req.name,
          registeredAt: new Date().toISOString(),
        });
      }

      await logActivity(buildingId, {
        type: "join_approved",
        title: "تم قبول طلب انضمام",
        description: `تم قبول ${req.name} — شقة ${req.unitCode}`,
        icon: "UserCheck",
        color: "#0D9488",
        metadata: { requestId, unitCode: req.unitCode },
      });
      // Notify the resident that they've been accepted
      if (req.phone) {
        await pushNotification(buildingId, req.phone, {
          type: "join_approved",
          title: "تم قبول طلبك",
          body: `مرحباً بك في ${buildingInfo?.name || "المبنى"}! تم قبول طلب انضمامك.`,
          icon: "UserCheck",
          color: "#0D9488",
          metadata: { requestId },
        });
      }
    } else {
      await logActivity(buildingId, {
        type: "join_rejected",
        title: "تم رفض طلب انضمام",
        description: `تم رفض طلب ${req.name} — شقة ${req.unitCode}`,
        icon: "UserX",
        color: "#ef4444",
        metadata: { requestId, unitCode: req.unitCode },
      });
    }

    return c.json({ message: `Join request ${newStatus}`, request: requests[idx] });
  } catch (err: any) {
    console.log("Error updating join request:", err.message);
    return c.json({ error: `Error updating join request: ${err.message}` }, 500);
  }
});

// Dashboard: Get approved residents (from join requests)
app.get("/make-server-86a3da15/residents", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const requests = await cachedGet(bKey(buildingId, "join_requests"), 15_000) || []; // 15s cache

    // Calculate actual unpaid invoices per unit from invoice_batches
    const batches = await cachedGet(bKey(buildingId, "invoice_batches"), 15_000) || [];
    const unpaidByUnit: Record<string, number> = {};
    for (const batch of batches) {
      if (!batch.invoices) continue;
      for (const inv of batch.invoices) {
        if (inv.status === "pending" || inv.status === "overdue" || inv.status === "awaiting_collection") {
          const amount = Number(inv.amount) || 0;
          const unit = inv.unit || "";
          unpaidByUnit[unit] = (unpaidByUnit[unit] || 0) + amount;
        }
      }
    }

    const approved = requests
      .filter((r: any) => r.status === "approved")
      .map((r: any) => ({
        id: r.id,
        title: r.title || "",
        name: r.name,
        phone: r.phone,
        unitCode: r.unitCode,
        floor: r.floor,
        type: r.type,
        joinedAt: r.updatedAt,
        banned: r.banned || false,
        debt: unpaidByUnit[r.unitCode] || 0,
        role: r.role || "resident",
        creditBalance: r.creditBalance || 0,
        previousDebt: r.previousDebt || 0,
        lastLogin: r.lastLogin || null,
      }));
    return c.json(approved);
  } catch (err: any) {
    console.log("Error fetching residents:", err.message);
    return c.json({ error: `Error fetching residents: ${err.message}` }, 500);
  }
});

// Resident portal: Get public resident info (no financial data, includes bio/avatar)
app.get("/make-server-86a3da15/resident/residents-public", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const requests = await cachedGet(bKey(buildingId, "join_requests"), 15_000) || [];
    const approved = (requests as any[]).filter((r: any) => r.status === "approved" && !r.banned);

    // Enrich with bio/avatar from auth profiles
    const results: any[] = [];
    for (const r of approved) {
      let bio: string | undefined;
      let avatarBase64: string | undefined;
      try {
        const normalizedPhone = (r.phone || "").replace(/\s/g, "");
        const fakeEmail = `${normalizedPhone}@mollak.app`;
        const userId = await kv.get(`auth:email:${fakeEmail}`);
        if (userId) {
          const authProfile = await kv.get(`auth:${userId}`);
          if (authProfile) {
            bio = (authProfile as any).bio || undefined;
            avatarBase64 = (authProfile as any).avatarBase64 || undefined;
          }
        }
      } catch {
        // ignore — just skip enrichment
      }
      results.push({
        id: r.id,
        title: r.title || "",
        name: r.name,
        phone: r.phone,
        unitCode: r.unitCode,
        floor: r.floor,
        type: r.type,
        bio,
        avatarBase64,
      });
    }
    return c.json(results);
  } catch (err: any) {
    console.log("Error fetching public residents:", err.message);
    return c.json({ error: `Error fetching public residents: ${err.message}` }, 500);
  }
});

// Dashboard: Toggle ban on a resident
app.put("/make-server-86a3da15/residents/:requestId/ban", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const requestId = c.req.param("requestId");
    const key = bKey(buildingId, "join_requests");
    const requests = await kv.get(key) || [];
    const idx = requests.findIndex((r: any) => r.id === requestId);
    if (idx === -1) {
      return c.json({ error: "Resident not found" }, 404);
    }

    const wasBanned = requests[idx].banned || false;
    requests[idx] = { ...requests[idx], banned: !wasBanned };
    await kv.set(key, requests);

    const action = wasBanned ? "رفع الحظر عن" : "حظر";
    await logActivity(buildingId, {
      type: wasBanned ? "resident_unbanned" : "resident_banned",
      title: `${action} ساكن`,
      description: `تم ${action} ${requests[idx].name} — شقة ${requests[idx].unitCode}`,
      icon: wasBanned ? "ShieldCheck" : "ShieldBan",
      color: wasBanned ? "#0D9488" : "#ef4444",
      metadata: { requestId },
    });

    return c.json({ message: `Resident ${wasBanned ? "unbanned" : "banned"}` });
  } catch (err: any) {
    console.log("Error toggling ban:", err.message);
    return c.json({ error: `Error toggling ban: ${err.message}` }, 500);
  }
});

// Dashboard: Update resident role (admin/treasurer/board_member/resident)
app.put("/make-server-86a3da15/residents/:requestId/role", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const requestId = c.req.param("requestId");
    const { role } = await c.req.json();
    const validRoles = ["resident", "treasurer", "board_member"];
    if (!validRoles.includes(role)) {
      return c.json({ error: `Invalid role: ${role}. Valid roles: ${validRoles.join(", ")}` }, 400);
    }

    const key = bKey(buildingId, "join_requests");
    const requests = await kv.get(key) || [];
    const idx = requests.findIndex((r: any) => r.id === requestId);
    if (idx === -1) {
      return c.json({ error: "Resident not found" }, 404);
    }

    const oldRole = requests[idx].role || "resident";
    requests[idx] = { ...requests[idx], role };
    await kv.set(key, requests);

    // Also update the auth profile if exists
    const residentPhone = requests[idx].phone?.replace(/\s/g, "");
    const fakeEmail = `${residentPhone}@mollak.app`;
    const authEmailKey = await kv.get(`auth:email:${fakeEmail}`);
    if (authEmailKey) {
      const authProfile = await kv.get(`auth:${authEmailKey}`);
      if (authProfile) {
        const roleLabels: Record<string, string> = {
          "treasurer": "أمين الصندوق",
          "board_member": "عضو اتحاد",
          "resident": "ساكن",
        };
        await kv.set(`auth:${authEmailKey}`, {
          ...authProfile,
          role: role,
          adminRole: roleLabels[role] || "ساكن",
        });
        // Also update Supabase Auth user_metadata so fallback paths work
        try {
          await supabaseAdmin.auth.admin.updateUserById(authEmailKey as string, {
            user_metadata: { role, adminRole: roleLabels[role] || "ساكن" },
          });
          console.log(`Role update: Updated Supabase Auth metadata for user ${authEmailKey}`);
        } catch (metaErr: any) {
          console.log(`Role update: Failed to update Auth metadata: ${metaErr.message}`);
        }
      }
    }

    const roleLabels: Record<string, string> = {
      "treasurer": "أمين الصندوق",
      "board_member": "عضو اتحاد",
      "resident": "ساكن",
    };
    await logActivity(buildingId, {
      type: "role_changed",
      title: "تغيير صلاحية",
      description: `تم تغيير صلاحية ${requests[idx].name} من ${roleLabels[oldRole] || oldRole} إلى ${roleLabels[role]}`,
      icon: "Shield",
      color: "#0D9488",
      metadata: { requestId, oldRole, newRole: role },
    });

    // Notify the resident about their role change
    if (residentPhone) {
      await pushNotification(buildingId, residentPhone, {
        type: "role_changed",
        title: "تم تغيير صلاحيتك",
        body: `تم تعيينك كـ "${roleLabels[role]}" في المبنى.${role !== "resident" ? " يمكنك الآن الوصول للوحة التحكم." : ""}`,
        icon: "Shield",
        color: "#0D9488",
      });
    }

    return c.json({ message: `Role updated to ${role}`, role });
  } catch (err: any) {
    console.log("Error updating resident role:", err.message);
    return c.json({ error: `Error updating role: ${err.message}` }, 500);
  }
});

// ===================================================================
// Resident Delete — Remove a resident from the building
// ===================================================================

app.delete("/make-server-86a3da15/residents/:requestId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const requestId = c.req.param("requestId");
    const key = bKey(buildingId, "join_requests");
    const requests = await kv.get(key) || [];
    const idx = requests.findIndex((r: any) => r.id === requestId);
    if (idx === -1) return c.json({ error: "Resident not found" }, 404);

    const resident = requests[idx];
    const deletedPhone = (resident.phone || "").replace(/\s/g, "");
    const fakeEmail = deletedPhone ? `${deletedPhone}@mollak.app` : "";

    // ── 1. Delete Supabase Auth user completely ──
    const authUserId = resident.authUserId;
    if (authUserId) {
      try {
        await supabaseAdmin.auth.admin.deleteUser(authUserId);
        console.log(`Resident delete: Supabase auth user ${authUserId} deleted`);
      } catch (authDelErr: any) {
        console.log(`Resident delete: Failed to delete auth user ${authUserId} (may not exist):`, authDelErr.message);
      }
      // ── 2. Delete KV auth profile ──
      await kv.del(`auth:${authUserId}`);
    } else if (fakeEmail) {
      // authUserId not on join request — try to find via KV email mapping
      const mappedUserId = await kv.get(`auth:email:${fakeEmail}`);
      if (mappedUserId) {
        try {
          await supabaseAdmin.auth.admin.deleteUser(mappedUserId as string);
          console.log(`Resident delete: Supabase auth user ${mappedUserId} deleted (via email mapping)`);
        } catch (authDelErr: any) {
          console.log(`Resident delete: Failed to delete auth user ${mappedUserId}:`, authDelErr.message);
        }
        await kv.del(`auth:${mappedUserId}`);
      }
    }

    // ── 3. Delete KV email mapping ──
    if (fakeEmail) {
      await kv.del(`auth:email:${fakeEmail}`);
    }

    // ── 4. Remove phone from global registry ──
    if (deletedPhone) {
      await kv.del(`platform:phone:${deletedPhone}`);
    }

    // ── 5. Remove from join_requests ──
    requests.splice(idx, 1);
    await kv.set(key, requests);
    invalidateCache(key);

    await logActivity(buildingId, {
      type: "resident_removed",
      title: "تم حذف مالك",
      description: `تم حذف ${resident.name} — شقة ${resident.unitCode}`,
      icon: "Trash2",
      color: "#ef4444",
      metadata: { requestId, unitCode: resident.unitCode },
    });

    console.log(`Resident fully deleted: ${resident.name} (${deletedPhone}) — auth, KV profile, email mapping, phone registry, join request all removed`);
    return c.json({ message: `Resident ${resident.name} fully removed` });
  } catch (err: any) {
    console.log("Error deleting resident:", err.message);
    return c.json({ error: `Error deleting resident: ${err.message}` }, 500);
  }
});

// ===================================================================
// Resident Edit — Update resident info (name, unitCode, floor, type)
// ===================================================================

app.put("/make-server-86a3da15/residents/:requestId/edit", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const requestId = c.req.param("requestId");
    const { name, unitCode, floor, type } = await c.req.json();
    const key = bKey(buildingId, "join_requests");
    const requests = await kv.get(key) || [];
    const idx = requests.findIndex((r: any) => r.id === requestId);
    if (idx === -1) return c.json({ error: "Resident not found" }, 404);

    const oldName = requests[idx].name;
    if (name) requests[idx].name = name;
    if (unitCode) requests[idx].unitCode = unitCode;
    if (floor !== undefined) requests[idx].floor = floor;
    if (type) requests[idx].type = type;
    requests[idx].updatedAt = new Date().toISOString();

    await kv.set(key, requests);
    invalidateCache(key);

    await logActivity(buildingId, {
      type: "resident_updated",
      title: "تم تعديل بيانات مالك",
      description: `تم تعديل بيانات ${name || oldName} — شقة ${unitCode || requests[idx].unitCode}`,
      icon: "Pencil",
      color: "#F59E0B",
      metadata: { requestId },
    });

    return c.json({ message: "Resident updated", resident: requests[idx] });
  } catch (err: any) {
    console.log("Error editing resident:", err.message);
    return c.json({ error: `Error editing resident: ${err.message}` }, 500);
  }
});

// ===================================================================
// Resident Credit Balance — Add/deduct credit for a resident
// ===================================================================

app.put("/make-server-86a3da15/residents/:requestId/credit", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const requestId = c.req.param("requestId");
    const { amount, note } = await c.req.json();
    if (typeof amount !== "number" || amount === 0) {
      return c.json({ error: "amount must be a non-zero number" }, 400);
    }

    const key = bKey(buildingId, "join_requests");
    const requests = await kv.get(key) || [];
    const idx = requests.findIndex((r: any) => r.id === requestId);
    if (idx === -1) return c.json({ error: "Resident not found" }, 404);

    const oldBalance = requests[idx].creditBalance || 0;
    const newBalance = oldBalance + amount;
    requests[idx] = { ...requests[idx], creditBalance: newBalance };
    await kv.set(key, requests);

    // Log credit transaction
    const txKey = bKey(buildingId, "credit_transactions");
    const txs = await kv.get(txKey) || [];
    txs.unshift({
      id: crypto.randomUUID(),
      residentId: requestId,
      residentName: requests[idx].name,
      unitCode: requests[idx].unitCode,
      amount,
      balanceAfter: newBalance,
      note: note || "",
      createdAt: new Date().toISOString(),
    });
    await kv.set(txKey, txs);

    await logActivity(buildingId, {
      type: "credit_added",
      title: amount > 0 ? "إضافة رصيد مالي" : "خصم من الرصيد",
      description: `${requests[idx].name} (شقة ${requests[idx].unitCode}) — ${Math.abs(amount).toLocaleString("en-US")} ج.م${note ? ` — ${note}` : ""}`,
      icon: "Wallet",
      color: amount > 0 ? "#22c55e" : "#F59E0B",
      metadata: { requestId, amount, newBalance },
    });

    // Auto-pay pending invoices if credit was added (amount > 0)
    if (amount > 0) {
      const invoiceKey = bKey(buildingId, "invoice_batches");
      const batches = await kv.get(invoiceKey) || [];
      let remainingCredit = newBalance;
      let autoPaidCount = 0;
      const now = new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });

      for (const batch of batches) {
        if (!batch.invoices || remainingCredit <= 0) continue;
        for (let i = 0; i < batch.invoices.length; i++) {
          const inv = batch.invoices[i];
          if (inv.unit === requests[idx].unitCode && (inv.status === "pending" || inv.status === "overdue") && remainingCredit >= inv.amount) {
            batch.invoices[i] = {
              ...inv,
              status: "paid",
              method: "رصيد مالي (دفع تلقائي)",
              paidDate: now,
            };
            remainingCredit -= inv.amount;
            autoPaidCount++;
          }
        }
      }

      if (autoPaidCount > 0) {
        await kv.set(invoiceKey, batches);
        // Update credit balance after auto-pay
        const updatedRequests = await kv.get(key) || [];
        const uIdx = updatedRequests.findIndex((r: any) => r.id === requestId);
        if (uIdx !== -1) {
          updatedRequests[uIdx] = { ...updatedRequests[uIdx], creditBalance: remainingCredit };
          await kv.set(key, updatedRequests);
        }

        // Log auto-pay transaction
        txs.unshift({
          id: crypto.randomUUID(),
          residentId: requestId,
          residentName: requests[idx].name,
          unitCode: requests[idx].unitCode,
          amount: -(newBalance - remainingCredit),
          balanceAfter: remainingCredit,
          note: `دفع تلقائي لـ ${autoPaidCount} فاتورة`,
          createdAt: new Date().toISOString(),
        });
        await kv.set(txKey, txs);

        await logActivity(buildingId, {
          type: "credit_auto_pay",
          title: "دفع تلقائي من الرصيد",
          description: `تم سداد ${autoPaidCount} فاتورة تلقائياً من رصيد ${requests[idx].name} (شقة ${requests[idx].unitCode})`,
          icon: "CheckCircle",
          color: "#0D9488",
          metadata: { requestId, autoPaidCount, remainingCredit },
        });
      }
    }

    return c.json({ message: "Credit updated", creditBalance: requests[idx].creditBalance });
  } catch (err: any) {
    console.log("Error updating resident credit:", err.message);
    return c.json({ error: `Error updating resident credit: ${err.message}` }, 500);
  }
});

// ===================================================================
// Resident Previous Debt — Set previous debt for a resident
// ===================================================================

app.put("/make-server-86a3da15/residents/:requestId/previous-debt", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const requestId = c.req.param("requestId");
    const { amount, note } = await c.req.json();
    if (typeof amount !== "number" || amount < 0) {
      return c.json({ error: "amount must be a non-negative number" }, 400);
    }

    const key = bKey(buildingId, "join_requests");
    const requests = await kv.get(key) || [];
    const idx = requests.findIndex((r: any) => r.id === requestId);
    if (idx === -1) return c.json({ error: "Resident not found" }, 404);

    requests[idx] = { ...requests[idx], previousDebt: amount };
    await kv.set(key, requests);

    await logActivity(buildingId, {
      type: "previous_debt_set",
      title: amount > 0 ? "تسجيل مديونية سابقة" : "إزالة مديونية سابقة",
      description: `${requests[idx].name} (شقة ${requests[idx].unitCode}) — ${amount > 0 ? amount.toLocaleString("en-US") + " ج.م" : "تم إزالة المديونية"}${note ? ` — ${note}` : ""}`,
      icon: "AlertTriangle",
      color: amount > 0 ? "#dc2626" : "#22c55e",
      metadata: { requestId, amount },
    });

    return c.json({ message: "Previous debt updated", previousDebt: amount });
  } catch (err: any) {
    console.log("Error updating resident previous debt:", err.message);
    return c.json({ error: `Error updating resident previous debt: ${err.message}` }, 500);
  }
});

// ===================================================================
// Get credit transactions for a resident
// ===================================================================

app.get("/make-server-86a3da15/residents/:requestId/credit-history", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);

    const requestId = c.req.param("requestId");
    const txKey = bKey(buildingId, "credit_transactions");
    const txs = await kv.get(txKey) || [];
    const filtered = txs.filter((t: any) => t.residentId === requestId);
    return c.json(filtered);
  } catch (err: any) {
    console.log("Error fetching credit history:", err.message);
    return c.json({ error: `Error fetching credit history: ${err.message}` }, 500);
  }
});

// ===================================================================
// Auth — Get current authenticated user's profile
// ===================================================================

// Quick phone check: returns whether an admin phone is already registered
app.post("/make-server-86a3da15/auth/check-phone", async (c) => {
  try {
    const { phone } = await c.req.json();
    if (!phone) {
      return c.json({ exists: false });
    }
    const normalizedPhone = phone.replace(/\s/g, "");
    if (normalizedPhone.length < 10) {
      return c.json({ exists: false });
    }
    const fakeEmail = `${normalizedPhone}@mollak.app`;

    // Fast KV check
    const kvUser = await kv.get(`auth:email:${fakeEmail}`);
    if (kvUser) {
      return c.json({ exists: true, phone: normalizedPhone });
    }

    // Fallback: Supabase Auth check
    try {
      const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
      const found = existingUsers?.users?.find((u: any) => u.email === fakeEmail);
      if (found) {
        return c.json({ exists: true, phone: normalizedPhone });
      }
    } catch (_) {
      // ignore — return not found
    }

    return c.json({ exists: false });
  } catch (err: any) {
    console.log("Error in /auth/check-phone:", err.message);
    return c.json({ exists: false });
  }
});

// Pre-login: Ensure auth user exists for approved residents (handles case where createUser failed during approval)
app.post("/make-server-86a3da15/auth/pre-login", async (c) => {
  try {
    const { phone } = await c.req.json();
    if (!phone) {
      return c.json({ error: "Missing phone number" }, 400);
    }

    const normalizedPhone = phone.replace(/\s/g, "");
    const fakeEmail = `${normalizedPhone}@mollak.app`;

    // Helper: update lastLogin on the join request for this phone
    const touchLastLogin = async (knownKey?: string | null, knownIdx?: number) => {
      try {
        if (knownKey && knownIdx !== undefined && knownIdx >= 0) {
          const reqs = await kv.get(knownKey) || [];
          if (reqs[knownIdx]) {
            reqs[knownIdx].lastLogin = new Date().toISOString();
            await kv.set(knownKey, reqs);
          }
          return;
        }
        const bList = await kv.get("buildings_list") || [];
        for (const b of bList) {
          const rKey = bKey(b.id, "join_requests");
          const reqs = await kv.get(rKey) || [];
          const i = reqs.findIndex((r: any) => r.phone?.replace(/\s/g, "") === normalizedPhone && r.status === "approved");
          if (i !== -1) {
            reqs[i].lastLogin = new Date().toISOString();
            await kv.set(rKey, reqs);
            break;
          }
        }
      } catch (e: any) {
        console.log("touchLastLogin error (non-fatal):", e.message);
      }
    };

    // Check if auth user already exists via KV mapping
    const existingUserId = await kv.get(`auth:email:${fakeEmail}`);
    if (existingUserId) {
      // Verify the auth user still exists in Supabase (KV could be stale after a project reset)
      const { data: { user: verifiedUser }, error: verifyErr } = await supabaseAdmin.auth.admin.getUserById(existingUserId as string);
      if (!verifyErr && verifiedUser) {
        await touchLastLogin();
        return c.json({ status: "ready", message: "Auth user exists" });
      }
      // KV mapping is stale — remove it so the code below can recreate the user
      console.log(`Pre-login: KV mapping stale for ${fakeEmail} (userId=${existingUserId}) — clearing`);
      await kv.del(`auth:email:${fakeEmail}`);
    }

    // Auth user doesn't exist in KV — search all buildings for approved join request
    const buildingsList = await kv.get("buildings_list") || [];
    let foundRequest: any = null;
    let foundBuildingId: string | null = null;
    let foundRequestsKey: string | null = null;
    let foundRequestIdx = -1;
    let hasPending = false;

    for (const bEntry of buildingsList) {
      const reqKey = bKey(bEntry.id, "join_requests");
      const requests = await kv.get(reqKey) || [];
      // Look for approved request with matching phone
      const idx = requests.findIndex((r: any) =>
        r.phone?.replace(/\s/g, "") === normalizedPhone && r.status === "approved"
      );
      if (idx !== -1) {
        // Check if this resident is banned
        if (requests[idx].banned) {
          return c.json({ status: "banned", error: "تم حظر حسابك — تواصل مع إدارة المبنى لمزيد من المعلومات" }, 403);
        }
        foundRequest = requests[idx];
        foundBuildingId = bEntry.id;
        foundRequestsKey = reqKey;
        foundRequestIdx = idx;
        break;
      }
      // Also track if there's a pending request
      if (!hasPending) {
        hasPending = requests.some((r: any) =>
          r.phone?.replace(/\s/g, "") === normalizedPhone && r.status === "pending"
        );
      }
    }

    if (!foundRequest) {
      // Also check if phone belongs to a building admin
      for (const bEntry of buildingsList) {
        const bInfo = await kv.get(bKey(bEntry.id, "info"));
        if (bInfo?.admin?.phone?.replace(/\s/g, "") === normalizedPhone) {
          // This phone belongs to a building admin — check if auth user exists
          const adminEmail = `${normalizedPhone}@mollak.app`;
          const adminUserId = await kv.get(`auth:email:${adminEmail}`);
          if (adminUserId) {
            return c.json({ status: "ready", message: "Admin auth user exists" });
          }
          // Admin auth user might exist in Supabase but not in KV
          try {
            const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
            const existingAdmin = existingUsers?.users?.find((u: any) => u.email === adminEmail);
            if (existingAdmin) {
              await kv.set(`auth:email:${adminEmail}`, existingAdmin.id);
              // Ensure KV profile exists
              const existingProfile = await kv.get(`auth:${existingAdmin.id}`);
              if (!existingProfile) {
                await kv.set(`auth:${existingAdmin.id}`, {
                  id: existingAdmin.id,
                  userId: existingAdmin.id,
                  email: adminEmail,
                  name: bInfo.admin.name || "",
                  phone: normalizedPhone,
                  buildingId: bEntry.id,
                  buildingName: bInfo.name || "",
                  unitCode: "",
                  floor: "",
                  type: "admin",
                  role: "admin",
                  adminRole: bInfo.admin.role || "رئيس الاتحاد",
                });
              }
              return c.json({ status: "ready", message: "Admin auth user exists (mapping restored)" });
            }
          } catch (lookupErr: any) {
            console.log("Pre-login: Error looking up admin user:", lookupErr.message);
          }
          // Admin auth user doesn't exist at all — they need to re-register or contact support
          return c.json({ status: "admin_no_auth", error: "حساب الإدارة غير مكتمل — أعد تسجيل المبنى أو تواصل مع الدعم" }, 404);
        }
      }
      
      if (hasPending) {
        return c.json({ status: "pending", error: "طلب انضمامك لم تتم الموافقة عليه بعد — انتظر موافقة إدارة المبنى" }, 403);
      }
      return c.json({ status: "not_found", error: "لا يوجد حساب مرتبط بهذا الرقم — تأكد من رقم الجوال أو قدّم طلب انضمام أولاً" }, 404);
    }

    // Found approved request — try to create auth user if it wasn't created
    if (foundRequest.authUserId) {
      // Auth user was created during approval, but KV mapping might be missing — restore it
      await kv.set(`auth:email:${fakeEmail}`, foundRequest.authUserId);
      await touchLastLogin(foundRequestsKey, foundRequestIdx);
      return c.json({ status: "ready", message: "Auth user exists (mapping restored)" });
    }

    // Auth user was NOT created during approval — create it now
    if (!foundRequest._tempPassword) {
      console.log(`Pre-login: approved request for ${normalizedPhone} has no stored password`);
      return c.json({ status: "no_password", error: "حدث خطأ في البيانات — تواصل مع إدارة المبنى لإعادة تعيين حسابك" }, 500);
    }

    // Create the auth user now
    const buildingInfo = await kv.get(bKey(foundBuildingId!, "info"));
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email: fakeEmail,
      password: foundRequest._tempPassword,
      user_metadata: {
        name: foundRequest.name,
        phone: foundRequest.phone,
        buildingId: foundBuildingId,
        buildingName: buildingInfo?.name || "",
        unitCode: foundRequest.unitCode,
        floor: foundRequest.floor,
        type: foundRequest.type,
        role: "resident",
      },
      email_confirm: true,
    });

    if (authError) {
      // If user already exists in Supabase but not in our KV, ensure KV profile exists
      if (authError.message?.includes("already been registered") || authError.message?.includes("already exists")) {
        console.log(`Pre-login: auth user already exists for ${fakeEmail}, ensuring KV profile...`);
        
        // Look up the existing user by email to get their ID
        try {
          const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
          const existingUser = existingUsers?.users?.find((u: any) => u.email === fakeEmail);
          if (existingUser) {
            const existingProfile = await kv.get(`auth:${existingUser.id}`);
            if (!existingProfile) {
              // KV profile missing — create it from the join request data
              console.log(`Pre-login: KV profile missing for ${existingUser.id}, creating from join request...`);
              const profileData = {
                id: existingUser.id,
                userId: existingUser.id,
                email: fakeEmail,
                name: foundRequest.name,
                phone: foundRequest.phone,
                buildingId: foundBuildingId,
                buildingName: buildingInfo?.name || "",
                unitCode: foundRequest.unitCode,
                floor: foundRequest.floor,
                type: foundRequest.type,
                joinRequestId: foundRequest.id,
              };
              await kv.set(`auth:${existingUser.id}`, profileData);
              await kv.set(`auth:email:${fakeEmail}`, existingUser.id);
              console.log(`Pre-login: KV profile created for ${existingUser.id}`);
            } else if (!existingProfile.id) {
              // Profile exists but missing 'id' field — fix it
              existingProfile.id = existingUser.id;
              await kv.set(`auth:${existingUser.id}`, existingProfile);
              console.log(`Pre-login: Fixed missing 'id' field in KV profile for ${existingUser.id}`);
            }
          }
        } catch (lookupErr: any) {
          console.log("Pre-login: Error looking up existing user:", lookupErr.message);
        }
        
        await touchLastLogin(foundRequestsKey, foundRequestIdx);
        return c.json({ status: "ready", message: "Auth user already exists in Supabase" });
      }
      console.log(`Pre-login: Error creating auth user for ${fakeEmail}:`, authError.message);
      return c.json({ status: "error", error: `خطأ في إنشاء الحساب: ${authError.message}` }, 500);
    }

    if (authData?.user) {
      console.log(`Pre-login: Auth user created for ${fakeEmail}: ${authData.user.id}`);
      // Save mappings
      const roleLabelsMap: Record<string, string> = {
        "treasurer": "أمين الصندوق",
        "board_member": "عضو اتحاد",
        "resident": "ساكن",
      };
      const residentRole = foundRequest.role || "resident";
      await kv.set(`auth:${authData.user.id}`, {
        id: authData.user.id,
        userId: authData.user.id,
        email: fakeEmail,
        name: foundRequest.name,
        phone: foundRequest.phone,
        buildingId: foundBuildingId,
        buildingName: buildingInfo?.name || "",
        unitCode: foundRequest.unitCode,
        floor: foundRequest.floor,
        type: foundRequest.type,
        role: residentRole,
        adminRole: roleLabelsMap[residentRole] || "ساكن",
        joinRequestId: foundRequest.id,
      });
      await kv.set(`auth:email:${fakeEmail}`, authData.user.id);

      // Update join request to mark auth user created
      if (foundRequestsKey && foundRequestIdx >= 0) {
        const requests = await kv.get(foundRequestsKey) || [];
        if (requests[foundRequestIdx]) {
          requests[foundRequestIdx].authUserId = authData.user.id;
          requests[foundRequestIdx]._tempPassword = undefined;
          await kv.set(foundRequestsKey, requests);
        }
      }

      await touchLastLogin(foundRequestsKey, foundRequestIdx);
      return c.json({ status: "ready", message: "Auth user created successfully" });
    }

    return c.json({ status: "error", error: "خطأ غير متوقع — حاول مرة أخرى" }, 500);
  } catch (err: any) {
    console.log("Error in /auth/pre-login:", err.message);
    return c.json({ error: `Error in pre-login: ${err.message}` }, 500);
  }
});

// ─────────────────────────────────────────────────────────────
// POST /auth/repair — Self-repair for broken auth users
// Called when signInWithPassword returns "Invalid login credentials".
// Updates the Supabase Auth password or recreates the user, then restores KV.
// ─────────────────────────────────────────────────────────────
// Helper to find a Supabase Auth user by email with full pagination
async function _findAuthUserByEmail(email: string): Promise<any | null> {
  let page = 1;
  const perPage = 1000;
  while (true) {
    const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage } as any);
    if (error || !data?.users?.length) break;
    const found = data.users.find((u: any) => u.email === email);
    if (found) return found;
    if (data.users.length < perPage) break;
    page++;
  }
  return null;
}

async function _rebuildKvProfile(userId: string, fakeEmail: string, normalizedPhone: string) {
  try {
    const buildingsList: any[] = await kv.get("buildings_list") || [];
    for (const bEntry of buildingsList) {
      const bInfo = await kv.get(bKey(bEntry.id, "info"));
      if (bInfo?.admin?.phone?.replace(/\s/g, "") === normalizedPhone) {
        await kv.set(`auth:${userId}`, {
          id: userId, userId, email: fakeEmail,
          name: bInfo.admin.name || "", phone: normalizedPhone,
          buildingId: bEntry.id, buildingName: bInfo.name || "",
          unitCode: bInfo.admin.unitCode || "", floor: "", type: "admin", role: "admin",
          adminRole: bInfo.admin.role || "رئيس الاتحاد",
        });
        return;
      }
    }
    for (const bEntry of buildingsList) {
      const joinReqs: any[] = await kv.get(bKey(bEntry.id, "join_requests")) || [];
      const match = joinReqs.find((r: any) =>
        r.phone?.replace(/\s/g, "") === normalizedPhone && r.status === "approved"
      );
      if (match) {
        const bInfo = await kv.get(bKey(bEntry.id, "info"));
        const roleLabels: Record<string, string> = { treasurer: "أمين الصندوق", board_member: "عضو اتحاد", resident: "ساكن" };
        const matchRole = match.role || "resident";
        await kv.set(`auth:${userId}`, {
          id: userId, userId, email: fakeEmail,
          name: match.name || "", phone: match.phone || normalizedPhone,
          buildingId: bEntry.id, buildingName: bInfo?.name || "",
          unitCode: match.unitCode || "", floor: match.floor || "",
          type: match.type || "مالك", role: matchRole,
          adminRole: roleLabels[matchRole] || "ساكن",
        });
        return;
      }
    }
  } catch (err: any) {
    console.log("Error in _rebuildKvProfile:", err.message);
  }
}

app.post("/make-server-86a3da15/auth/repair", async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const { phone, password } = body;

    if (!phone || !password) {
      return c.json({ error: "Missing phone or password" }, 400);
    }
    if (password.length < 6) {
      return c.json({ error: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" }, 400);
    }

    const normalizedPhone = phone.replace(/\s/g, "");
    const fakeEmail = `${normalizedPhone}@mollak.app`;
    console.log(`Auth/repair: Attempting repair for ${fakeEmail}`);

    // ── SECURITY: Only create MISSING auth users. Never reset existing passwords. ──
    // If the auth user already exists, refuse — the user must use the correct
    // password or go through a proper admin-initiated password-reset flow.
    const existingUser = await _findAuthUserByEmail(fakeEmail);
    if (existingUser) {
      console.log(`Auth/repair: Auth user already exists for ${fakeEmail} — refusing password change`);
      // Silently restore missing KV mappings without touching the password
      const kvEmailMapping = await kv.get(`auth:email:${fakeEmail}`);
      if (!kvEmailMapping) await kv.set(`auth:email:${fakeEmail}`, existingUser.id);
      const kvProfile = await kv.get(`auth:${existingUser.id}`);
      if (!kvProfile) await _rebuildKvProfile(existingUser.id, fakeEmail, normalizedPhone);
      return c.json({ status: "exists", error: "رقم الجوال أو كلمة المرور غير صحيحة" }, 401);
    }

    // Auth user does NOT exist — collect profile data from KV to create it
    const buildingsList: any[] = await kv.get("buildings_list") || [];
    let profileData: any = null;

    // Check building admins
    for (const bEntry of buildingsList) {
      const bInfo = await kv.get(bKey(bEntry.id, "info"));
      if (bInfo?.admin?.phone?.replace(/\s/g, "") === normalizedPhone) {
        profileData = {
          name: bInfo.admin.name || "", phone: normalizedPhone,
          buildingId: bEntry.id, buildingName: bInfo.name || "",
          unitCode: bInfo.admin.unitCode || "", floor: "", type: "admin", role: "admin",
          adminRole: bInfo.admin.role || "رئيس الاتحاد",
          userMeta: { name: bInfo.admin.name || "", phone: normalizedPhone, buildingId: bEntry.id, buildingName: bInfo.name || "", role: "admin", adminRole: bInfo.admin.role || "رئيس الاتحاد" },
        };
        break;
      }
    }

    // Check approved residents
    if (!profileData) {
      for (const bEntry of buildingsList) {
        const joinReqs: any[] = await kv.get(bKey(bEntry.id, "join_requests")) || [];
        const match = joinReqs.find((r: any) =>
          r.phone?.replace(/\s/g, "") === normalizedPhone && r.status === "approved"
        );
        if (match) {
          const bInfo = await kv.get(bKey(bEntry.id, "info"));
          const matchRole = match.role || "resident";
          const roleLabels: Record<string, string> = { treasurer: "أمين الصندوق", board_member: "عضو اتحاد", resident: "ساكن" };
          profileData = {
            name: match.name || "", phone: match.phone || normalizedPhone,
            buildingId: bEntry.id, buildingName: bInfo?.name || "",
            unitCode: match.unitCode || "", floor: match.floor || "",
            type: match.type || "مالك", role: matchRole, adminRole: roleLabels[matchRole] || "ساكن",
            userMeta: { name: match.name || "", phone: match.phone || normalizedPhone, buildingId: bEntry.id, buildingName: bInfo?.name || "", unitCode: match.unitCode || "", floor: match.floor || "", type: match.type || "مالك", role: matchRole },
          };
          break;
        }
      }
    }

    if (!profileData) {
      console.log(`Auth/repair: No approved user found for ${normalizedPhone}`);
      return c.json({ status: "not_found", error: "لا يوجد حساب مرتبط بهذا الرقم — تأكد من رقم الجوال أو قدّم طلب انضمام" }, 404);
    }

    // Step 3: Create Supabase Auth user
    console.log(`Auth/repair: Creating new auth user for ${fakeEmail}`);
    const { data: newAuthData, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email: fakeEmail,
      password,
      user_metadata: profileData.userMeta,
      email_confirm: true,
    });

    if (createError) {
      console.log(`Auth/repair: createUser failed: ${createError.message}`);
      // User might already exist (pagination miss on first search) — do NOT reset password
      if (createError.message?.includes("already") || createError.message?.includes("registered")) {
        console.log(`Auth/repair: User already exists (race condition) — refusing password change`);
        // Just restore KV mappings without touching the password
        const retryUser = await _findAuthUserByEmail(fakeEmail);
        if (retryUser) {
          const kvEmailMapping = await kv.get(`auth:email:${fakeEmail}`);
          if (!kvEmailMapping) await kv.set(`auth:email:${fakeEmail}`, retryUser.id);
          const kvProfile = await kv.get(`auth:${retryUser.id}`);
          if (!kvProfile) await _rebuildKvProfile(retryUser.id, fakeEmail, normalizedPhone);
        }
        return c.json({ status: "exists", error: "الحساب موجود بالفعل — استخدم كلمة المرور الصحيحة" }, 401);
      }
      return c.json({ error: `فشل إنشاء الحساب: ${createError.message}` }, 500);
    }

    if (newAuthData?.user) {
      const uid = newAuthData.user.id;
      const { userMeta: _meta, ...restProfile } = profileData;
      await kv.set(`auth:${uid}`, { id: uid, userId: uid, email: fakeEmail, ...restProfile });
      await kv.set(`auth:email:${fakeEmail}`, uid);
      console.log(`Auth/repair: Auth user created for ${uid}`);
      return c.json({ status: "created", message: "تم إنشاء الحساب — يمكنك تسجيل الدخول الآن" });
    }

    return c.json({ error: "خطأ غير متوقع — حاول مرة أخرى" }, 500);
  } catch (err: any) {
    console.log("Error in /auth/repair:", err.message);
    return c.json({ error: `Error in repair: ${err.message}` }, 500);
  }
});

app.get("/make-server-86a3da15/auth/me", async (c) => {
  try {
    // Read user token from query param (most reliable for Edge Functions), then X-User-Token header, then Authorization header
    const accessToken = c.req.query("token") || c.req.header("X-User-Token") || c.req.header("Authorization")?.split(" ")[1];
    if (!accessToken) {
      console.log("Auth/me: No access token found in query, X-User-Token, or Authorization headers");
      return c.json({ error: "Missing authorization token" }, 401);
    }

    // Avoid using the anon key as the user token
    if (accessToken === Deno.env.get("SUPABASE_ANON_KEY")) {
      console.log("Auth/me: Received anon key instead of user JWT — rejecting");
      return c.json({ error: "Invalid token — received anon key instead of user JWT" }, 401);
    }

    console.log("Auth/me: Token received, length:", accessToken.length, "starts with:", accessToken.substring(0, 10));

    // Verify the token with Supabase
    const { data: { user }, error } = await supabaseAdmin.auth.getUser(accessToken);
    if (error || !user) {
      console.log("Auth verification failed for /auth/me:", error?.message);
      return c.json({ error: "Invalid or expired token — يرجى تسجيل الدخول مرة أخرى" }, 401);
    }

    // Get the resident profile from KV
    const profile = await kv.get(`auth:${user.id}`);
    if (!profile) {
      // Fallback: try to build profile from user metadata
      const meta = user.user_metadata || {};
      if (meta.buildingId && meta.unitCode) {
        const buildingInfo = await kv.get(bKey(meta.buildingId, "info"));
        const metaRole = meta.role || "resident";
        const metaRoleLabels: Record<string, string> = { "admin": "رئيس الاتحاد", "treasurer": "أمين الصندوق", "board_member": "عضو اتحاد", "resident": "ساكن" };
        const fallbackProfile = {
          id: user.id,
          email: user.email,
          name: meta.name || "",
          phone: meta.phone || "",
          buildingId: meta.buildingId,
          buildingName: buildingInfo?.name || meta.buildingName || "",
          unitCode: meta.unitCode,
          floor: meta.floor || "",
          type: meta.type || "مالك",
          role: metaRole,
          adminRole: meta.adminRole || metaRoleLabels[metaRole] || "ساكن",
        };
        // Save it for next time
        await kv.set(`auth:${user.id}`, fallbackProfile);
        return c.json({ profile: fallbackProfile });
      }
      // Last resort fallback: search join requests for this user's phone
      const userPhone = meta.phone || user.email?.replace("@mollak.app", "");
      if (userPhone) {
        console.log("Auth/me: Searching join requests for phone:", userPhone);
        const buildingsList = await kv.get("buildings_list") || [];
        for (const bEntry of buildingsList) {
          const joinReqs = await kv.get(bKey(bEntry.id, "join_requests")) || [];
          const match = joinReqs.find((r: any) =>
            r.phone?.replace(/\s/g, "") === userPhone.replace(/\s/g, "") && r.status === "approved"
          );
          if (match) {
            const bInfo = await kv.get(bKey(bEntry.id, "info"));
            const matchRole = match.role || "resident";
            const matchRoleLabels: Record<string, string> = { "treasurer": "أمين الصندوق", "board_member": "عضو اتحاد", "resident": "ساكن" };
            const recoveredProfile = {
              id: user.id,
              email: user.email,
              name: match.name || "",
              phone: match.phone || "",
              buildingId: bEntry.id,
              buildingName: bInfo?.name || "",
              unitCode: match.unitCode || "",
              floor: match.floor || "",
              type: match.type || "مالك",
              role: matchRole,
              adminRole: matchRoleLabels[matchRole] || "ساكن",
            };
            await kv.set(`auth:${user.id}`, recoveredProfile);
            await kv.set(`auth:email:${user.email}`, user.id);
            console.log("Auth/me: Recovered profile from join requests for", user.id);
            return c.json({ profile: recoveredProfile });
          }
        }
      }
      return c.json({ error: "Resident profile not found — لم يتم العثور على بيانات الساكن" }, 404);
    }

    // Normalize: ensure profile always has 'id' field
    const normalizedProfile = {
      ...profile,
      id: profile.id || profile.userId || user.id,
    };
    // Fix KV if id was missing
    if (!profile.id) {
      await kv.set(`auth:${user.id}`, normalizedProfile);
    }

    // Check if resident is banned (skip for admins)
    if (normalizedProfile.role !== "admin" && normalizedProfile.buildingId && normalizedProfile.phone) {
      try {
        const joinReqs = await kv.get(bKey(normalizedProfile.buildingId, "join_requests")) || [];
        const residentReq = (joinReqs as any[]).find((r: any) =>
          r.phone?.replace(/\s/g, "") === normalizedProfile.phone.replace(/\s/g, "") && r.status === "approved"
        );
        if (residentReq?.banned) {
          return c.json({ error: "تم حظر حسابك — تواصل مع إدارة المبنى لمزيد من المعلومات", banned: true }, 403);
        }
      } catch (banCheckErr: any) {
        console.log("GET Auth/me: ban check error (non-fatal):", banCheckErr.message);
      }
    }

    return c.json({ profile: normalizedProfile });
  } catch (err: any) {
    console.log("Error in /auth/me:", err.message);
    return c.json({ error: `Error fetching user profile: ${err.message}` }, 500);
  }
});

// POST version of /auth/me — more reliable for passing tokens in body
app.post("/make-server-86a3da15/auth/me", async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const accessToken = body.token || c.req.query("token") || c.req.header("X-User-Token");
    if (!accessToken) {
      console.log("POST Auth/me: No access token found");
      return c.json({ error: "Missing authorization token" }, 401);
    }

    // Avoid using the anon key as the user token
    if (accessToken === Deno.env.get("SUPABASE_ANON_KEY")) {
      console.log("POST Auth/me: Received anon key instead of user JWT — rejecting");
      return c.json({ error: "Invalid token — received anon key instead of user JWT" }, 401);
    }

    console.log("POST Auth/me: Token received, length:", accessToken.length);

    // Verify the token with Supabase
    const { data: { user }, error } = await supabaseAdmin.auth.getUser(accessToken);
    if (error || !user) {
      console.log("POST Auth verification failed:", error?.message);
      return c.json({ error: "Invalid or expired token — يرجى تسجيل الدخول مرة أخرى" }, 401);
    }

    // Get the resident profile from KV
    const profile = await kv.get(`auth:${user.id}`);
    if (!profile) {
      // Fallback: try to build profile from user metadata
      const meta = user.user_metadata || {};
      if (meta.buildingId && meta.unitCode) {
        const buildingInfo = await kv.get(bKey(meta.buildingId, "info"));
        const metaRole = meta.role || "resident";
        const metaRoleLabels: Record<string, string> = { "admin": "رئيس الاتحاد", "treasurer": "أمين الصندوق", "board_member": "عضو اتحاد", "resident": "ساكن" };
        const fallbackProfile = {
          id: user.id,
          email: user.email,
          name: meta.name || "",
          phone: meta.phone || "",
          buildingId: meta.buildingId,
          buildingName: buildingInfo?.name || meta.buildingName || "",
          unitCode: meta.unitCode,
          floor: meta.floor || "",
          type: meta.type || "مالك",
          role: metaRole,
          adminRole: meta.adminRole || metaRoleLabels[metaRole] || "ساكن",
        };
        await kv.set(`auth:${user.id}`, fallbackProfile);
        return c.json({ profile: fallbackProfile });
      }
      // Last resort: search join requests
      const userPhone = meta.phone || user.email?.replace("@mollak.app", "");
      if (userPhone) {
        console.log("POST Auth/me: Searching join requests for phone:", userPhone);
        const buildingsList = await kv.get("buildings_list") || [];
        for (const bEntry of buildingsList) {
          const joinReqs = await kv.get(bKey(bEntry.id, "join_requests")) || [];
          const match = joinReqs.find((r: any) =>
            r.phone?.replace(/\s/g, "") === userPhone.replace(/\s/g, "") && r.status === "approved"
          );
          if (match) {
            const bInfo = await kv.get(bKey(bEntry.id, "info"));
            const matchRole = match.role || "resident";
            const matchRoleLabels: Record<string, string> = { "treasurer": "أمين الصندوق", "board_member": "عضو اتحاد", "resident": "ساكن" };
            const recoveredProfile = {
              id: user.id,
              email: user.email,
              name: match.name || "",
              phone: match.phone || "",
              buildingId: bEntry.id,
              buildingName: bInfo?.name || "",
              unitCode: match.unitCode || "",
              floor: match.floor || "",
              type: match.type || "مالك",
              role: matchRole,
              adminRole: matchRoleLabels[matchRole] || "ساكن",
            };
            await kv.set(`auth:${user.id}`, recoveredProfile);
            await kv.set(`auth:email:${user.email}`, user.id);
            console.log("POST Auth/me: Recovered profile from join requests for", user.id);
            return c.json({ profile: recoveredProfile });
          }
        }
      }
      return c.json({ error: "Resident profile not found — لم يتم العثور على بيانات الساكن" }, 404);
    }

    // Normalize: ensure profile always has 'id' field
    const normalizedProfile = {
      ...profile,
      id: profile.id || profile.userId || user.id,
    };
    if (!profile.id) {
      await kv.set(`auth:${user.id}`, normalizedProfile);
    }

    // Check if resident is banned (skip for admins)
    if (normalizedProfile.role !== "admin" && normalizedProfile.buildingId && normalizedProfile.phone) {
      try {
        const joinReqs = await kv.get(bKey(normalizedProfile.buildingId, "join_requests")) || [];
        const residentReq = (joinReqs as any[]).find((r: any) =>
          r.phone?.replace(/\s/g, "") === normalizedProfile.phone.replace(/\s/g, "") && r.status === "approved"
        );
        if (residentReq?.banned) {
          return c.json({ error: "تم حظر حسابك — تواصل مع إدارة المبنى لمزيد من المعلومات", banned: true }, 403);
        }
      } catch (banCheckErr: any) {
        console.log("POST Auth/me: ban check error (non-fatal):", banCheckErr.message);
      }
    }

    return c.json({ profile: normalizedProfile });
  } catch (err: any) {
    console.log("Error in POST /auth/me:", err.message);
    return c.json({ error: `Error fetching user profile: ${err.message}` }, 500);
  }
});

// PUT /auth/profile — update resident's optional profile fields
app.put("/make-server-86a3da15/auth/profile", async (c) => {
  try {
    let body: any;
    try {
      body = await c.req.json();
    } catch (parseErr: any) {
      console.log("PUT auth/profile: Failed to parse request body:", parseErr.message);
      return c.json({ error: "فشل في قراءة البيانات المرسلة — تأكد من صحة الطلب" }, 400);
    }
    const accessToken = body.token;
    if (!accessToken) {
      return c.json({ error: "Missing authorization token" }, 401);
    }
    if (accessToken === Deno.env.get("SUPABASE_ANON_KEY")) {
      return c.json({ error: "Invalid token — received anon key instead of user JWT" }, 401);
    }

    const { data: { user }, error } = await supabaseAdmin.auth.getUser(accessToken);
    if (error || !user) {
      console.log("PUT auth/profile: Auth failed:", error?.message);
      return c.json({ error: "Invalid or expired token" }, 401);
    }

    const existing = await kv.get(`auth:${user.id}`);
    if (!existing) {
      return c.json({ error: "Profile not found" }, 404);
    }

    // Allowed optional fields to update
    const { name, phone, gender, birthDate, bio, emergencyContact, emergencyPhone, nationalId, avatarBase64 } = body;

    const updates: Record<string, any> = {};
    if (name !== undefined) updates.name = name;
    if (phone !== undefined) updates.phone = phone;
    if (gender !== undefined) updates.gender = gender;
    if (birthDate !== undefined) updates.birthDate = birthDate;
    if (bio !== undefined) updates.bio = bio;
    if (emergencyContact !== undefined) updates.emergencyContact = emergencyContact;
    if (emergencyPhone !== undefined) updates.emergencyPhone = emergencyPhone;
    if (nationalId !== undefined) updates.nationalId = nationalId;
    if (avatarBase64 !== undefined) updates.avatarBase64 = avatarBase64; // base64 compressed image
    // Allow board members to set their unit (admin, treasurer, board_member)
    if (body.unitCode !== undefined) updates.unitCode = body.unitCode;
    if (body.floor !== undefined) updates.floor = body.floor;
    if (body.type !== undefined && (body.type === "مالك" || body.type === "مستأجر")) updates.type = body.type;

    const updatedProfile = { ...existing, ...updates, id: existing.id || user.id };
    await kv.set(`auth:${user.id}`, updatedProfile);

    console.log("PUT auth/profile: Updated profile for", user.id, "fields:", Object.keys(updates), "avatarIncluded:", !!updates.avatarBase64, "avatarLength:", typeof updates.avatarBase64 === "string" ? updates.avatarBase64.length : "null/undefined");
    return c.json({ profile: updatedProfile, message: "تم تحديث البروفايل بنجاح" });
  } catch (err: any) {
    console.log("Error in PUT /auth/profile:", err.message);
    return c.json({ error: `Error updating profile: ${err.message}` }, 500);
  }
});

// ===================================================================
// Advances — CRUD (Building-scoped)
// ===================================================================

// GET all advances for the active building
app.get("/make-server-86a3da15/advances", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const advances = await kv.get(bKey(buildingId, "advances"));
    return c.json(Array.isArray(advances) ? advances : []);
  } catch (err: any) {
    console.log("Error fetching advances:", err.message);
    return c.json({ error: `Error fetching advances: ${err.message}` }, 500);
  }
});

// CREATE a new advance
app.post("/make-server-86a3da15/advances", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const body = await c.req.json();
    const { person, amount, reason, date, dueDate, approvedBy } = body;
    if (!person || !amount || amount <= 0) {
      return c.json({ error: "Missing required fields: person, amount (must be > 0)" }, 400);
    }

    const advance = {
      id: `adv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      person,
      amount: Number(amount),
      reason: reason || "",
      date: date || new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" }),
      dueDate: dueDate || "",
      approvedBy: approvedBy || "رئيس الاتحاد",
      status: "active",
      createdAt: new Date().toISOString(),
    };

    const key = bKey(buildingId, "advances");
    const existing = await kv.get(key);
    const advances = Array.isArray(existing) ? existing : [];
    advances.unshift(advance);
    await kv.set(key, advances);

    await logActivity(buildingId, {
      type: "advance_created",
      title: "تسجيل سلفة جديدة",
      description: `${person} — ${Number(amount).toLocaleString("en-US")} ج.م — ${reason || "بدون سبب"}`,
      icon: "Banknote",
      color: "#6366f1",
      metadata: { advanceId: advance.id, person, amount },
    });

    return c.json({ message: "Advance created successfully", advance });
  } catch (err: any) {
    console.log("Error creating advance:", err.message);
    return c.json({ error: `Error creating advance: ${err.message}` }, 500);
  }
});

// UPDATE an advance
app.put("/make-server-86a3da15/advances/:advanceId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const advanceId = c.req.param("advanceId");
    const body = await c.req.json();
    const key = bKey(buildingId, "advances");
    const existing = await kv.get(key);
    const advances = Array.isArray(existing) ? existing : [];
    const idx = advances.findIndex((a: any) => a.id === advanceId);
    if (idx === -1) {
      return c.json({ error: `Advance not found: ${advanceId}` }, 404);
    }

    const oldStatus = advances[idx].status;
    advances[idx] = { ...advances[idx], ...body, id: advanceId };
    await kv.set(key, advances);

    // Log status change if applicable
    const newStatus = body.status || oldStatus;
    if (newStatus !== oldStatus) {
      const statusLabels: Record<string, string> = { active: "نشطة", returned: "مُرتجعة", overdue: "متأخرة" };
      await logActivity(buildingId, {
        type: "advance_status_changed",
        title: newStatus === "returned" ? "إرجاع سلفة" : "تحديث حالة سلفة",
        description: `${advances[idx].person} — ${Number(advances[idx].amount).toLocaleString("en-US")} ج.م — ${statusLabels[newStatus] || newStatus}`,
        icon: newStatus === "returned" ? "CheckCircle" : "Banknote",
        color: newStatus === "returned" ? "#22c55e" : "#F59E0B",
        metadata: { advanceId, oldStatus, newStatus },
      });
    } else {
      await logActivity(buildingId, {
        type: "advance_updated",
        title: "تعديل سلفة",
        description: `تم تعديل سلفة ${advances[idx].person}`,
        icon: "Pencil",
        color: "#F59E0B",
        metadata: { advanceId },
      });
    }

    return c.json({ message: "Advance updated successfully", advance: advances[idx] });
  } catch (err: any) {
    console.log("Error updating advance:", err.message);
    return c.json({ error: `Error updating advance: ${err.message}` }, 500);
  }
});

// DELETE an advance
app.delete("/make-server-86a3da15/advances/:advanceId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const advanceId = c.req.param("advanceId");
    const key = bKey(buildingId, "advances");
    const existing = await kv.get(key);
    const advances = Array.isArray(existing) ? existing : [];
    const deleted = advances.find((a: any) => a.id === advanceId);
    const filtered = advances.filter((a: any) => a.id !== advanceId);
    if (filtered.length === advances.length) {
      return c.json({ error: `Advance not found: ${advanceId}` }, 404);
    }
    await kv.set(key, filtered);

    await logActivity(buildingId, {
      type: "advance_deleted",
      title: "حذف سلفة",
      description: `تم حذف سلفة ${deleted?.person || ""} — ${Number(deleted?.amount || 0).toLocaleString("en-US")} ج.م`,
      icon: "Trash",
      color: "#ef4444",
      metadata: { advanceId },
    });

    return c.json({ message: "Advance deleted successfully" });
  } catch (err: any) {
    console.log("Error deleting advance:", err.message);
    return c.json({ error: `Error deleting advance: ${err.message}` }, 500);
  }
});

// ===================================================================
// Expenses — CRUD (Building-scoped)
// ===================================================================

// GET all expenses
app.get("/make-server-86a3da15/expenses", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const expenses = await kv.get(bKey(buildingId, "expenses"));
    return c.json(Array.isArray(expenses) ? expenses : []);
  } catch (err: any) {
    console.log("Error fetching expenses:", err.message);
    return c.json({ error: `Error fetching expenses: ${err.message}` }, 500);
  }
});

// CREATE a new expense
app.post("/make-server-86a3da15/expenses", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const body = await c.req.json();
    const { title, unitPrice, quantity, category, type, date, endDate, image } = body;
    if (!title || !unitPrice || unitPrice <= 0) {
      return c.json({ error: "Missing required fields: title, unitPrice (must be > 0)" }, 400);
    }

    const qty = Math.max(1, Number(quantity) || 1);
    const amount = Number(unitPrice) * qty;

    const expense = {
      id: `exp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      title,
      unitPrice: Number(unitPrice),
      quantity: qty,
      amount,
      category: category || "أخرى",
      type: type || "مؤقت",
      date: date || new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" }),
      endDate: type === "مؤقت" && endDate ? endDate : undefined,
      image: image || undefined,
      createdAt: new Date().toISOString(),
    };

    const key = bKey(buildingId, "expenses");
    const existing = await kv.get(key);
    const expenses = Array.isArray(existing) ? existing : [];
    expenses.unshift(expense);
    await kv.set(key, expenses);

    await logActivity(buildingId, {
      type: "expense_created",
      title: "إضافة مصروف",
      description: `${title} — ${amount.toLocaleString("en-US")} ج.م — ${category || "أخرى"}`,
      icon: "Receipt",
      color: "#ef4444",
      metadata: { expenseId: expense.id, amount, category },
    });

    return c.json({ message: "Expense created successfully", expense });
  } catch (err: any) {
    console.log("Error creating expense:", err.message);
    return c.json({ error: `Error creating expense: ${err.message}` }, 500);
  }
});

// UPDATE an expense
app.put("/make-server-86a3da15/expenses/:expenseId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const expenseId = c.req.param("expenseId");
    const body = await c.req.json();
    const key = bKey(buildingId, "expenses");
    const existing = await kv.get(key);
    const expenses = Array.isArray(existing) ? existing : [];
    const idx = expenses.findIndex((e: any) => e.id === expenseId);
    if (idx === -1) {
      return c.json({ error: `Expense not found: ${expenseId}` }, 404);
    }

    // Recalculate amount if unitPrice or quantity changed
    const unitPrice = body.unitPrice !== undefined ? Number(body.unitPrice) : expenses[idx].unitPrice;
    const quantity = body.quantity !== undefined ? Math.max(1, Number(body.quantity)) : expenses[idx].quantity;
    const amount = unitPrice * quantity;

    expenses[idx] = { ...expenses[idx], ...body, unitPrice, quantity, amount, id: expenseId };
    await kv.set(key, expenses);

    await logActivity(buildingId, {
      type: "expense_updated",
      title: "تعديل مصروف",
      description: `تم تعديل "${expenses[idx].title}" — ${amount.toLocaleString("en-US")} ج.م`,
      icon: "Pencil",
      color: "#F59E0B",
      metadata: { expenseId },
    });

    return c.json({ message: "Expense updated successfully", expense: expenses[idx] });
  } catch (err: any) {
    console.log("Error updating expense:", err.message);
    return c.json({ error: `Error updating expense: ${err.message}` }, 500);
  }
});

// STOP a recurring expense (set stoppedAt)
app.put("/make-server-86a3da15/expenses/:expenseId/stop", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const expenseId = c.req.param("expenseId");
    const key = bKey(buildingId, "expenses");
    const existing = await kv.get(key);
    const expenses = Array.isArray(existing) ? existing : [];
    const idx = expenses.findIndex((e: any) => e.id === expenseId);
    if (idx === -1) {
      return c.json({ error: `Expense not found: ${expenseId}` }, 404);
    }

    if (expenses[idx].type !== "دائم") {
      return c.json({ error: "Only recurring expenses can be stopped" }, 400);
    }

    expenses[idx].stoppedAt = new Date().toISOString();
    await kv.set(key, expenses);

    await logActivity(buildingId, {
      type: "expense_stopped",
      title: "إيقاف مصروف دائم",
      description: `تم إيقاف "${expenses[idx].title}" — ${expenses[idx].amount?.toLocaleString("en-US")} ج.م`,
      icon: "CircleStop",
      color: "#ef4444",
      metadata: { expenseId },
    });

    return c.json({ message: "Recurring expense stopped", expense: expenses[idx] });
  } catch (err: any) {
    console.log("Error stopping expense:", err.message);
    return c.json({ error: `Error stopping expense: ${err.message}` }, 500);
  }
});

// REACTIVATE a stopped recurring expense
app.put("/make-server-86a3da15/expenses/:expenseId/reactivate", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const expenseId = c.req.param("expenseId");
    const key = bKey(buildingId, "expenses");
    const existing = await kv.get(key);
    const expenses = Array.isArray(existing) ? existing : [];
    const idx = expenses.findIndex((e: any) => e.id === expenseId);
    if (idx === -1) {
      return c.json({ error: `Expense not found: ${expenseId}` }, 404);
    }

    delete expenses[idx].stoppedAt;
    await kv.set(key, expenses);

    await logActivity(buildingId, {
      type: "expense_reactivated",
      title: "إعادة تفعيل مصروف دائم",
      description: `تم إعادة تفعيل "${expenses[idx].title}" — ${expenses[idx].amount?.toLocaleString("en-US")} ج.م`,
      icon: "RotateCcw",
      color: "#0D9488",
      metadata: { expenseId },
    });

    return c.json({ message: "Recurring expense reactivated", expense: expenses[idx] });
  } catch (err: any) {
    console.log("Error reactivating expense:", err.message);
    return c.json({ error: `Error reactivating expense: ${err.message}` }, 500);
  }
});

// DELETE an expense
app.delete("/make-server-86a3da15/expenses/:expenseId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const expenseId = c.req.param("expenseId");
    const key = bKey(buildingId, "expenses");
    const existing = await kv.get(key);
    const expenses = Array.isArray(existing) ? existing : [];
    const deleted = expenses.find((e: any) => e.id === expenseId);
    const filtered = expenses.filter((e: any) => e.id !== expenseId);
    if (filtered.length === expenses.length) {
      return c.json({ error: `Expense not found: ${expenseId}` }, 404);
    }
    await kv.set(key, filtered);

    await logActivity(buildingId, {
      type: "expense_deleted",
      title: "حذف مصروف",
      description: `تم حذف "${deleted?.title || ""}" — ${Number(deleted?.amount || 0).toLocaleString("en-US")} ج.م`,
      icon: "Trash",
      color: "#ef4444",
      metadata: { expenseId },
    });

    return c.json({ message: "Expense deleted successfully" });
  } catch (err: any) {
    console.log("Error deleting expense:", err.message);
    return c.json({ error: `Error deleting expense: ${err.message}` }, 500);
  }
});

// PUBLIC: Get advances for residents (read-only, same building)
app.get("/make-server-86a3da15/resident/advances", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const advances = await kv.get(bKey(buildingId, "advances"));
    const list = Array.isArray(advances) ? advances : [];
    // Return only safe fields (no internal IDs)
    return c.json(list.map((a: any) => ({
      id: a.id,
      person: a.person,
      amount: a.amount,
      reason: a.reason,
      date: a.date,
      dueDate: a.dueDate,
      status: a.status,
      approvedBy: a.approvedBy,
    })));
  } catch (err: any) {
    console.log("Error fetching resident advances:", err.message);
    return c.json({ error: `Error fetching resident advances: ${err.message}` }, 500);
  }
});

// ===================================================================
// Revenues — CRUD (Building-scoped)
// ===================================================================

// GET all revenues
app.get("/make-server-86a3da15/revenues", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const revenues = await kv.get(bKey(buildingId, "revenues"));
    return c.json(Array.isArray(revenues) ? revenues : []);
  } catch (err: any) {
    console.log("Error fetching revenues:", err.message);
    return c.json({ error: `Error fetching revenues: ${err.message}` }, 500);
  }
});

// CREATE a new revenue
app.post("/make-server-86a3da15/revenues", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const body = await c.req.json();
    const { title, amount, category, type, date } = body;
    if (!title || !amount || amount <= 0) {
      return c.json({ error: "Missing required fields: title, amount (must be > 0)" }, 400);
    }

    const revenue = {
      id: `rev-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      title,
      amount: Number(amount),
      category: category || "أخرى",
      type: type || "مؤقت",
      date: date || new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" }),
      createdAt: new Date().toISOString(),
    };

    const key = bKey(buildingId, "revenues");
    const existing = await kv.get(key);
    const revenues = Array.isArray(existing) ? existing : [];
    revenues.unshift(revenue);
    await kv.set(key, revenues);

    await logActivity(buildingId, {
      type: "revenue_created",
      title: "إضافة إيراد",
      description: `${title} — ${Number(amount).toLocaleString("en-US")} ج.م — ${category || "أخرى"}`,
      icon: "TrendingUp",
      color: "#0D9488",
      metadata: { revenueId: revenue.id, amount: Number(amount), category },
    });

    return c.json({ message: "Revenue created successfully", revenue });
  } catch (err: any) {
    console.log("Error creating revenue:", err.message);
    return c.json({ error: `Error creating revenue: ${err.message}` }, 500);
  }
});

// UPDATE a revenue
app.put("/make-server-86a3da15/revenues/:revenueId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const revenueId = c.req.param("revenueId");
    const body = await c.req.json();
    const key = bKey(buildingId, "revenues");
    const existing = await kv.get(key);
    const revenues = Array.isArray(existing) ? existing : [];
    const idx = revenues.findIndex((r: any) => r.id === revenueId);
    if (idx === -1) {
      return c.json({ error: `Revenue not found: ${revenueId}` }, 404);
    }

    revenues[idx] = { ...revenues[idx], ...body, id: revenueId };
    if (body.amount !== undefined) revenues[idx].amount = Number(body.amount);
    await kv.set(key, revenues);

    await logActivity(buildingId, {
      type: "revenue_updated",
      title: "تعديل إيراد",
      description: `تم تعديل "${revenues[idx].title}" — ${Number(revenues[idx].amount).toLocaleString("en-US")} ج.م`,
      icon: "Pencil",
      color: "#F59E0B",
      metadata: { revenueId },
    });

    return c.json({ message: "Revenue updated successfully", revenue: revenues[idx] });
  } catch (err: any) {
    console.log("Error updating revenue:", err.message);
    return c.json({ error: `Error updating revenue: ${err.message}` }, 500);
  }
});

// STOP a recurring revenue (set stoppedAt)
app.put("/make-server-86a3da15/revenues/:revenueId/stop", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const revenueId = c.req.param("revenueId");
    const key = bKey(buildingId, "revenues");
    const existing = await kv.get(key);
    const revenues = Array.isArray(existing) ? existing : [];
    const idx = revenues.findIndex((r: any) => r.id === revenueId);
    if (idx === -1) return c.json({ error: `Revenue not found: ${revenueId}` }, 404);
    if (revenues[idx].type !== "دائم") return c.json({ error: "Only recurring revenues can be stopped" }, 400);

    revenues[idx].stoppedAt = new Date().toISOString();
    await kv.set(key, revenues);

    await logActivity(buildingId, {
      type: "revenue_stopped",
      title: "إيقاف إيراد دائم",
      description: `تم إيقاف "${revenues[idx].title}" — ${revenues[idx].amount?.toLocaleString("en-US")} ج.م`,
      icon: "CircleStop",
      color: "#ef4444",
      metadata: { revenueId },
    });

    return c.json({ message: "Recurring revenue stopped", revenue: revenues[idx] });
  } catch (err: any) {
    console.log("Error stopping revenue:", err.message);
    return c.json({ error: `Error stopping revenue: ${err.message}` }, 500);
  }
});

// REACTIVATE a stopped recurring revenue
app.put("/make-server-86a3da15/revenues/:revenueId/reactivate", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const revenueId = c.req.param("revenueId");
    const key = bKey(buildingId, "revenues");
    const existing = await kv.get(key);
    const revenues = Array.isArray(existing) ? existing : [];
    const idx = revenues.findIndex((r: any) => r.id === revenueId);
    if (idx === -1) return c.json({ error: `Revenue not found: ${revenueId}` }, 404);

    delete revenues[idx].stoppedAt;
    await kv.set(key, revenues);

    await logActivity(buildingId, {
      type: "revenue_reactivated",
      title: "إعادة تفعيل إيراد دائم",
      description: `تم إعادة تفعيل "${revenues[idx].title}" — ${revenues[idx].amount?.toLocaleString("en-US")} ج.م`,
      icon: "RotateCcw",
      color: "#0D9488",
      metadata: { revenueId },
    });

    return c.json({ message: "Recurring revenue reactivated", revenue: revenues[idx] });
  } catch (err: any) {
    console.log("Error reactivating revenue:", err.message);
    return c.json({ error: `Error reactivating revenue: ${err.message}` }, 500);
  }
});

// DELETE a revenue
app.delete("/make-server-86a3da15/revenues/:revenueId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const revenueId = c.req.param("revenueId");
    const key = bKey(buildingId, "revenues");
    const existing = await kv.get(key);
    const revenues = Array.isArray(existing) ? existing : [];
    const deleted = revenues.find((r: any) => r.id === revenueId);
    const filtered = revenues.filter((r: any) => r.id !== revenueId);
    if (filtered.length === revenues.length) {
      return c.json({ error: `Revenue not found: ${revenueId}` }, 404);
    }
    await kv.set(key, filtered);

    await logActivity(buildingId, {
      type: "revenue_deleted",
      title: "حذف إيراد",
      description: `تم حذف "${deleted?.title || ""}" — ${Number(deleted?.amount || 0).toLocaleString("en-US")} ج.م`,
      icon: "Trash",
      color: "#ef4444",
      metadata: { revenueId },
    });

    return c.json({ message: "Revenue deleted successfully" });
  } catch (err: any) {
    console.log("Error deleting revenue:", err.message);
    return c.json({ error: `Error deleting revenue: ${err.message}` }, 500);
  }
});

// ===================================================================
// Announcements — Building-scoped
// ===================================================================

interface AnnouncementData {
  id: string;
  title: string;
  description: string;
  category: string;
  date: string;
  timeFrom: string;
  timeTo: string;
  urgent: boolean;
  author: string;
  createdAt: string;
}

// GET all announcements
app.get("/make-server-86a3da15/announcements", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const existing = await kv.get(bKey(buildingId, "announcements"));
    const announcements: AnnouncementData[] = Array.isArray(existing) ? existing : [];
    announcements.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return c.json(announcements);
  } catch (err: any) {
    console.log("Error fetching announcements:", err.message);
    return c.json({ error: `Error fetching announcements: ${err.message}` }, 500);
  }
});

// CREATE announcement
app.post("/make-server-86a3da15/announcements", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const body = await c.req.json();
    const { title, description, category, date, timeFrom, timeTo, urgent, author } = body;
    if (!title || !description) {
      return c.json({ error: "عنوان الإعلان والتفاصيل مطلوبان" }, 400);
    }
    const newAnn: AnnouncementData = {
      id: `ann-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      title,
      description,
      category: category || "عام",
      date: date || "",
      timeFrom: timeFrom || "",
      timeTo: timeTo || "",
      urgent: !!urgent,
      author: author || "رئيس الاتحاد",
      createdAt: new Date().toISOString(),
    };
    const existing = await kv.get(bKey(buildingId, "announcements"));
    const list: AnnouncementData[] = Array.isArray(existing) ? existing : [];
    list.unshift(newAnn);
    await kv.set(bKey(buildingId, "announcements"), list);
    await logActivity(buildingId, {
      type: "announcement",
      title: "إعلان جديد",
      description: `تم نشر إعلان: ${title}`,
      icon: "Megaphone",
      color: urgent ? "#F59E0B" : "#0D9488",
      metadata: { announcementId: newAnn.id, category },
    });
    // Notify all residents about the new announcement
    await pushNotificationToAll(buildingId, {
      type: "announcement",
      title: urgent ? "إعلان عاجل" : "إعلان جديد",
      body: title,
      icon: "Megaphone",
      color: urgent ? "#F59E0B" : "#0D9488",
      metadata: { announcementId: newAnn.id },
    });
    return c.json({ message: "تم نشر الإعلان بنجاح", announcement: newAnn });
  } catch (err: any) {
    console.log("Error creating announcement:", err.message);
    return c.json({ error: `Error creating announcement: ${err.message}` }, 500);
  }
});

// UPDATE announcement
app.put("/make-server-86a3da15/announcements/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const annId = c.req.param("id");
    const body = await c.req.json();
    const existing = await kv.get(bKey(buildingId, "announcements"));
    const list: AnnouncementData[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((a) => a.id === annId);
    if (idx === -1) return c.json({ error: "الإعلان غير موجود" }, 404);
    list[idx] = { ...list[idx], ...body };
    await kv.set(bKey(buildingId, "announcements"), list);
    await logActivity(buildingId, {
      type: "announcement",
      title: "تعديل إعلان",
      description: `تم تعديل إعلان: ${list[idx].title}`,
      icon: "Megaphone",
      color: "#0D9488",
      metadata: { announcementId: annId },
    });
    return c.json({ message: "تم تحديث الإعلان بنجاح", announcement: list[idx] });
  } catch (err: any) {
    console.log("Error updating announcement:", err.message);
    return c.json({ error: `Error updating announcement: ${err.message}` }, 500);
  }
});

// DELETE announcement
app.delete("/make-server-86a3da15/announcements/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const annId = c.req.param("id");
    const existing = await kv.get(bKey(buildingId, "announcements"));
    const list: AnnouncementData[] = Array.isArray(existing) ? existing : [];
    const ann = list.find((a) => a.id === annId);
    if (!ann) return c.json({ error: "الإعلان غير موجود" }, 404);
    const filtered = list.filter((a) => a.id !== annId);
    await kv.set(bKey(buildingId, "announcements"), filtered);
    await logActivity(buildingId, {
      type: "announcement",
      title: "حذف إعلان",
      description: `تم حذف إعلان: ${ann.title}`,
      icon: "Trash2",
      color: "#dc2626",
      metadata: { announcementId: annId },
    });
    return c.json({ message: "تم حذف الإعلان بنجاح" });
  } catch (err: any) {
    console.log("Error deleting announcement:", err.message);
    return c.json({ error: `Error deleting announcement: ${err.message}` }, 500);
  }
});

// ===================================================================
// Directory (Contacts) — Building-scoped
// ===================================================================

interface DirectoryContact {
  id: string;
  name: string;
  specialty: string;
  phone: string;
  rating: number;
  area: string;
  available: boolean;
  createdAt: string;
}

// GET all contacts
app.get("/make-server-86a3da15/directory", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const existing = await kv.get(bKey(buildingId, "directory"));
    const contacts: DirectoryContact[] = Array.isArray(existing) ? existing : [];
    contacts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return c.json(contacts);
  } catch (err: any) {
    console.log("Error fetching directory:", err.message);
    return c.json({ error: `Error fetching directory: ${err.message}` }, 500);
  }
});

// CREATE contact
app.post("/make-server-86a3da15/directory", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const body = await c.req.json();
    const { name, specialty, phone, rating, area, available } = body;
    if (!name || !phone) {
      return c.json({ error: "الاسم ورقم الهاتف مطلوبان" }, 400);
    }
    const newContact: DirectoryContact = {
      id: `dir-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name,
      specialty: specialty || "أخرى",
      phone,
      rating: typeof rating === "number" ? rating : 5,
      area: area || "",
      available: available !== false,
      createdAt: new Date().toISOString(),
    };
    const existing = await kv.get(bKey(buildingId, "directory"));
    const list: DirectoryContact[] = Array.isArray(existing) ? existing : [];
    list.unshift(newContact);
    await kv.set(bKey(buildingId, "directory"), list);
    await logActivity(buildingId, {
      type: "directory",
      title: "جهة اتصال جديدة",
      description: `تم إضافة ${name} (${specialty}) إلى الأرقام`,
      icon: "Phone",
      color: "#0D9488",
      metadata: { contactId: newContact.id, specialty },
    });
    return c.json({ message: "تم إضافة جهة الاتصال بنجاح", contact: newContact });
  } catch (err: any) {
    console.log("Error creating directory contact:", err.message);
    return c.json({ error: `Error creating directory contact: ${err.message}` }, 500);
  }
});

// UPDATE contact
app.put("/make-server-86a3da15/directory/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const contactId = c.req.param("id");
    const body = await c.req.json();
    const existing = await kv.get(bKey(buildingId, "directory"));
    const list: DirectoryContact[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((ct) => ct.id === contactId);
    if (idx === -1) return c.json({ error: "جهة الاتصال غير موجودة" }, 404);
    list[idx] = { ...list[idx], ...body };
    await kv.set(bKey(buildingId, "directory"), list);
    await logActivity(buildingId, {
      type: "directory",
      title: "تعديل جهة اتصال",
      description: `تم تعديل بيانات ${list[idx].name} في الأرقام`,
      icon: "Phone",
      color: "#0D9488",
      metadata: { contactId },
    });
    return c.json({ message: "تم تحديث جهة الاتصال بنجاح", contact: list[idx] });
  } catch (err: any) {
    console.log("Error updating directory contact:", err.message);
    return c.json({ error: `Error updating directory contact: ${err.message}` }, 500);
  }
});

// DELETE contact
app.delete("/make-server-86a3da15/directory/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const contactId = c.req.param("id");
    const existing = await kv.get(bKey(buildingId, "directory"));
    const list: DirectoryContact[] = Array.isArray(existing) ? existing : [];
    const contact = list.find((ct) => ct.id === contactId);
    if (!contact) return c.json({ error: "جهة الاتصال غير موجودة" }, 404);
    const filtered = list.filter((ct) => ct.id !== contactId);
    await kv.set(bKey(buildingId, "directory"), filtered);
    await logActivity(buildingId, {
      type: "directory",
      title: "حذف جهة اتصال",
      description: `تم حذف ${contact.name} من الأرقام`,
      icon: "Trash2",
      color: "#dc2626",
      metadata: { contactId },
    });
    return c.json({ message: "تم حذف جهة الاتصال بنجاح" });
  } catch (err: any) {
    console.log("Error deleting directory contact:", err.message);
    return c.json({ error: `Error deleting directory contact: ${err.message}` }, 500);
  }
});

// ===================================================================
// Events (المناسبات) — Building-scoped
// ===================================================================

interface EventComment {
  id: string;
  name: string;
  unit: string;
  text: string;
  createdAt: string;
}

interface EventData {
  id: string;
  type: "congratulation" | "condolence";
  title: string;
  resident: string;
  unit: string;
  message: string;
  date: string;
  reactions: number;
  comments: EventComment[];
  createdAt: string;
}

// GET all events
app.get("/make-server-86a3da15/events", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const existing = await kv.get(bKey(buildingId, "events"));
    const events: EventData[] = Array.isArray(existing) ? existing : [];
    events.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return c.json(events);
  } catch (err: any) {
    console.log("Error fetching events:", err.message);
    return c.json({ error: `Error fetching events: ${err.message}` }, 500);
  }
});

// CREATE event
app.post("/make-server-86a3da15/events", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const body = await c.req.json();
    const { type, title, resident, unit, message, date } = body;
    if (!title || !resident) {
      return c.json({ error: "العنوان واسم الساكن مطلوبان" }, 400);
    }
    const newEvent: EventData = {
      id: `evt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      type: type || "congratulation",
      title,
      resident,
      unit: unit || "",
      message: message || "",
      date: date || new Date().toLocaleDateString("ar-u-nu-latn", { day: "numeric", month: "long", year: "numeric" }),
      reactions: 0,
      comments: [],
      createdAt: new Date().toISOString(),
    };
    const existing = await kv.get(bKey(buildingId, "events"));
    const list: EventData[] = Array.isArray(existing) ? existing : [];
    list.unshift(newEvent);
    await kv.set(bKey(buildingId, "events"), list);
    const typeLabel = type === "condolence" ? "تعزية" : "تهنئة";
    await logActivity(buildingId, {
      type: "event_created",
      title: `مناسبة جديدة — ${typeLabel}`,
      description: `${title} — ${resident} (وحدة ${unit || "—"})`,
      icon: type === "condolence" ? "Heart" : "PartyPopper",
      color: type === "condolence" ? "#6b7280" : "#0D9488",
      metadata: { eventId: newEvent.id, eventType: type },
    });
    // Notify all residents about the new event
    const eventTypeLabel = type === "condolence" ? "تعزية" : "تهنئة";
    await pushNotificationToAll(buildingId, {
      type: "event",
      title: `مناسبة جديدة — ${eventTypeLabel}`,
      body: `${title} — ${resident}`,
      icon: type === "condolence" ? "Heart" : "PartyPopper",
      color: type === "condolence" ? "#6b7280" : "#0D9488",
      metadata: { eventId: newEvent.id },
    });

    return c.json({ message: "تم إضافة المناسبة بنجاح", event: newEvent });
  } catch (err: any) {
    console.log("Error creating event:", err.message);
    return c.json({ error: `Error creating event: ${err.message}` }, 500);
  }
});

// UPDATE event
app.put("/make-server-86a3da15/events/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const eventId = c.req.param("id");
    const body = await c.req.json();
    const existing = await kv.get(bKey(buildingId, "events"));
    const list: EventData[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((e) => e.id === eventId);
    if (idx === -1) return c.json({ error: "المناسبة غير موجودة" }, 404);
    list[idx] = { ...list[idx], ...body, id: eventId };
    await kv.set(bKey(buildingId, "events"), list);
    await logActivity(buildingId, {
      type: "event_updated",
      title: "تعديل مناسبة",
      description: `تم تعديل: ${list[idx].title}`,
      icon: "Pencil",
      color: "#F59E0B",
      metadata: { eventId },
    });
    return c.json({ message: "تم تحديث المناسبة بنجاح", event: list[idx] });
  } catch (err: any) {
    console.log("Error updating event:", err.message);
    return c.json({ error: `Error updating event: ${err.message}` }, 500);
  }
});

// DELETE event
app.delete("/make-server-86a3da15/events/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const eventId = c.req.param("id");
    const existing = await kv.get(bKey(buildingId, "events"));
    const list: EventData[] = Array.isArray(existing) ? existing : [];
    const evt = list.find((e) => e.id === eventId);
    if (!evt) return c.json({ error: "المناسبة غير موجودة" }, 404);
    const filtered = list.filter((e) => e.id !== eventId);
    await kv.set(bKey(buildingId, "events"), filtered);
    await logActivity(buildingId, {
      type: "event_deleted",
      title: "حذف مناسبة",
      description: `تم حذف: ${evt.title}`,
      icon: "Trash2",
      color: "#dc2626",
      metadata: { eventId },
    });
    return c.json({ message: "تم حذف المناسبة بنجاح" });
  } catch (err: any) {
    console.log("Error deleting event:", err.message);
    return c.json({ error: `Error deleting event: ${err.message}` }, 500);
  }
});

// React to an event (increment reactions)
app.put("/make-server-86a3da15/events/:id/react", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const eventId = c.req.param("id");
    const existing = await kv.get(bKey(buildingId, "events"));
    const list: EventData[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((e) => e.id === eventId);
    if (idx === -1) return c.json({ error: "المناسبة غير موجودة" }, 404);
    list[idx].reactions = (list[idx].reactions || 0) + 1;
    await kv.set(bKey(buildingId, "events"), list);
    return c.json({ message: "تم التفاعل", reactions: list[idx].reactions });
  } catch (err: any) {
    console.log("Error reacting to event:", err.message);
    return c.json({ error: `Error reacting to event: ${err.message}` }, 500);
  }
});

// ADD comment to event
app.post("/make-server-86a3da15/events/:id/comments", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const eventId = c.req.param("id");
    const body = await c.req.json();
    const { name, unit, text } = body;
    if (!name || !text) return c.json({ error: "الاسم والتعليق مطلوبان" }, 400);
    const existing = await kv.get(bKey(buildingId, "events"));
    const list: EventData[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((e) => e.id === eventId);
    if (idx === -1) return c.json({ error: "المناسبة غير موجودة" }, 404);
    if (!list[idx].comments) list[idx].comments = [];
    const comment: EventComment = {
      id: `cmt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name,
      unit: unit || "",
      text,
      createdAt: new Date().toISOString(),
    };
    list[idx].comments.push(comment);
    await kv.set(bKey(buildingId, "events"), list);
    return c.json({ message: "تم إضافة التعليق", comment, comments: list[idx].comments });
  } catch (err: any) {
    console.log("Error adding comment to event:", err.message);
    return c.json({ error: `Error adding comment to event: ${err.message}` }, 500);
  }
});

// DELETE comment from event
app.delete("/make-server-86a3da15/events/:id/comments/:commentId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const eventId = c.req.param("id");
    const commentId = c.req.param("commentId");
    const existing = await kv.get(bKey(buildingId, "events"));
    const list: EventData[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((e) => e.id === eventId);
    if (idx === -1) return c.json({ error: "المناسبة غير موجودة" }, 404);
    if (!list[idx].comments) list[idx].comments = [];
    list[idx].comments = list[idx].comments.filter((cm) => cm.id !== commentId);
    await kv.set(bKey(buildingId, "events"), list);
    return c.json({ message: "تم حذف التعليق", comments: list[idx].comments });
  } catch (err: any) {
    console.log("Error deleting comment from event:", err.message);
    return c.json({ error: `Error deleting comment from event: ${err.message}` }, 500);
  }
});

// ===================================================================
// Donations (التبرعات) — Building-scoped
// ===================================================================

interface DonationCampaign {
  id: string;
  title: string;
  description: string;
  target: number;
  collected: number;
  donors: { name: string; amount: number; date: string }[];
  status: "active" | "completed";
  deadline: string;
  createdBy: string;
  createdAt: string;
}

// GET all donation campaigns
app.get("/make-server-86a3da15/donations", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const existing = await kv.get(bKey(buildingId, "donations"));
    const campaigns: DonationCampaign[] = Array.isArray(existing) ? existing : [];
    campaigns.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return c.json(campaigns);
  } catch (err: any) {
    console.log("Error fetching donations:", err.message);
    return c.json({ error: `Error fetching donations: ${err.message}` }, 500);
  }
});

// CREATE donation campaign
app.post("/make-server-86a3da15/donations", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const body = await c.req.json();
    const { title, description, target, deadline, createdBy } = body;
    if (!title || !target || target <= 0) {
      return c.json({ error: "العنوان والمبلغ المستهدف مطلوبان" }, 400);
    }
    const newCampaign: DonationCampaign = {
      id: `don-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      title,
      description: description || "",
      target,
      collected: 0,
      donors: [],
      status: "active",
      deadline: deadline || "",
      createdBy: createdBy || "رئيس الاتحاد",
      createdAt: new Date().toISOString(),
    };
    const existing = await kv.get(bKey(buildingId, "donations"));
    const list: DonationCampaign[] = Array.isArray(existing) ? existing : [];
    list.unshift(newCampaign);
    await kv.set(bKey(buildingId, "donations"), list);
    await logActivity(buildingId, {
      type: "donation_created",
      title: "حملة تبرع جديدة",
      description: `${title} — مستهدف ${target.toLocaleString("en-US")} ج.م`,
      icon: "Heart",
      color: "#0D9488",
      metadata: { campaignId: newCampaign.id },
    });
    // Notify all residents about the new donation campaign
    await pushNotificationToAll(buildingId, {
      type: "donation",
      title: "حملة تبرع جديدة",
      body: `${title} — مستهدف ${target.toLocaleString("en-US")} ج.م`,
      icon: "Heart",
      color: "#f43f5e",
      metadata: { campaignId: newCampaign.id },
    });

    return c.json({ message: "تم إنشاء حملة التبرع بنجاح", campaign: newCampaign });
  } catch (err: any) {
    console.log("Error creating donation:", err.message);
    return c.json({ error: `Error creating donation: ${err.message}` }, 500);
  }
});

// UPDATE donation campaign
app.put("/make-server-86a3da15/donations/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const campaignId = c.req.param("id");
    const body = await c.req.json();
    const existing = await kv.get(bKey(buildingId, "donations"));
    const list: DonationCampaign[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((d) => d.id === campaignId);
    if (idx === -1) return c.json({ error: "الحملة غير موجودة" }, 404);
    list[idx] = { ...list[idx], ...body, id: campaignId };
    await kv.set(bKey(buildingId, "donations"), list);
    await logActivity(buildingId, {
      type: "donation_updated",
      title: "تعديل حملة تبرع",
      description: `تم تعديل: ${list[idx].title}`,
      icon: "Pencil",
      color: "#F59E0B",
      metadata: { campaignId },
    });
    return c.json({ message: "تم تحديث الحملة بنجاح", campaign: list[idx] });
  } catch (err: any) {
    console.log("Error updating donation:", err.message);
    return c.json({ error: `Error updating donation: ${err.message}` }, 500);
  }
});

// DELETE donation campaign
app.delete("/make-server-86a3da15/donations/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const campaignId = c.req.param("id");
    const existing = await kv.get(bKey(buildingId, "donations"));
    const list: DonationCampaign[] = Array.isArray(existing) ? existing : [];
    const campaign = list.find((d) => d.id === campaignId);
    if (!campaign) return c.json({ error: "الحملة غير موجودة" }, 404);
    const filtered = list.filter((d) => d.id !== campaignId);
    await kv.set(bKey(buildingId, "donations"), filtered);
    await logActivity(buildingId, {
      type: "donation_deleted",
      title: "حذف حملة تبرع",
      description: `تم حذف: ${campaign.title}`,
      icon: "Trash2",
      color: "#dc2626",
      metadata: { campaignId },
    });
    return c.json({ message: "تم حذف الحملة بنجاح" });
  } catch (err: any) {
    console.log("Error deleting donation:", err.message);
    return c.json({ error: `Error deleting donation: ${err.message}` }, 500);
  }
});

// ADD donation to a campaign
app.post("/make-server-86a3da15/donations/:id/donate", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const campaignId = c.req.param("id");
    const body = await c.req.json();
    const { name, amount } = body;
    if (!name || !amount || amount <= 0) {
      return c.json({ error: "الاسم والمبلغ مطلوبان" }, 400);
    }
    const existing = await kv.get(bKey(buildingId, "donations"));
    const list: DonationCampaign[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((d) => d.id === campaignId);
    if (idx === -1) return c.json({ error: "الحملة غير موجودة" }, 404);
    if (list[idx].status !== "active") return c.json({ error: "الحملة مكتملة ولا تقبل تبرعات" }, 400);
    list[idx].donors.push({ name, amount, date: new Date().toISOString() });
    list[idx].collected += amount;
    // Auto-complete if target reached
    if (list[idx].collected >= list[idx].target) {
      list[idx].status = "completed";
    }
    await kv.set(bKey(buildingId, "donations"), list);
    await logActivity(buildingId, {
      type: "donation_received",
      title: "تبرع جديد",
      description: `${name} تبرع بمبلغ ${amount.toLocaleString("en-US")} ج.م لحملة "${list[idx].title}"`,
      icon: "Heart",
      color: "#6366f1",
      metadata: { campaignId, donorName: name, amount },
    });
    return c.json({ message: "تم تسجيل التبرع بنجاح", campaign: list[idx] });
  } catch (err: any) {
    console.log("Error adding donation:", err.message);
    return c.json({ error: `Error adding donation: ${err.message}` }, 500);
  }
});

// Toggle campaign status (active/completed)
app.put("/make-server-86a3da15/donations/:id/toggle-status", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const campaignId = c.req.param("id");
    const existing = await kv.get(bKey(buildingId, "donations"));
    const list: DonationCampaign[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((d) => d.id === campaignId);
    if (idx === -1) return c.json({ error: "الحملة غير موجودة" }, 404);
    list[idx].status = list[idx].status === "active" ? "completed" : "active";
    await kv.set(bKey(buildingId, "donations"), list);
    const statusLabel = list[idx].status === "active" ? "إعادة تفعيل" : "إغلاق";
    await logActivity(buildingId, {
      type: "donation_status_changed",
      title: `${statusLabel} حملة تبرع`,
      description: `${list[idx].title}`,
      icon: list[idx].status === "active" ? "Play" : "CheckCircle",
      color: list[idx].status === "active" ? "#0D9488" : "#6b7280",
      metadata: { campaignId },
    });
    return c.json({ message: "تم تحديث حالة الحملة", campaign: list[idx] });
  } catch (err: any) {
    console.log("Error toggling donation status:", err.message);
    return c.json({ error: `Error toggling donation status: ${err.message}` }, 500);
  }
});

// ===================================================================
// Donation Cash Requests (طلبات تبرع كاش) — Building-scoped
// ===================================================================

interface DonationCashRequest {
  id: string;
  campaignId: string;
  campaignTitle: string;
  residentName: string;
  unitCode: string;
  phone: string;
  amount: number;
  date: string;
  status: "pending" | "collected" | "cancelled";
  anonymous?: boolean;
}

// Resident requests cash donation
app.post("/make-server-86a3da15/donations/:id/request-cash", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const campaignId = c.req.param("id");
    const body = await c.req.json();
    const { residentName, unitCode, phone, amount, anonymous } = body;
    if (!residentName || !amount || amount <= 0) {
      return c.json({ error: "الاسم والمبلغ مطلوبان" }, 400);
    }
    const existing = await kv.get(bKey(buildingId, "donations"));
    const campaigns: DonationCampaign[] = Array.isArray(existing) ? existing : [];
    const campaign = campaigns.find((d) => d.id === campaignId);
    if (!campaign) return c.json({ error: "الحملة غير موجودة" }, 404);
    if (campaign.status !== "active") return c.json({ error: "الحملة مكتملة ولا تقبل تبرعات" }, 400);

    const now = new Date().toISOString();
    const newRequest: DonationCashRequest = {
      id: `dcr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      campaignId,
      campaignTitle: campaign.title,
      residentName: residentName || "",
      unitCode: unitCode || "",
      phone: phone || "",
      amount,
      date: now,
      status: "pending",
      anonymous: !!anonymous,
    };

    const reqKey = bKey(buildingId, "donation_cash_requests");
    const requests = await kv.get(reqKey) || [];
    const list: DonationCashRequest[] = Array.isArray(requests) ? requests : [];
    list.unshift(newRequest);
    await kv.set(reqKey, list);

    await logActivity(buildingId, {
      type: "donation_cash_requested",
      title: "تبرع بانتظار التحصيل",
      description: `${residentName} (شقة ${unitCode}) يريد التبرع بمبلغ ${amount.toLocaleString("en-US")} ج.م لحملة "${campaign.title}"`,
      icon: "Heart",
      color: "#6366f1",
      metadata: { campaignId, requestId: newRequest.id },
    });

    return c.json({ message: "تم تسجيل نية التبرع — بانتظار التحصيل", request: newRequest });
  } catch (err: any) {
    console.log("Error requesting donation cash:", err.message);
    return c.json({ error: `Error requesting donation cash: ${err.message}` }, 500);
  }
});

// Get all donation cash requests (for treasurer dashboard)
app.get("/make-server-86a3da15/donations/cash-requests", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const requests = await kv.get(bKey(buildingId, "donation_cash_requests")) || [];
    return c.json(Array.isArray(requests) ? requests : []);
  } catch (err: any) {
    console.log("Error fetching donation cash requests:", err.message);
    return c.json({ error: `Error fetching donation cash requests: ${err.message}` }, 500);
  }
});

// Confirm donation cash collection — adds to campaign
app.put("/make-server-86a3da15/donations/:id/confirm-cash/:requestId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const campaignId = c.req.param("id");
    const requestId = c.req.param("requestId");

    const reqKey = bKey(buildingId, "donation_cash_requests");
    const requests = await kv.get(reqKey) || [];
    const reqList: DonationCashRequest[] = Array.isArray(requests) ? requests : [];
    const reqIdx = reqList.findIndex((r) => r.id === requestId);
    if (reqIdx === -1) return c.json({ error: "طلب التبرع غير موجود" }, 404);
    if (reqList[reqIdx].status !== "pending") return c.json({ error: "تم معالجة هذا الطلب بالفعل" }, 400);
    reqList[reqIdx].status = "collected";
    await kv.set(reqKey, reqList);

    const donKey = bKey(buildingId, "donations");
    const donExisting = await kv.get(donKey);
    const donCampaigns: DonationCampaign[] = Array.isArray(donExisting) ? donExisting : [];
    const donIdx = donCampaigns.findIndex((d) => d.id === campaignId);
    if (donIdx === -1) return c.json({ error: "الحملة غير موجودة" }, 404);

    const req = reqList[reqIdx];
    donCampaigns[donIdx].donors.push({
      name: req.anonymous ? "متبرع مجهول" : req.residentName,
      amount: req.amount,
      date: new Date().toISOString(),
      anonymous: !!req.anonymous,
    });
    donCampaigns[donIdx].collected += req.amount;
    if (donCampaigns[donIdx].collected >= donCampaigns[donIdx].target) {
      donCampaigns[donIdx].status = "completed";
    }
    await kv.set(donKey, donCampaigns);

    await logActivity(buildingId, {
      type: "donation_cash_confirmed",
      title: "تم تحصيل تبرع",
      description: `تم تحصيل ${req.amount.toLocaleString("en-US")} ج.م من ${req.anonymous ? "متبرع مجهول" : req.residentName} لحملة "${donCampaigns[donIdx].title}"`,
      icon: "CheckCircle",
      color: "#0D9488",
      metadata: { campaignId, requestId, amount: req.amount },
    });
    // Notify the donor
    if (req.phone) {
      await pushNotification(buildingId, req.phone, {
        type: "donation_confirmed",
        title: "تم تحصيل تبرعك",
        body: `شكراً لتبرعك بمبلغ ${req.amount.toLocaleString("en-US")} ج.م لحملة "${donCampaigns[donIdx].title}"`,
        icon: "Heart",
        color: "#0D9488",
        metadata: { campaignId, requestId },
      });
    }

    return c.json({ message: "تم تحصيل التبرع وتحديث الحملة", campaign: donCampaigns[donIdx] });
  } catch (err: any) {
    console.log("Error confirming donation cash:", err.message);
    return c.json({ error: `Error confirming donation cash: ${err.message}` }, 500);
  }
});

// Cancel donation cash request (by resident themselves)
app.put("/make-server-86a3da15/donations/cancel-cash/:requestId", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const requestId = c.req.param("requestId");

    const reqKey = bKey(buildingId, "donation_cash_requests");
    const requests = await kv.get(reqKey) || [];
    const reqList: DonationCashRequest[] = Array.isArray(requests) ? requests : [];
    const reqIdx = reqList.findIndex((r) => r.id === requestId);
    if (reqIdx === -1) return c.json({ error: "طلب التبرع غير موجود" }, 404);
    if (reqList[reqIdx].status !== "pending") return c.json({ error: "لا يمكن إلغاء طلب تم معالجته" }, 400);
    reqList[reqIdx].status = "cancelled";
    await kv.set(reqKey, reqList);

    await logActivity(buildingId, {
      type: "donation_cash_cancelled",
      title: "إلغاء نية تبرع",
      description: `${reqList[reqIdx].residentName} ألغى نية التبرع بمبلغ ${reqList[reqIdx].amount.toLocaleString("en-US")} ج.م`,
      icon: "X",
      color: "#6b7280",
      metadata: { requestId },
    });

    return c.json({ message: "تم إلغاء طلب التبرع" });
  } catch (err: any) {
    console.log("Error cancelling donation cash:", err.message);
    return c.json({ error: `Error cancelling donation cash: ${err.message}` }, 500);
  }
});

// ===================================================================
// Voting / Polls (التصويت) — Building-scoped
// ===================================================================

interface PollOption {
  label: string;
  votes: number;
  voters: string[];
}

interface PollData {
  id: string;
  title: string;
  description: string;
  options: PollOption[];
  status: "active" | "ended";
  deadline: string;
  createdBy: string;
  createdAt: string;
}

// GET all polls
app.get("/make-server-86a3da15/polls", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const existing = await kv.get(bKey(buildingId, "polls"));
    const polls: PollData[] = Array.isArray(existing) ? existing : [];
    polls.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return c.json(polls);
  } catch (err: any) {
    console.log("Error fetching polls:", err.message);
    return c.json({ error: `Error fetching polls: ${err.message}` }, 500);
  }
});

// CREATE poll
app.post("/make-server-86a3da15/polls", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const body = await c.req.json();
    const { title, description, options, deadline, createdBy } = body;
    if (!title || !options || options.length < 2) {
      return c.json({ error: "العنوان وخيارين على الأقل مطلوبان" }, 400);
    }
    const newPoll: PollData = {
      id: `poll-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      title,
      description: description || "",
      options: options.map((label: string) => ({ label, votes: 0, voters: [] })),
      status: "active",
      deadline: deadline || "",
      createdBy: createdBy || "رئيس الاتحاد",
      createdAt: new Date().toISOString(),
    };
    const existing = await kv.get(bKey(buildingId, "polls"));
    const list: PollData[] = Array.isArray(existing) ? existing : [];
    list.unshift(newPoll);
    await kv.set(bKey(buildingId, "polls"), list);
    await logActivity(buildingId, {
      type: "poll_created",
      title: "تصويت جديد",
      description: `${title} — ${options.length} خيارات`,
      icon: "Vote",
      color: "#0D9488",
      metadata: { pollId: newPoll.id },
    });
    // Notify all residents about the new poll
    await pushNotificationToAll(buildingId, {
      type: "poll",
      title: "تصويت جديد",
      body: `${title} — ${options.length} خيارات — شارك برأيك!`,
      icon: "Vote",
      color: "#8b5cf6",
      metadata: { pollId: newPoll.id },
    });

    return c.json({ message: "تم إنشاء التصويت بنجاح", poll: newPoll });
  } catch (err: any) {
    console.log("Error creating poll:", err.message);
    return c.json({ error: `Error creating poll: ${err.message}` }, 500);
  }
});

// VOTE on a poll option
app.post("/make-server-86a3da15/polls/:id/vote", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const pollId = c.req.param("id");
    const body = await c.req.json();
    const { optionIndex, voterName } = body;
    if (optionIndex === undefined || optionIndex === null) {
      return c.json({ error: "يجب اختيار خيار" }, 400);
    }
    const existing = await kv.get(bKey(buildingId, "polls"));
    const list: PollData[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((p) => p.id === pollId);
    if (idx === -1) return c.json({ error: "التصويت غير موجود" }, 404);
    if (list[idx].status !== "active") return c.json({ error: "التصويت منتهي" }, 400);
    if (optionIndex < 0 || optionIndex >= list[idx].options.length) {
      return c.json({ error: "خيار غير صالح" }, 400);
    }
    const voterKey = voterName || "anonymous";
    const alreadyVoted = list[idx].options.some((opt) => opt.voters.includes(voterKey));
    if (alreadyVoted) {
      return c.json({ error: "لقد صوّت هذا الشخص بالفعل" }, 400);
    }
    list[idx].options[optionIndex].votes += 1;
    list[idx].options[optionIndex].voters.push(voterKey);
    await kv.set(bKey(buildingId, "polls"), list);
    await logActivity(buildingId, {
      type: "poll_vote",
      title: "صوت جديد",
      description: `${voterKey} صوّت في "${list[idx].title}"`,
      icon: "CheckCircle",
      color: "#6366f1",
      metadata: { pollId, optionIndex },
    });
    return c.json({ message: "تم تسجيل التصويت بنجاح", poll: list[idx] });
  } catch (err: any) {
    console.log("Error voting:", err.message);
    return c.json({ error: `Error voting: ${err.message}` }, 500);
  }
});

// END a poll
app.put("/make-server-86a3da15/polls/:id/end", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const pollId = c.req.param("id");
    const existing = await kv.get(bKey(buildingId, "polls"));
    const list: PollData[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((p) => p.id === pollId);
    if (idx === -1) return c.json({ error: "التصويت غير موجود" }, 404);
    list[idx].status = "ended";
    await kv.set(bKey(buildingId, "polls"), list);
    await logActivity(buildingId, {
      type: "poll_ended",
      title: "إنهاء تصويت",
      description: `تم إنهاء: ${list[idx].title}`,
      icon: "Ban",
      color: "#F59E0B",
      metadata: { pollId },
    });
    return c.json({ message: "تم إنهاء التصويت", poll: list[idx] });
  } catch (err: any) {
    console.log("Error ending poll:", err.message);
    return c.json({ error: `Error ending poll: ${err.message}` }, 500);
  }
});

// REACTIVATE a poll
app.put("/make-server-86a3da15/polls/:id/reactivate", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const pollId = c.req.param("id");
    const existing = await kv.get(bKey(buildingId, "polls"));
    const list: PollData[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((p) => p.id === pollId);
    if (idx === -1) return c.json({ error: "التصويت غير موجود" }, 404);
    list[idx].status = "active";
    await kv.set(bKey(buildingId, "polls"), list);
    await logActivity(buildingId, {
      type: "poll_reactivated",
      title: "إعادة تفعيل تصويت",
      description: `تم إعادة تفعيل: ${list[idx].title}`,
      icon: "Play",
      color: "#0D9488",
      metadata: { pollId },
    });
    return c.json({ message: "تم إعادة تفعيل التصويت", poll: list[idx] });
  } catch (err: any) {
    console.log("Error reactivating poll:", err.message);
    return c.json({ error: `Error reactivating poll: ${err.message}` }, 500);
  }
});

// DELETE a poll
app.delete("/make-server-86a3da15/polls/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const pollId = c.req.param("id");
    const existing = await kv.get(bKey(buildingId, "polls"));
    const list: PollData[] = Array.isArray(existing) ? existing : [];
    const poll = list.find((p) => p.id === pollId);
    if (!poll) return c.json({ error: "التصويت غير موجود" }, 404);
    const filtered = list.filter((p) => p.id !== pollId);
    await kv.set(bKey(buildingId, "polls"), filtered);
    await logActivity(buildingId, {
      type: "poll_deleted",
      title: "حذف تصويت",
      description: `تم حذف: ${poll.title}`,
      icon: "Trash2",
      color: "#dc2626",
      metadata: { pollId },
    });
    return c.json({ message: "تم حذف التصويت بنجاح" });
  } catch (err: any) {
    console.log("Error deleting poll:", err.message);
    return c.json({ error: `Error deleting poll: ${err.message}` }, 500);
  }
});

// ===================================================================
// Chat Messages — Building-scoped group chat
// ===================================================================

interface ChatMessage {
  id: string;
  sender: string;
  senderRole: string;
  senderPhone: string;
  text: string;
  timestamp: string;
}

// GET chat messages
app.get("/make-server-86a3da15/chat", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const messages = await kv.get(bKey(buildingId, "chat_messages"));
    return c.json(Array.isArray(messages) ? messages : []);
  } catch (err: any) {
    console.log("Error fetching chat messages:", err.message);
    return c.json({ error: `Error fetching chat messages: ${err.message}` }, 500);
  }
});

// POST send a chat message
app.post("/make-server-86a3da15/chat", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const body = await c.req.json();
    const { sender, senderRole, senderPhone, text } = body;
    if (!sender || !text) {
      return c.json({ error: "sender and text are required" }, 400);
    }

    const msg: ChatMessage = {
      id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      sender,
      senderRole: senderRole || "ساكن",
      senderPhone: senderPhone || "",
      text,
      timestamp: new Date().toISOString(),
    };

    const key = bKey(buildingId, "chat_messages");
    const existing = await kv.get(key);
    const messages: ChatMessage[] = Array.isArray(existing) ? existing : [];
    messages.push(msg);
    // Keep last 500 messages
    if (messages.length > 500) messages.splice(0, messages.length - 500);
    await kv.set(key, messages);

    return c.json({ message: "Message sent", msg });
  } catch (err: any) {
    console.log("Error sending chat message:", err.message);
    return c.json({ error: `Error sending chat message: ${err.message}` }, 500);
  }
});

// ===================================================================
// Direct Messages (DM) — Private chat between two users
// ===================================================================

function dmKey(buildingId: string, phone1: string, phone2: string): string {
  const sorted = [phone1.replace(/\s/g, ""), phone2.replace(/\s/g, "")].sort();
  return bKey(buildingId, `dm:${sorted[0]}:${sorted[1]}`);
}

// GET DM messages with a specific phone
app.get("/make-server-86a3da15/dm/:phone", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const targetPhone = decodeURIComponent(c.req.param("phone")).replace(/\s/g, "");
    const myPhone = c.req.query("myPhone")?.replace(/\s/g, "") || "";
    if (!myPhone || !targetPhone) return c.json([]);
    const key = dmKey(buildingId, myPhone, targetPhone);
    const messages = await kv.get(key);
    return c.json(Array.isArray(messages) ? messages : []);
  } catch (err: any) {
    console.log("Error fetching DM messages:", err.message);
    return c.json({ error: `Error fetching DM messages: ${err.message}` }, 500);
  }
});

// POST send a DM
app.post("/make-server-86a3da15/dm/:phone", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const targetPhone = decodeURIComponent(c.req.param("phone")).replace(/\s/g, "");
    const body = await c.req.json();
    const { sender, senderRole, senderPhone, text } = body;
    if (!sender || !text || !senderPhone) {
      return c.json({ error: "sender, senderPhone, and text are required" }, 400);
    }
    const normalizedSenderPhone = senderPhone.replace(/\s/g, "");
    const msg: ChatMessage = {
      id: `dm-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      sender,
      senderRole: senderRole || "ساكن",
      senderPhone: normalizedSenderPhone,
      text,
      timestamp: new Date().toISOString(),
    };
    const key = dmKey(buildingId, normalizedSenderPhone, targetPhone);
    const existing = await kv.get(key);
    const messages: ChatMessage[] = Array.isArray(existing) ? existing : [];
    messages.push(msg);
    if (messages.length > 200) messages.splice(0, messages.length - 200);
    await kv.set(key, messages);

    // Send notification to target
    try {
      await pushNotification(buildingId, targetPhone, {
        type: "dm",
        title: "رسالة خاصة",
        body: `${sender}: ${text.substring(0, 60)}${text.length > 60 ? "..." : ""}`,
        icon: "MessageCircle",
        color: "#0D9488",
      });
    } catch (_) {}

    return c.json({ message: "DM sent", msg });
  } catch (err: any) {
    console.log("Error sending DM:", err.message);
    return c.json({ error: `Error sending DM: ${err.message}` }, 500);
  }
});

// GET DM conversations list (all DMs for a user)
app.get("/make-server-86a3da15/dm-list", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const myPhone = c.req.query("myPhone")?.replace(/\s/g, "") || "";
    if (!myPhone) return c.json([]);
    
    const requests = await kv.get(bKey(buildingId, "join_requests")) || [];
    const approved = requests.filter((r: any) => r.status === "approved");
    const phoneToName: Record<string, { name: string; unitCode: string }> = {};
    for (const r of approved) {
      const p = r.phone?.replace(/\s/g, "");
      if (p) phoneToName[p] = { name: r.name, unitCode: r.unitCode };
    }
    const bInfo = await kv.get(bKey(buildingId, "info"));
    if (bInfo?.admin?.phone) {
      const ap = bInfo.admin.phone.replace(/\s/g, "");
      phoneToName[ap] = { name: bInfo.admin.name || "الإدارة", unitCode: "" };
    }

    const conversations: { phone: string; name: string; unitCode: string; lastMessage: string; lastTimestamp: string; unread: number }[] = [];
    for (const otherPhone of Object.keys(phoneToName)) {
      if (otherPhone === myPhone) continue;
      const key = dmKey(buildingId, myPhone, otherPhone);
      const msgs = await kv.get(key);
      if (Array.isArray(msgs) && msgs.length > 0) {
        const last = msgs[msgs.length - 1];
        conversations.push({
          phone: otherPhone,
          name: phoneToName[otherPhone]?.name || otherPhone,
          unitCode: phoneToName[otherPhone]?.unitCode || "",
          lastMessage: last.text?.substring(0, 50) || "",
          lastTimestamp: last.timestamp,
          unread: 0,
        });
      }
    }
    conversations.sort((a, b) => b.lastTimestamp.localeCompare(a.lastTimestamp));
    return c.json(conversations);
  } catch (err: any) {
    console.log("Error fetching DM list:", err.message);
    return c.json({ error: `Error fetching DM list: ${err.message}` }, 500);
  }
});

// ===================================================================
// Forgot Password — Admin resets user password
// ===================================================================

app.post("/make-server-86a3da15/auth/reset-password", async (c) => {
  try {
    const body = await c.req.json();
    const { phone, newPassword } = body;
    if (!phone || !newPassword) {
      return c.json({ error: "رقم الجوال وكلمة المرور الجديدة مطلوبان" }, 400);
    }
    if (newPassword.length < 6) {
      return c.json({ error: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" }, 400);
    }

    const normalizedPhone = phone.replace(/\s/g, "");
    const fakeEmail = `${normalizedPhone}@mollak.app`;

    // Find auth user by email
    const userId = await kv.get(`auth:email:${fakeEmail}`);
    if (!userId) {
      return c.json({ error: "لا يوجد حساب مرتبط بهذا الرقم" }, 404);
    }

    // Update password via Supabase Admin
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
      userId as string,
      { password: newPassword }
    );

    if (updateError) {
      console.log("Error resetting password:", updateError.message);
      return c.json({ error: `خطأ في إعادة تعيين كلمة المرور: ${updateError.message}` }, 500);
    }

    return c.json({ message: "تم إعادة تعيين كلمة المرور بنجاح" });
  } catch (err: any) {
    console.log("Error in /auth/reset-password:", err.message);
    return c.json({ error: `Error resetting password: ${err.message}` }, 500);
  }
});

// ===================================================================
// Notifications (الإشعارات) — Per-user, Building-scoped
// ===================================================================

interface MollakNotification {
  id: string;
  type: string;
  title: string;
  body: string;
  icon: string;
  color: string;
  read: boolean;
  timestamp: string;
  metadata?: Record<string, any>;
}

function notifKey(buildingId: string, phone: string) {
  return `building:${buildingId}:notifications:${phone}`;
}

async function pushNotification(buildingId: string, phone: string, notif: Omit<MollakNotification, "id" | "timestamp" | "read">) {
  try {
    const key = notifKey(buildingId, phone);
    const existing = await kv.get(key);
    const list: MollakNotification[] = Array.isArray(existing) ? existing : [];
    list.unshift({
      ...notif,
      id: `notif-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      read: false,
      timestamp: new Date().toISOString(),
    });
    if (list.length > 100) list.length = 100;
    await kv.set(key, list);
  } catch (err: any) {
    console.log("Error pushing notification:", err.message);
  }
}

async function pushNotificationToAll(buildingId: string, notif: Omit<MollakNotification, "id" | "timestamp" | "read">, excludePhone?: string) {
  try {
    // Get all approved residents from join_requests
    const joinRequests = await kv.get(bKey(buildingId, "join_requests")) || [];
    const approvedResidents = Array.isArray(joinRequests)
      ? joinRequests.filter((r: any) => r.status === "approved" && r.phone)
      : [];

    // Also notify admin (from building info)
    const buildingInfo = await kv.get(bKey(buildingId, "info"));
    const adminPhone = buildingInfo?.admin?.phone;

    const notifiedPhones = new Set<string>();

    for (const res of approvedResidents) {
      const phone = (res as any).phone;
      if (notifiedPhones.has(phone)) continue;
      if (excludePhone && phone === excludePhone) continue;
      notifiedPhones.add(phone);
      await pushNotification(buildingId, phone, notif);
    }

    // Notify admin if not already notified and not excluded
    if (adminPhone && !notifiedPhones.has(adminPhone) && (!excludePhone || adminPhone !== excludePhone)) {
      await pushNotification(buildingId, adminPhone, notif);
    }
  } catch (err: any) {
    console.log("Error pushing notification to all:", err.message);
  }
}

// GET notifications for current user
app.get("/make-server-86a3da15/notifications", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const phone = c.req.query("phone");
    if (!phone) return c.json({ error: "Missing phone parameter" }, 400);
    const key = notifKey(buildingId, phone);
    const existing = await kv.get(key);
    const list: MollakNotification[] = Array.isArray(existing) ? existing : [];
    return c.json(list);
  } catch (err: any) {
    console.log("Error fetching notifications:", err.message);
    return c.json({ error: `Error fetching notifications: ${err.message}` }, 500);
  }
});

// Mark all notifications as read (MUST be before :id/read to avoid route conflict)
app.put("/make-server-86a3da15/notifications/read-all", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const body = await c.req.json();
    const phone = body.phone;
    if (!phone) return c.json({ error: "Missing phone" }, 400);
    const key = notifKey(buildingId, phone);
    const existing = await kv.get(key);
    const list: MollakNotification[] = Array.isArray(existing) ? existing : [];
    list.forEach((n) => (n.read = true));
    await kv.set(key, list);
    return c.json({ message: "تم قراءة جميع الإشعارات" });
  } catch (err: any) {
    console.log("Error marking all notifications read:", err.message);
    return c.json({ error: `Error: ${err.message}` }, 500);
  }
});

// Mark single notification as read
app.put("/make-server-86a3da15/notifications/:id/read", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const notifId = c.req.param("id");
    const body = await c.req.json();
    const phone = body.phone;
    if (!phone) return c.json({ error: "Missing phone" }, 400);
    const key = notifKey(buildingId, phone);
    const existing = await kv.get(key);
    const list: MollakNotification[] = Array.isArray(existing) ? existing : [];
    const idx = list.findIndex((n) => n.id === notifId);
    if (idx !== -1) {
      list[idx].read = true;
      await kv.set(key, list);
    }
    return c.json({ message: "تم قراءة الإشعار" });
  } catch (err: any) {
    console.log("Error marking notification read:", err.message);
    return c.json({ error: `Error: ${err.message}` }, 500);
  }
});

// ===================================================================
// Service Requests (طلبات الخدمة)
// ===================================================================

interface ServiceRequest {
  id: string;
  requesterPhone: string;
  requesterName: string;
  unitCode: string;
  title: string;
  description: string;
  category: string;
  status: "pending" | "approved" | "rejected" | "closed";
  adminNote?: string;
  closingNote?: string;
  createdAt: string;
  updatedAt: string;
  respondedBy?: string;
  closedBy?: string;
}

// GET all service requests for building (dashboard) or for a specific resident
app.get("/make-server-86a3da15/service-requests", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json([]);
    const phone = c.req.query("phone")?.replace(/\s/g, "") || "";
    const key = bKey(buildingId, "service_requests");
    const all = await kv.get(key);
    const requests: ServiceRequest[] = Array.isArray(all) ? all : [];
    if (phone) {
      return c.json(requests.filter((r) => r.requesterPhone === phone));
    }
    return c.json(requests);
  } catch (err: any) {
    console.log("Error fetching service requests:", err.message);
    return c.json({ error: `Error fetching service requests: ${err.message}` }, 500);
  }
});

// POST create a new service request (resident)
app.post("/make-server-86a3da15/service-requests", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const body = await c.req.json();
    const { requesterPhone, requesterName, unitCode, title, description, category } = body;
    if (!requesterPhone || !requesterName || !title) {
      return c.json({ error: "requesterPhone, requesterName, and title are required" }, 400);
    }
    const now = new Date().toISOString();
    const req: ServiceRequest = {
      id: `sr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      requesterPhone: requesterPhone.replace(/\s/g, ""),
      requesterName,
      unitCode: unitCode || "",
      title,
      description: description || "",
      category: category || "أخرى",
      status: "pending",
      createdAt: now,
      updatedAt: now,
    };
    const key = bKey(buildingId, "service_requests");
    const existing = await kv.get(key);
    const requests: ServiceRequest[] = Array.isArray(existing) ? existing : [];
    requests.unshift(req);
    await kv.set(key, requests);

    // Notify all admins (building admin + board members)
    const bInfo = await kv.get(bKey(buildingId, "info"));
    if (bInfo?.admin?.phone) {
      await pushNotification(buildingId, bInfo.admin.phone.replace(/\s/g, ""), {
        type: "service_request",
        title: "طلب خدمة جديد",
        body: `${requesterName} — ${title}`,
        icon: "ClipboardList",
        color: "#F59E0B",
        metadata: { requestId: req.id },
      });
    }
    // Notify board members too
    const joinRequests = await kv.get(bKey(buildingId, "join_requests")) || [];
    const boardMembers = (Array.isArray(joinRequests) ? joinRequests : []).filter(
      (r: any) => r.status === "approved" && (r.role === "board_member" || r.role === "treasurer")
    );
    for (const member of boardMembers) {
      if (member.phone) {
        await pushNotification(buildingId, member.phone.replace(/\s/g, ""), {
          type: "service_request",
          title: "طلب خدمة جديد",
          body: `${requesterName} — ${title}`,
          icon: "ClipboardList",
          color: "#F59E0B",
          metadata: { requestId: req.id },
        });
      }
    }

    return c.json({ message: "تم إرسال الطلب بنجاح", request: req });
  } catch (err: any) {
    console.log("Error creating service request:", err.message);
    return c.json({ error: `Error creating service request: ${err.message}` }, 500);
  }
});

// PUT update service request status (dashboard — approve/reject/close)
app.put("/make-server-86a3da15/service-requests/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const requestId = c.req.param("id");
    const body = await c.req.json();
    const { status, adminNote, closingNote, respondedBy, closedBy } = body;
    if (!status) return c.json({ error: "status is required" }, 400);

    const key = bKey(buildingId, "service_requests");
    const existing = await kv.get(key);
    const requests: ServiceRequest[] = Array.isArray(existing) ? existing : [];
    const idx = requests.findIndex((r) => r.id === requestId);
    if (idx === -1) return c.json({ error: "Request not found" }, 404);

    const req = requests[idx];
    req.status = status;
    req.updatedAt = new Date().toISOString();
    if (adminNote !== undefined) req.adminNote = adminNote;
    if (closingNote !== undefined) req.closingNote = closingNote;
    if (respondedBy) req.respondedBy = respondedBy;
    if (closedBy) req.closedBy = closedBy;

    requests[idx] = req;
    await kv.set(key, requests);

    // Notify the requester
    let notifTitle = "";
    let notifBody = "";
    let notifColor = "#0D9488";
    let notifIcon = "ClipboardList";
    if (status === "approved") {
      notifTitle = "تم قبول طلبك";
      notifBody = `تمت الموافقة على طلب "${req.title}"${adminNote ? ` — ${adminNote}` : ""}`;
      notifColor = "#22c55e";
      notifIcon = "CheckCircle";
    } else if (status === "rejected") {
      notifTitle = "تم رفض طلبك";
      notifBody = `تم رفض طلب "${req.title}"${adminNote ? ` — ${adminNote}` : ""}`;
      notifColor = "#ef4444";
      notifIcon = "XCircle";
    } else if (status === "closed") {
      notifTitle = "تم إغلاق طلبك";
      notifBody = `تم إغلاق طلب "${req.title}"${closingNote ? ` — ${closingNote}` : ""}`;
      notifColor = "#6b7280";
      notifIcon = "CheckCircle2";
    }

    if (notifTitle && req.requesterPhone) {
      await pushNotification(buildingId, req.requesterPhone, {
        type: "service_request_update",
        title: notifTitle,
        body: notifBody,
        icon: notifIcon,
        color: notifColor,
        metadata: { requestId: req.id, status },
      });
    }

    return c.json({ message: "تم تحديث الطلب", request: req });
  } catch (err: any) {
    console.log("Error updating service request:", err.message);
    return c.json({ error: `Error updating service request: ${err.message}` }, 500);
  }
});

// DELETE a service request (only pending — by requester)
app.delete("/make-server-86a3da15/service-requests/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const requestId = c.req.param("id");
    const phone = c.req.query("phone")?.replace(/\s/g, "") || "";

    const key = bKey(buildingId, "service_requests");
    const existing = await kv.get(key);
    const requests: ServiceRequest[] = Array.isArray(existing) ? existing : [];
    const idx = requests.findIndex((r) => r.id === requestId);
    if (idx === -1) return c.json({ error: "Request not found" }, 404);

    const req = requests[idx];
    if (req.status !== "pending") {
      return c.json({ error: "لا يمكن حذف طلب تمت معالجته" }, 400);
    }
    if (phone && req.requesterPhone !== phone) {
      return c.json({ error: "غير مصرح" }, 403);
    }

    requests.splice(idx, 1);
    await kv.set(key, requests);
    return c.json({ message: "تم حذف الطلب" });
  } catch (err: any) {
    console.log("Error deleting service request:", err.message);
    return c.json({ error: `Error deleting service request: ${err.message}` }, 500);
  }
});

// ===================================================================
// Subscription Management
// ===================================================================

const PLANS = {
  monthly: { label: "شهري", months: 1, price: 299, discount: 0 },
  semi_annual: { label: "6 أشهر", months: 6, price: Math.round(299 * 6 * 0.85), discount: 15 },
  annual: { label: "سنوي", months: 12, price: Math.round(299 * 12 * 0.80), discount: 20 },
} as const;

// GET subscription status
app.get("/make-server-86a3da15/subscription", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    let sub = await kv.get(bKey(buildingId, "subscription"));

    // If no subscription exists (old building), create trial from building creation date
    if (!sub) {
      const buildingInfo = await cachedGet(bKey(buildingId, "info"), 60_000);
      const createdAt = buildingInfo?.createdAt || new Date().toISOString();
      const trialEnd = new Date(new Date(createdAt).getTime() + 90 * 24 * 60 * 60 * 1000).toISOString();
      sub = {
        plan: "trial",
        status: new Date() < new Date(trialEnd) ? "active" : "expired",
        startDate: createdAt,
        endDate: trialEnd,
        trialStartDate: createdAt,
        trialEndDate: trialEnd,
        amount: 0,
        history: [],
      };
      await kv.set(bKey(buildingId, "subscription"), sub);
    }

    // Auto-check expiration
    if (sub.status === "active" && new Date() > new Date(sub.endDate)) {
      sub.status = "expired";
      await kv.set(bKey(buildingId, "subscription"), sub);
    }

    // Calculate remaining days
    const now = new Date();
    const end = new Date(sub.endDate);
    const remainingDays = Math.max(0, Math.ceil((end.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)));

    return c.json({
      ...sub,
      remainingDays,
      plans: PLANS,
    });
  } catch (err: any) {
    console.log("Error fetching subscription:", err.message);
    return c.json({ error: `Error fetching subscription: ${err.message}` }, 500);
  }
});

// POST subscribe / renew
app.post("/make-server-86a3da15/subscription", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);

    const { plan } = await c.req.json();
    const planKey = plan as keyof typeof PLANS;
    if (!plan || !PLANS[planKey]) {
      return c.json({ error: `Invalid plan. Valid: ${Object.keys(PLANS).join(", ")}` }, 400);
    }

    const planInfo = PLANS[planKey];
    const existing = await kv.get(bKey(buildingId, "subscription")) || {};
    const now = new Date().toISOString();

    // Calculate new end date: if currently active, extend from current endDate; otherwise from now
    let startFrom = new Date();
    if (existing.status === "active" && new Date(existing.endDate) > new Date()) {
      startFrom = new Date(existing.endDate);
    }
    const endDate = new Date(startFrom.getTime() + planInfo.months * 30 * 24 * 60 * 60 * 1000).toISOString();

    const newHistory = [...(existing.history || [])];
    if (existing.plan && existing.plan !== "trial") {
      newHistory.push({
        plan: existing.plan,
        startDate: existing.startDate,
        endDate: existing.endDate,
        amount: existing.amount,
      });
    }

    const subscription = {
      plan,
      status: "active",
      startDate: now,
      endDate,
      trialStartDate: existing.trialStartDate || existing.startDate || now,
      trialEndDate: existing.trialEndDate || existing.endDate || now,
      amount: planInfo.price,
      history: newHistory,
    };

    await kv.set(bKey(buildingId, "subscription"), subscription);

    await logActivity(buildingId, {
      type: "subscription_activated",
      title: "تفعيل اشتراك",
      description: `تم تفعيل باقة "${planInfo.label}" بمبلغ ${planInfo.price.toLocaleString("en-US")} ج.م`,
      icon: "CreditCard",
      color: "#0D9488",
      metadata: { plan, amount: planInfo.price },
    });

    const remainingDays = Math.max(0, Math.ceil((new Date(endDate).getTime() - Date.now()) / (24 * 60 * 60 * 1000)));

    return c.json({
      message: `تم تفعيل باقة "${planInfo.label}" بنجاح`,
      subscription: { ...subscription, remainingDays },
    });
  } catch (err: any) {
    console.log("Error activating subscription:", err.message);
    return c.json({ error: `Error activating subscription: ${err.message}` }, 500);
  }
});

// ===================================================================
// Reports (التقارير)
// ===================================================================

async function generateReportData(buildingId: string, year: number, month: number) {
  const periodStart = new Date(year, month - 1, 1);
  const periodEnd = new Date(year, month, 0, 23, 59, 59);
  function isInPeriod(dateStr: string): boolean {
    if (!dateStr) return false;
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return false;
    return d >= periodStart && d <= periodEnd;
  }
  function isRecurringInPeriod(item: any): boolean {
    let startDate: Date | null = null;
    if (item.createdAt) { const d = new Date(item.createdAt); if (!isNaN(d.getTime())) startDate = d; }
    if (!startDate && item.date) { const d = new Date(item.date); if (!isNaN(d.getTime())) startDate = d; }
    if (!startDate) return false;
    if (startDate > periodEnd) return false;
    const stoppedStr = item.stoppedAt || item.endDate;
    if (stoppedStr) { const sd = new Date(stoppedStr); if (!isNaN(sd.getTime()) && sd < periodStart) return false; }
    return true;
  }

  const [batches, expensesData, revenuesData, advancesData, donationsData, buildingInfo, units] =
    await Promise.all([
      kv.get(bKey(buildingId, "invoice_batches")).then((v: any) => v || []),
      kv.get(bKey(buildingId, "expenses")).then((v: any) => v || []),
      kv.get(bKey(buildingId, "revenues")).then((v: any) => v || []),
      kv.get(bKey(buildingId, "advances")).then((v: any) => v || []),
      kv.get(bKey(buildingId, "donations")).then((v: any) => v || []),
      kv.get(bKey(buildingId, "info")),
      kv.get(bKey(buildingId, "units")).then((v: any) => v || []),
    ]);

  let totalInvoiceRevenue = 0, totalPending = 0, totalOverdue = 0;
  let paidCount = 0, pendingCount = 0, overdueCount = 0, awaitingCount = 0, totalInvoiceCount = 0;
  const unitMap: Record<string, any> = {};
  for (const u of units) {
    unitMap[u.code] = { unitCode: u.code, floor: u.floor || "", residentName: u.residentName || "—", invoices: [], totalDue: 0, totalPaid: 0, totalPending: 0, totalOverdue: 0, paidCount: 0, pendingCount: 0, overdueCount: 0, donations: 0 };
  }

  for (const batch of batches) {
    const batchInPeriod = batch.type === "دائم" ? isRecurringInPeriod(batch) : (isInPeriod(batch.date) || isInPeriod(batch.dueDate));
    if (!batchInPeriod) continue;
    for (const inv of (batch.invoices || [])) {
      if (!inv.occupied && inv.occupied !== undefined) continue;
      const amount = Number(inv.amount) || 0;
      totalInvoiceCount++;
      const uc = inv.unit;
      if (!unitMap[uc]) { unitMap[uc] = { unitCode: uc, floor: inv.floor || "", residentName: inv.resident || "—", invoices: [], totalDue: 0, totalPaid: 0, totalPending: 0, totalOverdue: 0, paidCount: 0, pendingCount: 0, overdueCount: 0, donations: 0 }; }
      unitMap[uc].invoices.push({ description: batch.description, amount, status: inv.status, dueDate: batch.dueDate, paidDate: inv.paidDate, method: inv.method });
      unitMap[uc].totalDue += amount;
      if (inv.resident && inv.resident !== "—") unitMap[uc].residentName = inv.resident;
      if (inv.status === "paid") { paidCount++; totalInvoiceRevenue += amount; unitMap[uc].totalPaid += amount; unitMap[uc].paidCount++; }
      else if (inv.status === "overdue") { overdueCount++; totalOverdue += amount; unitMap[uc].totalOverdue += amount; unitMap[uc].overdueCount++; }
      else if (inv.status === "awaiting_collection") { awaitingCount++; totalPending += amount; unitMap[uc].totalPending += amount; unitMap[uc].pendingCount++; }
      else { pendingCount++; totalPending += amount; unitMap[uc].totalPending += amount; unitMap[uc].pendingCount++; }
    }
  }

  const expensesByCategory: Record<string, number> = {};
  let totalExpenses = 0;
  const expensesList: any[] = [];
  for (const exp of expensesData) {
    const amount = Number(exp.amount) || 0;
    const inP = exp.type === "دائم" ? isRecurringInPeriod(exp) : (isInPeriod(exp.createdAt) || isInPeriod(exp.date));
    if (!inP) continue;
    totalExpenses += amount;
    const cat = exp.category || "أخرى";
    expensesByCategory[cat] = (expensesByCategory[cat] || 0) + amount;
    expensesList.push({ title: exp.title, amount, category: cat, date: exp.date, type: exp.type });
  }

  const revenuesByCategory: Record<string, number> = {};
  let totalOtherRevenue = 0;
  const revenuesList: any[] = [];
  for (const rev of revenuesData) {
    const amount = Number(rev.amount) || 0;
    const inP = rev.type === "دائم" ? isRecurringInPeriod(rev) : (isInPeriod(rev.createdAt) || isInPeriod(rev.date));
    if (!inP) continue;
    totalOtherRevenue += amount;
    const cat = rev.category || "أخرى";
    revenuesByCategory[cat] = (revenuesByCategory[cat] || 0) + amount;
    revenuesList.push({ title: rev.title, amount, category: cat, date: rev.date, type: rev.type });
  }

  let activeAdvances = 0, activeAdvancesCount = 0, returnedAdvances = 0;
  const advancesList: any[] = [];
  for (const adv of advancesData) {
    const amt = Number(adv.amount) || 0;
    if (adv.status === "active" || adv.status === "overdue") { activeAdvances += amt; activeAdvancesCount++; advancesList.push({ person: adv.person, amount: amt, reason: adv.reason, status: adv.status, dueDate: adv.dueDate }); }
    else if (adv.status === "returned" && (isInPeriod(adv.createdAt) || isInPeriod(adv.date))) { returnedAdvances += amt; }
  }

  let totalDonations = 0;
  for (const campaign of donationsData) {
    for (const donor of (campaign.donors || [])) {
      if (isInPeriod(donor.date)) {
        totalDonations += Number(donor.amount) || 0;
        const uc = Object.keys(unitMap).find(k => unitMap[k].residentName === donor.name);
        if (uc) unitMap[uc].donations += Number(donor.amount) || 0;
      }
    }
  }

  const initialBalance = Number(buildingInfo?.initialBalance) || 0;
  const previousDebts = Number(buildingInfo?.previousDebts) || 0;
  const previousRevenues = Number(buildingInfo?.previousRevenues) || 0;
  const totalRevenue = totalInvoiceRevenue + totalOtherRevenue;
  const netBalance = initialBalance + previousRevenues + totalRevenue - totalExpenses - activeAdvances;
  const totalUnits = units.length;
  const occupiedUnits = units.filter((u: any) => u.occupied).length;
  const collectionRate = totalInvoiceCount > 0 ? Math.round((paidCount / totalInvoiceCount) * 100) : 0;

  const prevMonth = month === 1 ? 12 : month - 1;
  const prevYear = month === 1 ? year - 1 : year;
  const prevReport = await kv.get(bKey(buildingId, `report:${prevYear}-${String(prevMonth).padStart(2, "0")}`));
  const comparison = prevReport ? { revenueDiff: totalRevenue - (prevReport.building?.totalRevenue || 0), expensesDiff: totalExpenses - (prevReport.building?.totalExpenses || 0), collectionRateDiff: collectionRate - (prevReport.building?.collectionRate || 0), hasPrev: true } : { revenueDiff: 0, expensesDiff: 0, collectionRateDiff: 0, hasPrev: false };

  const unitReports = Object.values(unitMap).filter((u: any) => u.totalDue > 0 || u.donations > 0).sort((a: any, b: any) => a.unitCode.localeCompare(b.unitCode));
  const delinquentUnits = unitReports.filter((u: any) => u.totalOverdue > 0 || u.totalPending > 0).map((u: any) => ({ unitCode: u.unitCode, residentName: u.residentName, amount: u.totalOverdue + u.totalPending, overdueCount: u.overdueCount })).sort((a: any, b: any) => b.amount - a.amount);

  return {
    building: { name: buildingInfo?.name || "—", address: buildingInfo?.address || "", city: buildingInfo?.city || "", totalUnits, occupiedUnits, totalRevenue, invoiceRevenue: totalInvoiceRevenue, otherRevenue: totalOtherRevenue, totalExpenses, netBalance, initialBalance, previousDebts, previousRevenues, totalDonations, collectionRate, totalInvoices: totalInvoiceCount, paidCount, pendingCount: pendingCount + awaitingCount, overdueCount, totalPending: totalPending + totalOverdue, activeAdvances, activeAdvancesCount, returnedAdvances, expensesByCategory, revenuesByCategory, expensesList, revenuesList, advancesList, delinquentUnits, comparison },
    unitReports,
  };
}

const MONTH_NAMES_AR = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];

app.post("/make-server-86a3da15/reports/generate", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const { year, month } = await c.req.json();
    if (!year || !month || month < 1 || month > 12) return c.json({ error: "Invalid year or month" }, 400);
    const rk = bKey(buildingId, `report:${year}-${String(month).padStart(2, "0")}`);
    const existing = await kv.get(rk);
    if (existing) return c.json({ report: existing, cached: true });
    const data = await generateReportData(buildingId, year, month);
    const report = { id: `${year}-${String(month).padStart(2, "0")}`, year, month, monthName: MONTH_NAMES_AR[month - 1], generatedAt: new Date().toISOString(), sentToResidents: false, ...data };
    await kv.set(rk, report);
    const ik = bKey(buildingId, "reports_index");
    const idx = await kv.get(ik) || [];
    if (!idx.find((r: any) => r.id === report.id)) { idx.unshift({ id: report.id, year, month, monthName: MONTH_NAMES_AR[month - 1], generatedAt: report.generatedAt, sentToResidents: false }); await kv.set(ik, idx); }
    await logActivity(buildingId, { type: "report_generated", title: "إنشاء تقرير", description: `تم إنشاء تقرير ${MONTH_NAMES_AR[month - 1]} ${year}`, icon: "FileText", color: "#0D9488", metadata: { year, month } });
    return c.json({ report, cached: false });
  } catch (err: any) { console.log("Error generating report:", err.message); return c.json({ error: `Error generating report: ${err.message}` }, 500); }
});

app.put("/make-server-86a3da15/reports/regenerate", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const { year, month } = await c.req.json();
    if (!year || !month) return c.json({ error: "Invalid year or month" }, 400);
    const data = await generateReportData(buildingId, year, month);
    const report = { id: `${year}-${String(month).padStart(2, "0")}`, year, month, monthName: MONTH_NAMES_AR[month - 1], generatedAt: new Date().toISOString(), sentToResidents: false, ...data };
    await kv.set(bKey(buildingId, `report:${year}-${String(month).padStart(2, "0")}`), report);
    return c.json({ report });
  } catch (err: any) { console.log("Error regenerating report:", err.message); return c.json({ error: `Error regenerating report: ${err.message}` }, 500); }
});

app.get("/make-server-86a3da15/reports/:id", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const report = await kv.get(bKey(buildingId, `report:${c.req.param("id")}`));
    if (!report) return c.json({ error: "Report not found" }, 404);
    return c.json({ report });
  } catch (err: any) { console.log("Error fetching report:", err.message); return c.json({ error: `Error fetching report: ${err.message}` }, 500); }
});

app.get("/make-server-86a3da15/reports", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    return c.json({ reports: await kv.get(bKey(buildingId, "reports_index")) || [] });
  } catch (err: any) { console.log("Error listing reports:", err.message); return c.json({ error: `Error listing reports: ${err.message}` }, 500); }
});

app.put("/make-server-86a3da15/reports/:id/send", async (c) => {
  try {
    const buildingId = await getActiveBuildingId();
    if (!buildingId) return c.json({ error: "No active building" }, 400);
    const id = c.req.param("id");
    const rk = bKey(buildingId, `report:${id}`);
    const report = await kv.get(rk);
    if (!report) return c.json({ error: "Report not found" }, 404);
    report.sentToResidents = true; report.sentAt = new Date().toISOString();
    await kv.set(rk, report);
    const ik = bKey(buildingId, "reports_index");
    const idx = await kv.get(ik) || [];
    const fi = idx.findIndex((r: any) => r.id === id);
    if (fi !== -1) { idx[fi].sentToResidents = true; idx[fi].sentAt = report.sentAt; await kv.set(ik, idx); }
    const joinReqs = await kv.get(bKey(buildingId, "join_requests")) || [];
    const approved = joinReqs.filter((r: any) => r.status === "approved");
    for (const res of approved) {
      const nk = bKey(buildingId, `notifications:${res.phone}`);
      const notifs = await kv.get(nk) || [];
      notifs.unshift({ id: crypto.randomUUID(), type: "report", title: "تقرير شهري جديد", body: `تقرير ${report.monthName} ${report.year} جاهز للاطلاع`, icon: "FileText", color: "#0D9488", read: false, timestamp: new Date().toISOString(), metadata: { reportId: id } });
      await kv.set(nk, notifs.slice(0, 50));
    }
    await logActivity(buildingId, { type: "report_sent", title: "إرسال تقرير", description: `تم إرسال تقرير ${report.monthName} ${report.year} للسكان`, icon: "FileText", color: "#F59E0B", metadata: { reportId: id, residentsCount: approved.length } });
    return c.json({ message: `تم إرسال التقرير لـ ${approved.length} ساكن`, report });
  } catch (err: any) { console.log("Error sending report:", err.message); return c.json({ error: `Error sending report: ${err.message}` }, 500); }
});

Deno.serve(app.fetch);