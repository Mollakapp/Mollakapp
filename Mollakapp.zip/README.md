
  # Mollak

  This is a code bundle for Mollak. The original project is available at https://www.figma.com/design/R9cxuQNY9RSpyUzFNF5tKY/Mollak.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  